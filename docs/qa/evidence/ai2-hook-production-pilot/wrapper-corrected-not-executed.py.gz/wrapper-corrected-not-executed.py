"""Private single-case full silent1080p30 pilot; no production-code changes."""
from pathlib import Path
from types import SimpleNamespace
import fcntl,hashlib,json,os,resource,shutil,subprocess,sys,time
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[key]='1'
from PIL import Image
import manim
ROOT=Path('/workspace/explainer-videos');sys.path.insert(0,str(ROOT));from tools import qa_series
part,lang,scene=sys.argv[1:]
if (part,lang,scene)!=('ai2','en','Hook'):raise SystemExit('This bounded pilot permits only ai2/en/Hook.')
qa_series.OUT=ROOT/'renders/qa/production-motion-1080';folder=qa_series.OUT/part/lang/(scene+'_motion');folder.mkdir(parents=True,exist_ok=True)
if (folder/'result.json').exists():raise SystemExit('Existing pilot outcome must be reconciled before another run.')
source_endpoint=ROOT/'renders/qa/series'/part/lang/scene
with (source_endpoint/'.lock').open('r') as lock:
    fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
    (folder/'Tex').mkdir(exist_ok=True)
    for source in (source_endpoint/'Tex').glob('*.svg'):shutil.copy2(source,folder/'Tex'/source.name)
original_config=manim.tempconfig
requested={}
def production_config(options):
    config=dict(options,quality='high_quality',pixel_width=1920,pixel_height=1080,frame_rate=30,max_inflight_encoders=1,encoder_queue_size=2,video_encoder_options=dict(manim.config.video_encoder_options,threads='1'))
    requested.update(config)
    return original_config(config)
manim.tempconfig=production_config
start=time.monotonic();status=qa_series.worker(SimpleNamespace(video=part,lang=lang,worker=scene,motion=True,cached_only=True));record_path=folder/'result.json';record=json.loads(record_path.read_text());sizes={Image.open(folder/f['file']).size for f in record['frames']};assert sizes=={(1920,1080)},sizes
movie=ROOT/record['movie'];probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]));(folder/'ffprobe.json').write_text(json.dumps(probe,indent=2)+'\n');video=[s for s in probe['streams'] if s['codec_type']=='video'];assert len(video)==1;assert (video[0]['width'],video[0]['height'])==(1920,1080);assert video[0]['r_frame_rate']=='30/1'
record['manual_capture_configuration']={'pixel_width':1920,'pixel_height':1080,'frame_rate':30,'animations':'full motion render','audio':'silent timing placeholders; stream presence verified after encoding','encoded_audio_streams':[{k:s.get(k) for k in ('index','codec_name','sample_rate','channels','duration')} for s in probe['streams'] if s['codec_type']=='audio'],'source_inputs':'cached-only','nice':os.getpriority(os.PRIO_PROCESS,0),'numeric_threads':{key:os.environ.get(key) for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS')},'encoder_threads_requested':1,'max_inflight_encoders':1,'encoder_queue_size':2,'requested_tempconfig':requested,'wrapper_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'movie_sha256':hashlib.sha256(movie.read_bytes()).hexdigest(),'wall_seconds_including_worker_checks':time.monotonic()-start,'peak_self_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'interpretation':'Full silent production-resolution motion pilot; selected-image review and continuous perceptual playback/listening have independent statuses.'}
record_path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':record['status'],'frames':len(record['frames']),'warnings':record['warnings'],'movie':record['movie'],'video':{k:video[0].get(k) for k in ('width','height','r_frame_rate','avg_frame_rate','duration','nb_frames')},'wall_seconds':record['manual_capture_configuration']['wall_seconds_including_worker_checks']}));sys.exit(status)
