# Kernels EN/ZH selected-motion review — partial, storage blocked

As of 2026-11-01T08:32:30.002113+00:00. No source, data, cache, movie, sidecar, producer, render or commit changes by this review.

All86existing endpoint/bookmark times are mapped to45exact-PNG representatives and actually viewed at native854×480: EN44→23, ZH42→22. No held clipping/overlap observed. All four original raw results remain passed/0warnings. The historical direct scene1f3f3b02 matched current at preparation; historical caption table20635e73 differs from current0884, but all88actualcaptured strings and12frozen narration records reconcile identically. Motion text logs are empty; endpoint logs provide actual strings. Unseen branches and historical imported modules are not certified.

English primary:3291decoded,611selected→498unique PNGs, all63chronological sheets actually viewed at1280wide with640×360tiles;17additional native854×480followups. Largest selected gap1.0000000000000009s (float precision);2680unselected frames and every gap retained in en/primary-review-checkpoint.json and original audit. Critical lifting/plane/projection, Gaussian identity/1Dgrid/errorplot, PSD curves/legends, representer equations/readouts clear at held samples.

Six transition-readability polish opportunities are confirmed on native frames. Retained old rows duplicate while the appended row appears; subsequent held states are clean. Minimal proposal: only step(1/2/3,transform=False) in trick and representer. Root approval required before source edits; none applied.

| Call | Actual ghost sample | Next clean selected sample | Source line |
|---|---:|---:|---:|
| trick step(1) | 98.466341s | 99.199674s | 182 |
| trick step(2) | 101.066341s | 102.066341s | 184 |
| trick step(3) | 116.866341s | 117.599674s | 188 |
| representer step(1) | 181.532682s | 182.532682s | 275 |
| representer step(2) | 190.466016s | 191.466016s | 277 |
| representer step(3) | 195.799349s | 196.532682s | 279 |

Native PNG paths/SHA/source-frame IDs are in en/transition-findings.json and actual receipts in en/audit/unique/views.json. Exact encoded duration is pending; these are transient polish findings, not held factual failures.

Blocked: new ZH audit and every-encoded brief proof windows. Current free 713543680bytes <805306368required. ZHguard stopped before audit creation. No further extraction attempted belowguard. EN154targeted proof-window frames include61already-extracted/viewed frames and93missing; prepare index saved without extraction. Original116factoryartifacts were rechecked byte/size/mtime exact and both movies remain independent nlink1.

No continuous playback, listening/synchronization, unseen-frame, native1080/4K or full current-source approval. Runtime indexes, ledgers, raw record/source/data pins, extraction commands and full gaps are linked in review.json.
