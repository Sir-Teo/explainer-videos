from pathlib import Path
import ast,copy,hashlib,json,sys
import numpy as np
from manim import Axes,Dot,UpdateFromAlphaFunc,VGroup,VMobject,linear,smooth,DOWN,WHITE
from explainer.style import C
B=Path('/workspace/explainer-videos');O=Path(__file__).parent;source=B/'videos/ai/ai4/s15_quadratic.py';old=(O/'source-before.py').read_text();new=source.read_text();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
node=next(n for n in ast.parse(new).body if isinstance(n,ast.FunctionDef) and n.name=='trajectory_reveal');env=dict(np=np,math=__import__('math'),UpdateFromAlphaFunc=UpdateFromAlphaFunc,VGroup=VGroup);exec(compile(ast.Module([node],type_ignores=[]),str(source),'exec'),env);reveal=env['trajectory_reveal']
cache=B/'.cache/ai4/valley.npz';metadata=cache.with_suffix('.json');before={str(p.relative_to(B)):sha(p) for p in [cache,metadata]}
with np.load(cache,allow_pickle=False) as z:vertices={k:np.asarray(z[k]).copy() for k in ['gd','momentum','newton']}
axis=Axes(x_range=[-5,5,1],y_range=[-1.2,1.2,.5],x_length=11.,y_length=4.4,tips=False,axis_config={'include_ticks':False}).move_to(DOWN*.6)
rows=[]
for name,rate,duration,color in [('gd',linear,3.5,WHITE),('momentum',linear,3.,C.TRUE_P),('newton',smooth,1.,C.BITS)]:
 points=np.array([axis.c2p(*q) for q in vertices[name]]);path=VMobject(color=color,stroke_width=4).set_points_as_corners(points);original=path.copy();dot=Dot(points[0],radius=.08,color=color);animation=reveal(path,dot);animation.rate_func=rate;animation.run_time=duration;animation.begin();lengths=np.linalg.norm(np.diff(points,axis=0),axis=1);total=float(lengths.sum());alphas=set(np.linspace(0,1,1001))
 if rate is linear:
  for boundary in np.cumsum(lengths)/total:
   for alpha in [boundary,np.nextafter(boundary,0.),np.nextafter(boundary,1.)]:alphas.add(float(np.clip(alpha,0,1)))
 maxima=dict(dot_prefix_end=0.,arc_length=0.,retained_curve_controls=0.);checks=0
 for alpha in sorted(alphas):
  animation.interpolate(alpha);curves=path.get_cubic_bezier_tuples();observed=sum(np.linalg.norm(c[-1]-c[0]) for c in curves);maxima['dot_prefix_end']=max(maxima['dot_prefix_end'],float(np.linalg.norm(dot.get_center()-path.get_end())));maxima['arc_length']=max(maxima['arc_length'],abs(observed-total*rate(alpha)))
  if len(curves)>1:
   error=float(np.max(np.abs(np.asarray(curves[:-1])-np.asarray(original.get_cubic_bezier_tuples()[:len(curves)-1]))));maxima['retained_curve_controls']=max(maxima['retained_curve_controls'],error)
  assert np.isfinite(path.points).all();assert maxima['dot_prefix_end']<2e-12 and maxima['arc_length']<2e-10 and maxima['retained_curve_controls']<2e-12
  checks+=1
 animation.interpolate(0.);np.testing.assert_allclose(path.get_end(),points[0],atol=2e-14);animation.interpolate(1.);np.testing.assert_array_equal(path.points,original.points);np.testing.assert_allclose(dot.get_center(),points[-1],atol=2e-14);assert path.get_stroke_color()==original.get_stroke_color() and path.get_stroke_width()==original.get_stroke_width()
 rows.append({'name':name,'measured_vertices':len(points),'zero_length_segments':int((lengths==0).sum()),'visible_arc_length':total,'alphas_tested':checks,'rate_function':rate.__name__,'original_run_time_retained':duration,'max_errors':maxima,'final_control_points_bit_identical':True,'start_end_correct':True,'stroke_color_width_unchanged':True})
# Normalize only the authorized changes and prove every other AST node stays identical.
a=ast.parse(old);b=ast.parse(new);oldplays={}
for n in ast.walk(a):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='play' and n.args and isinstance(n.args[0],ast.Call) and isinstance(n.args[0].func,ast.Name) and n.args[0].func.id=='Create':
  expr=ast.unparse(n.args[0]);
  if 'paths[' in expr:oldplays[expr]=n
class Restore(ast.NodeTransformer):
 def visit_FunctionDef(self,n):
  if n.name=='trajectory_reveal':return None
  return self.generic_visit(n)
 def visit_Call(self,n):
  n=self.generic_visit(n)
  if isinstance(n.func,ast.Name) and n.func.id=='step':n.keywords=[k for k in n.keywords if not(k.arg=='transform' and isinstance(k.value,ast.Constant) and k.value.value is False)]
  if isinstance(n.func,ast.Attribute) and n.func.attr=='play' and n.args and isinstance(n.args[0],ast.Call) and isinstance(n.args[0].func,ast.Name) and n.args[0].func.id=='trajectory_reveal':
   key='Create('+ast.unparse(n.args[0].args[0])+')';original=oldplays[key];assert ast.dump(ast.Module([],type_ignores=[]))
   assert [ast.dump(k,include_attributes=False) for k in n.keywords]==[ast.dump(k,include_attributes=False) for k in original.keywords];n.args=copy.deepcopy(original.args)
  return n
restored=Restore().visit(b);assert ast.dump(restored,include_attributes=False)==ast.dump(a,include_attributes=False),'Unapproved source AST change'
for p,h in before.items():assert sha(B/p)==h
assert 'videos.ai.ai4.compute' not in sys.modules
report={'scope':'Actual installed Manim Animation.begin/interpolate on the exact completed cached GD/momentum/Newton vertices and source-matched axes. No scene import/render, producer/model/training/download, source/global/cache mutation. Tests inspect geometry/interpolation, not rendered output.','source_sha256':sha(source),'before_source_sha256':sha(O/'source-before.py'),'data_before_after_sha256':before,'all_other_source_ASTs_unchanged':True,'all_voiceover_data_geometry_bookmark_ASTs_unchanged':True,'original_play_durations_rate_functions_unchanged':True,'choice':'Progress is on-screen polyline arc length, mapped to the original cubic-segment index and within-segment parameter. All complete original controls/corners retained; the current last segment is revealed partially. The dot is moved to that exact visible prefix end. No trajectory resampling or corner-cutting. Path and dot share the animated VGroup so Cairo cannot cache the marker as static.','rows':rows,'rendered_EN_ZH_regression':'pending root combined contour/source render wave'}
(O/'actual-trajectory-check.json').write_text(json.dumps(report,indent=2)+'\n');(O/'source-after.py').write_text(new);print(json.dumps(report,indent=2))
