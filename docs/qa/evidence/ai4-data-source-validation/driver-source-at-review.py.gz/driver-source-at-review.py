"""Manual single-owner23-item run; no renders, CI/CD or background retry."""
from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,sys,time,shutil
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R));O=Path('/workspace/runtime/ai4-production-compute');O.mkdir(exist_ok=True);F=Path('/workspace/runtime/ai4-producer-contract-implementation/freeze.json');freeze=json.loads(F.read_text());H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sources=[r for r in freeze['source_files'] if not r['path'].startswith('tests/')]
def check():
 for r in sources:
  if H(R/r['path'])!=r['sha256']:raise RuntimeError('Frozen numerical source changed: '+r['path'])
check();tree=ast.parse((R/'videos/ai/ai4/compute.py').read_text());items=next([ast.literal_eval(k) for k in n.value.keys] for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ITEMS' for t in n.targets));assert len(items)==23
if (O/'progress.json').exists():raise SystemExit('Existing run must be reconciled; no duplicate automatic computation.')
(O/'source-freeze.json').write_bytes(F.read_bytes());env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1');rows=[]
from videos.ai.ai4 import compute
for name in items:
 check()
 if shutil.disk_usage(R).free<512*1024*1024:raise RuntimeError('Stopped before nextitem: less than512MiBfree; no data/evidence deleted.')
 cmd=[sys.executable,'-m','videos.ai.ai4.compute',name];log=O/(name+'.log');start=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with log.open('w') as stream:
  p=subprocess.Popen(cmd,cwd=R,env=env,stdout=stream,stderr=subprocess.STDOUT)
  state={'scope':'Manual actual numerical computation only; rendering not attempted.','source_freeze_sha256':H(F),'source_files':sources,'items':rows,'active':{'item':name,'pid':p.pid,'started_utc':utc,'command':cmd,'timeout_seconds':1200,'log':str(log)}};(O/'progress.json').write_text(json.dumps(state,indent=2)+'\n');print('START',name,'pid',p.pid,flush=True)
  timedout=False
  try:code=p.wait(timeout=1200)
  except subprocess.TimeoutExpired:timedout=True;p.kill();code=p.wait()
 check();cache=R/f'.cache/ai4/{name}.json';current=compute.cache_current(name) if cache.exists() else False;artifacts={}
 for path in (cache,cache.with_suffix('.npz')):
  if path.exists():s=path.stat();artifacts[str(path.relative_to(R))]={'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'sha256':H(path)}
 row={'item':name,'exit_code':code,'timed_out':timedout,'seconds':time.monotonic()-start,'started_utc':utc,'current_after':current,'artifacts':artifacts,'log':str(log),'log_sha256':H(log)};rows.append(row);state['active']=None;state['items']=rows;state['completed_items']=sum(x['exit_code']==0 and x['current_after'] for x in rows);(O/'progress.json').write_text(json.dumps(state,indent=2)+'\n');print('DONE',name,'exit',code,'current',current,'seconds',round(row['seconds'],1),flush=True)
print('RUN_FINISHED',state['completed_items'],'of',len(items),flush=True)
