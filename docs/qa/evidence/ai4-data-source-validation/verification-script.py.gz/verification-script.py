"""Read-only cached-result verification. Producer calls fail immediately; no jobs rerun."""
from pathlib import Path
import sys,json,hashlib,math
from unittest.mock import patch
import numpy as np
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R))
from videos.ai.ai4 import compute as c
from videos.ai.ai4.cache_contract import canonical,digest
O=Path(__file__).resolve().parent
progress_path=Path('/workspace/runtime/ai4-production-compute/progress.json');progress=json.loads(progress_path.read_text())
checks=[];findings=[]
def check(name,condition,scope,**data):
 row=dict(name=name,passed=bool(condition),scope=scope,details=data);checks.append(row)
 if not row['passed']:findings.append(row)
def sig(p):
 s=p.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,sha256=digest(p))
def close(a,b,tol=1e-12):return bool(np.allclose(a,b,rtol=tol,atol=tol,equal_nan=False))
check('run-complete',len(progress['items'])==23 and progress['active'] is None and progress['completed_items']==23,'Actual root run receipt, not scientific or render signoff')
check('frozen-receipt',digest(Path('/workspace/runtime/ai4-production-compute/source-freeze.json'))==progress['source_freeze_sha256'],'Exact generation source-freeze receipt')
for row in progress['source_files']:check('source:'+row['path'],digest(R/row['path'])==row['sha256'],'Current source agrees with root generation freeze')
original={}
for row in progress['items']:
 check('completion:'+row['item'],row['exit_code']==0 and not row['timed_out'] and row['current_after'],'CLI completion and stored validator result')
 for rel,expected in row['artifacts'].items():
  actual=sig(R/rel);original[rel]=actual
  check('artifact:'+rel,actual==expected,'Hash, size and mtime equal actual production receipt',expected=expected,actual=actual)
 check('log:'+row['item'],digest(Path(row['log']))==row['log_sha256'],'Exact original producer log')
loaded={};metadata={};finiteness=[]
def nonfinite(value,path):
 if isinstance(value,np.ndarray):
  if value.dtype.kind in 'fc':
   bad=~np.isfinite(value)
   if bad.any():finiteness.append(dict(path=path,shape=list(value.shape),nonfinite_count=int(bad.sum()),nan_count=int(np.isnan(value).sum()),inf_count=int(np.isinf(value).sum())))
 elif isinstance(value,dict):
  for key,val in value.items():nonfinite(val,path+'/'+str(key))
 elif isinstance(value,(list,tuple)):
  for i,val in enumerate(value):nonfinite(val,path+'/'+str(i))
 elif isinstance(value,(float,np.floating)) and not math.isfinite(value):finiteness.append(dict(path=path,value=str(value)))
with patch.object(c.CACHE,'_produce',side_effect=AssertionError('forbidden producer call')) as producer, patch.dict(c.CACHE.items,{n:(lambda:(_ for _ in ()).throw(AssertionError('forbidden item'))) for n in c.ITEMS}):
 for name in c.ITEMS:
  current=c.cache_current(name);check('current:'+name,current,'Schema/recipe/dependency/payload integrity only')
  d=c.CACHE.load(name);loaded[name]=d;meta=d['_cache'];raw=json.loads(c.CACHE.path(name).read_text());raw.pop('_cache')
  recipe=c.CACHE.recipe(name);deps=c.CACHE.dependencies(name);npz=c.CACHE.path(name).with_suffix('.npz')
  expected=dict(schema_version=1,recipe=recipe,dependencies=deps,payload_sha256=canonical(raw),arrays_sha256=digest(npz) if npz.exists() else None,origin='producer-save')
  check('metadata:'+name,meta==expected,'Independent reconstruction of metadata identity; no producer executed')
  metadata[name]=dict(cache_metadata=meta,array_shapes={k:list(v.shape) for k,v in d.items() if isinstance(v,np.ndarray)},array_dtypes={k:str(v.dtype) for k,v in d.items() if isinstance(v,np.ndarray)})
  nonfinite({k:v for k,v in d.items() if k!='_cache'},name)
 producer.assert_not_called()
producer_calls=0
# Small algebra on already-computed arrays, not reproduction of kernels/training.
d=loaded['params'];check('parameter-provenance',all(d['provenance'][k]['source']=='pinned-safetensors-headers' and not d['provenance'][k]['error'] for k in ('gpt2','qwen3_4b')),'Actual pinned header counts, no fallback')
d=loaded['tiny'];v=d['values'];check('tiny-forward',close(v['u'],d['inputs']['w']*d['inputs']['x']) and close(v['z'],v['u']+d['inputs']['b']) and close(v['L'],v['e']**2),'Direct algebra using cached scalar values')
check('tiny-chain',close(d['grads']['w'],2*v['e']*v['a']*(1-v['a'])*d['inputs']['x']),'Direct cached scalar derivative chain; library equality also asserted during producer')
d=loaded['linapprox'];check('derivative-formula',close(d['d1'],-1/(d['p0']*math.log(2))) and close(d['d2'],1/(d['p0']**2*math.log(2))),'Analytic derivative values')
check('gradient-cauchy-schwarz',np.max(np.abs(d['D']))<=d['gnorm']+1e-12,'Sampled directional dot products obey norm bound')
d=loaded['depth'];check('depth-spread',all(np.all(d[f'lo{k}']<=d[f'mean{k}']) and np.all(d[f'mean{k}']<=d[f'hi{k}']) for k in range(len(d['gains']))),'Stored across-seed log10 norm mean/min/max consistency; seeds not rerun')
d=loaded['jacobians'];p=np.asarray(d['p']);check('softmax-jacobian',close(d['J_sm'],np.diag(p)-np.outer(p,p)) and close(np.sum(p),1),'Independent formula on cached probabilities')
check('layernorm-jacobian',close(d['J_ln'],(np.eye(6)-np.ones((6,6))/6-np.outer(d['y'],d['y'])/6)/d['sigma']),'Independent formula on cached normalized inputs')
check('matrix-vjp',close(d['dX'],d['G']@d['W'].T) and close(d['dW'],d['X'].T@d['G']),'Cached matrix products, no autodiff rerun')
for key,tol in [('sm_diff',1e-12),('ln_diff',1e-10),('mm_diff',1e-12)]:check('jacobian-difference:'+key,d[key]<tol,'Stored production library comparison',value=d[key],tolerance=tol)
d=loaded['modes'];B=d['B'];din,dh,k=d['net'];work=B*din*dh+2*B*dh*k+B*dh
check('requested-gradient-work',d['madds_rev']==work and d['madds_fwd']==work*d['P'],'Independent counted work under documented derivative-matmul+tanh convention; excludes dX/primal/scalar overhead')
check('mode-gradient-agreement',d['agree']<1e-10 and d['lib_diff']<1e-10 and d['grad_diff']<1e-12,'Stored production comparisons, not independent autodiff rerun')
d=loaded['mlp2'];check('mlp2-gradients',d['d_lib']<1e-12 and d['d_torch']<1e-12,'Stored hand/library/Torch agreement')
check('single-example-rank',np.max(np.asarray(d['sv_one'])[1:])<1e-12,'Stored single-example gradient singular values')
d=loaded['tape'];check('tape-counts',len(d['tape'])==d['n_tape'] and len(d['tape2'])==d['n_tape2'] and close(d['wgrad'],loaded['tiny']['grads']['w']),'Cached tape sizes and worked scalar gradient continuity')
d=loaded['check'];check('gradient-checks',d['torch_diff']<1e-12 and d['fd_diff']<1e-8,'Stored library/Torch/finite-difference comparisons',torch_difference=d['torch_diff'],fd_difference=d['fd_diff'])
d=loaded['train'];check('train-normalization',close(np.exp(d['logp']).sum(1),np.ones(27)) and close(np.exp(d['snaps_logp']).sum(2),np.ones((4,27))),'Probability normalization of cached final and four snapshots')
a=d['snaps']-d['snaps'].max(2,keepdims=True);check('train-snapshot-contract',close(d['snaps_logp'],a-np.log(np.exp(a).sum(2,keepdims=True))) and d['metrics']['curve_parameter_step']=='t-1' and d['metrics']['snapshot_parameter_step']=='t','Raw-score to logp conversion and documented pre/post-update timing')
mask=np.exp(d['logcond'])>d['metrics']['correlation']['threshold'];corr=float(np.corrcoef(d['logp'][mask],d['logcond'][mask])[0,1]);check('train-correlation-cohort',int(mask.sum())==d['metrics']['correlation']['count'] and close(corr,d['corr']),'Recalculate from cached log probabilities under the declared mask',count=int(mask.sum()),correlation=corr)
check('train-outcome-metadata',close(d['bits_train']-d['H_cond'],d['metrics']['performance']['entropy_gap_bits']),'Measured entropy gap recorded; convergence not assumed')
d=loaded['grad0'];check('initial-gradient-zero-row-sums',close(d['grad'].sum(1),np.zeros(27)) and d['diff']<1e-12,'Softmax gradient row-sum invariant and stored library difference')
d=loaded['gdlr'];check('gdlr-grid',len(d['etas'])==5 and all(len(d[f'bitcurve{i}'])==301 and len(d[f'lamcurve{i}'])==121 for i in range(5)) and d['metrics']['curve_parameter_step']=='t','3001evaluated states at t0..3000, downsampled10/25; raw full trajectories not recreated')
d=loaded['floats'];check('stable-logsumexp',close(d['lse_p'].sum(),1,tol=1e-6) and close(d['fp16_shift_p'].sum(),1,tol=1e-6) and np.isfinite(d['lse_p']).all(),'Stable probability arrays; deliberately overflowed naive examples remain strings')
for precision in ('fp16','e5m2','e4m3'):
 missing=(d['xs']<d['info'][precision]['min_sub']) | (d['xs']>=d['info'][precision]['max'])
 check('spacing-unavailable-domain:'+precision,np.array_equal(np.isnan(d['ulp_'+precision]),missing),'All NaN markers exactly match samples below minimum positive subnormal or at/above greatest finite positive value, where a next-positive spacing is undefined',count=int(missing.sum()))
d=loaded['cancel'];check('stable-cancellation-nonnegative',all(np.all(d[key]>=0) for key in ('naive_fp32','stable_fp32','naive_fp64','stable_fp64')),'Relative-error arrays have valid sign and matching grid')
d=loaded['vcurve'];check('paired-directions',d['directions'].shape[0]==8 and close(np.linalg.norm(d['directions'],axis=1),np.ones(8)),'One stored normalized direction cohort used by both precisions; no kernel rerun')
right_window=(d['hs']>d['meas']['fp32']['central']*30)&(d['hs']<.1)
check('fp32-right-slope-unavailable',np.count_nonzero(right_window)==0 and math.isnan(d['slope_right_fp32']),'No eligible points in the declared right-slope fitting window; NaN means unavailable fit, not a measured zero slope')
for precision in ('fp32','fp64'):
 for method in ('central','forward'):
  curve=d[f'{method}_{precision}'];i=int(np.argmin(curve));check('median-marker:'+precision+method,close(d['meas'][precision][method],d['hs'][i]) and close(d['meas'][precision][method+'_err'],curve[i]),'Exact measured marker on actual plotted median curve')
d=loaded['checkpoint'];check('checkpoint-gradient',d['worst']<1e-12,'Stored comparison across schedules; actual defaultworst0',worst=d['worst'])
check('checkpoint-minimum',d['kbest']==int(d['ks'][np.argmin(d['peak'])]) and d['store_all_peak']==257 and d['none_evals']==33152,'Cached logical activation-liveness/evaluation counts; excludes process/allocator memory')
d=loaded['newton'];check('newton-step-mapping',len(d['gd_err'])==len(d['gd_err_steps']) and d['gd_err_steps'][-1]==d['gd_steps'] and d['gd_path_steps'][-1]==d['gd_steps'] and len(d['gd_path_steps'])==len(d['gd']),'Explicit matching final-inclusive x coordinates')
check('newton-rate-metadata',close(d['eta']*d['L'],1),'Conservative eta1/L, not2/L')
for method in ('gd','newton'):
 r=d['convergence'][method];check('newton-status:'+method,r['status']=='converged' and r['first_hit_step'] is not None and r['residual']<r['threshold'] and r['iterations']<=r['cap'],'Actual default hit/residual/iteration cap; different stopping criteria preserved',result=r)
d=loaded['hessian'];last=np.asarray(d[f'eig{len(d["keep"])-1}']);check('hvp-check',d['hv_full_diff']<1e-10,'Stored independently formed full-Hessian product comparison',difference=d['hv_full_diff'])
check('power-target',close(d['lam_dominant'],last[np.argmax(np.abs(last))]) and abs(d['lam_power']-d['lam_dominant'])/abs(d['lam_dominant'])<1e-10,'Signed greatest-magnitude target; actual default has positive unique dominant magnitude')
for i in range(len(d['keep'])):
 ev=np.asarray(d[f'eig{i}']);rho=float(np.abs(ev).max());check('spectrum-counts:'+str(i),d[f'nneg{i}']==int((ev<-.01*rho).sum()) and d[f'flat{i}']==float((np.abs(ev)<=.01*rho).mean()) and d[f'nout{i}']==int((ev>.1*rho).sum()),'Uniform relative thresholds using spectral radius, training cohort')
check('spectrum-final-summary',d['n_neg']==d['nneg5'] and d['frac_flat']==d['flat5'] and d['n_outliers']==d['nout5'],'Final versus snapshot definitions identical')
d=loaded['valley'];r=d['convergence']['gd'];hits=np.flatnonzero(d['gd_f']<r['threshold']);check('valley-first-hit',r['status']=='converged' and len(hits)>0 and r['first_hit_step']==int(hits[0])==d['gd_steps_to_1pct'],'Actual first recorded objective-threshold crossing')
d=loaded['quad'];check('quadratic-rates',close(d['rate_opt'],d['rate_opt_pred']) and close(d['rate_L'],d['rate_L_pred']),'Measured contraction factors match analytic quadratic predictions')
for method in ('opt','L','escape'):
 for i,r in enumerate(d['convergence'][method]):check(f'quad-status:{method}{i}',r['status']=='converged' and r['first_hit_step'] is not None and r['iterations']<=r['cap'] and (r['residual']>r['threshold'] if method=='escape' else r['residual']<r['threshold']),'Actual default threshold/cap outcomes')
d=loaded['lagrange'];check('constrained-solvers',all(v['success'] for v in d['solvers'].values()),'SciPy success flags alone are not sufficient scientific evidence')
check('circle-residual',abs(np.sum(d['x_star']**2)-1)<1e-6 and np.linalg.norm(d['grad_f']+d['lam']*d['grad_g'])<1e-6,'Cached independent primal/stationarity residual arithmetic')
check('entropy-constraints',close(d['p_dice'].sum(),1) and close(d['p_dice']@np.arange(1,7),4.5) and np.min(d['p_dice'])>0,'Closed-form entropy distribution constraints')
pi=d['pref']*np.exp(d['rew']/d['kl_beta']);pi/=pi.sum();check('regularized-reward-formula',close(pi,d['pi_star']) and d['dice_diff']<1e-4 and d['rl_diff']<1e-4,'Closed-form distributions and stored optimizer agreement')
d=loaded['kkt'];margins=d['y']*(d['X']@d['w']+d['b']);alpha=d['alpha'];res=dict(primal_feasibility=float(max(0,(1-margins).max())),dual_nonnegative=float(max(0,-alpha.min())),dual_equality=abs(float(alpha@d['y'])),stationarity_w=float(np.abs(d['w']-(alpha*d['y'])@d['X']).max()),stationarity_b=abs(float(alpha@d['y'])),complementarity=float(np.abs(alpha*(margins-1)).max()),duality_gap=abs(d['p_star']-d['d_star']))
check('svm-residual-arithmetic',all(close(value,d['residuals'][key]) for key,value in res.items()),'Independent cached-data KKT arithmetic',residuals=res)
check('svm-feasibility-tolerances',max(res['primal_feasibility'],res['dual_nonnegative'],res['dual_equality'],res['complementarity'],res['duality_gap'])<1e-6 and res['stationarity_w']<1e-4 and all(v['success'] for v in d['solvers'].values()),'Actual primal/dual solver flags plus numerical feasibility/stationarity/complementarity')
check('grid-qualification','finite grid' in d['grid']['scope'] and len(d['nc_l'])==d['grid']['lambda_count'],'Nonconvex p/d/gap are grid estimates, not a continuous-domain dual certificate')
d=loaded['deq'];check('deq-dimensions',d['initial_state_dimension']==8 and d['training_state_dimension']==12 and d['parameter_count']==12*12+3*12+1==181,'Distinct initial/trained state dimensions and trainable parameter count')
for phase in ('initial','final'):
 r=d['solves'][phase];check('deq-solve:'+phase,r['status']=='converged' and r['residual']<r['tolerance'] and r['iterations']<=r['cap'],'Actual completed solve residual/cap')
for phase in ('training','fit'):
 r=d['solves'][phase];check('deq-solve:'+phase,r['converged']==r['count'] and r['capped']==0 and r['nonfinite']==0 and r['max_residual']<r['tolerance'],'All recorded solver observations converged; training includes final evaluation',result=r)
check('deq-cohorts',d['solves']['training']['count']==(d['steps']+1)*len(d['xs']) and d['solves']['fit']['count']==len(d['keep'])*len(d['gx']),'800updates plus final training-cohort evaluation, six90-point fitted grids')
for item in ('modes','checkpoint','hessian'):
 b=loaded[item]['benchmark'];runs=b['runs'];check('benchmark:'+item,b['context']['torch_threads']==1 and all(len(r['seconds'])==r['repeats'] and close(np.mean(r['seconds']),r['mean_seconds']) and min(r['seconds'])>=0 for r in runs),'Recorded repeat means/context/scope; no timing rerun or confidence interval',runs=len(runs),native_threadpools=b['context']['native_threadpools'])
for rel,before in original.items():check('unchanged-after-read:'+rel,sig(R/rel)==before,'No cache JSON/NPZ byte or mtime changed during guarded loads/checks')
summary=dict(scope='Read-only verification of completed Part4 numeric artifacts; schema/integrity checks distinguished from scientific cached-result checks and stored producer comparisons.',producer_calls=producer_calls,loaded_items=list(loaded),cache_metadata=metadata,checks=checks,findings=findings,nonfinite_inventory=finiteness,production_seconds=sum(x['seconds'] for x in progress['items']),per_item_seconds={x['item']:x['seconds'] for x in progress['items']},artifact_count=len(original),progress_sha256=digest(progress_path),limits=['No training/model/solver/kernel rerun, new parameter/network request, render or audio.','Direct cached-array algebra validates listed invariants only; stored producer difference metrics also rely on exact frozen producer/assertion code and successful original logs.','NaN spacing markers outside representable formats and insufficient-window slope fits are not silently classified as corrupt numerical results.','No visual/continuous/narration/listening/production export approval.'])
(O/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(loaded=len(loaded),producer_calls=producer_calls,artifacts=len(original),checks=len(checks),failed_checks=len(findings),nonfinite=finiteness,production_seconds=summary['production_seconds']),indent=2))
