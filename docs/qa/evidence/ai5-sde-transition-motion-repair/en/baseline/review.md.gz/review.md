# SDE en: selected-time visual QA

272 selected times: 214 native unique images directly viewed on 27 chronological sheets, 58 exact duplicate reuse. Every file frame was automatically decoded (1720 frames); this is not continuous perceptual playback/listening. Largest selected gap 1.000000s.

Movie SHA `01e05fc1a4843db879d370281227b5d305957baca1b5c777ceea91bcebefd1c4`; tool SHA `1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e`. Source/input/record/frame/page provenance and gaps remain in JSON.

Page 1: Viewed openingtitle fade/hold/fadeout through3.667s; all heading/timeline text contained.

Page 2: Viewed openingtitle fade/hold/fadeout through3.667s; all heading/timeline text contained.

Page 3: Viewed SDE equation/card reveals and pushbrace emphasis through5.867s. Drift/noise semantic colors and definition card contained; no collision.

Page 4: Viewed SDE equation/card reveals and pushbrace emphasis through5.867s. Drift/noise semantic colors and definition card contained; no collision.

Page 5: Viewed drift/noise brace reveals/holds and Euler formula onset through27.133s. Definition panel remains inset; braces do not collide.

Page 6: Viewed drift/noise brace reveals/holds and Euler formula onset through27.133s. Definition panel remains inset; braces do not collide.

Page 7: Viewed Euler-Maruyama formula Write/hold through34.333s; noise term sqrtDelta-t and standard-bell qualifier clear, card does not collide with equation.

Page 8: Viewed Euler-Maruyama formula Write/hold through34.333s; noise term sqrtDelta-t and standard-bell qualifier clear, card does not collide with equation.

Page 9: Viewed Euler-to-OU crossfade and path reveals through38.467s. Possible transient caption/axis overlap during crossfade36.2–36.5 requires native follow-up; settled paths clear.

Page 10: Viewed Euler-to-OU crossfade and path reveals through38.467s. Possible transient caption/axis overlap during crossfade36.2–36.5 requires native follow-up; settled paths clear.

Page 11: Viewed OU pathensemble full reveal/hold and meanline onset through44.067s; paths remain below text, no settled layout issue.

Page 12: Viewed OU pathensemble full reveal/hold and meanline onset through44.067s; paths remain below text, no settled layout issue.

Page 13: Viewed OU mean/band overlays, holds and stationarywidth.57/bell reveal through48.4s. Settledmean/band readable; stationarycaption animation rightedge needs nativefollow-up.

Page 14: Viewed OU mean/band overlays, holds and stationarywidth.57/bell reveal through48.4s. Settledmean/band readable; stationarycaption animation rightedge needs nativefollow-up.

Page 15: Viewed settled OU width.57/bell and holds then panel fade into GBM axes/legend through64s. Stationarycaption remains inside viewport; no settled caption clipping.

Page 16: Viewed settled OU width.57/bell and holds then panel fade into GBM axes/legend through64s. Stationarycaption remains inside viewport; no settled caption clipping.

Page 17: Viewed exact shared-noiseGBM path/legend hold and4/16/256approximation reveals through79.2s; curves/legend stay below title, no label collision.

Page 18: Viewed exact shared-noiseGBM path/legend hold and4/16/256approximation reveals through79.2s; curves/legend stay below title, no label collision.

Page 19: Viewed completed shared-noise approximations and20k-pathcohort footer reveal through85.267s; footerandlegend inset, no overlap.

Page 20: Viewed completed shared-noise approximations and20k-pathcohort footer reveal through85.267s; footerandlegend inset, no overlap.

Page 21: Viewed strongerror curve/dots/slope.54 reveal thenweakcurve onset through87s; errorformula absolutevalue placement clear and footer contained.

Page 22: Viewed strongerror curve/dots/slope.54 reveal thenweakcurve onset through87s; errorformula absolutevalue placement clear and footer contained.

Page 23: Viewed weakerror dots/formula |E(Xh-X)| slope.95 and strongcomparison holds through101.067s; two errorlabels distinct and data/legend contained.

Page 24: Viewed weakerror dots/formula |E(Xh-X)| slope.95 and strongcomparison holds through101.067s; two errorlabels distinct and data/legend contained.

Page 25: Viewed G.Maruyama1955credit reveal/holds and closingfade through114.6s. Strong/weaklabels and20kcohort footer remain inset; one earlier crossfade collision retained as finding.

Page 26: Viewed G.Maruyama1955credit reveal/holds and closingfade through114.6s. Strong/weaklabels and20kcohort footer remain inset; one earlier crossfade collision retained as finding.

Page 27: Viewed G.Maruyama1955credit reveal/holds and closingfade through114.6s. Strong/weaklabels and20kcohort footer remain inset; one earlier crossfade collision retained as finding.


## Confirmed finding and scope

The incoming OU formula overlaps the fading Euler–Maruyama subtitle during the transition. The incoming axis traverses the old card region, without a separate confirmed glyph collision. Settled panels are clear. This baseline is coverage-complete with an unresolved visual finding; it is not a visual clean pass. See JSON findings/native_followups for exact pixels and times.

Five individual native checks covered drift/card, sqrt-step qualifier, OU width0.57, GBM/error readouts, and the transition collision. Continuous perceptual playback, audio/listening/sync, and production-resolution appearance remain unverified.
