# SDE zh: selected-time visual QA

285 selected times: 213 native unique images directly viewed on 27 chronological sheets, 72 exact duplicate reuse. Every file frame was automatically decoded (1755 frames); this is not continuous perceptual playback/listening. Largest selected gap 1.000000s.

Movie SHA `5e1c314162284c01f8e13ba78f2acdf586ffc41670fca3a1652bf813ca5c93b0`; tool SHA `1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e`. Source/input/record/frame/page provenance and gaps remain in JSON.

Page 1: Viewed openingtitle fade/hold/fadeout through3.867s; translated chaptertitle/timeline contained.

Page 2: Viewed openingtitle fade/hold/fadeout through3.867s; translated chaptertitle/timeline contained.

Page 3: Viewed SDE formula/definitioncard and driftbrace reveals through6.133s; Chinese text wraps within card and arrows separate.

Page 4: Viewed SDE formula/definitioncard and driftbrace reveals through6.133s; Chinese text wraps within card and arrows separate.

Page 5: Viewed noisebrace reveal/holds and Eulerformula onset through28.467s; translations/definitioncard clear, no overlap.

Page 6: Viewed noisebrace reveal/holds and Eulerformula onset through28.467s; translations/definitioncard clear, no overlap.

Page 7: Viewed Eulerformula Write/holds and OUtransition onset through35.333s; nativefollow-up required for oldEuler/newOU formula overlap, matching English lead.

Page 8: Viewed Eulerformula Write/holds and OUtransition onset through35.333s; nativefollow-up required for oldEuler/newOU formula overlap, matching English lead.

Page 9: Viewed OUtransition completion and ensemblepath reveal through38.133s; settledgeometry clear; earlier Euler/OU text collision confirmed separately atnative35.333s.

Page 10: Viewed OUtransition completion and ensemblepath reveal through38.133s; settledgeometry clear; earlier Euler/OU text collision confirmed separately atnative35.333s.

Page 11: Viewed OU ensemble path reveal and holds38.4–44.067s; mean onset. Plot/caption separated and no new defect.

Page 12: Viewed OU ensemble path reveal and holds38.4–44.067s; mean onset. Plot/caption separated and no new defect.

Page 13: Viewed orange mean and uncertainty-band reveals44.267–49s, stationary width0.57 and bell. Labels/geometry separate; no new defect.

Page 14: Viewed orange mean and uncertainty-band reveals44.267–49s, stationary width0.57 and bell. Labels/geometry separate; no new defect.

Page 15: Viewed settled OU mean/band/bell width0.57 through64.6s and fade onset. Caption contained; no new defect.

Page 16: Viewed settled OU mean/band/bell width0.57 through64.6s and fade onset. Caption contained; no new defect.

Page 17: Viewed OU fade/GBM exact shared-noise reference reveal64.867–68.2s and colored4/16/256-step approximation reveals79.733–80.733. Legend and axes readable, no new defect.

Page 18: Viewed OU fade/GBM exact shared-noise reference reveal64.867–68.2s and colored4/16/256-step approximation reveals79.733–80.733. Legend and axes readable, no new defect.

Page 19: Viewed completed4/16/256 paths and holds81–86.733s, then20,000-path exact-solution cohort footer. Legend/method labels separate; no new defect.

Page 20: Viewed completed4/16/256 paths and holds81–86.733s, then20,000-path exact-solution cohort footer. Legend/method labels separate; no new defect.

Page 21: Viewed strong-error curve/dots/slope0.54 reveal86.933–87.8 and weak-curve onset88–88.467. Absolute-error vs error-of-mean forms distinct, no new defect.

Page 22: Viewed strong-error curve/dots/slope0.54 reveal86.933–87.8 and weak-curve onset88–88.467. Absolute-error vs error-of-mean forms distinct, no new defect.

Page 23: Viewed weak-error label0.95 and green curve/dot reveal88.6–90.133, final holds/Maruyama1955 credit through100.467. Strong/weak definitions and legend remain readable; no new defect.

Page 24: Viewed weak-error label0.95 and green curve/dot reveal88.6–90.133, final holds/Maruyama1955 credit through100.467. Strong/weak definitions and legend remain readable; no new defect.

Page 25: Viewed final holds100.533–116.333, Maruyama1955 credit and cohort footer contained; final fade begins. No new defect.

Page 26: Viewed final holds100.533–116.333, Maruyama1955 credit and cohort footer contained; final fade begins. No new defect.

Page 27: Viewed final fade116.533–116.933 through file last frame; no new defect.


## Confirmed finding and scope

The incoming OU formula overlaps the fading Euler–Maruyama subtitle during the transition. The incoming axis traverses the old card region, without a separate confirmed glyph collision. Settled panels are clear. This baseline is coverage-complete with an unresolved visual finding; it is not a visual clean pass. See JSON findings/native_followups for exact pixels and times.

Five individual native checks covered drift/card, sqrt-step qualifier, OU width0.57, GBM/error readouts, and the transition collision. Continuous perceptual playback, audio/listening/sync, and production-resolution appearance remain unverified.
