from pathlib import Path
import runpy,sys,ast,json,hashlib
import numpy as np
D=Path(__file__).parent
q=runpy.run_path(str(D/'geometry.py'));s=q['scope']; review_language=q['review_language'];variant=q['variant'];bounds=q['bounds'];config=q['config']
def fills(m):return [float(p.get_fill_opacity()) for p in m.family_members_with_points()]
assert all(max(fills(r[0]),default=0)>.9 for key in ['vb','accs'] for r in s[key])
assert all(max(fills(r[0]),default=0)==0 for r in s['lls'])
contracts={}
for key in ['vb','accs','lls']:
 chart=s[key];contracts[key]={'visible_glyph_name_max_fill':[max(fills(r[0]),default=0) for r in chart], 'name_to_bar_gaps':[float(r[1].get_left()[0]-r[0].get_right()[0]) for r in chart], 'full_bounds':bounds(chart)}
 assert np.allclose(contracts[key]['name_to_bar_gaps'],.2,rtol=0,atol=1e-12)
 assert all(chart[i][1].get_y()>chart[i+1][1].get_y() for i in range(3))
headings={k:bounds(s[k]) for k in ['ta','tl']};horizontal_gap=float(s['gL'].get_left()[0]-s['gA'].get_right()[0]);heading_chart_gaps={a:float(s[a].get_bottom()[1]-s[b].get_top()[1]) for a,b in [('ta','accs'),('tl','lls')]}
assert all(abs(x-.3)<1e-12 for x in heading_chart_gaps.values())
assert horizontal_gap>0
frame={'width':float(config.frame_width),'height':float(config.frame_height)}
frame_insets={k:{'left':float(s[k].get_left()[0]+config.frame_width/2),'right':float(config.frame_width/2-s[k].get_right()[0]),'bottom':float(s[k].get_bottom()[1]+config.frame_height/2),'top':float(config.frame_height/2-s[k].get_top()[1])} for k in ['vbox','gA','gL']}
assert all(min(insets.values())>0 for insets in frame_insets.values())
# Evaluate the actual candidate source's quantitative emphasis, not a reimplemented animation.
call=next(n for n in ast.walk(q['gauss']) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='Indicate' and n.args and isinstance(n.args[0],ast.IfExp) and isinstance(n.args[0].body,ast.Subscript) and isinstance(n.args[0].body.value,ast.Name) and n.args[0].body.value.id=='vb')
s.update(HL=q['C'].BITS,beats=s['ts_h']<s['H']['ols']['var']);animation=eval(compile(ast.Expression(call),'frozen-actual-variance-Indicate','eval'),s)
row=animation.mobject;original=[m.get_points().copy() for m in row.family_members_with_points()];animation.begin();changes=[]
for alpha in np.linspace(0,1,61):
 animation.interpolate(float(alpha));change=max(float(np.max(np.abs(m.get_points()-v))) for m,v in zip(row.family_members_with_points(),original));changes.append(change)
animation.finish()
if variant=='candidate':assert max(changes)<1e-12
report={'variant':variant,'language':review_language,'charts':contracts,'heading_bounds':headings,'heading_to_chart_gaps':heading_chart_gaps,'full_group_horizontal_gap':horizontal_gap,'frame':frame,'full_group_frame_insets':frame_insets,'actual_Indicate_ast':ast.unparse(call),'actual_Indicate_61_alphas_max_point_drift':max(changes),'source_shapes_and_value_fields':'Actual immutable source expressions; no scene imports/whole-scene rendering/data loaders or producers.','hidden_name_check':'All point-bearing glyph descendants checked; container fill-opacity alone is insufficient.','geometry_is_not_render_approval':True}
(D/f'extended-{variant}-{review_language}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'variant':variant,'language':review_language,'column_gap':horizontal_gap,'minimum_frame_inset':min(v for a in frame_insets.values() for v in a.values()),'emphasis_max_drift':max(changes)}))
