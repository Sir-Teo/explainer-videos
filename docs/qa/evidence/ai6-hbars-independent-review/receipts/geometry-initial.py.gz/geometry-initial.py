from pathlib import Path
import os,sys,ast,json,math,hashlib
import numpy as np
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;review_language=sys.argv[1];variant=sys.argv[2]
sys.path.insert(0,str(R));os.environ['EXPLAINER_LANG']=review_language;os.environ['EXPLAINER_VIDEO']='ai6'
assert all(os.environ.get(k)=='1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','EXPLAINER_CACHED_ONLY'])
from manim import config
config.media_dir=str(D/'geometry-media'/review_language)
from explainer.ai import *
assert 'videos.ai.ai6.compute' not in sys.modules
sha=lambda b:hashlib.sha256(b).hexdigest()
source=(D/'baseline/videos/ai/ai6/common.py') if variant=='baseline' else (R/'videos/ai/ai6/common.py')
b=source.read_bytes();node=next(n for n in ast.parse(b).body if isinstance(n,ast.FunctionDef) and n.name=='hbars');env=dict(globals());exec(compile(ast.Module([node],type_ignores=[]),'actual-hbars-only','exec'),env);helper=env['hbars']
def method(name,fn):return next(n for n in ast.walk(ast.parse((R/'videos/ai/ai6'/name).read_text())) if isinstance(n,ast.FunctionDef) and n.name==fn)
def assigned(n,k):return isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==k for t in n.targets)
def run(nodes,e):exec(compile(ast.Module(nodes,type_ignores=[]),'actual-caller-chart-only','exec'),e)
def identity(p):return {'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}
def bounds(o):return {'left':float(o.get_left()[0]),'right':float(o.get_right()[0]),'bottom':float(o.get_bottom()[1]),'top':float(o.get_top()[1])}
reads=[]
def raw(name):
 p=R/'.cache/ai6'/f'{name}.json';before=identity(p);out=json.loads(p.read_text());after=identity(p);assert before==after;reads.append(before);return out
gm=raw('gaussmarkov');cal=raw('calibration');G=gm['gauss'];H=gm['t3'];scope=dict(env,hbars=helper,G=G,H=H,ts_g=G['ts']['var'],ts_h=H['ts']['var'],OLS=C.MODEL_Q,TS='#4FD1C5',c=cal)
gauss=method('s03_gauss.py','simulate');g_nodes=[n for n in gauss.body if any(assigned(n,k) for k in ['vb','vbh','vbox'])];run(g_nodes,scope)
metrics=method('s17_metrics.py','scores');m_nodes=[n for n in metrics.body if any(assigned(n,k) for k in ['specs','accs','loss_top','lls','ta','tl','gA','gL'])]
# Preserve the actual source loop that hides lossnames and its actual title placement.
for index,n in enumerate(metrics.body):
 if isinstance(n,ast.For) and isinstance(n.iter,ast.Name) and n.iter.id=='lls':m_nodes.append(n)
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='tl':m_nodes.append(n)
m_nodes.sort(key=lambda n:n.lineno);run(m_nodes,scope)
def chart(name,group,values,width,lo,hi,whole=None):
 starts=[float(r[1].get_left()[0]) for r in group];widths=[float(r[1].width) for r in group];gaps=[float(r[2].get_left()[0]-r[1].get_right()[0]) for r in group];baseline=[max(width*(v-lo)/(hi-lo),.02) for v in values]
 assert np.allclose(widths,baseline,rtol=0,atol=1e-12) and np.allclose(gaps,.12,rtol=0,atol=1e-12)
 return {'name':name,'lo':lo,'hi':hi,'width_parameter':width,'values':values,'bar_origins':starts,'origin_spread':max(starts)-min(starts),'bar_widths':widths,'expected_legacy_widths':baseline,'value_label_bar_end_gaps':gaps,'name_widths':[float(r[0].width) for r in group],'name_opacities':[float(r[0].get_fill_opacity()) for r in group],'value_label_centers':[[float(x) for x in r[2].get_center()] for r in group],'row_centers_y':[float(r[1].get_y()) for r in group],'chart_bounds':bounds(group),'whole_bounds':bounds(whole) if whole is not None else None,'minimum_stub_floor':.02,'scope':'Commonbaseline = lo, not necessarily zero. Numericlengths/readouts preserved; beyond-range behavior follows existinghelper floor/no upperclamp.'}
rows=[chart('Gauss.simulate.vb',scope['vb'],[G['ols']['var'],G['ts']['var'],H['ols']['var'],H['ts']['var']],3.4,0,.0125,scope['vbox']),chart('Metrics.scores.accs',scope['accs'],[cal['acc'][k] for k,_,_ in scope['specs']],3.6,.7,1,scope['gA']),chart('Metrics.scores.lls',scope['lls'],[cal[k]['logloss'] for k,_,_ in scope['specs']],3,0,scope['loss_top'],scope['gL'])]
assert all(np.isclose(v,0) for v in rows[2]['name_opacities'])
empty=helper([]);assert len(empty)==0
compat=helper([(r'$x$',-1,WHITE),(r'$x_{123456789}$',0,WHITE),(r'$z$',2,WHITE)],width=4,lo=0,hi=1,fmt=lambda v:f'{v:g}')
compat_widths=[float(r[1].width) for r in compat];assert np.allclose(compat_widths,[.02,.02,8],rtol=0,atol=1e-12)
report={'language':review_language,'variant':variant,'hbars_source':str(source),'hbars_source_sha256':sha(b),'caller_source_sha256':{n:sha((R/'videos/ai/ai6'/n).read_bytes()) for n in ['s03_gauss.py','s17_metrics.py']},'charts':rows,'empty_list_length':len(empty),'legacy_outofrange_widths':compat_widths,'data_reads':reads,'compute_module_imported':False,'scope':'ActualManimgeometry/TeXonly viaAST-extractedhbars andexact3callerchartconstruction; no sceneimport/render/producer/TTS/model.','accuracy_baseline_cue_source_observation':'Actualaccslo=.7; headinghas no70%origin disclosure in current source. Geometryalone is not renderedfailure evidence.'};assert source.read_bytes()==b
(D/f'{variant}-{review_language}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'language':review_language,'variant':variant,'origin_spreads':{r['name']:r['origin_spread'] for r in rows},'bounds':{r['name']:r['whole_bounds'] for r in rows},'empty':len(empty),'legacy_widths':compat_widths}))
