# Independent Part6 hbars/Gauss/Metrics source and geometry review

Accepted within the bounded source and actual-Manim geometry scope. No blocking regression found. No repository edits, producers, model inference, scene imports, full-scene renders or TTS occurred.

All three actual callers were constructed from frozen AST snippets in English and Chinese against raw, unchanged completed data: Gauss variance, Metrics accuracy and Metrics log loss. The six candidate charts share their intended baseline/origin exactly within 1e-12. Accuracy starts at70%; the other two start at0. Numeric values, encoded widths, .2 name gaps, .12 value gaps, row order and hidden duplicate loss names remain correct. Point-bearing glyph descendants were inspected programmatically; container opacity alone was not treated as hidden text.

Baseline origin spreads were0.82554world in Gauss and0.98394world in EN Metrics. The candidate actual source Indicate keeps all row geometry fixed at61 alpha samples per language, with maximal point drift8.9e-16; the old default emphasis displaced geometry. Empty rows and the existing minimum .02 stub/no upper-clamp behavior remain compatible.

All other common-module AST is identical. All voiceover AST is identical. The entire Gauss AST matches after reverting only its seven append transform=False keywords and the single scale_factor=1; Metrics matches after reverting only its new accuracy heading. Three existing candidate tests passed independently. The older601-test baseline result does not cover this candidate.

Actual rendered regressions remain open. Inspect Metrics’ new two-line70% cue and narrow left gutter: the Chinese group has0.12988world (~7.8px at480) clearance in this geometry fixture and no computed clipping; the whole-column gap is0.34056world. This is a native follow-up priority, not a demonstrated rendering defect. Fresh Gauss/Metrics bilingual movies must confirm append readability and final layout. No continuous playback, listening or production resolution approval is made.

Exact sources, data observations, tests, source-delta proof and complete per-chart bounds are recorded in report.json and the sibling geometry receipts.
