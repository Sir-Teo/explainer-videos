from pathlib import Path
import json,hashlib,datetime,sys,os,time
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-five-chapter-caption-regression');D.mkdir(exist_ok=False);S=Path('/workspace/runtime/ai6-five-chapter-source-integration');h=lambda b:hashlib.sha256(b).hexdigest();old=json.loads((S/'before/ai_text_zh.json').read_text());newbytes=(R/'videos/ai/ai_text_zh.json').read_bytes();new=json.loads(newbytes);assert h((S/'before/ai_text_zh.json').read_bytes())=='0884ed469261b1b911c233f875d03430ed6099b6ce79c499972cce6ff0e9d0ad';assert h(newbytes)=='89f96750476f9684e003084695f24f6902ffe0b2fc049387d3111dbef5ffef46'
sys.path.insert(0,str(R));from explainer import lang,zh_text
assert lang.LANG=='zh';prior=Path('/workspace/runtime/ai6-newton-caption-integration');report=json.loads((prior/'report.json').read_text());assert report['current_table_sha256']==h((S/'before/ai_text_zh.json').read_bytes())
for rel,sha in report['lookup_code_sha256'].items():assert h((R/rel).read_bytes())==sha
used=json.loads((prior/'used-caption-results.json').read_text());assert len(used)==5541;known={v['english']:v['after'] for v in used};contexts={};files=[];nrows=0
for p in sorted((R/'renders/qa/series/ai6/en').glob('*/text.jsonl')):
 b=p.read_bytes();rows=[json.loads(x) for x in b.decode().splitlines() if x.strip()];files.append(dict(path=str(p.relative_to(R)),bytes=len(b),sha256=h(b),rows=len(rows)))
 for v in rows:
  text=v.get('s');assert isinstance(text,str);nrows+=1;contexts.setdefault(text,set()).add(str(p.relative_to(R)))
zh_text._TABLE=old;zh_text._BY_NUMBERS=None;t=time.monotonic();p6before={s:zh_text.translate(s) for s in contexts}
for s,v in p6before.items():
 if s in known:assert known[s]==v,'Shared prior-output discrepancy'
 else:known[s]=v
zh_text._TABLE=new;zh_text._BY_NUMBERS=None;diff=[];out=[]
for s,before in sorted(known.items()):
 after=zh_text.translate(s);row=dict(english=s,before=before,after=after,part6_contexts=sorted(contexts.get(s,[])));out.append(row)
 if before!=after:diff.append(row)
expected=json.loads((S/'caption-add.json').read_text())['strings'];actual={k:zh_text.translate(k) for k in expected};assert actual==expected
for f in files:
 b=(R/f['path']).read_bytes();assert h(b)==f['sha256'] and len(b)==f['bytes']
assert (R/'videos/ai/ai_text_zh.json').read_bytes()==newbytes
receipt=dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),before_table_sha256=h((S/'before/ai_text_zh.json').read_bytes()),after_table_sha256=h(newbytes),prior_Part1_5_unique_strings=5541,prior_Part1_5_rows=30384,prior_Part1_5_files=314,part6_captured_files=files,part6_captured_rows=nrows,part6_unique_strings=len(contexts),combined_unique_strings=len(known),changed_outputs=len(diff),differences=diff,new_caption_checks=actual,elapsed_s=time.monotonic()-t,scope='Actual retained Part1–5 outputs at0884 and actual Part6 English constructor-text inputs. Pure caption lookups only, no frame/render/audio/VO/uncaptured-branch/source-fingerprint refresh approval. Local VO differences are separately tested through actual whole-module Translator.')
(D/'report.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');(D/'used-results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ['part6_captured_files','differences','new_caption_checks']},indent=2));assert not diff
