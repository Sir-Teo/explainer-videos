"""Private adapter: unchanged native endpoint wrapper, no new speech/data production."""
from pathlib import Path
import hashlib
import json
import os
import runpy
import sys

ROOT = Path('/workspace/explainer-videos')
HERE = Path(__file__).resolve().parent
case_dir, language, scene = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
os.environ.update(EXPLAINER_CACHED_ONLY='1', EXPLAINER_TTS='silent',
                  EXPLAINER_LANG=language, EXPLAINER_VIDEO='ai6',
                  OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
                  MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
sys.path.insert(0, str(ROOT))
from explainer import tts
from videos.ai.ai6 import compute

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
speech_reads = []
denied_calls = []

def deny(*args, **kwargs):
    denied_calls.append('producer-or-synthesis')
    raise RuntimeError('Native endpoint QA forbids producers and new speech/data payloads')

# The existing cached-only loader still validates every consumed item normally.
# These guards deny the producer entry point even if a later refactor bypasses it.
compute.CACHE._produce = deny
compute.CACHE.save = deny
compute.CACHE.prepare_inputs = deny
assert tts.BACKEND == 'silent'
original_synthesize = tts.synthesize
# A cache race must fail rather than create even a silent placeholder payload.
tts._synth_silent = deny
tts._synth_server = deny
tts._synth_kokoro = deny
tts._write_wav = deny

def cached_speech_only(text):
    _, _, key = tts.cache_key(text)
    paths = [tts.CACHE_DIR / (key + suffix) for suffix in ['.wav', '.json']]
    if not all(p.is_file() for p in paths):
        raise FileNotFoundError(f'Missing existing silent preview audio {key}; finish normal480QA first, no synthesis here')
    before = [{'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size,
               'mtime_ns': p.stat().st_mtime_ns} for p in paths]
    utterance = original_synthesize(text)
    after = [{'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size,
              'mtime_ns': p.stat().st_mtime_ns} for p in paths]
    assert before == after, 'Existing audio payload changed during read'
    speech_reads.append({'key': key, 'backend': tts.BACKEND, 'voice': tts.VOICE,
                         'speed': tts.SPEED, 'language': language, 'payloads': before})
    return utterance

tts.synthesize = cached_speech_only
wrapper = HERE / 'qa_production_endpoint-original.py'
assert sha(wrapper) == '87a00a2438f120958c658343893d6b0d36934a65d8438beb7790f77384f88a9d'
sys.argv = [str(wrapper), 'ai6', language, scene]
try:
    runpy.run_path(str(wrapper), run_name='__main__')
finally:
    (case_dir / 'guarded-reads.json').write_text(json.dumps({
        'scope': 'Real cached-only validation retained; producer/save/preparation and all synthesis/wav-writer entrypoints fail on call. Existing silent WAV/JSON only; transient advisory locks may be touched.',
        'denied_calls': denied_calls, 'existing_speech_reads': speech_reads,
        'adapter_sha256': sha(Path(__file__)), 'unchanged_wrapper_sha256': sha(wrapper),
    }, indent=2) + '\n')
