"""Prepared serial Part6 native1080 endpoints. No captures without root final pin."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import ast
import datetime
import fcntl
import hashlib
import importlib.metadata
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time

from PIL import Image, ImageDraw

ROOT = Path('/workspace/explainer-videos')
HERE = Path(__file__).resolve().parent
MIN_DISK = 768 * 1024**2
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def scenes_from(source):
    tree = ast.parse(source)
    return ast.literal_eval(next(n.value for n in tree.body if isinstance(n, ast.Assign)
                                and any(isinstance(t, ast.Name) and t.id == 'SCENES' for t in n.targets)))

def prefix_cases(cases, stop_after):
    if stop_after is None:
        return cases, []
    matching = [i for i, (language, _, scene, _) in enumerate(cases)
                if f'{scene}:{language}' == stop_after]
    if len(matching) != 1:
        raise ValueError('Unknown or ambiguous stop-after-case; no capture may start')
    limit = matching[0] + 1
    return cases[:limit], cases[limit:]

def source_path(path):
    return ((path.startswith('videos/ai/ai6/') and path.endswith(('.py', '.json')))
            or (path.startswith('explainer/') and path.endswith('.py'))
            or path in ['videos/ai/ai_text_zh.json', 'tools/qa_series.py', 'requirements-lock.txt'])

def pins_from_commit(commit):
    paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', commit], cwd=ROOT, text=True).splitlines()
    return {p: hashlib.sha256(subprocess.check_output(['git', 'show', f'{commit}:{p}'], cwd=ROOT)).hexdigest()
            for p in paths if source_path(p)}

def changed_pins(pins):
    return [{'path': p, 'expected': expected, 'observed': sha(ROOT / p) if (ROOT / p).is_file() else None}
            for p, expected in pins.items() if not (ROOT / p).is_file() or sha(ROOT / p) != expected]

def copy2_verified(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert sha(source) == sha(target)
    assert (source.stat().st_dev, source.stat().st_ino) != (target.stat().st_dev, target.stat().st_ino)
    return {'source': str(source), 'copy': str(target), 'sha256': sha(target), 'bytes': target.stat().st_size}

def snapshot_files(paths, destination):
    return [copy2_verified(ROOT / p, destination / p) for p in paths]

def preserve_output(folder, destination):
    record = folder / 'result.json'
    if not record.is_file():
        return {'result_present': False, 'copies': []}
    raw = json.loads(record.read_text())
    names = ['result.json', 'text.jsonl', 'render.log', 'sheet.png'] + [f['file'] for f in raw.get('frames', [])]
    return {'result_present': True, 'copies': [copy2_verified(folder / n, destination / n)
            for n in names if (folder / n).is_file()]}

def standard_witness(folder, destination):
    if not folder.exists():
        return {'result_present': False, 'reason': 'No prior480output'}
    with (folder / '.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            return {'result_present': False, 'reason': 'Prior480worker active; no mutable output copied'}
        return preserve_output(folder, destination)

def caption_projection(source, table, strings):
    # Run the actual frozen pure lookup functions, without importing Manim/models.
    tree = ast.parse(source)
    names = {'_SPACE', '_TEXT_CMD', '_NUM'}
    nodes = [n for n in tree.body if
             (isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in names for t in n.targets))
             or (isinstance(n, ast.FunctionDef) and n.name in ['_by_numbers', 'translate'])]
    scope = dict(re=re, lang=SimpleNamespace(LANG='zh'), _TABLE=table, _BY_NUMBERS=None)
    exec(compile(ast.Module(nodes, type_ignores=[]), 'actual-frozen-caption-lookup', 'exec'), scope)
    return {s: scope['translate'](s) for s in strings}

def review_plan(case, record):
    frames = []
    for i, row in enumerate(record['frames']):
        path = case / 'native' / row['file']
        assert Image.open(path).size == (1920, 1080)
        frames.append(dict(row, index=i, sha256=sha(path), bytes=path.stat().st_size, size=[1920, 1080]))
    pages = []
    for start in range(0, len(frames), 4):
        chosen = frames[start:start + 4]
        page = Image.new('RGB', (1920, 1144), '#10151d')
        draw = ImageDraw.Draw(page)
        for pos, frame in enumerate(chosen):
            x, y = (pos % 2) * 960, (pos // 2) * 572
            draw.text((x + 8, y + 7), f'{case.name} endpoint{frame["index"]} {frame["time"]:.3f}s', fill='white')
            with Image.open(case / 'native' / frame['file']) as image:
                page.paste(image.resize((960, 540), Image.Resampling.LANCZOS), (x, y + 32))
        dest = case / 'pages' / f'page-{len(pages) + 1:03d}.png'
        dest.parent.mkdir(exist_ok=True)
        page.save(dest)
        pages.append({'page': len(pages) + 1, 'file': str(dest.relative_to(case)), 'sha256': sha(dest),
                      'frame_indices': [f['index'] for f in chosen], 'tile_size': [960, 540],
                      'review_scale': '50% per native1920x1080 frame; critical unscaled views required separately'})
    dump(case / 'plan.json', {'frames': frames, 'pages': pages, 'actual_visual_approval': 'pending'})
    dump(case / 'views.json', {'pages': [], 'native': [], 'findings': []})
    return len(frames), len(pages)

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--final-source-commit')
    ap.add_argument('--global-caption-sha256')
    ap.add_argument('--release', choices=['root-confirmed'])
    ap.add_argument('--run-id')
    ap.add_argument('--stop-after-case', help='Inclusive manifest-prefix cap, e.g. LeastSquares:zh; remaining cases stay queued')
    ap.add_argument('--prepare-plan', action='store_true')
    args = ap.parse_args()
    working_scenes = scenes_from((ROOT / 'videos/ai/ai6/manifest.py').read_text())
    assert len(working_scenes) == 19
    cases = [(lang, module, scene, title) for module, scene, title in working_scenes for lang in ['en', 'zh']]
    selected_cases, remaining_cases = prefix_cases(cases, args.stop_after_case)
    if args.prepare_plan:
        dump(HERE / 'prepared-cases.json', {'scope': 'Not released; source/table still pending. No renderer/model/producer imported.',
             'cases': cases, 'total_cases': len(cases), 'selected_cases': selected_cases,
             'remaining_queued_cases': remaining_cases, 'frame_count': 'dynamic from actual captures',
             'wrapper_sha256': sha(HERE / 'qa_production_endpoint-original.py')})
        print('PREPARED38CASES_NO_CAPTURE')
        return
    if (args.release != 'root-confirmed' or not args.final_source_commit or not args.global_caption_sha256
            or not args.run_id):
        ap.error('STOP: explicit root final source/table pin and run-id/release required; no captures started')
    serial_lock = (HERE / 'serial-native.lock').open('a')
    fcntl.flock(serial_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert re.fullmatch('[0-9a-f]{40}', args.final_source_commit)
    assert re.fullmatch('[0-9a-f]{64}', args.global_caption_sha256)
    assert re.fullmatch('[A-Za-z0-9_-]+', args.run_id)
    pins = pins_from_commit(args.final_source_commit)
    assert pins['videos/ai/ai_text_zh.json'] == args.global_caption_sha256
    assert not changed_pins(pins), changed_pins(pins)
    # Newly introduced untracked critical files may not silently escape the release pin.
    actual_part = {str(p.relative_to(ROOT)) for p in (ROOT / 'videos/ai/ai6').iterdir()
                   if p.is_file() and p.suffix in ['.py', '.json']}
    assert actual_part <= set(pins), sorted(actual_part - set(pins))
    assert scenes_from(subprocess.check_output(['git', 'show', f'{args.final_source_commit}:videos/ai/ai6/manifest.py'], cwd=ROOT, text=True)) == working_scenes
    assert sha(HERE / 'qa_production_endpoint-original.py') == '87a00a2438f120958c658343893d6b0d36934a65d8438beb7790f77384f88a9d'
    out = HERE / ('run-' + args.run_id)
    out.mkdir()  # Immutable run: never reuse/overwrite an uncertain existing attempt.
    env = dict(os.environ, EXPLAINER_CACHED_ONLY='1', EXPLAINER_TTS='silent',
               OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', NUMEXPR_NUM_THREADS='1')
    release = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commit': args.final_source_commit,
               'global_caption_sha256': args.global_caption_sha256, 'source_pins': pins,
               'driver_sha256': sha(Path(__file__)), 'adapter_sha256': sha(HERE / 'read_only_capture.py'),
               'wrapper_sha256': sha(HERE / 'qa_production_endpoint-original.py'), 'case_inventory': cases,
               'selected_cases': selected_cases, 'remaining_queued_cases': remaining_cases,
               'inclusive_stop_after_case': args.stop_after_case,
               'versions_observed': {p: importlib.metadata.version(p) for p in ['manim', 'numpy', 'scipy', 'pillow']},
               'scope': 'Root-released held endpoint capture only; no full-motion/listening/4K approval.'}
    dump(out / 'release.json', release)
    progress = []
    for language, module, scene, title in selected_cases:
        if shutil.disk_usage(ROOT).free < MIN_DISK:
            dump(out / 'STOP.json', {'reason': 'disk below768MiB', 'before_case': language + '/' + scene})
            raise RuntimeError('STOPbeforecase diskguard')
        drift = changed_pins(pins)
        if drift:
            dump(out / 'STOP.json', {'reason': 'released source pin drift', 'before_case': language + '/' + scene, 'drift': drift})
            raise RuntimeError('STOPbeforecase source drift; request new reconciled release')
        case = out / (language + '-' + scene)
        case.mkdir()
        selected = [f'videos/ai/ai6/{module}.py', 'videos/ai/ai6/common.py', 'videos/ai/ai6/compute.py',
                    'videos/ai/ai6/cache_contract.py', 'videos/ai/ai6/contracts.py', 'videos/ai/ai6/zh_lines.py',
                    'videos/ai/ai6/text_zh_add.json', 'videos/ai/ai6/narration_zh.json', 'videos/ai/ai_text_zh.json',
                    'explainer/ai/__init__.py', 'explainer/ai/viz.py', 'explainer/ai/lecture.py', 'explainer/ai/fonts.py',
                    'explainer/analysis/__init__.py', 'explainer/voiceover.py', 'explainer/lang.py', 'explainer/tts.py',
                    'explainer/zh_text.py', 'explainer/zh_templates.py', 'explainer/cache_lock.py',
                    'explainer/paths.py', 'explainer/ai/cache.py', 'tools/qa_series.py']
        before = snapshot_files(selected, case / 'source-before')
        canonical = ROOT / 'renders/qa/production-endpoints-1080/ai6' / language / scene
        witness = preserve_output(canonical, case / 'prior-native-witness')
        standard = ROOT / 'renders/qa/series/ai6' / language / scene
        standard_record = standard_witness(standard, case / 'standard480-witness')
        command = ['nice', '-n', '15', sys.executable, str(HERE / 'read_only_capture.py'), str(case), language, scene]
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        launch_ns = time.time_ns()
        dump(case / 'start.json', {'started': started, 'command': command, 'free_disk': shutil.disk_usage(ROOT).free,
                                 'source_before': before, 'prior_native': witness, 'standard480': standard_record})
        print('START', language, scene, flush=True)
        stop_reason = None
        with (case / 'capture.log').open('w') as log:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + 1800
            while process.poll() is None:
                if shutil.disk_usage(ROOT).free < MIN_DISK or time.monotonic() > deadline:
                    stop_reason = 'disk below768MiB' if shutil.disk_usage(ROOT).free < MIN_DISK else 'case timeout1800s'
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL)
                        process.wait()
                    break
                time.sleep(.5)
        after = snapshot_files(selected, case / 'source-after')
        captured = preserve_output(canonical, case / 'native')
        drift = changed_pins(pins)
        result_path = case / 'native/result.json'
        raw = json.loads(result_path.read_text()) if result_path.exists() else None
        # A child can fail before writing a new record. Never relabel an old
        # canonical result as a successful new capture.
        fresh_result = bool(raw and (canonical / 'result.json').stat().st_mtime_ns >= launch_ns
                            and all((canonical / f['file']).stat().st_mtime_ns >= launch_ns
                                    for f in raw.get('frames', [])))
        manual = raw.get('manual_capture_configuration', {}) if raw else {}
        native_postcondition = manual.get('pixel_width') == 1920 and manual.get('pixel_height') == 1080
        guarded = json.loads((case / 'guarded-reads.json').read_text()) if (case / 'guarded-reads.json').exists() else None
        inputs = []
        if raw and fresh_result:
            for rel, signature in raw.get('inputs', {}).items():
                p = ROOT / rel
                inputs.append({'path': rel, 'sha256': sha(p) if p.is_file() else None,
                               'captured_signature': signature, 'current_signature': [p.stat().st_size, p.stat().st_mtime_ns] if p.is_file() else None})
            text_path = case / 'native/text.jsonl'
            entries = [json.loads(line) for line in text_path.read_text().splitlines() if line] if text_path.exists() else []
            strings = list(dict.fromkeys(e['s'] for e in entries))
            before_projection = caption_projection((case / 'source-before/explainer/zh_text.py').read_text(),
                                json.loads((case / 'source-before/videos/ai/ai_text_zh.json').read_text()), strings)
            after_projection = caption_projection((case / 'source-after/explainer/zh_text.py').read_text(),
                                json.loads((case / 'source-after/videos/ai/ai_text_zh.json').read_text()), strings)
            old480 = json.loads((case / 'standard480-witness/result.json').read_text()) if (case / 'standard480-witness/result.json').exists() else {}
            native_lines, old_lines = raw.get('narration', []), old480.get('narration', [])
            utterance_comparison = [{'index': index, 'raw_exact': a.get('raw') == b.get('raw'),
                                    'translated_clean_text_exact': a.get('text') == b.get('text'),
                                    'native_start': a.get('start'), 'prior480_start': b.get('start'),
                                    'native_duration': a.get('duration'), 'prior480_duration': b.get('duration')}
                                   for index, (a, b) in enumerate(zip(native_lines, old_lines))]
            dump(case / 'used-caption-narration-scope.json', {'lookup_inputs': strings, 'projection_before': before_projection,
                 'projection_after': after_projection, 'used_lookup_outputs_unchanged': before_projection == after_projection,
                 'actual_captured_narration': raw.get('narration'), 'standard480_captured_narration': old480.get('narration'),
                 'native_vs480_utterance_count': [len(native_lines), len(old_lines)],
                 'native_vs480_utterance_comparison': utterance_comparison,
                 'actual_texts': [[f['time'], f.get('texts')] for f in raw.get('frames', [])],
                 'scope': 'Actual collected inputs/captured outputs and pure frozen translator projections. Source copies are observations, not historical-import proof; no blanket currentness or visual approval.'})
        receipt = {'case': language + '/' + scene, 'started': started, 'completed': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   'exit': process.returncode, 'stop_reason': stop_reason, 'source_before': before, 'source_after': after,
                   'new_result_freshly_written': fresh_result, 'native_wrapper_postcondition': native_postcondition,
                   'released_source_drift_after': drift, 'copies': captured, 'raw_status': raw.get('status') if raw else None,
                   'raw_warnings': raw.get('warnings') if raw else None, 'raw_fingerprint': raw.get('fingerprint') if raw else None,
                   'guarded_reads': guarded, 'inputs': inputs, 'visual_review': 'pending', 'native_dimensions': [1920, 1080]}
        dump(case / 'receipt.json', receipt)
        if raw and fresh_result and native_postcondition and raw.get('frames'):
            frames, pages = review_plan(case, raw)
            receipt.update(native_frames=frames, review_pages=pages)
            dump(case / 'receipt.json', receipt)
        progress.append(receipt)
        dump(out / 'progress.json', progress)
        print('DONE', language, scene, process.returncode, receipt['raw_status'], receipt.get('native_frames'), flush=True)
        if (stop_reason or drift or not fresh_result or not native_postcondition or not raw
                or raw.get('status') not in ['passed', 'needs-review'] or not guarded or guarded['denied_calls']):
            dump(out / 'STOP.json', {'reason': 'case incomplete/guard/source drift', 'case': language + '/' + scene})
            raise RuntimeError('STOP after preserving case; reconcile before another source pin')
        # Warning exit1 never skips later cases solely due shell chaining.
    dump(out / 'capture-complete.json', {'completed_runtime_cases': len(progress),
         'planned_runtime_cases': len(selected_cases), 'total_inventory_cases': len(cases),
         'remaining_queued_cases': remaining_cases, 'visual_review': 'pending',
         'scope': 'Only selected manifest-prefix runtime captures completed; allpage/nativeactualreview separately recorded. Remaining cases were not attempted or passed.'})

if __name__ == '__main__':
    main()
