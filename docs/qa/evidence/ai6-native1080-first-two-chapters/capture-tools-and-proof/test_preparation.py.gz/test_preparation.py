import ast,hashlib,importlib.util,json,subprocess,sys,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
B=Path(__file__).resolve().parent;R=Path('/workspace/explainer-videos');spec=importlib.util.spec_from_file_location('prepared_native_driver',B/'capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Preparation(unittest.TestCase):
 def test_first_two_chapter_cap_retains_remaining34_without_skip_pass(self):
  scenes=m.scenes_from((R/'videos/ai/ai6/manifest.py').read_text());all_cases=[(l,mod,s,title) for mod,s,title in scenes for l in ['en','zh']];chosen,remaining=m.prefix_cases(all_cases,'LeastSquares:zh');self.assertEqual(len(chosen),4);self.assertEqual(len(remaining),34);self.assertEqual(chosen[-1][0:3],('zh','s02_lsq','LeastSquares'));self.assertEqual(remaining[0][2],'GaussMarkov')
  with self.assertRaises(ValueError):m.prefix_cases(all_cases,'Unknown:zh')
 def test_no_release_refuses_before_capture(self):
  p=subprocess.run([sys.executable,str(B/'capture.py')],capture_output=True,text=True)
  self.assertEqual(p.returncode,2);self.assertIn('no captures started',p.stderr)
 def test_manifest_has38_unique_cases_in_chapter_then_language_order(self):
  scenes=m.scenes_from((R/'videos/ai/ai6/manifest.py').read_text());self.assertEqual(len(scenes),19);cases=[(l,s) for _,s,_ in scenes for l in ['en','zh']];self.assertEqual(len(set(cases)),38);self.assertEqual(cases[:2],[('en','Hook'),('zh','Hook')])
 def test_copy2_is_a_real_independent_witness(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'before';p.write_text('original');q=Path(d)/'copy';row=m.copy2_verified(p,q);p.write_text('changed');self.assertEqual(q.read_text(),'original');self.assertEqual(row['sha256'],hashlib.sha256(b'original').hexdigest())
 def test_actual_caption_lookup_proof_is_scoped_to_used_strings(self):
  src=(R/'explainer/zh_text.py').read_text();old={'strings':{'training pages: $448$':'训练页：$448$'},'patterns':[]};new={'strings':dict(old['strings'],unused='未使用'),'patterns':[]};self.assertEqual(m.caption_projection(src,old,['training pages: $448$']),m.caption_projection(src,new,['training pages: $448$']));changed={'strings':{'training pages: $448$':'错误'},'patterns':[]};self.assertNotEqual(m.caption_projection(src,old,['training pages: $448$']),m.caption_projection(src,changed,['training pages: $448$']))
 def read_function(self):
  node=next(n for n in ast.parse((B/'read_only_capture.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='cached_speech_only');return node
 def test_missing_silent_audio_never_calls_synthesizer(self):
  with tempfile.TemporaryDirectory() as d:
   called=[];scope={'tts':SimpleNamespace(cache_key=lambda t:(t,t,'fixture'),CACHE_DIR=Path(d)), 'original_synthesize':lambda t:called.append(t),'sha':lambda p:'unused','speech_reads':[],'language':'en'};exec(compile(ast.Module([self.read_function()],type_ignores=[]),'actual-readonly-audio-guard','exec'),scope)
   with self.assertRaises(FileNotFoundError):scope['cached_speech_only']('text')
   self.assertEqual(called,[]);self.assertEqual(list(Path(d).iterdir()),[])
 def test_existing_fixture_payload_read_is_hash_and_mtime_preserving(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d)
   for suffix in ['.wav','.json']:(root/('fixture'+suffix)).write_bytes(b'fixture-only-not-real-speech')
   scope={'tts':SimpleNamespace(cache_key=lambda t:(t,t,'fixture'),CACHE_DIR=root,BACKEND='silent',VOICE='fixture',SPEED=1.),'original_synthesize':lambda t:'cached-value','sha':lambda p:hashlib.sha256(p.read_bytes()).hexdigest(),'speech_reads':[],'language':'en'};exec(compile(ast.Module([self.read_function()],type_ignores=[]),'actual-readonly-audio-guard','exec'),scope);self.assertEqual(scope['cached_speech_only']('text'),'cached-value');self.assertEqual(len(scope['speech_reads']),1)
if __name__=='__main__':unittest.main()
