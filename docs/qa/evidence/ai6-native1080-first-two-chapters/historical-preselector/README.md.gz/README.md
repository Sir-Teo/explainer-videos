# Part6 native1080 endpoint pass: prepared, not released

No native capture has run. `capture.py --prepare-plan` read the manifest AST only and prepared all19chapters ×EN/ZH =38cases, in chapter order with EN thenZH. Root must provide the final committed source/table identity after the pending LeastSquares/Ridge/qualification batch. Working pending hashes are never approval pins.

After root explicitly releases the final pin, the command is:

```bash
source /workspace/runtime/activate.sh
export EXPLAINER_CACHED_ONLY=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
python /workspace/runtime/ai6-native1080-preparation/capture.py \
  --final-source-commit FINAL_40_HEX_COMMIT \
  --global-caption-sha256 FINAL_64_HEX_TABLE_SHA \
  --release root-confirmed --run-id FINAL_UNIQUE_RUN_ID
```

This ONE serial driver refuses missing release arguments, concurrent copies of itself, mismatched working source, missing/untracked Part6critical files, source drift, stale existing results, unexpected dimensions, missing cached speech, production attempts, less than768MiB free disk, and cases exceeding1800seconds. It never auto-retries an existing run ID, deletes data or overwrites a previous private run. Warning exit1 is preserved and does not by itself skip later cases; actual failures/drift stop after preserving the partial outcome. There is no CI, deployment, model download/inference, numerical producer, speech synthesis or scientific payload rewrite.

The unchanged previously used `qa_production_endpoint.py` is pinned here as `qa_production_endpoint-original.py` (87a00a2438f120958c658343893d6b0d36934a65d8438beb7790f77384f88a9d). It uses the existing cached-only worker,1920×1080/nominal30fps with animations skipped and silent timing placeholders. A private adapter forbids Part6producer/save/preparation paths and all synthesis/WAV-writing entry points. Existing silent WAV/JSON pairs must already exist and remain hash/size/mtime-identical. Transient advisory locks are not audio/data payload rewrites. Missing preview audio blocks the case until the ordinary480QA workflow has populated it; no threshold or schema rule is weakened.

Each new run pins the exact committed Part6sources/local tables, all `explainer` Python helpers, shared caption table and QA worker. Before/after observations and independently copied direct/shared source bytes are recorded per case, with independent prior-native and nonbusy480witnesses. Native PNGs/raw result/text/log are copied using copy2 with independent-inode checks. Inputs retain actual size/mtime/hash or explicit known absence. Raw fingerprints/status/warnings are never rewritten into approval. Actual collected English caption keys, native visible strings, captured narration,480utterance comparisons and frozen before/after translation projections permit scoped analysis if peers change unrelated templates; they do not establish historical-import proof. A released pin drift stops the subsequent queue for root reconciliation.

Review plans expose every actual native PNG/time/SHA/dimensions dynamically. Four-image chronological pages use960×540tiles from1920×1080originals (declared50% scale). Every page must actually be viewed; dense/critical labels/formulae/plot joins and suspected issues need separate original1920×1080views. `mark_review.py CASE page 1,2 'actual observation'` or `... native 3,7 'actual observation'` records ONLY images already inspected. View ledgers start empty. Endpoint capture/runtime completion never implies visual approval, full1080motion,4K, continuous playback, real narration/listening/synchronization or assembled production approval. Known skipped-updater artifacts require motion evidence before a source defect is inferred.

Prior Part5 actual reference:38serial native cases /604PNGs /91,014,994PNGbytes; aggregate capture-and-freeze time1169.832seconds, median25.996seconds, maximum77.445seconds per case. These are historical measurements, not a Part6duration/size guarantee. Independent native copies, pages, snapshots and TeX add storage beyond PNGbytes. Current2.8GiBfree is compatible with starting only when the release arrives, but free space is checked anew before and during every case; the768MiB reserve controls stopping. No large archives/movies are copied by this driver.

Six preparation fixtures passed: refusal without release,38unique manifest cases/order, genuine independent copies, actual frozen caption lookup scopes, missing-audio zero-synthesis behavior, and unchanged existing-fixture payload reads. These are script fixtures, not native-render evidence. No render command or new native production image was executed during preparation.
