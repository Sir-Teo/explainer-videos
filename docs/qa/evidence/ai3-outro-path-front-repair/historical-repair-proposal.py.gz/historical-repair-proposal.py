# Proposal only: not integrated or executed against a production scene.
# Use with existing self.play(..., run_time=3.0), retaining default smooth rate.
def smooth_trail_reveal(path, dot):
    full = path.copy()  # immutable original smooth cubic control points
    family = VGroup(path, dot)

    def reveal(group, alpha):
        visible, marker = group
        visible.pointwise_become_partial(full, 0, alpha)
        marker.move_to(visible.get_end())

    return UpdateFromAlphaFunc(family, reveal)
