# Part5 producer/cache preflight (read-only)

All28 registered compute items and all19 manifest scene load sites were inspected statically. No `.cache/ai5` directory exists. This preparation does not complete Part5 QA. Sources were hashed before/after and remained unchanged; exact refs and hashes are in `sources.json`, complete dependencies/assertions/returns in `inventory.json`, and all scene load sites in `scene-item-map.json`.

Eight bounded actual-helper fixtures are in `fixtures.json`: stale partial, omitted resume identity, missing NPZ, corrupt JSON, stale dependent item, atomic replacement control, declared-parameter/finalization control, and zero-common-token judge boundary. They execute AST-extracted cache/lock or judge definitions only, on disposable files/tiny deterministic tensors. No production producer, loader, trained model, tokenizer or scene is imported.

## Current available upstream assets

Raw JSON confirms novels base **2,929 steps**, last recorded step2,928, `diverged=false`; base weight file27,390,812B is only hashed, not deserialized. Train/valid uint16 arrays contain6,596,815/346,584 IDs, all0–4095. Tokenizer/base/metadata and Part1 train/valid/passage/bigram/letters are present. GPT-2 local ref is `607a30d783dfa663caf39e06633721c8d4cfcd7e`; all seven snapshot files resolve (550,959,861B total). Exact raw-file identities are in `upstream.json`. Part3 numerical `gpt2.json/.npz` is not the input to Part5 inference; Part5 directly resolves HF model/tokenizer files. Evicted Qwen1.7B files are not a Part5 dependency.

## Concrete findings and bounded repairs

### P5-C01: Whole-item cache has no recipe/schema/dependency validation

Priority: high before producer execution. Refs: videos/ai/ai5/compute.py:33-34,1218-1248; explainer/ai/cache.py:76-97,119-138; tools/qa_series.py:278-306.

fixtures missing-array-sidecar, corrupt-cache-cli-skip and dependent-cache-stale reproduce acceptance with actual AST-extracted generic Cache methods.
Ai5 supplies no cache_current; cached-only QA rejects absentJSON but cannot distinguish stale/corrupt/array-incomplete results before ordinary load.

No .cache/ai5 exists now: no present corrupt/stale Part5 asset asserted. This is an observed contract defect on controlled tiny cache files, relevant before first long run and future reuse.

Proposed bounded repair: Part5-local SchemaCache contract: item-specific required keys/shapes/dtypes/finite/nonfinite policy, JSON/NPZ identity and schema, exact producer/helper recipe plus declared upstream digests. Expose cache_current and make cached-only stale fail explicitly without computing. Compute/invalidate under existing item lock; do not weaken shared Parts1–4 contracts. Invalid upstreams must be reported before any loader.

### P5-C02: Decoding partial reuse not bound to measured experiment

Priority: high before decoding/resume. Refs: videos/ai/ai5/decoding.py:144-159; explainer/ai/cache.py:32-55.

Actual Partial fixture retains OLD metric when generator identity changes to NEW; same actual params dictionary is used.
params contains settings/prompts/samples/gen/v2; omitsPROMPT_LEN,promptseed,generationseeds,actualselectedpromptIDs/text,baseweights/tokenizer/validdata,GPT-2weights/tokenizerrevision,sourceversions.

Proposed bounded repair: Versioned decoding checkpoint contract including all experiment constants/seeds/metric definitions, selectedpromptID/text hash, exact upstreamfile/model/tokenizer fingerprints and producer/helperhashes. Validate each completed entry for finite metric domains/lengths/cohort and mark incompatible partial stale under lock; preserve/quarantine old proof rather than mix metrics. Include same provenance in final cache. Changes to legitimate parameter contract should explicitly invalidate; existing declared-param invalidation and atomic pieces already work.

### P5-C03: Missing upstream can silently train/download/rebuild

Priority: high resource/data guard before compute. Refs: videos/ai/ai5/decoding.py:34-45,144-155; explainer/ai/novels.py:37-46,49-66,82-96,99-134; videos/ai/ai5/compute.py:93-95,157-165.

gpt2 tries local then online with unpinnedmain; novels.load_base trains if weights ormetadata absent; token_arrays/tokenizer/_texts can rebuild andPart1 books maydownload.
Ai5 markov computes Part1 item before calling _save, so that computation occurs outside _save item lock and can duplicate other owners; normal c1.load performs compute underlock.

RequiredcurrentPart1files/base/arrays/localGPT-2snapshot are actually present andhashed. No training/download necessary based on filepreflight, but modelcompatibility not loaded/tested.

Proposed bounded repair: Root precompute gate validates exact completed2929stepbase+tokenizer+tokenarrays+Part1corpus andresolves fixed GPT-2revision local-only, validates requiredfiles before model imports; fail missing/stale with target/reason. Replace redundantPart1 existence/_save path with guarded current load or explicitpreflight; no model-loader/globalsharednovels rewrite required for boundedPart5fix.

### P5-C04: Judge zero-common-token boundary uses negative slice

Priority: medium robustness. Refs: videos/ai/ai5/decoding.py:109-127.

Actualjudge AST with tiny fake tokenizer/judge: prompttoken[9], concatenation[0,1,2] causesk0; currentNLL1.6094379 instead of2.3025851 for bothavailable autoregressivetargets. No actualdefaultpromptoccurrence asserted.

Proposed bounded repair: Clamp scoring offset max(k-1,0); define empty/one-token/no-continuation behavior andguard zerochar denominators; preserve ordinaryk>=1 behavior with boundary-retokenization fixtures.

### P5-C05: Prompt selector has unbounded rejection and limited length guards

Priority: medium robustness. Refs: videos/ai/ai5/decoding.py:70-90.

Source while len(out)<12 has no attemptbound; a validarray containing no newline or noqualifying72-token segment never terminates. len(valid)<=200 fails integers upperbound before usefuldiagnostic. Existingvalidarray346,584tokens ispresent; noactualdefaultfailureasserted.

Proposed bounded repair: Validate lengths/specialIDs, precomputeadmissible starts orcap deterministicattempts; fail clear error with availablecandidatecount, requestedprompts andinputfingerprint.

### P5-C06: Statistical outcomes are hard assertions and long nondecoding work is not resumable

Priority: medium methodology. Refs: inventory.json assertion entries for all28producers; videos/ai/ai5/compute.py:48-120,198-325,518-620,1102-1162.

Examples chi2<30, oneposteriorCIcontainsreference, MonteCarlo/importanceaccuracy, mixtureoccupancy, Brownianvariance, Fisherasymptoticcloseness, Itoslope are hoped stochasticoutcomes, distinctfrom algebraic/probabilityinvariants.
Fisher~3.49B climb-elementvisits, diffusion400Mparticleupdates, shape450Mpairdistances; onlydecoding is partialcheckpointed. Noactualdefaultseedfailureclaim.

Proposed bounded repair: Retain structural/numerical integrity assertions; store measured checkpass/threshold/seed/cohort ratherthan rejecting validrandomresults. Consumers qualify unmet expectations. Add bounded per-family/perconfiguration resume only if measured runtime justifies, provenance-bound likeC02; keep singleproducerowner. Record walltime/context first then update README estimates.

### P5-C07: Environment-dependent geometry and generation defaults lack provenance

Priority: medium reproducibility. Refs: videos/ai/ai5/compute.py:123-154,328-351; videos/ai/ai5/decoding.py:34-45.

glyph_points selects resolved font via fc-match thenfallback, so same numerical seed can yielddifferent AIpointcloud; no fontfilehash is returned.
temperature generation inherits model generationconfig defaults beyond suppliedargs; current local7HFfiles arehashed, butfuturemain/generationconfig changes wouldnotinvalidate results.

Proposed bounded repair: Record actual fontfamily/filehash/Pillowversion for shape; pin modelrevision/config/tokenizer/generationconfig andrecordeffectivegenerationparameters/libraryversions for temperature+decoding. No font/modeldownload needed for currentpreflight.

## All28 item work/storage forecast

These are source-derived operation/shape counts, not measured runtime or peak RSS. Persistent outputs are compact retained arrays/statistics (generally KiB; shape and Langevin about1MiB each), whereas transient sampling arrays and model activations dominate memory. Compressed bytes cannot be predicted exactly before compute; provision a bounded initial **20MiB numerical-output allowance** with actual-size checks, separate from existing~551MB GPT-2/model/tokenizer cache and~42MB novels assets. This is a planning allowance, not a proof that all compressed outputs total20MiB. Rendered movies/images/audio are excluded and may dwarf numerical storage.

Readme’s hour/one–two-thread estimate is historical. No current runtime estimate is defensible before measurement. Run one producer owner, honor existing locks, set numeric threads explicitly; decoding currently forcesTorch2threads, while temperature does not setthreads. Interrupted decoding replays the current entire setting (up to96×40tokens and96judgecalls); all other item work restarts from beginning.

| # | Item (source lines) | Work / saved storage |
|---|---|---|
| 1 | `galton` (48–59) | 1,000×12 fair steps; compact saved first80 paths and all1,000 bin totals; no checkpoint. |
| 2 | `clt` (62–69) | 12 short exact 1D convolutions; five distributions saved; no random source. |
| 3 | `mle` (72–86) | 61×65×1,000 broadcast distance grid (~31.72MB float64 temporary); depends on galton. |
| 4 | `bayes` (93–114) | Five posterior grids of2,001points, saved every fourth point; Part1 passage27 text. |
| 5 | `temperature` (123–153) | Two GPT-2 next-token forwards plus4×24 autoregressive tokens; logits arrays2×50,257float32 ≈402,056B; exact config/revision and generation defaults must be bound. |
| 6 | `markov` (157–194) | 27×27 eigendecompositions,13 distributions and400-state walk; Part1 bigram+letters. |
| 7 | `montecarlo` (198–223) | 28,888,000 random point pairs across200 repeats at9Ns plus4,000 path points; two10,000-draw rare-event estimators; saves only400 importance weights. |
| 8 | `mcmc` (232–246) | 6,000 scalar Metropolis transitions; saves6,001×2float64 chain ≈96,016B; no checkpoint. |
| 9 | `brownian` (250–261) | 3 paths at8/64/1,024steps,60×400 Gaussian paths and20,000×4 endpoints; compact histories/histograms. |
| 10 | `diffusion` (265–324) | 20,000 explicit PDE/particle updates ×20,000 particles ≈400M Gaussian draws, streamed; five grid/histogram snapshots and40OU paths; no checkpoint. |
| 11 | `shape` (354–395) | 500 reverse steps ×600 particles ×1,500 mixture centers =450M pair distances; pair-distance matrix7.2MB, broadcast2D difference14.4MB; saved fwd+bwd each51×600×2, ≈979,200B together plus grids/data; no checkpoint. |
| 12 | `lln` (401–408) | 6×5,000 flips; at most160 retained indices perrun; compact. |
| 13 | `conv` (451–475) | 64 repeated FFT convolutions each for exp anduniform; largest exp mass array ≈512k float64 entries (~4.1MB), FFT temporaries larger; final grids6×161 per family. |
| 14 | `gauss` (481–512) | 400,000×2 and3,000,000×4 standard-normal arrays; largest named array96MB, matrix multiplication may coexist with similarly sized temporary; only2,000displaypoints andconditional statistics saved. |
| 15 | `mlebias` (518–536) | 40,000 samples for7sizes through100; largest x array32MB; compact histogram/statistics output. |
| 16 | `fisher` (588–615) | 4,000 Cauchy samples at7sizes through500;40 climbing iterations perstart,6/11/21/25starts dependingn, ≈3.4896B element/climb visits plus score/bisection/log-likelihood work; largest x16MB with several similar temporaries; only summary histograms/statistics saved; no checkpoint. |
| 17 | `map` (621–657) | 200 datasets×45 ridge10×10 solves plusleast-squares; total9,000 smallsolves; fits/errors/statistics only. |
| 18 | `maxent` (678–722) | 60-step Newton fits,61-step replay and20,000 feasible die draws; whileloop has no cap; on-line grids4,001points; saves6otherdice andsummary histogram. |
| 19 | `tails` (728–759) | 1,000,000binomial draws,29 threshold reductions andfixed-n search; largest draws8MB; summary arrays/histogram. |
| 20 | `draws` (765–813) | 20k inverse/rejection examples,100k Box-Muller normal coordinates,200k×6Gumbels (~9.6MB) and20k×6relaxations; summary/truncatedexamples. |
| 21 | `mixing` (840–889) | 8eigendecompositions of41×41 and300,000 vector×41×41 transitions (~504M matrix multiply-add terms); seven41point snapshots; no checkpoint. |
| 22 | `ess` (895–918) | 5seeds×8dimensions×5,000draws (largest5,000×200=8MB); ESS arrays5×8; uses first400stored rare-event weights frommontecarlo, n_rare explicitly400. |
| 23 | `scorefn` (929–988) | 400k analytic samples,6,000population-gradient probes andup to16×1,000×16objective evaluations; divergence stops early, paths padded/clipped andfinal-1sentinel; saves201-step paths. |
| 24 | `langevin` (1018–1096) | 4configs×5seeds×20,000=400k sequential transitions; plus1,500particles×400updates,7KDEgrids41×31against1,500particles; largest KDEdistancearray15.252MB; frames81×600×2≈777,600B; no checkpoint. |
| 25 | `qv` (1102–1128) | 400Brownianpaths×16,384fineincrements in4chunks; largest100×16,384array13.1072MB plusW/inc temporaries; onlysummary stats andone1,025point path saved. |
| 26 | `ito` (1131–1160) | 2,000paths at7sizes through10,000; largest individual20Mfloat64array160MB; dW,W,eW andproducts coexist, plan substantially above160MB (several hundredMB to~1GB), not a measured peak; compactstatistics/101point replay. |
| 27 | `em` (1163–1203) | 20,000×512=10.24Mfine increments81.92MB; coarse/full increments andtemporaries coexist;9coupled resolution loops; final129point exactpath/threeEMpaths anderrors. |
| 28 | `decoding` (1209–1215) | 16settings (1greedy+15stochastic):12×(1+15×8)×40=58,080generatedtokens;640batched generator forwards +1finaldistribution;1,452generatedcontinuations+12humanreference=1,464GPT-2judgeforwards; max96parallel generator sequences; checkpoints after the human reference and each complete setting; no intrastep resume. |

## Safe pre-compute sequence proposal

1. Freeze reviewed producer/helper recipes and explicit item contracts, then validate required upstream files and the completed base without loader calls. Fail missing/stale; no opportunistic training/download.
2. Pin and record exact local GPT-2 revision, tokenizer/config/weights/generation configuration and runtime package versions. Keep current completed upstream assets read-only.
3. Run dependency-ordered cached numerical computation with a single owner, preserving logs/timings/peak-memory observations and partial/final contracts. Validate outputs and unmet statistical expectations separately.
4. Only after every required item is current/complete, root can start cached-only scene endpoints/motion in manifest order and compare README numbers with actual outputs.

No action was denied or uncertain. Remaining blockers are source/contract repairs and root-authorized measured computation; no Part5 producer/model/render has been started by this review.
