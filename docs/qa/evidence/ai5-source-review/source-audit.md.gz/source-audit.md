# Part 5: read-only source preparation

This prepares the next sequential review. **This task has not begun or completed Part 5 rendered QA.** It made no Part 5 source or cache changes, imported no scenes, ran no production experiment, downloaded no model, and produced no renders. It used source/AST inspection, public primary sources, and small standalone mathematical counterexamples. Every inventoried Part 5 file remains byte-identical.

The complete machine-readable findings, exact source hashes, narration expressions, citation calls, dependency inventory and counterexample values are in `report.json`, `inventory.json` and `standalone-counterexamples.json`.

## Inventory

There are **19 manifest scenes**, comprising a hook, 17 numbered chapters and an outro; **28 compute items**; and **106 narration blocks**. Bilingual endpoint captures and silent-motion renders would be 38 cases each, or 76 separate jobs before audio or native-resolution checks. This is an inventory, not completed coverage.

| Position | Scene | Direct cached items |
|---|---|---|
| 1 | Hook | shape |
| 2 | Bell | clt, conv, galton, lln |
| 3 | Gauss | gauss |
| 4 | Likelihood | galton, mle, mlebias |
| 5 | Fisher | fisher |
| 6 | Bayes | bayes, map |
| 7 | MaxEnt | maxent |
| 8 | Tails | tails |
| 9 | Sampling | draws, markov |
| 10 | Decoding | decoding, temperature |
| 11 | Markov | markov, mixing |
| 12 | MonteCarlo | ess, montecarlo |
| 13 | ScoreFn | scorefn |
| 14 | MCMC | langevin, mcmc |
| 15 | Brownian | brownian, qv |
| 16 | Ito | ito |
| 17 | SDE | diffusion, em |
| 18 | FokkerPlanck | diffusion, langevin, shape |
| 19 | Outro | conv, decoding, fisher, gauss, langevin, maxent, shape, tails |

`s08_mcmc.py` is a compatibility reexport of `heat_image` for Part 7, not another manifest chapter. Preserve that dependency during later changes.

The AST-only Chinese translation inventory reports **146 of 146 source fragments covered**, without ambiguity warnings. That establishes lookup coverage only; it does not approve translation meaning, numeric fields, rendered text or listening.

## Findings to resolve during implementation

These are source or mathematical findings, not observed failures of rendered output or the default seeded runs. P1 identifies central numerical or teaching issues; P2 identifies narrower mismatches and conditional branches.

1. **F01 · P2 — 16 decoding settings are described as 17.** `decoding.py:23–29` defines 1 greedy + 4 temperature + 3 top-k + 4 top-p + 4 min-p settings. The human continuation is a separate reference. `s11_decoding.py:298` and the README say 17. Use the actual setting count and disclose that greedy produces one continuation per prompt while stochastic settings produce eight.

2. **F02 · P1 — Exact Gaussian reverse conditioning is overgeneralized.** `s03_gauss.py:227–238` says every diffusion-model backward step is a Gaussian conditional given by the displayed formula. Gaussian forward noise does not imply this: if clean data is equally likely to be −1 or +1, its posterior after observing a noisy value of zero is still two atoms. DDPM's exact Gaussian posterior additionally conditions on the clean sample, `q(x[t−1] | x[t], x0)`; its learned reverse Gaussian is a model choice. Qualify the history card and narration accordingly.

3. **F03 · P1 — Temperature and its inverse are confused.** `s07_maxent.py:235–237` calls temperature the energy Lagrange multiplier in `p ∝ exp(−E/T)`. The multiplier is inverse temperature, `β = 1/T` when the Boltzmann constant is set to one. Keep the stated convention explicit.

4. **F04 · P1 — “Exact flips needed: 281” is not the smallest qualifying sample size.** `compute.py:748–756` searches for two consecutive successful sample sizes. Exact integer binomial sums give tail probability **0.0475574 at n = 262**, below 0.05; n = 263 rebounds to **0.0543540** because of the integer threshold. Choose between “smallest qualifying fixed n” (262) and “a threshold after which every larger n works” (281 here). The latter can be verified by enumerating 281–599 and using Hoeffding thereafter; two consecutive successes alone are not a general proof. Matching labels are in `s09_tails.py:212–218` and the README.

5. **F05 · P1 — The iid same-batch baseline changes the estimator's expectation.** `compute.py:955–961,970–975` subtracts the same population's sample mean. For N independent probes, the estimator's expectation becomes `(1−1/N)∇J`, or **15/16** of the intended gradient at N = 16. A leave-one-out baseline or finite-batch correction avoids that shrinkage. Exact antithetic pairs are an exception: their mean probe is zero, so subtracting a shared scalar cancels algebraically. Do not apply the iid correction to the mirrored estimator.

6. **F06 · P1 — ES error uses the wrong gradient target.** The estimator/header targets a Gaussian-smoothed objective, but `compute.py:948–961` compares it to the unsmoothed Rosen gradient. At the actual starting point and noise scale, these are **(−6.08, −0.5)** and **(−5.36, −0.4)** respectively. Use the analytic smoothed gradient, or explicitly separate smoothing bias from estimation error. The “gradient's own size” is also a squared norm and needs that unit.

7. **F07 · P2 — ES fallback narration can claim success when every run diverged.** `s14_scorefn.py:208` says both methods reach the valley floor whenever the earlier divergence-count branches do not apply; `(dp, db) = (8, 8)` is a direct counterexample. Derive success from final objectives/statuses. Producer runs stop early on divergence and then pad trajectories, so describe equal nominal caps rather than equal actual evaluation budgets unless actual counts are recorded.

8. **F08 · P1 — Continuous Langevin invariance is attributed to fixed-step ULA.** `s15_mcmc.py:228` says the pictured process's long-run distribution is exactly the target. For a standard-normal target, its discretization has invariant variance `1/(1−h/2)`, giving **1.17647 at h = 0.3**, rather than 1. State the continuous-time result and finite-step bias separately. The later claim that every sampler trades exactness for speed also needs to distinguish MH/MALA target invariance from finite mixing error.

9. **F09 · P1 — The displayed ESS “truth” is an asymptotic proxy.** `compute.py:895–915` and `s13_montecarlo.py:245–265` compare the empirical weight ESS to `N/E[w²]`. At the stated N = 5,000, dimension 200 and width 1.25, the latter is **0.0046866**. The actual weight statistic `(Σw)²/Σw²` is always between 1 and N. Label the population-moment approximation and explain why a finite-sample diagnostic can miss rare important weights; it is not an exact finite-N count.

10. **F10 · P2 — Midpoint stochastic integration is simulatable.** `s17_ito.py:187–190` implies only the left-point integral can be computed in a simulation. Its own producer computes midpoint sums, and official solver documentation provides Stratonovich methods. Explain the non-anticipating Itô definition without implying that midpoint, implicit or corrected Stratonovich numerical schemes are impossible.

11. **F11 · P1 — The Cauchy optimizer does not certify a global MLE.** For n > 20, `compute.py:539–585` starts only within median ±3, makes 40 moves bounded by 0.3, and finally checks stationarity. A constructed 21-point sample `[0 repeated 10 times, 100, 200, …, 1100]` has a local stationary point near **99.928858**, with log-likelihood **−214.41177**, while θ = 0 gives **−136.31852**. The initial search region excludes the dense cluster at zero. This is a conditional mathematical counterexample, not an executed default-data failure. Broaden/validate global peak selection and retain convergence status before calling every output an MLE.

12. **F12 · P2 — BPE-token metrics are called word metrics.** `distinct2` and `rep4` in `decoding.py:131–142` count integer token IDs, but `s11_decoding.py:233,264,301` calls them word pairs and four-word runs. Use “token pairs” and “token 4-grams” in both languages. Keep those units separate from the judge's nats per decoded character.

13. **F13 · P2 — Partial decoding comparisons and judge rankings need guards.** `s11_decoding.py:266–287` can access missing `at['temp']` if another sampler spans diversity 0.85 but temperature does not. Some branches still say “four rules” after filtering. Greedy is called the judge's favourite regardless of actual judge scores; a generator's greedy ranking need not match another model's ranking. Test empty, partial, nonfinite and reversed-ranking branches using actual scene expressions.

14. **F14 · P2 — The best baseline is not the ordinary mean reward in this example.** `s14_scorefn.py:140–142` describes it as near the average of f. Here `E[f] = 2`, whereas the variance-minimizing baseline is `E[f score²]/E[score²] = 4`. Explain the weighting or simply report the measured optimum.

15. **F15 · P2 — Gaussian-slice verdicts do not measure sampling error.** `s03_gauss.py:197–204` uses fixed tolerances of 0.03 for the mean and 5% for variance, then calls them sampling-error checks; failure is automatically attributed to strip width. Compute actual uncertainty and slice bias, or describe the thresholds as tolerances without an unsupported cause.

16. **F16 · P2 — Fokker–Planck error is labelled against the wrong reference.** `compute.py:308–322` computes histogram error against the exact analytic density; `s19_fokker.py:151–152` calls it histogram-to-grid-solution error. Relabel it or calculate the intended comparison, ideally using matching bin averages.

17. **F17 · P2 — Component truth differs from the measured halfspace statistic.** `compute.py:1018–1059` measures `x < 0` but uses component mass 2/3 and component variance 0.35 as exact references. For the specified overlapping mixture, **P(X < 0) = 0.66483635** and **Var(X | X < 0) = 0.34141651**. The difference is small; label component references as approximations or use exact partition benchmarks.

18. **F18 · P2 — MCMC outcome wording is not fully data-dependent.** `s15_mcmc.py:288–296` calls big-step ULA the most frequent hopper whenever its spread is biased, without checking the maximum; `best_hops` is unused. Fewer MALA hops do not establish that most cross-valley proposals were refused. Branch on the actual ranking and recorded acceptance/proposal evidence, or report hopping without inferring a cause.

## Dependencies, cost and availability

Part-local edges are `mle → galton`, `mixing → markov` and `ess → montecarlo`. Bayes needs the Part 1 passage; Markov needs Part 1 bigram/letter data. Temperature needs GPT-2. Decoding also needs the shared novels model, tokenizer and held-out tokens.

At inspection, `.cache/ai5` did not exist. The novels weights, tokenizer, held-out tokens and Part 1 letter/bigram files existed; existence/size does not certify compatible content. GPT-2 cache availability was not verified. `Cache.load` can compute missing items, and the GPT-2 loader can download missing weights. Keep one compute owner and use cached-only render gates after source/input freezing.

The README's roughly one-hour estimate and the function's roughly 40-minute decoding comment were **not measured here**. Source workloads identify the likely expensive items:

- **Decoding:** 1,452 generated continuations, or 58,080 novels-model tokens, plus GPT-2 judging and human references; resumes by completed setting.
- **Fisher:** seven sample sizes × 4,000 replications; larger sizes use 25 starts × 40 climbs plus score polishing. This merits separate measurement.
- **Shape:** 500 reverse steps, each evaluating distances for 600 particles against 1,500 points, roughly 450 million pair distances.
- **Diffusion:** 20,000 particles over 20,000 fine time steps, roughly 400 million normal draws.
- **Langevin:** 400,000 chain transitions plus a particle flow and density estimates.
- **Itô:** largest arrays contain 20 million float64 elements, about 160 MB each; several coexist, so peak memory may approach or exceed 1 GiB. This is an array-shape estimate, not measured RSS.
- **Other substantial work:** three million four-dimensional Gaussian points, 20,000 × 512 Euler–Maruyama increments, repeated convolutions, ridge sweeps, 300,000 mixing replay steps, ES runs and 20,000 maximum-entropy dice.

The separate producer reviewer, `motion_foundations`, owns deeper resume/provenance/cost analysis. The static observations here should not replace that review or performance measurements.

## Bounded primary-source checks

- [Ho et al., DDPM](https://arxiv.org/html/2006.11239v2): original equations 1 and 5–7 distinguish learned Gaussian reverse transitions from the exact posterior conditioned on clean x0. This supports F02.
- [Song et al., score-based SDEs](https://arxiv.org/abs/2011.13456): original abstract/history supports the 2020 preprint / 2021 attribution, score-dependent reverse SDE and numerical-solver framing.
- [Shevtsova 2011](https://arxiv.org/abs/1111.6554): original abstract supports the iid Berry–Esseen constant below 0.4748 with finite third absolute moment. The repository's 0.4748 upper bound is conservative.
- [Williams 1992](https://link.springer.com/article/10.1007/BF00992696): publisher abstract/metadata supports REINFORCE and its expected-gradient interpretation. The full baseline theorem or invention priority was not audited.
- [Martino, Elvira and Louzada](https://arxiv.org/abs/1602.03572) and [Agapiou et al.](https://arxiv.org/abs/1511.06196): original abstracts distinguish importance-sampling diagnostics and computational-cost context. The ESS bounds in F09 are standalone algebra; full paper theorems were not checked.
- [Nguyen et al.](https://arxiv.org/abs/2407.01082): original submission history supports the 2024 preprint / ICLR 2025 attribution. [Schaeffer et al.](https://arxiv.org/abs/2506.13681): the June 2025 critique supports the chapter's qualified statement that min-p's evidence was challenged.
- [Itô 1944, Japan Academy](https://www.jstage.jst.go.jp/article/pjab1912/20/8/20_8_519/_article): issuer metadata confirms *Stochastic Integral*, volume 20(8), pages 519–524. Full original text was not read.
- [Nagoya volume 3](https://www.cambridge.org/core/journals/nagoya-mathematical-journal/volume/2DF7D120350921C5AA36B1F5DB12A6D2): publisher-indexed extract supports the 1951 formula paper and pages 55–65; direct fetching timed out. Treat this as metadata/extract evidence.
- [Anderson 1982](https://www.sciencedirect.com/science/article/pii/0304414982900515) and [ANU's author record](https://researchportalplus.anu.edu.au/en/publications/reverse-time-diffusion-equation-models/): title, author, date and reverse-time model abstract agree. The full general-coefficient theorem was not checked.
- [Académie des sciences](https://www.academie-sciences.fr/pdf/revue/PLS_PlisCachetes.pdf): its indexed custodian account supports Doeblin's envelope being opened in 2000, not a full audit of the 1940 manuscript's mathematics.
- [Official SciML SDE solver documentation](https://docs.sciml.ai/DiffEqDocs/stable/solvers/sde_solve/): implemented Stratonovich methods support the numerical-simulation qualification in F10.

No whole papers are included. Ancient discovery dates, all bibliography entries, historical priority and every modern application claim were not exhaustively verified.

## Further qualifications and actual visual review priorities

Retain the iid / positive finite-variance CLT assumptions and finite third moment for the Berry–Esseen rate. The main Bell chapter does this; the recap should preserve it. Concentration requires independence as well as bounded values. MLE efficiency needs regularity qualifications. The reverse SDE formula needs state-independent diffusion for its displayed simple form. The MAP sweep selects lambda using the same synthetic test errors, so label it an oracle demonstration or introduce independent validation.

The later rendered pass should inspect dense derivations and all actual axes/readouts, narrow posterior peaks, clipped histogram/trajectory boundaries, token units and long generated-text wrapping, fixed 3D overlays, Gaussian contour alignment, numerical uncertainty and data-dependent outcomes. In particular, inspect every ladder reveal and the current shared contour helper's output. Helper reuse alone is not evidence of a visual defect.

Full default-data computation, rendered layouts, temporal coverage, audio/narration synchronization, listening and native-resolution approval remain untested in this preparation task.
