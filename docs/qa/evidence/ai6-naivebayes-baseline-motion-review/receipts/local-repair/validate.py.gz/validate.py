from pathlib import Path
import ast,json,hashlib,math,copy,datetime,difflib,os
import numpy as np
from explainer.ai import *
from explainer import lang
R=Path('/workspace/explainer-videos');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=ast.parse((D/'before.py').read_text());after=ast.parse((D/'after.py').read_text())
def method(t,n):return next(x for x in ast.walk(t) if isinstance(x,ast.FunctionDef) and x.name==n)
def dump(x):return ast.dump(x,include_attributes=False)
assert dump(method(before,'construct'))==dump(method(after,'construct'))
assert dump(method(before,'learned'))==dump(method(after,'learned'))
# All original literal strings, including VO/bookmarks/math/captions, remain exact.
def strings(t):return [x.value for x in ast.walk(t) if isinstance(x,ast.Constant) and isinstance(x.value,str)]
# New loop field names are metadata, not displayed strings.
oldstr=strings(before);newstr=strings(after)
from collections import Counter
assert Counter(newstr)-Counter(oldstr)==Counter({'mean':1,'lo':1,'hi':1,'nb':1,'lr':1})
assert Counter(oldstr)-Counter(newstr)==Counter()
for n in ['derive','calibrate']:
 b=copy.deepcopy(method(before,n));a=copy.deepcopy(method(after,n))
 for node in ast.walk(a):
  if isinstance(node,ast.Call):
   node.keywords=[k for k in node.keywords if k.arg not in ['transform','scale_factor']]
   if isinstance(node.func,ast.Name) and node.func.id=='Indicate' and isinstance(node.args[0],ast.Attribute) and node.args[0].attr=='head':node.args[0]=node.args[0].value
 assert dump(a)==dump(b),n
# No actual scene or producer imports: compile only pure common.plot plus constructors before voiceover.
scope=dict(globals());scope.update(NB='#4FD1C5',LR=C.MODEL_Q,PLATT='#B48EF0',DICKENS='#58A6FF',AUSTEN='#E86F8A',HL=C.BITS)
ct=ast.parse((R/'videos/ai/ai6/common.py').read_text());pn=next(n for n in ct.body if isinstance(n,ast.FunctionDef) and n.name=='plot');exec(compile(ast.Module([pn],type_ignores=[]),'actual-pure-plot','exec'),scope)
data={k:json.loads((R/f'.cache/ai6/{k}.json').read_text()) for k in ['nbvslr','calibration']}
# Strip cache envelope only when present (current actual payload is direct dict).
for k,v in data.items():
 if 'data' in v and 'sizes' not in v and 'nb' not in v:data[k]=v['data']
rawpins={k:{'sha256':sha(R/f'.cache/ai6/{k}.json'),'mtime_ns':(R/f'.cache/ai6/{k}.json').stat().st_mtime_ns} for k in data}
receipts=[]
for language in ['en','zh']:
 lang.LANG=language
 s=dict(scope,load=lambda k:data[k],self=None,ladder=lambda *a,**kw:None)
 def prefix(name,stop):
  m=method(after,name);out=[]
  for n in m.body:
   if stop(n):break
   out.append(n)
  exec(compile(ast.Module(out,type_ignores=[]),'actual-NB-'+name,'exec'),s)
 prefix('derive',lambda n:isinstance(n,ast.With))
 cards=s['cards'];boxes=[s[k].box for k in ['gen','dis']]
 boxpts=[b.get_all_points().copy() for b in boxes];boxfill=[b.get_fill_color().to_hex() for b in boxes];boxopacity=[b.get_fill_opacity() for b in boxes]
 cardnotes=[]
 for k,col in [('gen',s['NB']),('dis',s['LR'])]:
  card=s[k];head=card.head;points=head.get_all_points().copy();an=Indicate(head,color=col,scale_factor=1);an.begin()
  for alpha in np.linspace(0,1,21):
   an.interpolate(float(alpha));np.testing.assert_allclose(head.get_all_points(),points,atol=1e-12)
   for i,b in enumerate(boxes):
    np.testing.assert_array_equal(b.get_all_points(),boxpts[i]);assert b.get_fill_color().to_hex()==boxfill[i];assert b.get_fill_opacity()==boxopacity[i]
  an.finish();cardnotes.append({'card':k,'bounds':[float(card.get_left()[0]),float(card.get_right()[0]),float(card.get_bottom()[1]),float(card.get_top()[1])],'rectangle_fill':boxfill[len(cardnotes)],'alphas_checked':21,'geometry_unchanged':True})
 prefix('race',lambda n:isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='key_' for t in n.targets))
 ax=s['ax'];d=data['nbvslr'];maxhi=max(d[k][str(m)]['hi'] for k in ['nb','lr'] for m in s['sizes']);assert s['top']>maxhi
 coords=[]
 for k in ['nb','lr']:
  for m in s['sizes']:
   for field in ['mean','lo','hi']:
    v=d[k][str(m)][field];assert 0<=v<s['top'];pt=ax.c2p(math.log10(m),v);assert np.isfinite(pt).all();assert ax.c2p(0,0)[1]-1e-10<=pt[1]<ax.c2p(0,s['top'])[1];coords.append({'model':k,'n':m,'field':field,'value':v,'point':pt.tolist()})
 # Actual band objects equal the unchanged geometry constructor on original values, no clamp.
 for k,col in [('nb',s['NB']),('lr',s['LR'])]:
  expected=band(ax,s['lx'],[d[k][str(m)]['lo'] for m in s['sizes']],[d[k][str(m)]['hi'] for m in s['sizes']],col,opacity=.18)
  np.testing.assert_array_equal(expected.get_all_points(),s['art'][k][0].get_all_points())
 curve_receipt={'top':s['top'],'ticks':s['yticks'],'max_measured_hi':maxhi,'absolute_headroom':s['top']-maxhi,'relative_headroom':s['top']/maxhi-1,'all90_original_values_inside':True,'geometry_values':coords,'chart_bounds':[float(s['g'].get_left()[0]),float(s['g'].get_right()[0]),float(s['g'].get_bottom()[1]),float(s['g'].get_top()[1])]}
 prefix('calibrate',lambda n:isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='head' for t in n.targets))
 pts=s['panels'][0][2];centers=np.array([p.get_center() for p in pts]);cloudpoints=pts.get_all_points().copy();an=Indicate(pts,color=WHITE,scale_factor=1);an.begin()
 for alpha in np.linspace(0,1,21):
  an.interpolate(float(alpha));np.testing.assert_allclose([p.get_center() for p in pts],centers,atol=1e-12);np.testing.assert_allclose(pts.get_all_points(),cloudpoints,atol=1e-12)
 an.finish();receipts.append({'language':language,'cards':cardnotes,'learning_curve':curve_receipt,'calibration':{'21_intermediate_alphas_points_and_centers_invariant':True,'centers':centers.tolist()}})
for k,v in rawpins.items():assert sha(R/f'.cache/ai6/{k}.json')==v['sha256'] and (R/f'.cache/ai6/{k}.json').stat().st_mtime_ns==v['mtime_ns']
(D/'geometry.json').write_text(json.dumps({'cases':receipts,'cache_readonly':rawpins,'no_scene_or_producer_import':True,'scope':'Actual Manim geometry/interpolation on AST-selected source constructors and read-only JSON; no scene render, no producer/load function/model, no visual acceptance.'},indent=2)+'\n')
(D/'source.patch').write_text(''.join(difflib.unified_diff((D/'before.py').read_text().splitlines(True),(D/'after.py').read_text().splitlines(True),fromfile='before/s08_bayes.py',tofile='after/s08_bayes.py')))
(D/'freeze.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_sha256':sha(D/'before.py'),'after_sha256':sha(D/'after.py'),'current_source_matches':sha(R/'videos/ai/ai6/s08_bayes.py')==sha(D/'after.py'),'all_source_displayed_strings_and_VO_bookmarks_preserved':True,'construct_learned_AST_exact':True,'derive_calibrate_AST_exact_after_removing_only_authorized_changes':True,'new_captions':[],'axis_numeric_changes':{'before_top':.32,'after_top':receipts[0]['learning_curve']['top'],'ticks':receipts[0]['learning_curve']['ticks']},'producer_data_unchanged':True,'requested_timing_unchanged':True,'fresh_bilingual_visual_regression':'pending root','geometry_sha256':sha(D/'geometry.json')},indent=2)+'\n')
print(json.dumps({'source_sha256':sha(D/'after.py'),'both_languages':True,'top':receipts[0]['learning_curve']['top'],'headroom':receipts[0]['learning_curve']['absolute_headroom'],'readonly_payloads':rawpins,'status':'geometry and AST checks passed; rendered acceptance pending'},indent=2))
