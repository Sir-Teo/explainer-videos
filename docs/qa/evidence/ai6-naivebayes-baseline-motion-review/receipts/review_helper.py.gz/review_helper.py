from pathlib import Path
import json,hashlib,math,sys,datetime
from PIL import Image,ImageDraw
D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def prep(language,mode):
 out=D/language/(mode+'-views');out.mkdir(exist_ok=True)
 if (out/'plan.json').exists():return
 if mode=='endpoints':
  raw=json.loads((D/language/mode/'raw-result.json').read_text());base=Path('/workspace/runtime/ai6-remaining-qa-serial/runs/20261101T055536/08-NaiveBayes')/language/mode/'completed';frames=[dict(x,path=str(base/x['file']),ordinal=i) for i,x in enumerate(raw['frames'])];cols,rows=2,2
 else:
  base=D/language/'audit';raw=json.loads((base/'result.json').read_text());frames=[dict(x,path=str(base/x['file']),ordinal=i) for i,x in enumerate(raw['selected_frames'])];cols,rows=2,4
 unique=[];groups={};allframes=[]
 for f in frames:
  p=Path(f['path']);im=Image.open(p).convert('RGB');pixel=hashlib.sha256(str(im.size).encode()+im.tobytes()).hexdigest();f.update(sha256=sha(p),pixel_sha256=pixel,size=list(im.size));allframes.append(f)
  if mode=='endpoints' or pixel not in groups:unique.append(f)
  groups.setdefault(pixel,[]).append(f['ordinal'])
 pages=[];tile_w=640;tile_h=round(unique[0]['size'][1]*tile_w/unique[0]['size'][0]);per=cols*rows
 for no,offset in enumerate(range(0,len(unique),per),1):
  chunk=unique[offset:offset+per];sheet=Image.new('RGB',(cols*tile_w,math.ceil(len(chunk)/cols)*(tile_h+28)),'#171e28');draw=ImageDraw.Draw(sheet)
  for j,f in enumerate(chunk):
   x=(j%cols)*tile_w;y=(j//cols)*(tile_h+28);draw.text((x+6,y+5),f"{language} {mode} #{f['ordinal']}  {f['time']:.3f}s",fill='white');im=Image.open(f['path']).convert('RGB').resize((tile_w,tile_h));sheet.paste(im,(x,y+28))
  p=out/f'page-{no:03d}.png';sheet.save(p);pages.append({'number':no,'path':str(p),'sha256':sha(p),'ordinals':[f['ordinal'] for f in chunk],'first_time':chunk[0]['time'],'last_time':chunk[-1]['time']})
 (out/'plan.json').write_text(json.dumps({'language':language,'mode':mode,'source_result_sha256':sha((D/language/mode/'raw-result.json') if mode=='endpoints' else (D/language/'audit/result.json')),'frames':allframes,'unique_representatives':[f['ordinal'] for f in unique],'exact_pixel_groups':groups,'pages':pages,'tile_width':tile_w,'tile_height':tile_h,'native_width':unique[0]['size'][0],'dedup_scope':'Within-language exact decoded RGB byte identity including dimensions; no perceptual matching. Endpoint states are all shown directly even when duplicates.'},indent=2)+'\n')
 print(language,mode,'selected',len(frames),'unique',len(unique),'pages',len(pages),flush=True)
def mark(language,mode,kind,ids,note):
 root=D/language/(mode+'-views');plan=json.loads((root/'plan.json').read_text());p=root/'views.json';v=json.loads(p.read_text()) if p.exists() else []
 for no in [int(a) for a in ids.split(',')]:
  item=next(x for x in plan['pages'] if x['number']==no) if kind=='page' else plan['frames'][no];path=Path(item['path']);assert sha(path)==item['sha256'];v.append({'kind':kind,'number':no,'path':str(path),'sha256':sha(path),'viewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scale':'640px tiles from854 native' if kind=='page' else 'original854x480','note':note})
 p.write_text(json.dumps(v,indent=2)+'\n')
if sys.argv[1]=='prep':prep(*sys.argv[2:])
elif sys.argv[1]=='mark':mark(*sys.argv[2:])
