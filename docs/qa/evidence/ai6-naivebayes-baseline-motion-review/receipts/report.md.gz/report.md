# Part6 NaiveBayes baseline review

Both frozen bilingual silent480p15 movies were fully decoded: 4756 frames. Actual visual coverage: 818 selected times, 638 exact-RGB unique images directly viewed on81 chronological640px-tile pages. All26 endpoint states were directly viewed on8pages, plus18 original854px critical followups. Exact unselected gaps are retained inreport.json. This is sampled visual review, not continuous playback/listening.

Four concrete findings: measured upper uncertainty bands silently capped32percent despite stored90th percentile41.4136percent; three retained-copy equation ghosts; enlarged/filled definition-card flashes overlap and clip; calibration point-cloud enlargement shifts quantitative values off axes. Held states recover. Only the band repair has been authorized at baseline closure; fresh repaired EN/ZH review is pending.

Chinese motion rawneeds-review/source-changed-during-render is retained. Parent clearance binds unrelated hbars/Gauss drift; NBdoesnot usehbars, other helper AST unchanged. This is not whole-source/fingerprint equivalence. All74 inventorieddatafiles retain exact hashes/sizes/mtimes. No producer/model/TTS/render execution.

Official Ng/Jordan abstract supports conditional two-regime results: https://proceedings.neurips.cc/paper/2001/hash/7b7a53e239400a13bd6be6c91c4f6c4e-Abstract.html . No change to2002citation is inferred from2001conferenceyear.
