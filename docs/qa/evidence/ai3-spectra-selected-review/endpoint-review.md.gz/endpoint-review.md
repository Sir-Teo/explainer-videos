# Spectra EN/ZH endpoint review

All 31 native 480p endpoint frames (15 EN, 16 ZH) and both sheets were actually viewed. No concrete clipping, held-text overlap,legend/curve obstruction or bilingual mathematical-caption defect was found. This is endpoint review, not motion or listening approval.

Frozen cache labels agree: one 768×3072 random reference, q=.25, edges .25/2.25, 0 strict Gaussian outliers; displayed GPT-2 layer6 MLP-in has 62 strict outliers and largest/edge 8.705→8.7; shuffled 0. The 48 tail fits include 46 in the descriptive 1.5–5 band, 0 unavailable and 0 triangle caps. Selected-tail checks reproduce n=102, alpha=3.5305374 and two-sided KS=.03618997 at cached xmin. The novels plot correctly shows 30 matrices, 7 fresh-reference strict outliers in total and 13–32 trained outliers per matrix. Strict/no 2%-margin, finite-size, omitted-window and descriptive/no GOF disclosures are visible in both languages.

The producer compares trained novels weights with a fresh seed0 same-architecture construction. The base training also uses seed0 immediately before construction, supporting initialization reconstruction under unchanged code/environment; no model load or exact initial-state equality test was performed here. This is not evidence of a saved pre-training weight snapshot.

Direct scene SHA 571d2736… independently matches commit 4a20866abd5d8b5edbf3fd600b0d9474748b790b. Parent attests this module stayed unchanged. The later review-time module snapshot is not represented as import-time bytes. Original endpoint fingerprint a1ea477a… differs from the current aggregate after unrelated Netflix-caption/JL/Geometry/Words work; that gap remains explicit. Both records retain the same exact mp JSON input signature and cached bytes. No producer/scene imports, model compute, downloads, renders, source/global/STATUS edits or commits were performed.

Complete actual times, PNG SHA256s,dimensions, record/data hashes and per-case checklists are in `endpoint-review.json` and `freeze-receipt.json`. Motion review awaits root readiness/hashes. Continuous playback, narration/listening/synchronization and native production-resolution approval remain unverified.
