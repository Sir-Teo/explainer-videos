# Part3 LowRank tailnorm motion regression checkpoint

Dense actual repaired-movie regression for Part3 LowRank tailnorm; exact inspected-baseline PNG reuse only EN+ZH; complete-file decoding automatic. Continuous perceptual playback, audio/listening and final-resolution review remain unverified.

| Case | Duration | Decoded | Selected | Viewed | Exact duplicates | Unreviewed selected | Status |
|---|---:|---:|---:|---:|---:|---:|---|
| en/LowRank | 178.865s | 2683 | 425 | 34 | 5 | 0 | all_selected_appearances_covered |
| zh/LowRank | 183.199s | 2748 | 439 | 42 | 10 | 0 | all_selected_appearances_covered |

Each selected-time map, reviewed sheet SHA/time range, movie/tool/source/input provenance, original capture warnings and native followups are in ai3-lowrank-tailnorm-motion-review.json.

Only exact PNG-byte SHA256 matches justify duplicate reuse. The bounded gap is1s plus RGB-detected transition extras. Full decode is automated and does not imply continuous visual playback.
