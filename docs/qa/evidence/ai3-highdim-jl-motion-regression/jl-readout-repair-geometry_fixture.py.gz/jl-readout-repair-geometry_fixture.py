import ast,hashlib,json,os
from pathlib import Path
from manim import *
from explainer.ai import C,label
root=Path('/workspace/explainer-videos');base=Path(__file__).parent;src=root/'videos/ai/ai3/s16_jl.py';tree=ast.parse(src.read_text());cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='JL');fun=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='squeeze')
selected=[]
for node in fun.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['w10','wcaption','wread'] for t in node.targets):selected.append(node)
 elif isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and isinstance(node.value.func.value,ast.Name) and (node.value.func.value.id,node.value.func.attr) in [('wread','move_to'),('wcaption','add_updater')]:selected.append(node)
assert len(selected)==5
j=json.loads((base/'before-jl.json').read_text());ks=[2,5,20,100,400];namespace=globals()|{'j':j,'ks':ks}
with tempconfig({'media_dir':str(base/'fixture-media'), 'disable_caching':True}):
 exec(compile(ast.Module(body=selected,type_ignores=[]),str(src),'exec'),namespace)
 number,caption,group=(namespace[n] for n in ['w10','wcaption','wread']);records=[]
 for k in ks:
  value=100*j[f'within10_{k}'];number.set_value(value);caption.update(0);gap=caption.get_left()[0]-number.get_right()[0];left,right=group.get_left()[0],group.get_right()[0]
  assert number.num_decimal_places==1;assert abs(gap-.2)<1e-8;assert -config.frame_width/2<=left<right<=config.frame_width/2,(left,right,config.frame_width)
  records.append({'k':k,'measured_percent':value,'displayed_percent':f'{value:.1f}%','descriptor_gap':gap,'group_x_bounds':[left,right]})
 assert records[-1]['displayed_percent']=='99.6%'
lang=os.environ.get('EXPLAINER_LANG','en');out={'language':lang,'fixture':'Actual five AST statements from JL.squeeze, completed-cache numeric values, real DecimalNumber/translated label geometry; no scene load/construct/render','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'data_json_sha256':hashlib.sha256((base/'before-jl.json').read_bytes()).hexdigest(),'records':records,'passed':True};(base/f'geometry-{lang}.json').write_text(json.dumps(out,indent=2)+'\n');print(lang,'geometry PASS',records[-1])
