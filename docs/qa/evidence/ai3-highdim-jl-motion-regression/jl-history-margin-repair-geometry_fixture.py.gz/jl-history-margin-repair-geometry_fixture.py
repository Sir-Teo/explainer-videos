import ast,hashlib,json,os
from pathlib import Path
from manim import *
from explainer.ai import *
root=Path('/workspace/explainer-videos');base=Path(__file__).parent;src=root/'videos/ai/ai3/s16_jl.py';tree=ast.parse(src.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='JL');f=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='worst');helper=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='worst_plot_data')
selected=[]
for n in f.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['g','ax','leg','cap','hist'] for t in n.targets):selected.append(n)
 elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and (n.value.func.value.id,n.value.func.attr)==('hist','shift'):selected.append(n)
assert len(selected)==6
j=json.loads((root/'.cache/ai3/jl.json').read_text());fine=j['fine'];HIST=C.HUMAN;MEAS=C.TRUE_P;BOUND=C.INTERVAL;confidence=100*float(j['confidence']);delta=float(j['delta']);big=[v for v in fine if v['k']>=100]
import math,numpy as np
namespace=globals();exec(compile(ast.Module(body=[helper],type_ignores=[]),str(src),'exec'),namespace);good,measured,omitted=worst_plot_data(fine)
with tempconfig({'media_dir':str(base/'fixture-media'),'disable_caching':True}):exec(compile(ast.Module(body=selected,type_ignores=[]),str(src),'exec'),namespace)
bounds=lambda o:[float(o.get_left()[0]),float(o.get_right()[0]),float(o.get_bottom()[1]),float(o.get_top()[1])]
def overlap(a,b):
 a,b=bounds(a),bounds(b);return min(a[1],b[1])>max(a[0],b[0])+1e-9 and min(a[3],b[3])>max(a[2],b[2])+1e-9
print('OBSERVED',bounds(hist),bounds(cap),float(hist.get_bottom()[1]-cap.get_top()[1]),flush=True)
assert not overlap(hist,cap);assert hist.get_bottom()[1]-cap.get_top()[1]>.1;assert not overlap(hist,leg)
framehalf=config.frame_width/2;frameheight=config.frame_height/2
for o in [hist,cap,leg]:
 left,right,bottom,top=bounds(o);assert -framehalf<=left<right<=framehalf and -frameheight<=bottom<top<=frameheight,(bounds(o),framehalf,frameheight)
data_points=[ax.c2p(x,y) for x,lo,hi,mean in measured for y in [lo,hi,mean]]+[ax.c2p(x,y) for x,y,k in good];max_data_x=max(p[0] for p in data_points);assert hist.get_left()[0]-max_data_x>.1
texts=[o for o in g.family_members_with_points() if isinstance(o,(Tex,MathTex,Text))];collisions=[getattr(o,'tex_string',str(type(o))) for o in texts if overlap(hist,o)];assert not collisions,collisions
old=hist.copy().shift(DOWN*.4);out={'language':os.environ.get('EXPLAINER_LANG','en'),'passed':True,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'fixture':'Six actual JL.worst AST statements construct axes,legend,caption,history card and0.4UPshift; pure plot helper uses completed immutablejl.json; no scene load/construct/render.','history_bounds':bounds(hist),'caption_bounds':bounds(cap),'legend_bounds':bounds(leg),'vertical_caption_gap':float(hist.get_bottom()[1]-cap.get_top()[1]),'data_horizontal_gap':float(hist.get_left()[0]-max_data_x),'plot_text_collisions':collisions,'old_history_bounds':bounds(old),'old_history_caption_bbox_overlap':overlap(old,cap),'disclosure':'The pre-existing card can cover an unlabeled trailing axis-line segment; tested data points,bound segment,axis labels/ticks,legend andcaption remain unobstructed after local lift.'};(base/('geometry-'+out['language']+'.json')).write_text(json.dumps(out,indent=2)+'\n');print(out['language'],'PASS','captiongap',out['vertical_caption_gap'],'datagap',out['data_horizontal_gap'])
