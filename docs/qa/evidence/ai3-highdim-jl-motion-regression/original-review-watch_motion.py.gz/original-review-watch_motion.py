import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/explainer-videos');base=Path(__file__).parent;env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(root/'tools/qa_motion.py')=='1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e'
for lang,scene,module in [('en','HighDim','s15_highdim.py'),('en','JL','s16_jl.py'),('zh','HighDim','s15_highdim.py'),('zh','JL','s16_jl.py')]:
 key=lang+'-'+scene;folder=base/(key+'-motion');folder.mkdir(exist_ok=True);record=root/'renders/qa/series/ai3'/lang/(scene+'_motion')/'result.json';print('Waiting for completed',key,'motion record',flush=True)
 while True:
  try:
   raw=record.read_bytes();d=json.loads(raw)
   if d.get('status') in ['passed','needs-review','failed'] and d.get('movie') and d.get('mode')=='motion':
    movie=root/d['movie']
    if movie.exists():break
  except (FileNotFoundError,json.JSONDecodeError):pass
  time.sleep(5)
 assert d['status']!='failed',d
 (folder/'pre-extraction-render-result.json').write_bytes(raw);shutil.copy2(movie,folder/'frozen-reviewed-movie.mp4');source=root/'videos/ai/ai3'/module;shutil.copy2(source,folder/('pre-extraction-'+module));assert record.read_bytes()==raw
 (folder/'pre-extraction-provenance.json').write_text(json.dumps({'record_sha256':sha(record),'movie_sha256':sha(movie),'source_at_extraction_sha256':sha(source),'render_fingerprint':d['fingerprint'],'warnings':d.get('warnings',[]),'source_linkage':'Direct module captured at extraction; render warnings preserved. No source-at-extraction copy is substituted for proof of a historical import.'},indent=2)+'\n')
 audit=root/'renders/qa/temporal'/('ai3-'+key+'-theory-motion-final');print('Extracting',key,sha(movie),flush=True)
 with (folder/'extraction.log').open('w') as log:subprocess.run(['nice','-n','10',sys.executable,'tools/qa_motion.py',str(movie),'--out',str(audit),'--max-gap','1'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert sha(movie)==sha(folder/'frozen-reviewed-movie.mp4');subprocess.run([sys.executable,str(base/'prepare_motion.py'),lang,scene],cwd=root,env=env,check=True);print('Ready for actual visual review:',key,flush=True)
print('All four audits extracted; no perceptual review is implied by extraction.',flush=True)
