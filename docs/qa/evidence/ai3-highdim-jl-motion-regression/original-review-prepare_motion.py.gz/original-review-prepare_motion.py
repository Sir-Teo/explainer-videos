"""Build exact-PNG representative pages from a completed qa_motion audit; no scene imports."""
import argparse,ast,datetime,hashlib,json,re,shutil
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path('/workspace/explainer-videos');BASE=Path('/workspace/runtime/ai3-highdim-jl-review')
MODULE={'HighDim':'s15_highdim.py','JL':'s16_jl.py'}
def sha(p):
 with open(p,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
p=argparse.ArgumentParser();p.add_argument('lang');p.add_argument('scene');a=p.parse_args();key=a.lang+'-'+a.scene
folder=BASE/(key+'-motion');folder.mkdir(exist_ok=True)
audit=ROOT/'renders/qa/temporal'/('ai3-'+key+'-theory-motion-final')
r=json.loads((audit/'result.json').read_text());render=ROOT/'renders/qa/series/ai3'/a.lang/(a.scene+'_motion')
original=json.loads((render/'result.json').read_text());movie=ROOT/original['movie']
assert sha(movie)==r['source_sha256']
assert r['tool_sha256']=='1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e'
assert r['settings']['maximum_selected_gap_seconds']==1.
for file in ['result.json','render.log','dead_air.log']:
 if (render/file).exists():shutil.copy2(render/file,folder/('render-'+file))
shutil.copy2(audit/'result.json',folder/'audit-result.json')
source=ROOT/'videos/ai/ai3'/MODULE[a.scene];shutil.copy2(source,folder/source.name)
seen={};unique=[];mapping=[]
for index,f in enumerate(r['selected_frames']):
 path=audit/f['file'];assert sha(path)==f['sha256']
 if f['sha256'] not in seen:
  seen[f['sha256']]=len(unique);unique.append({'representative_index':len(unique),'selected_index':index,**f})
 mapping.append({'selected_index':index,'source_frame':f['source_frame'],'time':f['time'],'png_sha256':f['sha256'],'representative_index':seen[f['sha256']],'file':str(path),'reasons':f['reasons']})
pages=[]
for start in range(0,len(unique),8):
 group=unique[start:start+8];canvas=Image.new('RGB',(1280,((len(group)+1)//2)*394),'#202732');draw=ImageDraw.Draw(canvas)
 for offset,f in enumerate(group):
  x=(offset%2)*640;y=(offset//2)*394
  draw.text((x+7,y+4),f"rep{f['representative_index']:03d} | selected{f['selected_index']:03d} | {f['time']:.3f}s",fill='white')
  draw.text((x+7,y+18),f"source frame{f['source_frame']} | "+','.join(f['reasons']),fill='#c6d6e9')
  with Image.open(audit/f['file']) as image:canvas.paste(image.convert('RGB').resize((640,360)),(x,y+34))
 name=f'unique-page-{start//8+1:03d}.png';canvas.save(folder/name)
 pages.append({'file':name,'sha256':sha(folder/name),'representative_indices':list(range(start,start+len(group))),'selected_indices':[f['selected_index'] for f in group],'time_range':[group[0]['time'],group[-1]['time']],'viewed':False})
inputs=[]
for name,sig in original.get('inputs',{}).items():
 path=ROOT/name;stat=path.stat() if path.exists() else None;current=[stat.st_size,stat.st_mtime_ns] if stat else None
 inputs.append({'file':name,'render_signature':sig,'current_signature':current,'signature_matches':sig==current,'sha256':sha(path) if stat else None})
tool=ROOT/'tools/qa_series.py';tree=ast.parse(tool.read_text());func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='fingerprint');env={'ROOT':ROOT,'Path':Path,'__file__':str(tool),'re':re,'hashlib':hashlib};exec(compile(ast.Module(body=[func],type_ignores=[]),str(tool),'exec'),env)
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'case':key,'lang':a.lang,'scene':a.scene,'render_result':str(render/'result.json'),'render_result_sha256':sha(folder/'render-result.json'),'render_status':original['status'],'render_warnings':original.get('warnings',[]),'render_fingerprint':original['fingerprint'],'current_fingerprint':env['fingerprint']('ai3'),'source_file':str(source.relative_to(ROOT)),'source_sha256':sha(source),'movie':str(movie),'movie_sha256':r['source_sha256'],'audit_result':str(audit/'result.json'),'audit_result_sha256':sha(folder/'audit-result.json'),'tool_sha256':r['tool_sha256'],'inputs':inputs,'decoded_frames':r['analysis']['decoded_frames'],'selected_times':len(mapping),'unique_representatives':len(unique),'coverage_start':r['first_decoded_time'],'coverage_end':r['last_decoded_time'],'largest_selected_gap':r['largest_selected_time_gap'],'unavoidable_source_gaps':r['timestamp_quantization']['unavoidable_source_gaps'],'unextracted_frame_gaps':r['unextracted_frame_gaps'],'selected_to_representative':mapping,'unique_representative_frames':unique,'pages':pages,'native_followups':[],'findings':[],'visual_selected_frame_review':'pending','continuous_perceptual_playback':'unverified','audio_listening_and_synchronization':'unverified','limits':r['coverage_limits']}
record['source_linkage']={'meaning':'Direct source hash at audit preparation; pre-worker/fix-freeze snapshots are preserved separately. Render warnings remain explicit; no later current-copy substitution proves an earlier import.'};record['fingerprint_matches_at_freeze']=record['render_fingerprint']==record['current_fingerprint'];(folder/'review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'case':key,'decoded':record['decoded_frames'],'selected':len(mapping),'unique':len(unique),'pages':len(pages),'max_gap':record['largest_selected_gap'],'status':original['status'],'warnings':len(record['render_warnings'])}))
