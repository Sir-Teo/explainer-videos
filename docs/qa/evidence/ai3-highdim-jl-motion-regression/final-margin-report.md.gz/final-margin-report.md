# Final JL history-card margin regression

Both parent-confirmed final b0ce1007 movies pass selected-time visual regression. The English disclosure previously touched by the history-card border now has a visible gap. The unified lift also preserves Chinese readability. Native mid-reveal, settled-card and late-hold views show no data-point, bound-line, legend or tick-text occlusion.

| Final case | Selected times covered | New unique images viewed | Exact PNG inheritance | Changed pages | Native checks |
| --- | ---: | ---: | ---: | ---: | ---: |
| EN JL | 390 | 18 | 274 | 3 | 3 |
| ZH JL | 402 | 19 | 283 | 3 | 3 |

Every selected timestamp is covered. All37changed unique images were directly inspected chronologically;557unique representatives reuse only exact full-PNG hashes from completed original reviews. Both final render records report passed with zero warnings. Movie/source/fingerprint/input hashes and timestamp/page/native/coverage mappings are retained per case. The corrected Chinese64-character movie hash is recorded with the parent's original65-character transcription and explicit correction.

Continuous perceptual playback, audio synchronization, production-resolution layout and player/responsive behavior remain unverified. Unselected frames were not individually perceived. Original before receipts remain unchanged; this report closes only the local final-margin regression.
