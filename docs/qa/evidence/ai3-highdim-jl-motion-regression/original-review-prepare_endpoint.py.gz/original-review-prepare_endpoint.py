import argparse,datetime,hashlib,json,shutil
from pathlib import Path
from PIL import Image,ImageDraw
root=Path('/workspace/explainer-videos');base=Path(__file__).parent
p=argparse.ArgumentParser();p.add_argument('lang');p.add_argument('scene',choices=['HighDim','JL']);p.add_argument('--label',default='');a=p.parse_args();key=a.lang+'-'+a.scene;b=base/(key+'-endpoints'+a.label);b.mkdir(exist_ok=True);src=root/'renders/qa/series/ai3'/a.lang/a.scene
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=(src/'result.json').read_bytes();r=json.loads(raw);assert r['status'] in ['passed','failed','needs-review'];assert r['mode']=='endpoints';assert len(r['frames'])>0
(b/'render-result.json').write_bytes(raw)
for f in ['render.log','dead_air.log']:
 if (src/f).exists():shutil.copy2(src/f,b/f)
frames=[]
for i,f in enumerate(r['frames']):
 file=src/f['file'];shutil.copy2(file,b/file.name);frames.append({'index':i,'file':file.name,'time':f['time'],'reason':f['reason'],'png_sha256':sha(file),'width':Image.open(file).width,'height':Image.open(file).height,'actually_viewed':False})
assert (src/'result.json').read_bytes()==raw
pages=[]
for start in range(0,len(frames),8):
 group=frames[start:start+8];im=Image.new('RGB',(1280,394*((len(group)+1)//2)),'#202732');draw=ImageDraw.Draw(im)
 for k,f in enumerate(group):
  x=(k%2)*640;y=(k//2)*394;draw.text((x+8,y+5),f"endpoint{f['index']:03d} | {f['time']:.3f}s | {f['reason']}",fill='white');im.paste(Image.open(b/f['file']).convert('RGB').resize((640,360)),(x,y+34))
 dest=b/f'page-{start//8+1:03d}.png';im.save(dest);pages.append({'file':dest.name,'sha256':sha(dest),'frame_indices':[f['index'] for f in group],'actually_viewed':False})
module={'HighDim':'s15_highdim.py','JL':'s16_jl.py'}[a.scene];pre=base/'source-pre-worker'/module;current=root/'videos/ai/ai3'/module;shutil.copy2(current,b/module)
inputs=[]
for name,signature in r.get('inputs',{}).items():
 path=root/name;stat=path.stat() if path.exists() else None;inputs.append({'file':name,'render_signature':signature,'current_signature':[stat.st_size,stat.st_mtime_ns] if stat else None,'sha256_at_review':sha(path) if stat else None})
d={'case':key,'kind':'endpoints only','captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'render_record':str(src/'result.json'),'render_record_sha256':sha(b/'render-result.json'),'render_status':r['status'],'warnings':r.get('warnings',[]),'render_fingerprint':r['fingerprint'],'source_module':str(current.relative_to(root)),'pre_worker_source_sha256':sha(pre),'source_sha256_at_review':sha(current),'pre_worker_source_matches':sha(pre)==sha(current),'inputs':inputs,'frames':frames,'pages':pages,'native_followups':[],'findings':[],'review_status':'pending','coverage_limits':['Endpoints only: selected endpoint/hold screenshots, not motion or continuous playback.','No audio listening or narration synchronization approval.','Pre-worker source snapshot and post-worker direct hash agree only if indicated; render warnings and later aggregate drift remain explicit.']};(b/'review.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'case':key,'frames':len(frames),'pages':len(pages),'warnings':r.get('warnings',[]),'source_matches_pre':d['pre_worker_source_matches']}))
