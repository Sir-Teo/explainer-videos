import argparse,datetime,hashlib,json
from pathlib import Path
BASE=Path('/workspace/runtime/ai3-highdim-jl-review')
p=argparse.ArgumentParser();p.add_argument('case');p.add_argument('pages',help='comma-separated page numbers or inclusive ranges');p.add_argument('--note',default='Chronological native-timestamp representatives inspected at original sheet detail; follow-up priorities recorded separately.');a=p.parse_args()
file=BASE/a.case/'review.json';r=json.loads(file.read_text());numbers=set()
for token in a.pages.split(','):
 if '-' in token:
  lo,hi=map(int,token.split('-'));numbers.update(range(lo,hi+1))
 else:numbers.add(int(token))
for i in sorted(numbers):
 page=r['pages'][i-1];path=file.parent/page['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==page['sha256']
 page.update(viewed=True,viewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),view_detail='original1280px-wide sheet;8chronological640x360tiles maximum',review_note=a.note)
actually_viewed={i for page in r['pages'] if page['viewed'] for i in page['representative_indices']}
inherited={f['representative_index'] for f in r.get('inherited_exact_png_representatives',[])}
covered=actually_viewed|inherited
selected=[f for f in r['selected_to_representative'] if f['representative_index'] in covered]
r['checkpoint']={'viewed_pages':sum(p['viewed'] for p in r['pages']),'total_pages':len(r['pages']),'viewed_unique_representatives':len(actually_viewed),'inherited_exact_png_representatives':len(inherited),'covered_unique_representatives':len(covered),'total_unique_representatives':r['unique_representatives'],'selected_times_covered_including_exact_repeats':len(selected),'total_selected_times':r['selected_times'],'viewed_representative_time_range':[min((r['unique_representative_frames'][i]['time'] for i in covered),default=None),max((r['unique_representative_frames'][i]['time'] for i in covered),default=None)],'all_selected_frames_covered':len(selected)==r['selected_times']}
file.write_text(json.dumps(r,indent=2)+'\n');print(r['case'],r['checkpoint'])
