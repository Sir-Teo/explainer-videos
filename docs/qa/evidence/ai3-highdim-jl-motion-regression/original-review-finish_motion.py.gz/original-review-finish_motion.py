import json,sys,hashlib,shutil,datetime
from pathlib import Path
base=Path(__file__).parent;case=sys.argv[1];folder=base/(case+'-motion');p=folder/'review.json';d=json.loads(p.read_text());assert d['checkpoint']['all_selected_frames_covered']
for t in map(float,sys.argv[2:]):
 f=min(d['unique_representative_frames'],key=lambda a:abs(a['time']-t));source=Path(d['audit_result']).parent/f['file'];assert hashlib.sha256(source.read_bytes()).hexdigest()==f['sha256'];dest=folder/('native-'+source.name);shutil.copy2(source,dest);d['native_followups'].append({**f,'evidence':str(dest),'actually_viewed':True})
frozen=folder/'frozen-reviewed-movie.mp4';assert hashlib.sha256(frozen.read_bytes()).hexdigest()==d['movie_sha256'];d['frozen_movie']=str(frozen);d['visual_selected_frame_review']='complete; no additional concrete defect found in reviewed selections';d['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();p.write_text(json.dumps(d,indent=2)+'\n');print(case,'complete',d['checkpoint'])
