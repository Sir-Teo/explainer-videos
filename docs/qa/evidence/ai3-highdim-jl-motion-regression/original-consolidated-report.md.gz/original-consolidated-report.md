# HighDim and JL visual QA

All four initial bilingual endpoint cases and all four silent selected-time motion cases are reviewed. HighDim has no concrete visual defect in this coverage. The Chinese d=10 histogram appears and holds clearly at 18.133–19.000 seconds; the missing endpoint screenshot was a sampling gap, now closed by actual motion-frame review.

| Motion case | Decoded source frames | Selected times covered | Unique images actually viewed | Pages viewed | Native checks | Render warnings |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| en-HighDim | 2,152 | 371 | 308 | 39 | 6 | 0 |
| en-JL | 2,748 | 390 | 292 | 37 | 6 | 0 |
| zh-HighDim | 2,067 | 360 | 298 | 38 | 6 | 0 |
| zh-JL | 2,964 | 402 | 303 | 38 | 6 | 0 |

Total motion coverage: 9,931 decoded frames; 1,523 selected timestamps; 1,201 actually viewed unique representatives on 152 pages; 24 native followups. All four initial endpoint cases add 68 inspected screenshots and 18 native followups. Configured selected gap is one second; the EN JL reported maximum of 1.0000000000000018 seconds is retained as floating-point representation. Complete timestamp/hash mappings, page receipts and unselected-frame gaps are in the per-case ledgers.

## Findings and repairs

English JL originally rounded the measured 99.6% at k=400 to 100% and crowded the following descriptor. The authorized one-decimal readout and dynamic 0.2-unit descriptor gap pass actual EN/ZH cached-value geometry fixtures and both complete rendered motion reviews. Data, narration and timing did not change. Those reviewed movies use source6cb5b16754a225018b047c77c5f3913139920ebcc17019b90b873a32fe337447.

A native followup then confirmed that the final English history-card lower border touched upper strokes of “fabricated bounds” in the bottom disclosure. Chinese text ended left of the card and was clear. The authorized unified local card lift of 0.4 world units passes real EN/ZH AST geometry: caption gaps0.1586/0.1480units and data horizontal gap0.2972units; frame,plot-text and legend checks pass. An initial0.3lift failed the preselected0.1-unit minimum gap; the placement was increased and no threshold reduced. This local polish is sourceb0ce1007f88106ee78554e4438d2267f32678df53819c24a06d43c13bf842ac5 and still needs actual fresh bilingual rendered regression from the parent.

The original after-readout movies and their complete reviews remain valid scoped evidence before the margin polish. Native before English collision/crop and Chinese clear receipts are preserved in jl-history-margin-repair/. No final after-render approval is inferred from geometry alone.

## Provenance and limits

Each movie was frozen with its exact completed render record and direct module snapshot before extraction; complete input signatures and SHA hashes remain in the ledgers. All four motion render records have zero warnings. Historical HighDim endpoint source-change warnings remain preserved, even though the direct module agreed with its pre-worker snapshot. Later whole-part source changes may conservatively stale aggregate fingerprints; no warning is silently converted into a clean pass.

This is selected-frame visual QA of silent854×480,15fps previews. Continuous perceptual playback, listening/narration synchronization, production-resolution readability and player/responsive behavior remain unverified. Unselected frames were not individually perceived. No production compute, model/data mutation, production render, global caption/narration/timing/STATUS change, commit or push was performed by this reviewer.

The separate completed English readout endpoint regression adds 17 actually viewed screenshots on three pages and two native checks. Its exact render-record SHAe9eff8a4a022b2154a73f6fee620b641e65e0b91e95af0887891e419c0561c63 and imported source6cb5b167 were explicitly attested by the parent for root26378,19:46–19:50UTC, and matched to preserved bytes. The later direct b0ce source-at-review copy is labeled separately. The99.6%endpoint repair is closed; only fresh margin-polish regression remains.
