# Chinese Brownian selected-motion baseline

All 50 original1280px-wide chronological sheets were actually inspected:459 selected times map solely by exact PNG SHA256 to400 viewed representatives.23 native854×480 critical images were also actually viewed and logged. The frozen movie has2254 decoded frames;1795 frames remain outside visual review. The maximum selected gap is1s.

This is the OLD PRE-POLISH baseline movie af59b8661b3496da6c9b85cec807c1a53b9e1650bf594ff117ab9c08aeb9c796, with direct source3d7f660b…. Current source780521… contains the parent-authorized two-keyword polish and is not approved by these baseline views. Raw status passed, warnings empty, fingerprint33c66cce… and raw logs remain unchanged; source snapshots do not prove historical imports.

The fan extrema/reference bands, single QV path minimum, raw accumulated QV line, and400-path mean ± across-path-SD table are visible and readable. Actual table values are0.995±0.320,1.004±0.088,0.999±0.011 at n=2^4/2^8/2^14; total variations3.2,12.8,102.1. The diffusion footer, heat equation, history caption and final fade were checked natively. Points near the footer do not persistently obscure its glyphs.

Two retained-row-copy transitions duplicate old glyphs in flight: the variance-row reveal around94.067–94.733s (native overlap94.267s; later clean95.000s), and the sum-row reveal around96.667–97.333s (native overlap97.200s; later clean97.733s). Native before/overlap/clean hashes and callsites250/252 are in review-notes.json. These are the same two local Write-polish targets already approved by root; later held equations are correct and clean. Selected samples do not prove the exact first/last overlap frame.

A minor optional hierarchy observation remains: the fan's time-axis label touches the dense endpoint paths (native50.867/51.933/69.600s), while remaining readable. Its frozen callsite centers it below the endpoint. No further source change was made or required for the held-state conclusion.

Complete exact view receipts, time/SHA mapping, all unselected gaps, source/input identities and raw warnings are preserved in review-notes.json and views.json. All frozen files/blobs and actual current input hashes/metadata were verified. No new extraction or producer/render/compute job occurred. No continuous playback, listening/audio, native1080 or unsampled-frame approval is claimed.
