MC cohort synchronization and ScoreFn retained-row reveal repair.

See freeze.json and proposed-zh-overlay.json. Both MC/ScoreFn baseline bilingual clips were actually reviewed before these edits. All7focused tests passed, including actual Manim bilingual geometry; fresh rendered validation is pending root. VO/bookmarks/play durations/data unchanged. Initial dart appearance deliberately changes to exact discrete prefix; graph replay still rewinds toN1 and uses original1s+6s linear progression. No full continuous or audio approval.
