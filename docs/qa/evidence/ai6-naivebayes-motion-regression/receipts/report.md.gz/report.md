# NaiveBayes bilingual repair regression

Accepted within selected-image and all-encoded repair-window scope. All4fresh endpoint/motion captures passed0warnings with stable source/data. All4repairs visually verified; no new defect found within scope.

Actual motion coverage: 822 adaptive times, 964 uniontimes including every one of244 encodedframe-times in10repairwindows. 750 unique images comprise383 exactbaseline matches and367 newimages actuallyviewed on47 pages. All26endpoints covered: 20 exactPNGinheritance,0 fullnativeRGB-onlyinheritance,6 newstates viewed on2pages. 14 original854px followups. All4756 framesdecoded; 3792 remainvisuallyunselected with exactgapsretained.

Full uncapped uncertainty lies inside45percentaxis; original numericvalues remainunchanged. Copyghosts removed; cardhighlight no longer fills/overlaps/clips; pointcloud remains fixed on its axes duringemphasis. CompletePTS/narration/SRT/WAV/rawobjects/durations unchanged. All74existingpayloadinventoryfiles unchanged. No producer/model/TTS/sourceedit ran in thisassignment.

No continuous/listening/narratedsync/native1080/4K approval. Rootfullsuite/captionlookupregression gates are separate.
