from pathlib import Path
import importlib.util,json,sys,hashlib,datetime
D=Path(__file__).parent;R=Path('/workspace/explainer-videos');spec=importlib.util.spec_from_file_location('capture',D/'capture_driver.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
scene=R/'videos/ai/ai6/s08_bayes.py';expected='096df1ad04b1b9c22c0ee27f5a925171f263153fc8bf179579a1e66b78ac9639';table='0884ed469261b1b911c233f875d03430ed6099b6ce79c499972cce6ff0e9d0ad'
assert m.sha(scene)==expected and m.sha(m.TABLE)==table
snap=m.source_snapshot();assert snap['qa_fingerprint'].startswith('a59fad15'),snap['qa_fingerprint'];m.disk();assert not (D/'current').exists();run=D/'current';run.mkdir();m.write(run/'start-gate.json',{'created':m.now(),'scene_sha256':expected,'table_sha256':table,'qa_fingerprint':snap['qa_fingerprint'],'scope':'Exactly4rootauthorizedNaiveBayespasses, cachedonly,silent,threads1,768MiB guard; no other queue cases.','original_driver_sha256':m.sha(Path('/workspace/runtime/ai6-remaining-qa-serial/driver.py')),'private_driver_copy_sha256':m.sha(D/'capture_driver.py')});rows=[]
for language in ['en','zh']:
 for mode in ['endpoints','motion']:
  assert m.sha(scene)==expected and m.sha(m.TABLE)==table and m.source_snapshot()['qa_fingerprint']==snap['qa_fingerprint']
  receipt=m.run_one({'position':8,'scene':'NaiveBayes'},language,mode,run,table,1200);rows.append(receipt);m.write(run/'progress.json',rows)
  assert receipt['runtime_completed'] and not receipt['needs_reconcile']
m.write(run/'complete.json',{'created':m.now(),'cases':len(rows),'raw_warning_cases':sum(bool(r['raw_warnings']) for r in rows),'visual_review':'pending','source_sha256':m.sha(scene),'qa_fingerprint':m.source_snapshot()['qa_fingerprint']})
