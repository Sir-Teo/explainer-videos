from pathlib import Path
import json,hashlib,datetime,subprocess,os,time
repo=Path('/workspace/explainer-videos');rt=Path('/workspace/runtime/ai3-production1080-foundations');rt.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();wrapper=Path('/workspace/runtime/qa_production_endpoint.py');out=repo/'renders/qa/production-endpoints-1080/ai3';rp=rt/'capture-receipts.json'
r={'scope':'Actual1920x1080endpointcapturesonly; cached-only/silent/animationsskipped; no fullproductionmotion/audio/listening/player claim.','wrapper_sha256':sha(wrapper),'initial_reconciliation':'No existing Part3 result.json found in production-endpoints-1080 before this run. Existing Part2 outputs untouched.','cases':{}}
rp.write_text(json.dumps(r,indent=2)+'\n');env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',PYTHONPATH=str(repo))
for scene in ['LowRank','Norms','GaLore']:
 for lang in ['en','zh']:
  key=lang+'/'+scene;folder=out/lang/scene;record=folder/'result.json';assert not record.exists(),f'Unexpected existing result; reconcile first: {record}'
  cmd=['nice','-n','10',str(repo/'.venv/bin/python'),str(wrapper),'ai3',lang,scene];started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.time();log=rt/(lang+'-'+scene+'-capture.log')
  with log.open('w') as f:proc=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
  c={'command':cmd,'numeric_threads':1,'started_utc':started,'elapsed_seconds':time.time()-t,'exit_code':proc.returncode,'log':str(log),'log_sha256':sha(log),'result_exists':record.exists()}
  if record.exists():
   d=json.loads(record.read_text());c.update(result=str(record),result_sha256=sha(record),status=d['status'],warnings=d['warnings'],frames=len(d['frames']),fingerprint=d['fingerprint'],manual_capture_configuration=d.get('manual_capture_configuration'),storage_bytes=sum(p.stat().st_size for p in folder.rglob('*') if p.is_file()))
  r['cases'][key]=c;rp.write_text(json.dumps(r,indent=2)+'\n');print(key,'exit',proc.returncode,c.get('status'),c.get('frames'),'frames',flush=True)
