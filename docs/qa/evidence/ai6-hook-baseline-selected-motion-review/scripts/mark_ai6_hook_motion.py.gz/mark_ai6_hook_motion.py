from pathlib import Path
import sys,json,datetime,hashlib
lang,start,end,note=sys.argv[1:];D=Path('/workspace/runtime/ai6-hook-baseline-motion-review')/lang
p=D/'views.json';v=json.loads(p.read_text());a=json.loads((D/'plan.json').read_text())
for i in range(int(start)-1,int(end)):
 row=a['pages'][i];actual=hashlib.sha256((D/'unique'/row['file']).read_bytes()).hexdigest();assert actual==row['sha256']
 if any(r['file']==row['file'] for r in v['pages']):raise RuntimeError('page already recorded')
 v['pages'].append(dict(row,viewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scale='1280px sheet;640px tile from854x480source',notes=note))
p.write_text(json.dumps(v,indent=2)+'\n');print(lang,'pages now',len(v['pages']))
