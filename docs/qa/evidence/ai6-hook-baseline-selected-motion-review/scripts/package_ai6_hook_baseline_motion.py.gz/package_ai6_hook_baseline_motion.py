from pathlib import Path
import json,hashlib,gzip,shutil,datetime,subprocess,os
from PIL import Image
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-hook-baseline-motion-review');P=R/'docs/qa/evidence/ai6-hook-baseline-selected-motion-review'
if P.exists():raise RuntimeError('package already exists; preserve rather than overwrite')
P.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def gz(p,q):
 q.parent.mkdir(parents=True,exist_ok=True);b=p.read_bytes();q.write_bytes(gzip.compress(b,mtime=0));return {'path':str(q.relative_to(P)),'sha256':sha(q),'decoded_original_sha256':hashlib.sha256(b).hexdigest(),'decoded_original_bytes':len(b)}
summaries=[];compressed=[];derivatives=[]
for lang in ['en','zh']:
 C=D/lang;a=json.loads((C/'audit/result.json').read_text());plan=json.loads((C/'plan.json').read_text());v=json.loads((C/'views.json').read_text());freeze=json.loads((C/'baseline-freeze.json').read_text())
 assert len(v['pages'])==len(plan['pages'])==44 and len(v['native'])==7
 assert sha(C/'witness/Hook.mp4')==a['source_sha256']==freeze['files'][0]['sha256']
 assert (C/'witness/Hook.mp4').stat().st_nlink==1
 for row in plan['pages']:assert sha(C/'unique'/row['file'])==row['sha256']
 for row in a['selected_frames']:assert sha(C/'audit'/row['file'])==row['sha256']
 for name in ['baseline-freeze.json','pre-audit.json','plan.json','views.json','native-plan.json','audit.log','witness/result.json','witness/Hook.narration.json','witness/s01_hook.py','witness/common.py','audit/result.json']:
  compressed.append(gz(C/name,P/lang/'receipts'/(name.replace('/','--')+'.gz')))
 for source in sorted((C/'observed-source').rglob('*')):
  if source.is_file():compressed.append(gz(source,P/lang/'observed-source'/(str(source.relative_to(C/'observed-source'))+'.gz')))
 for row in plan['pages']:
  source=C/'unique'/row['file'];target=P/lang/'viewed-page-exports'/source.with_suffix('.jpg').name;target.parent.mkdir(parents=True,exist_ok=True)
  with Image.open(source) as im:im.convert('RGB').save(target,quality=74,optimize=True,subsampling=0)
  derivatives.append({'path':str(target.relative_to(P)),'sha256':sha(target),'original_png_sha256':row['sha256'],'original_runtime_path':str(source),'scope':'Lossy JPEG export at original1280px sheet size; actual views used originalPNG, identified in views ledger.'})
 for row in v['native']:
  src=C/'audit'/row['file'];dest=P/lang/'critical-native'/Path(row['file']).name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest);assert sha(dest)==row['sha256']
 streams=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=index,codec_type,codec_name,width,height,r_frame_rate,sample_rate','-of','json',str(C/'witness/Hook.mp4')],text=True))
 summaries.append({'case':lang+'/Hook','source_sha256':a['source_sha256'],'duration_seconds':a['duration'],'first_selected_time':a['selected_frames'][0]['time'],'last_selected_time':a['selected_frames'][-1]['time'],'decoded_frames':plan['decoded'],'selected_frames':plan['selected'],'unselected_decoded_frames':plan['decoded']-plan['selected'],'unique_original_pngs_actually_viewed':plan['unique'],'exact_png_hash_reuse_count':plan['selected']-plan['unique'],'unique_pages_actually_viewed':len(v['pages']),'native_followups_actually_viewed':len(v['native']),'largest_selected_time_gap_seconds':plan['max_gap'],'unextracted_gap_interval_count':len(plan['gaps']),'all_unextracted_gaps_receipt':lang+'/receipts/audit--result.json.gz','raw_status':freeze['raw_status'],'raw_warnings':freeze['raw_warnings'],'source_commit_from_root_freeze':freeze['source_commit'],'source_observation_sha256':sha(C/'witness/s01_hook.py'),'raw_render_fingerprint':json.loads((C/'witness/result.json').read_text()).get('fingerprint'),'inputs':freeze['inputs'],'tool_sha256':a['tool_sha256'],'streams':streams,'findings':v['findings'],'verdict':'sampled-image baseline review complete; no new blocking defect; known split-disclosure enhancement pending separate owner regression'})
report={'schema_version':1,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Complete chronological selected-time baseline image review of frozenPart6HookEN/ZH480p15movies, not continuous viewing.','cases':summaries,'totals':{'decoded':sum(r['decoded_frames'] for r in summaries),'selected':sum(r['selected_frames'] for r in summaries),'unique_original_pngs_actually_viewed':sum(r['unique_original_pngs_actually_viewed'] for r in summaries),'unique_pages_actually_viewed':sum(r['unique_pages_actually_viewed'] for r in summaries),'native_followups':14,'unselected_decoded_frames':sum(r['unselected_decoded_frames'] for r in summaries)},'view_scale':'1280px sheets at originalpixel dimensions,640px tiles from854x480source; critical native854x480followups.','coverage_rule':'Every selected time maps to an actually viewed representative with exact PNGSHA equality only. No perceptual-similarity reuse. Repeated static holds can have distinct encoderPNG identities and were reviewed as listed.','limits':['Every decoded frame was analyzed, but only selected frames were visually reviewed.','Dense selection0.25s in detectedmotion; maximum gap1s including static/slow changes, with EN1.8e-15 floatingpoint reporting epsilon.','No continuous perceptual playback, listening, narratedsync, native1080/4Kmotion or finalsource approval.','Allrawpasses/warnings preserved; laterworkingtree/globalchanges cannot retroactively establish loaded-source equivalence.','Rootfrozen sourcecommitb664 is provenance attestation; observedbytes snapshots alone do not prove historical in-memory imports.','Known root-owned on-screen split/vocabulary disclosure addition is not present in these baseline movies; new renders require regression.'],'resource_and_storage':{'free_disk_after_review':shutil.disk_usage(R).free,'start_floor_bytes':768*1024**2,'stop_floor_bytes':512*1024**2,'lock_used':'/workspace/runtime/qa-motion-extraction.lock','lock_note':'Both audits finished before root identified existing sharedlock. No furtherextraction undertaken; futureuse /workspace/runtime/ai4-tail-motion-review/extract.lock.','witnesses':'Originalrootbaseline and reviewerwitness are independentcopy2 files, not hardlinks. Allpreserved; noMP4inrepo package.'},'compressed_receipts':compressed,'lossy_page_exports':derivatives}
(D/'review-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(P/'report.json').write_bytes((D/'review-summary.json').read_bytes())
for name in ['prepare_ai6_hook_motion.py','mark_ai6_hook_motion.py','package_ai6_hook_baseline_motion.py']:compressed.append(gz(Path('/workspace/runtime')/name,P/'scripts'/(name+'.gz')))
readme='''# Part6 Hook baseline selected-motion review

Frozen bilingual **baseline** only, before the separately owned on-screen split-disclosure enhancement. Both complete480p15clips were decoded:5381frames total. Actual image coverage is880selected times,694distinct originalPNGs on88chronological sheets, plus14native854×480followups.4501decoded frames remain visually unselected; every gap and exact duplicate mapping is retained in compressed audit/plan receipts.

No new blocking visual defect was found in the reviewed samples. The cloud lacks visual train/test and vocabulary-fit disclosure, already assigned to another owner. The frozen narration includes those qualifications. Timeline labels are small at480p but remain separated in native checks. History→bars and seriesmap→objectives crossfade overlaps resolve before held reading states; they were not labeled as persistent defects.

`report.json` binds exact movie/result/tool/source/input identities and raw status/warnings. Both raw records passed without warnings. This preserves their original meaning and is not a current broaderfingerprint pass. The sourcecommit from root’s freeze isb6649e39995f128019948cb32831b1a3caeb3842; scene snapshot SHA2baeb217…. Filesystem snapshots are observations, not historical-import proof.

`viewed-page-exports` contains lossy JPEG derivatives of every actually viewed originalPNG sheet, at the same1280px dimensions. OriginalPNG SHA hashes and viewing receipts identify the actual reviewed bytes; exactPNG inheritance must use those originals/hashes, neverJPEG similarity. `critical-native` contains14byte-exact actualnative followups. FulloriginalPNG cohorts, allMP4witnesses and raw runtime files remain under `/workspace/runtime/ai6-hook-baseline-motion-review` and `/workspace/runtime/ai6-hook-baseline`; independentcopy2 movies are preserved, nohardlinks or moviecopies added here.

Selection used existing`tools/qa_motion.py --dense .25 --max-gap1` (exact SHA inreport). Everyframe decode is computational validation, not perception. **Continuous playback, listening, narratedsynchronization,1080p/4Kmotion and later-source approval remain unverified.** No productioncompute, scene/data/table edit, modeldownload or render was performed by this review.
'''
(P/'README.md').write_text(readme)
payloads=[]
for p in sorted(P.rglob('*')):
 if p.is_file():payloads.append({'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':sha(p)})
manifest={'schema_version':1,'payloads':payloads,'payload_count':len(payloads),'payload_bytes':sum(r['bytes'] for r in payloads)}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert manifest['payload_bytes']<=12*1024**2,manifest['payload_bytes']
print(json.dumps({'package':str(P),'payload_count':len(payloads),'payload_bytes':manifest['payload_bytes'],'manifest_sha256':sha(P/'manifest.json'),'report_sha256':sha(P/'report.json')},indent=2))
