from pathlib import Path
import os, sys, json, hashlib, shutil, subprocess, datetime, fcntl, time, importlib.util
R=Path('/workspace/explainer-videos'); BASE=Path('/workspace/runtime/ai6-hook-baseline'); OUT=Path('/workspace/runtime/ai6-hook-baseline-motion-review')
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def available():
 vals={l.split(':')[0]:int(l.split()[1])*1024 for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')}
 host=vals['MemAvailable'];cg=Path('/sys/fs/cgroup');m=(cg/'memory.max').read_text().strip()
 if m=='max':return host
 stat=dict(l.split() for l in (cg/'memory.stat').read_text().splitlines());limit=int(m);cur=int((cg/'memory.current').read_text());inactive=int(stat.get('inactive_file','0'))
 return min(host,max(0,min(limit,limit-cur+inactive)))
OUT.mkdir(exist_ok=True)
for lang in ['en','zh']:
 D=OUT/lang;D.mkdir(exist_ok=True)
 if (D/'plan.json').exists():raise RuntimeError('Existing completed plan; reconcile before rerun')
 frozen=json.loads((BASE/lang/'freeze.json').read_text())
 for row in frozen['files']:
  p=Path(row['copy']);assert sha(p)==row['sha256'],p
  q=D/'witness'/p.name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
  assert sha(p)==sha(q) and (p.stat().st_dev,p.stat().st_ino)!=(q.stat().st_dev,q.stat().st_ino) and q.stat().st_nlink==1
 for rel,row in frozen['inputs'].items():assert sha(R/rel)==row['sha256'],rel
 shutil.copy2(BASE/lang/'freeze.json',D/'baseline-freeze.json')
 observations=[]
 for rel in ['tools/qa_motion.py','tools/qa_series.py','videos/ai/ai6/zh_lines.py','videos/ai/ai_text_zh.json']:
  p=R/rel;q=D/'observed-source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);observations.append({'path':rel,'sha256':sha(p),'bytes':p.stat().st_size,'scope':'filesystem observation, not imported-source proof'})
 (D/'pre-audit.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tool':observations[0],'observations':observations,'disk_free':shutil.disk_usage(R).free,'ram_available_estimate':available(),'independent_movie_sha256':sha(D/'witness/Hook.mp4'),'raw_freeze':frozen},indent=2)+'\n')
 with open('/workspace/runtime/qa-motion-extraction.lock','a') as lock:
  print('waiting extraction lock',lang,flush=True);fcntl.flock(lock,fcntl.LOCK_EX)
  if shutil.disk_usage(R).free<768*1024**2 or available()<768*1024**2:raise RuntimeError('start resource guard')
  env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
  with (D/'audit.log').open('w') as log:
   p=subprocess.Popen(['nice','-n','10',sys.executable,str(R/'tools/qa_motion.py'),str(D/'witness/Hook.mp4'),'-o',str(D/'audit'),'--dense','.25','--max-gap','1'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
   while p.poll() is None:
    if shutil.disk_usage(R).free<512*1024**2:p.terminate();p.wait();raise RuntimeError('stop disk guard')
    time.sleep(.5)
   if p.returncode:raise RuntimeError('audit failed '+lang)
 spec=importlib.util.spec_from_file_location('qa_motion',R/'tools/qa_motion.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 a=json.loads((D/'audit/result.json').read_text());reps=[];seen={};mapping=[]
 for n,f in enumerate(a['selected_frames']):
  h=f['sha256']
  if h not in seen:seen[h]=len(reps);reps.append({**f,'file':'../audit/'+f['file']})
  mapping.append({'selected_index':n,'time':f['time'],'source_frame':f['source_frame'],'sha256':h,'representative':seen[h]})
 U=D/'unique';U.mkdir(exist_ok=True);pages=m.sheets(U,reps)
 plan={'case':lang+'/Hook','source_sha256':a['source_sha256'],'decoded':a['analysis']['decoded_frames'],'selected':len(a['selected_frames']),'unique':len(reps),'reps':reps,'mapping':mapping,'pages':pages,'gaps':a['unextracted_frame_gaps'],'max_gap':a['largest_selected_time_gap']}
 (D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(D/'views.json').write_text('{"pages":[],"native":[],"findings":[]}\n')
 assert sha(D/'witness/Hook.mp4')==a['source_sha256']
 print(lang,'ready',len(a['selected_frames']),len(reps),len(pages),flush=True)
