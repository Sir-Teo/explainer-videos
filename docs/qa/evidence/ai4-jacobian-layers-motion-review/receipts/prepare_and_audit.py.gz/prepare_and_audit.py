from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys
repo=Path('/workspace/explainer-videos');out=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();tool=repo/'tools/qa_motion.py';tool_sha=sha(tool)
for lang,scene,module in [('en','Jacobian','s04_jacobian'),('zh','Jacobian','s04_jacobian'),('en','Layers','s05_layers'),('zh','Layers','s05_layers')]:
 record_path=repo/f'renders/qa/series/ai4/{lang}/{scene}_motion/result.json';record=json.loads(record_path.read_text());movie=repo/record['movie'];h=sha(movie);case=out/f'{lang}-{scene}'/h;assert not case.exists();case.mkdir(parents=True);frozen=case/'frozen';frozen.mkdir();files={}
 for p in [record_path,movie,movie.with_suffix('.narration.json'),repo/f'videos/ai/ai4/{module}.py',repo/'videos/ai/ai4/zh_lines.py',repo/'videos/ai/ai4/common.py',repo/'videos/ai/ai4/manifest.py',repo/'videos/ai/ai_text_zh.json',tool]:
  relative=str(p.relative_to(repo));target=frozen/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);assert sha(p)==sha(target);files[relative]={'sha256':sha(target),'bytes':target.stat().st_size,'frozen':str(target)}
 inputs={}
 for rel,sig in record['inputs'].items():
  p=repo/rel;s=p.stat() if p.exists() else None;current=[s.st_size,s.st_mtime_ns] if s else None;assert current==sig,f'Input signature mismatch {rel}'
  inputs[rel]={'record_signature':sig,'observed_signature':current,'sha256':sha(p) if s else None}
  if s:
   target=frozen/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target);assert sha(target)==inputs[rel]['sha256']
 receipt={'scope':'Actual selected-time motion QA, not continuous perceptual playback/listening','lang':lang,'scene':scene,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'movie_sha256':h,'movie':str(movie),'record_status':record['status'],'record_warnings':record.get('warnings'),'render_fingerprint':record.get('fingerprint'),'direct_source':f'videos/ai/ai4/{module}.py','files':files,'inputs':inputs,'qa_motion_tool_sha256':tool_sha,'narration':record['narration']}
 (case/'freeze.json').write_text(json.dumps(receipt,indent=2)+'\n');assert sha(tool)==tool_sha
 cmd=[sys.executable,str(tool),str(movie),'-o',str(case/'audit'),'--dense','0.5','--max-gap','1'];receipt['audit_command']=cmd;(case/'freeze.json').write_text(json.dumps(receipt,indent=2)+'\n')
 env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1');p=subprocess.run(cmd,env=env,cwd=repo,capture_output=True,text=True);(case/'audit-command.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr;assert sha(tool)==tool_sha and sha(movie)==h;print(json.dumps({'lang':lang,'scene':scene,'case':str(case),'audit':p.stdout.strip()}),flush=True)
