from pathlib import Path
import datetime,hashlib,json,math
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for case in sorted(root.glob('*/*')):
 p=case/'audit/result.json'
 if not p.is_file() or (case/'review.json').exists():continue
 audit=json.loads(p.read_text())
 if audit.get('status')!='automated-temporal-audit-completed':continue
 seen={};unique=[];selected=[]
 for i,f in enumerate(audit['selected_frames']):
  d={**f,'selection_index':i,'path':str(case/'audit'/f['file'])};assert sha(Path(d['path']))==f['sha256']
  if f['sha256'] in seen:d.update(coverage='pending-exact-duplicate',first_unique_index=seen[f['sha256']])
  else:seen[f['sha256']]=i;unique.append(d);d.update(coverage='pending-actual-view')
  selected.append(d)
 folder=case/'review-pages';folder.mkdir();pages=[]
 for offset in range(0,len(unique),8):
  chunk=unique[offset:offset+8];canvas=Image.new('RGB',(1280,394*math.ceil(len(chunk)/2)),'#0e1117');draw=ImageDraw.Draw(canvas)
  for k,f in enumerate(chunk):
   x=(k%2)*640;y=(k//2)*394;im=Image.open(f['path']).convert('RGB').resize((640,360));canvas.paste(im,(x,y+34));draw.text((x+8,y+3),f"{f['time']:.3f}s / sourceframe{f['source_frame']}",fill='white');draw.text((x+8,y+18),', '.join(f['reasons'])[:100],fill='#c6d6e9')
  page=folder/f'page-{len(pages)+1:03d}.png';canvas.save(page);pages.append({'path':str(page),'sha256':sha(page),'selection_indices':[f['selection_index'] for f in chunk],'actual_view':'pending'})
 review={'scope':'Selected-time motion review only, not continuous playback or listening','case':str(case),'audit_sha256':sha(p),'source_movie_sha256':audit['source_sha256'],'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decoded_frames':audit['analysis']['decoded_frames'],'selected_count':len(selected),'unique_count':len(unique),'duplicate_count':len(selected)-len(unique),'selected':selected,'pages':pages,'pages_viewed':[],'native_views':[],'findings':[],'status':'pending','continuous_perceptual_playback':False,'listening':False}
 (case/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(case.parent.name,len(selected),'selected',len(unique),'unique',len(pages),'pages')
