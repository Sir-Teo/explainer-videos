from pathlib import Path
import datetime,hashlib,json,sys
root=Path(__file__).resolve().parent;name,mode=sys.argv[1:3];paths=list((root/name).glob('*/review.json'));assert len(paths)==1;p=paths[0];r=json.loads(p.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
if mode=='pages':
 for n in map(int,sys.argv[3:]):
  page=r['pages'][n-1];assert sha(page['path'])==page['sha256'];page.update(actual_view='actual-chronological-image-view',viewed_utc=now)
  if n not in r['pages_viewed']:r['pages_viewed'].append(n)
  for i in page['selection_indices']:r['selected'][i].update(coverage='actual-image-view',proof={'page':page['path'],'page_sha256':page['sha256'],'viewed_utc':now})
 for f in r['selected']:
  if f['coverage']=='pending-exact-duplicate':
   first=r['selected'][f['first_unique_index']]
   if first['coverage']=='actual-image-view':f.update(coverage='exact-PNG-reuse',proof=first['proof'])
elif mode=='native':
 for number in map(int,sys.argv[3:]):
  f=r['selected'][number];assert sha(f['path'])==f['sha256'];r['native_views'].append({'selection_index':number,'time':f['time'],'source_frame':f['source_frame'],'path':f['path'],'sha256':f['sha256'],'viewed_utc':now})
r['selected_times_accounted']=sum(not f['coverage'].startswith('pending') for f in r['selected']);p.write_text(json.dumps(r,indent=2)+'\n');print(name,len(r['pages_viewed']),'/',len(r['pages']),'pages,',r['selected_times_accounted'],'/',r['selected_count'],'times;native',len(r['native_views']))
