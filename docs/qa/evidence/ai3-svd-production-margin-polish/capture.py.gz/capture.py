from pathlib import Path
from types import SimpleNamespace
import sys,os,json,hashlib,importlib.util,importlib,shutil
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R));mode,language=sys.argv[1:];B=Path(__file__).parent;source=B/(mode+'.py');os.environ.update(EXPLAINER_LANG=language,EXPLAINER_VIDEO='ai3',EXPLAINER_TTS='silent',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
from tools import qa_series
import manim
qa_series.OUT=R/'renders/qa/svd-native-margin-polish'/mode
oldconfig=manim.tempconfig
manim.tempconfig=lambda options:oldconfig(dict(options,quality='fourk_quality',pixel_width=3840,pixel_height=2160,frame_rate=60))
oldimport=importlib.import_module

def import_review(name,package=None):
 if name=='videos.ai.ai3.s08_svd':
  spec=importlib.util.spec_from_file_location(name,source);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);module.__file__=str(R/'videos/ai/ai3/s08_svd.py');return module
 return oldimport(name,package)
importlib.import_module=import_review
status=qa_series.worker(SimpleNamespace(video='ai3',lang=language,worker='SVD',motion=False,cached_only=True))
p=qa_series.OUT/'ai3'/language/'SVD/result.json';d=json.loads(p.read_text());d['actual_import_override']={'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Exact before/after scene import under unchanged shared environment; broad fingerprint describes working disk, not historical import. 3840x2160 skipped-animation endpoint geometry only, no narrated/motion production approval.'};d['native_capture']={'width':3840,'height':2160,'nominal_fps':60};p.write_text(json.dumps(d,ensure_ascii=False,indent=1)+'\n');print(mode,language,d['status'],len(d['frames']),d['warnings']);sys.exit(status)
