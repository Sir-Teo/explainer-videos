from pathlib import Path
import json,hashlib,datetime,sys
p=Path('/workspace/runtime/ai3-norms-galore-final-endpoints/review.json');r=json.loads(p.read_text());c=r['cases'][sys.argv[1]];a,b=int(sys.argv[2]),int(sys.argv[3]);note=sys.argv[4]
for n in range(a,b+1):
 pg=c['pages'][n-1];assert hashlib.sha256(Path(pg['file']).read_bytes()).hexdigest()==pg['sha256'];pg.update(reviewed=True,observations=note,reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 for f in c['frames']:
  if f['file'] in pg['files']:f['reviewed']=True
c['review_status']='all_endpoint_frames_directly_viewed' if all(f['reviewed'] for f in c['frames']) else 'in_progress';p.write_text(json.dumps(r,indent=2)+'\n');print(sys.argv[1],sum(f['reviewed'] for f in c['frames']),'/',len(c['frames']))
