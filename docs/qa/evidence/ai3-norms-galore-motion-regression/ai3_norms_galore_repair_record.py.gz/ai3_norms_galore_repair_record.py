from pathlib import Path
import json,sys,datetime,hashlib
P=Path('/workspace/runtime/ai3-norms-galore-repair-motion-review.json');r=json.loads(P.read_text());key=sys.argv[1];start=int(sys.argv[2]);end=int(sys.argv[3]);note=sys.argv[4];c=r['cases'][key];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in range(start,end+1):
 pg=c['pages'][n-1];assert sha(pg['file'])==pg['sha256'];c['reviewed_pages']=[p for p in c['reviewed_pages'] if p['page']!=n]+[{'page':n,'file':pg['file'],'sha256':pg['sha256'],'first_time':pg['frames'][0]['time'],'last_time':pg['frames'][-1]['time'],'frames':len(pg['frames']),'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observations':note}]
c['reviewed_pages'].sort(key=lambda p:p['page']);direct={}
for pg in c['reviewed_pages']:
 for f in c['pages'][pg['page']-1]['frames']:direct[f['sha256']]=f
for f in c['frame_coverage']:
 if f['sha256'] in direct:
  rep=direct[f['sha256']];f['coverage']='directly_inspected' if rep['source_frame']==f['frame'] else 'exact_png_duplicate_of_inspected';f['representative_frame']=rep['source_frame']
c['coverage_counts']={s:sum(f['coverage']==s for f in c['frame_coverage']) for s in ['directly_inspected','exact_png_duplicate_of_inspected','exact_png_inherited_from_completed_baseline','not_yet_reviewed']}
if c['coverage_counts']['not_yet_reviewed']==0:c['review_status']='all_selected_appearances_covered'
P.write_text(json.dumps(r,indent=2)+'\n');print(key,c['coverage_counts'])
lines=['# Part3 Norms/GaLore repairs motion regression checkpoint','',r['scope'],'','| Case | Duration | Decoded | Selected | Viewed | Exact duplicates | Unreviewed selected | Status |','|---|---:|---:|---:|---:|---:|---:|---|']
for key in r['expected_cases']:
 if key not in r['cases']:lines.append(f'| {key} | — | — | — | — | — | — | Pending movie/audit |');continue
 c=r['cases'][key];v=c.get('coverage_counts',{});lines.append(f"| {key} | {c['duration']:.3f}s | {c['decoded_frames']} | {c['selected_frames']} | {v.get('directly_inspected',0)} | {v.get('exact_png_duplicate_of_inspected',0)} | {v.get('not_yet_reviewed',c['selected_frames'])} | {c['review_status']} |")
lines+=['','Each selected-time map, reviewed sheet SHA/time range, movie/tool/source/input provenance, original capture warnings and native followups are in ai3-norms-galore-repair-motion-review.json.','', 'Only exact PNG-byte SHA256 matches justify duplicate reuse. The bounded gap is1s plus RGB-detected transition extras. Full decode is automated and does not imply continuous visual playback.','']
Path('/workspace/runtime/ai3-norms-galore-repair-motion-review.md').write_text('\n'.join(lines))
