from pathlib import Path
import json,sys,hashlib,shutil,datetime,math
from PIL import Image,ImageDraw
root=Path('/workspace/explainer-videos');base=Path('/workspace/runtime/ai3-norms-galore-final-endpoints');key=sys.argv[1];lang,scene=key.split('/');p=root/f'renders/qa/series/ai3/{lang}/{scene}/result.json';c=json.loads(p.read_text());out=base/key;out.mkdir(parents=True,exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();shutil.copy2(p,out/'capture.json');src=root/'videos/ai/ai3'/dict(LowRank='s09_lowrank.py',Norms='s10_norms.py',GaLore='s12_galore.py')[scene];shutil.copy2(src,out/src.name);shutil.copy2(root/'videos/ai/ai_text_zh.json',out/'table-at-review.json');frames=[];pages=[]
for f in c['frames']:
 q=p.parent/f['file'];shutil.copy2(q,out/q.name);frames.append(dict(file=str(out/q.name),sha256=sha(q),time=f['time'],reason=f.get('reason'),texts=f.get('texts'),reviewed=False))
for n,start in enumerate(range(0,len(frames),8),1):
 chunk=frames[start:start+8];tiles=[]
 for f in chunk:
  im=Image.open(f['file']).convert('RGB');im.thumbnail((640,360));tile=Image.new('RGB',(640,394),'#202732');tile.paste(im,(0,34));ImageDraw.Draw(tile).text((8,4),f"{f['time']:.6f}s / {Path(f['file']).name}",fill='white');tiles.append(tile)
 sheet=Image.new('RGB',(1280,394*math.ceil(len(tiles)/2)),'#0e1117')
 for i,t in enumerate(tiles):sheet.paste(t,((i%2)*640,(i//2)*394))
 q=out/f'page-{n:03}.png';sheet.save(q);pages.append(dict(page=n,file=str(q),sha256=sha(q),times=[f['time'] for f in chunk],files=[f['file'] for f in chunk],reviewed=False))
report=base/'review.json';r=json.loads(report.read_text()) if report.exists() else dict(scope='Actual endpoint appearance review only; full motion/continuous/audio/final-quality distinct and pending. No production imports/compute/render/source mutations.',cases={});assert key not in r['cases'];r['cases'][key]=dict(scene=scene,lang=lang,capture_record=str(p),capture_sha256=sha(p),capture_snapshot=str(out/'capture.json'),capture_status=c['status'],capture_warnings=c.get('warnings',[]),capture_fingerprint=c['fingerprint'],capture_inputs=c['inputs'],scene_source=str(src),scene_source_sha256=sha(src),source_snapshot=str(out/src.name),table_snapshot=str(out/'table-at-review.json'),table_sha256=sha(out/'table-at-review.json'),frames=frames,pages=pages,findings=[],native_followups=[],review_status='prepared;unviewed',prepared_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());report.write_text(json.dumps(r,indent=2)+'\n');print(key,len(frames),'endpoints',len(pages),'pages')
