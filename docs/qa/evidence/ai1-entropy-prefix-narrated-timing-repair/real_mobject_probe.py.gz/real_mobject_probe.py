"""Tiny actual visual constructors/shared ladder, no Scene/camera/render/provider/data load."""
from pathlib import Path
import ast,hashlib,json,datetime,shutil
import numpy as np
from manim import config,tempconfig,Write,Create,VMobject,UP
from explainer.ai import mtex,cmath,why,ladder
from explainer.style import C
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;assert shutil.disk_usage('/workspace').free>512*1024**2+2*1024**2
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();tex=D/'constructor-Tex';tex.mkdir(exist_ok=True)
class Plays:
 def __init__(self):self.calls=[]
 def play(self,*args,run_time=1.,**kwargs):self.calls.append(dict(animation_classes=[type(a).__name__ for a in args],run_time=run_time))
rows=[]
with tempconfig(dict(tex_dir=str(tex),frame_rate=60)):
 t=ast.parse((R/'videos/ai/ai1/s04_entropy.py').read_text());coin=next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name=='coin');fnode=next(n.value for n in coin.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='f' for x in n.targets));f=eval(compile(ast.Expression(fnode),'actual-coin-formula','eval'),dict(mtex=mtex,UP=UP));formula=dict(source=ast.unparse(fnode),mobject_type=type(f).__name__,Write_default_run_time=Write(f).run_time,Create_default_run_time=Create(VMobject().set_points_as_corners([[0,0,0],[1,1,0]])).run_time)
 assert formula['Write_default_run_time']==2 and formula['Create_default_run_time']==1
 for file,method,index in [('s04_entropy.py','uniqueness',4),('s05_prefix.py','mcmillan',1)]:
  t=ast.parse((R/'videos/ai/ai1'/file).read_text());fn=next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name==method);scene=Plays();ns=dict(C=C,A=C.ENTROPY,cmath=cmath,why=why,ladder=ladder,self=scene)
  wanted={'rows','whys','step'};nodes=[n for n in fn.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in wanted];assert len(nodes)==3
  exec(compile(ast.Module(nodes,type_ignores=[]),'actual-literal-ladder-constructors','exec'),ns)
  ns['step'](index);assert [r['run_time'] for r in scene.calls]==[.6,1.2,.8],scene.calls
  rows.append(dict(file=file,method=method,index=index,source_sha256=h(R/'videos/ai/ai1'/file),actual_MathTex_row_count=len(ns['rows']),actual_ladder_stage_calls=scene.calls,scope='Actual shared ladder and real formula/why Mobjects; fake play records API calls only, no Animation interpolation/frame/camera output.'))
report=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),coin_constructor=formula,ladder_targets=rows,shared_source_sha256=h(R/'explainer/analysis/__init__.py'),source_quantization_proof='Separatefocusedtests execute installed Manim frame progression/validation with a clock; this probe verifies actualconstructor/ladder branch durations only.',limits='No Scene/renderer/camera, model/data/producer/loader, speech access/generation or video/imageoutput. TeXcompile only inprivate directory.')
(D/'actual-constructor-and-ladder-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
