from pathlib import Path
import importlib.util,json,hashlib,datetime,shutil
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;assert shutil.disk_usage('/workspace').free>512*1024**2+1024**2
p=R/'tests/test_ai1_entropy_prefix_timing.py';spec=importlib.util.spec_from_file_location('actual_entropy_prefix_timing_fixtures',p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
rows=[];old=[]
for item,late in zip(mod.SPECS,[.96,1.56,.11]):
 scene,vo,scope,aligned=mod.span(item,100,before=True,rounded=False);actual=scene.renderer.time-vo.mark_time(item[4]);assert abs(actual-late)<1e-9;old.append(dict(spec=item,reported_late_seconds=late,reproduced_unrounded_late_seconds=actual,events=scene.events))
 for fps in [15,30,60]:
  for phase in [0,.49,1]:
   for variant in ['before','after']:
    scene,vo,scope,aligned=mod.span(item,fps,phase,before=variant=='before');end=scene.renderer.time;target=vo.mark_time(item[4]);events=list(scene.events);residual=None
    if variant=='after':
     assert end<=target-1/fps+1e-10;vo.wait_until(item[4]);cuearrival=scene.renderer.time
     if item[1]=='coin':residual=vo.mark_time('b')-scene.renderer.time;kind='fair-coin state untilnextspokenb'
     else:
      scope['step'](item[5]+1);residual=aligned['duration']-scene.renderer.time;kind='residual speech afterallthreeplays ofnextproofstep (bothretainedpreviousline andnewlastline remain)'
     assert residual>=1.5
    rows.append(dict(spec=item,fps=fps,phase_in_frames=phase,variant=variant,span_end_seconds_relative_utterance=end,target_seconds_relative_utterance=target,lead_seconds=target-end,stages=events,min_stage_requested_seconds=min(e['requested'] for e in events),min_stage_quantized_seconds=min(e['end']-e['start'] for e in events),settled_reading_residual_seconds=residual,reading_scope=kind if variant=='after' else None))
after=[r for r in rows if r['variant']=='after'];summary=[]
for item in mod.SPECS:
 r=[x for x in after if x['spec']==item];summary.append(dict(spec=item,min_stage_requested_seconds=min(x['min_stage_requested_seconds'] for x in r),min_stage_quantized_seconds=min(x['min_stage_quantized_seconds'] for x in r),minimum_cue_lead_seconds=min(x['lead_seconds'] for x in r),minimum_settled_reading_residual_seconds=min(x['settled_reading_residual_seconds'] for x in r)))
report=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_pins={str((R/'videos/ai/ai1'/v[0]).relative_to(R)):hashlib.sha256((R/'videos/ai/ai1'/v[0]).read_bytes()).hexdigest() for v in mod.CASES.values()},test_source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),old_unrounded_reproductions=old,phase_probe_rows=len(rows),current_probes=len(after),all27current_spans_beforecue_by_atleast_one_frame=True,minimum_visible_reading_residual_seconds=min(r['settled_reading_residual_seconds'] for r in after),summary=summary,rows=rows,scope='Realcachedwordtimings plus actualTracker, installedframeprogression/validation and actualsharedladderstep AST in controlledclock/object-interface fixture. No Scene,camera,renderer, audio access/synthesis, data/model load, decoder or producer.',reading_limit='Residuals derived fromsource retention andspeech-clocktime, notencoded pixelbrightness orperceptualreadability. Shortmotionstagesarenotreadabilityapproval; productionmotion/listening remainpending.' )
(D/'phase-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(summary=summary,total_phase_rows=len(rows),current_probes=len(after),minimum_settled_reading_residual_seconds=report['minimum_visible_reading_residual_seconds']),indent=2))
