"""Six serial, cached-only native endpoint captures; no source/model/data edits."""
from pathlib import Path
import ast,datetime,fcntl,hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai3-production-endpoint-sgns-words-geometry');OUT.mkdir(exist_ok=True)
wrapper=Path('/workspace/runtime/qa_production_endpoint.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
scene_files={'SGNS':'s14_sgns.py','Words':'s13_words.py','Geometry':'s17_geometry.py'}
commands=[];env=os.environ.copy()
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS'):env[name]='1'
receipt={'scope':'1920x1080 cached-only endpoint images; not full-resolution motion or listening approval','started_utc':stamp(),'wrapper_sha256':sha(wrapper),'numeric_thread_environment':{k:env[k] for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS')},'initial_disk_usage':dict(zip(('total','used','free'),shutil.disk_usage(ROOT))),'cases':commands}
state=OUT/'capture-receipt.json'
def save():state.write_text(json.dumps(receipt,indent=2)+'\n')
save()
for scene in ('SGNS','Words','Geometry'):
 for language in ('en','zh'):
  live=ROOT/'renders/qa/production-endpoints-1080/ai3'/language/scene
  row={'scene':scene,'lang':language,'target':str(live),'reconciled_before':{'folder_existed':live.exists(),'record_existed':(live/'result.json').exists()},'started_utc':stamp()};commands.append(row)
  source=ROOT/'videos/ai/ai3'/scene_files[scene];row['direct_source_before_sha256']=sha(source)
  # The six target folders were absent during explicit reconciliation. Refuse
  # unexpected concurrent output instead of overwriting an uncertain capture.
  if (live/'result.json').exists():row.update(status='pending-reconciliation',reason='unexpected existing capture appeared');save();continue
  before=OUT/'before'/language/scene;before.mkdir(parents=True,exist_ok=True)
  for p in (source,ROOT/'videos/ai/ai3/common.py',ROOT/'videos/ai/ai3/compute.py',ROOT/'videos/ai/ai3/manifest.py',ROOT/'videos/ai/ai3/zh_lines.py',ROOT/'videos/ai/ai_text_zh.json',ROOT/'tools/qa_series.py',wrapper):
   shutil.copy2(p,before/p.name)
  row['command']=['nice','-n','10',sys.executable,str(wrapper),'ai3',language,scene]
  row['log']=str(OUT/f'{language}-{scene}-capture.log');save();start=time.monotonic()
  with Path(row['log']).open('w') as log:run=subprocess.run(row['command'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
  row.update(exit_code=run.returncode,elapsed_seconds=round(time.monotonic()-start,3),completed_utc=stamp(),direct_source_after_sha256=sha(source));p=live/'result.json'
  if not p.exists():row.update(status='failed-no-record');save();continue
  record=json.loads(p.read_text());row.update(status=record['status'],warnings=record['warnings'],fingerprint=record['fingerprint'],record_sha256=sha(p),frames=len(record['frames']))
  if record['status'] not in ('passed','needs-review'):save();continue
  frozen=OUT/'captures'/language/scene/sha(p);frozen.mkdir(parents=True,exist_ok=True)
  with (live/'.lock').open('a') as lock:
   fcntl.flock(lock,fcntl.LOCK_SH)
   assert sha(p)==row['record_sha256'];shutil.copy2(p,frozen/'result.json');frames=[]
   for index,f in enumerate(record['frames']):
    dest=frozen/f['file'];shutil.copy2(live/f['file'],dest);frames.append(dict(f,index=index,path=str(dest),sha256=sha(dest),actual_view='pending'))
   for name in ('text.jsonl','sheet.png'):
    if (live/name).exists():shutil.copy2(live/name,frozen/name)
  sources={}
  for p in before.iterdir():sources[p.name]={'before_path':str(p),'before_sha256':sha(p)}
  inputs=[]
  for rel,signature in record['inputs'].items():
   p=ROOT/rel;s=p.stat();h=sha(p);saved=OUT/'inputs'/h/p.name;saved.parent.mkdir(parents=True,exist_ok=True)
   if not saved.exists():shutil.copy2(p,saved)
   inputs.append(dict(file=rel,recorded_signature=signature,signature_at_freeze=[s.st_size,s.st_mtime_ns],signature_matches=signature==[s.st_size,s.st_mtime_ns],sha256=h,preserved=str(saved)))
  audit=dict(scope=receipt['scope'],lang=language,scene=scene,frozen_utc=stamp(),record_sha256=row['record_sha256'],runtime_status=row['status'],warnings=row['warnings'],record_fingerprint=row['fingerprint'],source_before_after_matches=row['direct_source_before_sha256']==row['direct_source_after_sha256'],direct_source_sha256=row['direct_source_after_sha256'],sources=sources,inputs=inputs,frames=frames,actual_frames_viewed=0,findings=[],status='pending-native-view')
  (frozen/'review.json').write_text(json.dumps(audit,indent=2,ensure_ascii=False)+'\n');row['frozen']=str(frozen);row['storage_bytes']=sum(x.stat().st_size for x in live.rglob('*') if x.is_file());save();print(language,scene,row['status'],len(frames),'frames',flush=True)
receipt.update(completed_utc=stamp(),final_disk_usage=dict(zip(('total','used','free'),shutil.disk_usage(ROOT))));save();print('all six commands reconciled',flush=True)
