from pathlib import Path
import ast,json,os,hashlib,datetime
import numpy as np
from manim import config,tempconfig,Indicate,WHITE,DR,VGroup
from explainer.analysis import note,label
from explainer.style import C
from explainer import lang,zh_text
D=Path(__file__).parent;R=Path('/workspace/explainer-videos');language=os.environ['EXPLAINER_LANG'];lang.LANG=language
source=(D/'s18_contest.py').read_text();tree=ast.parse(source);body=next(n for n in next(n for n in tree.body if isinstance(n,ast.ClassDef)).body if isinstance(n,ast.FunctionDef) and n.name=='board').body
ov=json.loads((D/'translation-overlay.json').read_text());table=json.loads((R/'videos/ai/ai_text_zh.json').read_text());table['strings'].update(ov['strings']);zh_text._TABLE=table;zh_text._BY_NUMBERS=None
board=json.loads((R/'.cache/ai6/board.json').read_text());rows=board['rows'];best=max(r['70']['cv'] for r in rows if '70' in r);selected=[(k,r) for k,r in enumerate(rows) if '70' in r and r['70']['cv']==best]
# Execute only the actual new legend expression and unchanged row construction AST,
# with a tiny selector retaining true original row indices. No Scene construction.
from manim import Rectangle,Line,MathTex,GREY_D,RIGHT
ns=dict(W=2.5,col2=-.5,col70=3.4,rows=rows,b=board,np=np,C2=C.TRUE_P,C70=C.BITS,LO=.7,note=note,label=label,DR=DR,VGroup=VGroup,MathTex=MathTex,WHITE=WHITE,GREY_D=GREY_D,RIGHT=RIGHT,Rectangle=Rectangle,Line=Line,enumerate=lambda _:selected)
loop=next(n for n in body if isinstance(n,ast.For));scale=next(n for n in body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='scale' for t in n.targets));ns['lines']=VGroup()
texdir=D/('geometry-Tex-'+language);texdir.mkdir(exist_ok=True)
with tempconfig(dict(tex_dir=str(texdir),frame_width=128/9,frame_height=8,pixel_width=854,pixel_height=480,disable_caching=False)):
 exec(compile(ast.Module([loop,scale],type_ignores=[]),'<actual-bounded-row/legend-geometry>','exec'),ns)
 legend=ns['scale'];bounds=lambda m:[float(m.get_left()[0]),float(m.get_right()[0]),float(m.get_bottom()[1]),float(m.get_top()[1])];lb=bounds(legend);last_bar_bottom=2.35-.47*(len(rows)-1)-.26/2
 assert lb[0]>=-config.frame_width/2+.19 and lb[1]<=config.frame_width/2-.19,(language,lb)
 assert lb[2]>=-4+.19 and last_bar_bottom-lb[3]>=.15,(language,lb,last_bar_bottom)
 groups=ns['lines'];sweep=[]
 for i,(k,row) in enumerate(selected):
  target=groups[i][2];origin=bounds(target)
  for alpha in np.linspace(0,1,21):
   obj=target.copy();animation=Indicate(obj,color=WHITE,scale_factor=1.05);animation.begin();animation.interpolate(float(alpha));bb=bounds(obj);assert bb[0]>=-config.frame_width/2 and bb[1]<=config.frame_width/2 and bb[2]>=-4 and bb[3]<=4;assert bb[3]-bb[2]<.47
   sweep.append(dict(method=row['key'],alpha=float(alpha),bounds=bb));animation.finish()
 report=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),language=language,source_sha256=hashlib.sha256(source.encode()).hexdigest(),source_nodes='Actual legend assignment and unchanged row loop, evaluated only at true co-leader original indices2and7.',frame=[config.frame_width,config.frame_height],pixels=[854,480],legend_original_english=next(iter(ov['strings'])),legend_translation=zh_text.translate(next(iter(ov['strings']))),legend_bounds=lb,legend_font_size=float(legend.font_size),bottom_margin_world=lb[2]+4,chart_legend_gap_world=last_bar_bottom-lb[3],right_margin_world=config.frame_width/2-lb[1],co_leader_rows=[k for k,r in selected],actual_Indicate_bounds_sweep=sweep,checks=['Newtwo-linelegend compiled with actualEN/ChineseTex and explicitprivateoverlay','Bottom/right margins>=.19world and legend-to-chart gap>=.15world','42actualIndicate states bounded and rowheight<.47world'],limits='Geometry/Texcompile only. No camera, movie, Scene, producer, model, defaultloader or actual post-patch visual approval. Tex intermediates are private regeneration outputs.')
 (D/('geometry-'+language+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['actual_Indicate_bounds_sweep']},ensure_ascii=False,indent=2))
