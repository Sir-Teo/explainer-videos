# Contest joint leaders and capped SD bars — private candidate

Not applied. Source target is `videos/ai/ai6/s18_contest.py`; root owns controlled integration and EN/ZH renders.

Completed board data give logistic regression and Gaussian-kernel SVM the same exact mean0.9953365384615385 and SD0.007509171468762143. The candidate says two procedures tie for the highest mean,99.5%, and highlights both in original row order. Exact equality is tested before display rounding; distinct means both rounded99.5 do not become a tie. Unique/three-way/unavailable winner fragments have private translations and tiny source-expression fixtures.

Of22method/feature cases,10 two-rate cases have no lower/upper SD caps;12 seventy-rate cases have zero lower and8upper caps. The existing values/line clipping remain unchanged, with an explicit two-line70–100%/axis-cap legend. Actual English and Chinese TeX geometry passes:20pt, bottom/right inset0.20world, chart gap0.4027/0.4011world.42Indicate states/language preserve row clearance; this is geometry, not rendered-output review.

All other scene methods, numerical bar/error construction, earlier reveal statements/run-times and three bookmark names/order remain unchanged.15 private source/translation/invariant checks pass. Two original854×480 endpoint003 frames were actually viewed and copied byte-exact; neither is1080. Changed voiceover wording requires fresh timing/appearance validation.

`handoff.json` carries exact source/table/cache pins, old/new full voiceover expressions, cap inventory and limits. `translation-overlay.json` is private only, based on localZH0c4… and global0884…; no shared source/table/cache changes. Initial tuple-selection fixture error was corrected and retained separately, with no application defect inferred.
