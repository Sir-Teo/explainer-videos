from pathlib import Path
import ast,json,hashlib,math,copy,re,functools,datetime
D=Path(__file__).parent;R=Path('/workspace/explainer-videos');old=(R/'videos/ai/ai6/s18_contest.py').read_text();new=(D/'s18_contest.py').read_text();ot=ast.parse(old);nt=ast.parse(new);ov=json.loads((D/'translation-overlay.json').read_text());data=json.loads((R/'.cache/ai6/board.json').read_text());checks=[]
def check(name,value):
 assert value,name;checks.append(dict(name=name,passed=True))
def dump(n):return ast.dump(n,include_attributes=False)
def cls(t):return next(n for n in t.body if isinstance(n,ast.ClassDef))
om={n.name:n for n in cls(ot).body if isinstance(n,ast.FunctionDef)};nm={n.name:n for n in cls(nt).body if isinstance(n,ast.FunctionDef)}
check('construct/cultures/tables/today AST exact',all(dump(om[n])==dump(nm[n]) for n in om if n!='board'))
ob=om['board'];nb=nm['board']
# Every plotted data transformation and row/column construction remains identical.
oldloop=next(n for n in ob.body if isinstance(n,ast.For));newloop=next(n for n in nb.body if isinstance(n,ast.For));check('bar/error/numeric label loop exact AST',dump(oldloop)==dump(newloop))
voice=lambda b:next(n for n in ast.walk(b) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover').args[0]
marks=lambda n:re.findall(r"<bookmark mark='([^']+)'/>",''.join(v.value for v in ast.walk(n) if isinstance(v,ast.Constant) and isinstance(v.value,str)))
check('first narration bookmark order a/b/c exact',marks(voice(ob))==marks(voice(nb))==['a','b','c'])
oldwith=next(n for n in ob.body if isinstance(n,ast.With));newwith=next(n for n in nb.body if isinstance(n,ast.With))
check('all reveal/wait statements before final emphasis exact AST',all(dump(a)==dump(b) for a,b in zip(oldwith.body[:-1],newwith.body[:-1])) and len(oldwith.body)==len(newwith.body))
newlast=newwith.body[-1];oldlast=oldwith.body[-1];check('co-leader emphasis and empty fallback retain one second',isinstance(newlast,ast.If) and next(k.value.value for k in oldlast.value.keywords if k.arg=='run_time')==1 and next(k.value.value for k in newlast.body[0].value.keywords if k.arg=='run_time')==1 and newlast.orelse[0].value.args[0].value==1)
ns={'math':math};exec(compile(ast.Module([next(n for n in nt.body if isinstance(n,ast.FunctionDef) and n.name=='board_leaders')],type_ignores=[]),'<pure-board-helper>','exec'),ns);leader=ns['board_leaders'];ls=leader(data['rows'])
check('actual exact LR/SVM tie and input order',[(r['key'],r['70']['cv'],r['70']['sd']) for r in ls]==[('lr',.9953365384615385,.007509171468762143),('svm_rbf',.9953365384615385,.007509171468762143)])
check('synthetic equal displayed precision does not invent exact tie',len(leader([{'70':{'cv':.9954}},{'70':{'cv':.9953}}]))==1)
check('finite/nonfinite/missing-feature alternatives',leader([{'70':{'cv':float('nan')}},{'70':{'cv':float('inf')}},{'2':{'cv':1}}])==[])
check('synthetic multiple exact co-leaders preserve all rows',len(leader([{'70':{'cv':.8}},{'70':{'cv':.8}},{'70':{'cv':.8}}]))==3)
# Pure translator extraction: no production imports/loaders/Scene construction.
ref=ast.parse(Path('/workspace/runtime/ai6-svm-native1080-review/reconcile.py').read_text());nodes=[n for n in ref.body if isinstance(n,ast.FunctionDef) and n.name in {'dicts','cap','narration_translator'}];trns=dict(ast=ast,re=re,types=__import__('types'),functools=functools);exec(compile(ast.Module(nodes,type_ignores=[]),'<pure-translation-tools>','exec'),trns)
zsrc=(R/'videos/ai/ai6/zh_lines.py').read_text();z=trns['dicts'](zsrc);z['ZH'].update(ov['ZH_updates']);tr=trns['narration_translator']((R/'explainer/zh_templates.py').read_text(),new,z)
allowed={'a2','lo2','hi2','leaders70','winner_s','best70','best_mean','tree70','xgb70','lr70','line_s'}
def env(rows):
 env={'math':math,'board_leaders':leader,'rows':rows}
 for n in nb.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and all(isinstance(v,ast.Name) and v.id in allowed for v in (n.targets[0].elts if isinstance(n.targets[0],ast.Tuple) else [n.targets[0]])):exec(compile(ast.Module([n],type_ignores=[]),'<actual-scene-scalar-expression>','exec'),env)
  if isinstance(n,ast.If) and any(isinstance(x,ast.Assign) and any(isinstance(v,ast.Name) and v.id in {'winner_s','line_s'} for v in x.targets) for x in ast.walk(n)):exec(compile(ast.Module([n],type_ignores=[]),'<actual-scene-verdict-branch>','exec'),env)
 return env
actual=env(data['rows']);vn=voice(nb);actualvoice=eval(compile(ast.Expression(vn),'<actual-VO-expression>','eval'),actual);actualzh=tr(' '.join(actualvoice.split()));check('actual nested joint-best verdict translated with numeric value',actualzh is not None and '2种流程并列取得最高平均准确率，为99.5%' in actualzh and '最高的是逻辑回归' not in actualzh)
check('actual EN and ZH bookmarks preserved',marks(ast.Constant(actualvoice))==marks(ast.Constant(actualzh))==['a','b','c'])
alt=copy.deepcopy(data['rows']);next(r for r in alt if r['key']=='lr')['70']['cv']=.996;unique=env(alt);uniqueen=eval(compile(ast.Expression(vn),'<actual-unique-VO-expression>','eval'),unique);uniquezh=tr(' '.join(uniqueen.split()));check('unique-winner alternative method-name translation',uniquezh is not None and '逻辑回归的平均准确率最高，为99.6%' in uniquezh)
alt=copy.deepcopy(data['rows']);next(r for r in alt if r['key']=='lasso')['70']['cv']=.9953365384615385;multi=env(alt);multizh=tr(' '.join(eval(compile(ast.Expression(vn),'<actual-three-way-VO-expression>','eval'),multi).split()));check('three-way exact tie translated as three rather than first',multizh is not None and '3种流程并列取得最高平均准确率' in multizh)
for n in ['No finite seventy-rate mean accuracy is available here.']:
 check('unavailable winner fragment translates',tr(n)==ov['ZH_updates'][n])
zt=(R/'explainer/zh_text.py').read_text();base=json.loads((R/'videos/ai/ai_text_zh.json').read_text());base['strings'].update(ov['strings']);ct=trns['cap'](zt,base)
for k,v in ov['strings'].items():check('exact proposed cap-legend global lookup',ct(k)==v)
report=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=checks,total=len(checks),candidate_sha256=hashlib.sha256(new.encode()).hexdigest(),actual_english=actualvoice,actual_zh=actualzh,unique_zh=uniquezh,three_way_zh=multizh,scope='Actual AST scalar/VO expressions with existing board and tiny alternative fixtures; no Scene/defaultload/import/producer/model/render/decode. Geometry separate.')
(D/'source-translation-fixtures.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(checks=len(checks),passed=True,candidate_sha256=report['candidate_sha256'],actual_verdict=actual['winner_s'],actual_zh=actualzh),ensure_ascii=False,indent=2))
