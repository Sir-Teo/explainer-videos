import json,sys,hashlib,shutil
from pathlib import Path
from datetime import datetime,timezone
root=Path(__file__).parent;p=root/sys.argv[1]/'review.json';d=json.loads(p.read_text())
assert d['checkpoint']['all_selected_frames_covered']
for t in map(float,sys.argv[2:]):
 a=min(d['unique_representative_frames'],key=lambda a:abs(a['time']-t));src=Path(d['audit_result']).parent/a['file'];assert hashlib.sha256(src.read_bytes()).hexdigest()==a['sha256'];dest=p.parent/('native-'+src.name);shutil.copy2(src,dest);d['native_followups'].append({**a,'evidence':str(dest),'actually_viewed':True})
d['visual_selected_frame_review']='complete; no additional concrete defect found in reviewed selections'
d['completed_utc']=datetime.now(timezone.utc).isoformat()
src=Path(d['movie']);dest=p.parent/'reviewed-movie.mp4';shutil.copy2(src,dest);assert hashlib.sha256(dest.read_bytes()).hexdigest()==d['movie_sha256'];d['frozen_movie']=str(dest)
p.write_text(json.dumps(d,indent=2)+'\n');print(d['case'],d['checkpoint'])
