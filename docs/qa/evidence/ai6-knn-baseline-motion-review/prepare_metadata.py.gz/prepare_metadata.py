from pathlib import Path
import json,hashlib,shutil,subprocess,fcntl,time,os,datetime
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;I=Path('/workspace/runtime/ai6-remaining-qa-serial/final-gate-completed-index.json');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[x for x in json.loads(I.read_text())['rows'] if x['scene']=='KNN'];assert len(rows)==4
(D/'index-at-freeze.json').write_bytes(I.read_bytes());sources={}
for name in ['videos/ai/ai6/s10_knn.py','videos/ai/ai6/common.py','videos/ai/ai6/zh_lines.py','videos/ai/ai_text_zh.json','tools/qa_motion.py']:
 p=R/name;q=D/'observed-source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);sources[name]={'sha256':sha(p),'bytes':p.stat().st_size}
freeze=[]
for row in rows:
 receipt=Path(row['receipt']);assert sha(receipt)==row['receipt_sha256'];case=receipt.parent;out=D/row['lang']/row['mode'];out.mkdir(parents=True,exist_ok=True)
 for name in ['receipt.json','source-before.json','source-after.json','data-before.json','data-after.json','command.json']:
  p=case/name;shutil.copyfile(p,out/name)
 for name in ['result.json','copy-manifest.json','text.jsonl']:
  p=case/'completed'/name;shutil.copyfile(p,out/('raw-'+name))
 observations=[]
 for artifact in json.loads(receipt.read_text())['freeze']['artifacts']:
  p=Path('/workspace/runtime/ai6-remaining-qa-serial')/artifact['destination'];assert p.is_file() and sha(p)==artifact['sha256'];assert p.stat().st_nlink==1
  observations.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'inode':p.stat().st_ino,'nlink':p.stat().st_nlink})
 freeze.append({'index_row':row,'artifacts_verified':observations})
(D/'freeze.json').write_text(json.dumps({'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':freeze,'observed_sources':sources,'observations_not_historical_import_proof':True},indent=2)+'\n')
