from pathlib import Path
import json,hashlib,shutil,subprocess,fcntl,time,os,datetime
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((D/'freeze.json').read_text());rows=[c['index_row'] for c in frozen['cases']];sources=frozen['observed_sources']
for language in ['en','zh']:
 row=next(x for x in rows if x['lang']==language and x['mode']=='motion');movie=Path(row['movie']['path']);out=D/language/'audit';log=D/language/'audit.log'
 with open('/workspace/runtime/ai4-tail-motion-review/extract.lock','a') as lock:
  print(language,'waiting-shared-extract-lock',flush=True);fcntl.flock(lock,fcntl.LOCK_EX)
  assert shutil.disk_usage('/workspace').free>=768*2**20,'disk guard before extraction'
  assert sha(movie)==row['movie']['sha256']
  command=['nice','-n','10',os.environ['ACTIVE_PYTHON'],str(R/'tools/qa_motion.py'),str(movie),'-o',str(out),'--dense','.25','--max-gap','1']
  # The activated interpreter is supplied by the parent process; no guessed environment path.
  with log.open('w') as f:
   child=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
   while child.poll() is None:
    free=shutil.disk_usage('/workspace').free
    if free<768*2**20:
     child.terminate();child.wait();(D/'resource-stop.json').write_text(json.dumps({'language':language,'free_bytes':free,'threshold':768*2**20,'command':command,'reason':'disk guard during extraction','time':time.time()},indent=2));raise SystemExit(72)
    time.sleep(1)
  assert child.returncode==0,language+' extraction exit '+str(child.returncode)
  assert sha(movie)==row['movie']['sha256'];assert sha(R/'tools/qa_motion.py')==sources['tools/qa_motion.py']['sha256']
  print(language,'audit-complete',flush=True)
(D/'extract-complete.json').write_text(json.dumps({'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'both_movie_sha_unchanged':True,'disk_free_bytes':shutil.disk_usage('/workspace').free},indent=2)+'\n')
