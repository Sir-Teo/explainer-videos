"""Byte-preserving zero-interior sparsification of completed Part6 silent QA snapshots only."""
from pathlib import Path
import os,json,hashlib,stat,subprocess,datetime,shutil,gzip,ast
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/capacity-ai6-snapshot-silent-wav-sparse-20261101');PLAN=D/'plan.json';PIN='3f2b23abd416e1f7bf25e0b47334912ff465e919d49ff6bb7bc0b46782f8e6b4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save_gz(name,obj):
 with (D/name).open('wb') as f:
  with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as z:z.write(json.dumps(obj,indent=2).encode())
def stamp(p):
 s=p.stat();return dict(bytes=s.st_size,sha256=sha(p),mtime_ns=s.st_mtime_ns,mode=stat.S_IMODE(s.st_mode),inode=s.st_ino,device=s.st_dev,allocated_bytes=s.st_blocks*512,ctime_ns=s.st_ctime_ns)
def source_inventory():
 paths=set()
 for name in ['explainer','videos','tools','tests']:
  paths.update(p for p in (R/name).rglob('*') if p.is_file() and p.suffix in ['.py','.json'] and '__pycache__' not in p.parts)
 for name in ['pyproject.toml','uv.lock','requirements.txt','manim.cfg']:
  p=R/name
  if p.is_file():paths.add(p)
 H=R/'docs/qa/evidence/production-handoff-parts1-3';paths.update(p for p in H.glob('*') if p.is_file() and p.suffix in ['.py','.json']);paths.update((H/'overlays').glob('*.json'))
 return {str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(paths)}
def activity(targets):
 counts={};matches=[]
 def count(k):counts[k]=counts.get(k,0)+1
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  count('pids_seen')
  try:
   fds=list((proc/'fd').iterdir());count('fd_dirs_readable')
   for fd in fds:
    try:q=os.readlink(fd);count('fd_links_readable')
    except (PermissionError,FileNotFoundError,ProcessLookupError):count('fd_links_unreadable_or_raced');continue
    if q in targets:matches.append({'pid':proc.name,'path':q,'kind':'fd'})
  except (PermissionError,FileNotFoundError,ProcessLookupError):count('fd_dirs_unreadable_or_raced')
  try:
   maps=(proc/'maps').read_text();count('maps_readable')
   for line in maps.splitlines():
    fields=line.split(maxsplit=5)
    if len(fields)==6 and fields[5] in targets:matches.append({'pid':proc.name,'path':fields[5],'kind':'mapped'})
  except (PermissionError,FileNotFoundError,ProcessLookupError):count('maps_unreadable_or_raced')
 return dict(at=now(),counts=counts,visible_open_or_mapped_targets=matches,caveat='Partial host FD/maps visibility. Only already completed independent runtime snapshots, with task-owned copy activity reconciled by receipts; no global process-absence claim.')
assert sha(PLAN)==PIN;plan=json.loads(PLAN.read_text());candidates=[r for r in plan['files'] if r['eligible']];assert len(candidates)==30
protected_reference=json.loads(Path('/workspace/runtime/capacity-silent-qa-sparse-20261101/receipt.json').read_text())['protected_after'];assert len(protected_reference)==306
protected_before={p:stamp(Path(p)) for p in protected_reference};save_gz('protected306-before.json.gz',protected_before)
assert all(v['sha256']==protected_reference[p]['sha256'] and v['bytes']==protected_reference[p]['bytes'] for p,v in protected_before.items())
sources_before=source_inventory();assert len(sources_before)==1524;save_gz('source-before.json.gz',sources_before)
targets={r['path'] for r in candidates};assert len(targets)==len(candidates)
activity_before=activity(targets);(D/'activity-before.json').write_text(json.dumps(activity_before,indent=2));opened={r['path'] for r in activity_before['visible_open_or_mapped_targets']}
free_before=shutil.disk_usage('/workspace').free;started=now();rows=[];stopped=None
for row in candidates:
 p=Path(row['path']);result={'path':str(p),'completion_witness':row['witness']}
 if str(p) in opened:result.update(status='skipped-visible-open-or-mapped');rows.append(result);continue
 try:
  assert sha(PLAN)==PIN and source_inventory()==sources_before,'Plan/source hash drift'
  assert p.is_relative_to('/workspace/runtime') and p.relative_to('/workspace/runtime').parts[0].startswith('ai6-') and any(x in ['frozen','completed'] for x in p.parts),'Path scope mismatch'
  assert p.resolve()==p and not p.is_symlink() and p.suffix=='.wav' and stat.S_ISREG(p.stat().st_mode) and p.stat().st_nlink==1,'Not regular independent snapshot'
  s=p.stat();assert s.st_size==row['inventory']['bytes'] and s.st_ino==row['inventory']['inode'] and s.st_mtime_ns==row['inventory']['mtime_ns'],'Snapshot metadata drift'
  assert sha(Path(row['witness']['path']))==row['witness']['sha256'],'Completion witness changed'
  if row.get('command'):assert sha(Path(row['command']['path']))==row['command']['sha256'],'Silent command witness changed'
  before=stamp(p);assert before['sha256']==row['expected_sha256'],'Completed artifact hash mismatch'
  start=4096;length=(s.st_size//4096)*4096-start
  if length<=0:result.update(status='skipped-no-aligned-interior');rows.append(result);continue
  with p.open('rb') as f:
   header=f.read(start);assert header[:4]==b'RIFF' and header[8:12]==b'WAVE','Not RIFF/WAVE'
   remaining=length;zero=True;checked=0
   while remaining:
    chunk=f.read(min(1024*1024,remaining));assert chunk,'Truncated interior'
    checked+=len(chunk)
    if chunk.strip(b'\0'):zero=False;break
    remaining-=len(chunk)
   f.seek(start+length);tail=f.read()
  if not zero:result.update(status='skipped-nonzero-interior',checked_bytes=checked);rows.append(result);continue
  assert checked==length and stamp(p)==before and sha(Path(row['witness']['path']))==row['witness']['sha256'],'File/witness changed during zero proof'
  # Recheck known visible consumers immediately before this one physical operation.
  check=activity({str(p)})
  if check['visible_open_or_mapped_targets']:result.update(status='skipped-visible-consumer-before-punch',activity=check);rows.append(result);continue
  header_sha=hashlib.sha256(header).hexdigest();tail_sha=hashlib.sha256(tail).hexdigest()
  result.update(before=before,punch_offset=start,punch_length=length,entire_aligned_interior_verified_zero=True,zero_bytes_checked=checked,header_bytes=len(header),tail_bytes=len(tail),header_sha256=header_sha,tail_sha256=tail_sha)
  (D/'operation-intent.json').write_text(json.dumps({'at':now(),**result},indent=2))
  operation=subprocess.run(['fallocate','--punch-hole','--keep-size','--offset',str(start),'--length',str(length),str(p)],capture_output=True,text=True)
  if operation.returncode:
   result.update(status='unsupported-or-failed',returncode=operation.returncode,stderr=operation.stderr);rows.append(result);stopped='Physical hole punch failed/unsupported; no retry or alternate method attempted';break
  os.utime(p,ns=(s.st_atime_ns,s.st_mtime_ns));after=stamp(p)
  for k in ['bytes','sha256','mtime_ns','mode','inode','device']:assert before[k]==after[k],(str(p),k)
  with p.open('rb') as f:
   after_header=f.read(start);f.seek(start+length);after_tail=f.read()
  assert after_header==header and after_tail==tail,'Header/tail changed'
  assert sha(Path(row['witness']['path']))==row['witness']['sha256'],'Completion witness changed during operation'
  result.update(status='byte-exact-sparse',after=after,allocated_bytes_recovered=before['allocated_bytes']-after['allocated_bytes'],original_mtime_explicitly_restored=True,ctime_changed=before['ctime_ns']!=after['ctime_ns'],header_tail_unchanged=True)
  rows.append(result);(D/'progress.json').write_text(json.dumps({'rows':rows},indent=2)+'\n');print('processed',len(rows),'/',len(candidates),'recovered',result['allocated_bytes_recovered'],flush=True)
 except (AssertionError,FileNotFoundError) as e:
  result.update(status='skipped-drift-or-eligibility-failure',reason=str(e));rows.append(result);stopped='Drift/eligibility failure; remaining candidates preserved';break
protected_after={p:stamp(Path(p)) for p in protected_reference};sources_after=source_inventory();save_gz('protected306-after.json.gz',protected_after);save_gz('source-after.json.gz',sources_after)
activity_after=activity(targets);(D/'activity-after.json').write_text(json.dumps(activity_after,indent=2));free_after=shutil.disk_usage('/workspace').free
receipt={'started':started,'finished':now(),'scope':'Only initial30 alreadycompleted independent runtime/ai6-*/frozen|completed silentQA WAV snapshots; no canonicalactive renders/voice/model/cache paths. Physicalzero-interiorholepunch, no deletion/reencoding/speech changes.','plan_sha256':PIN,'candidate_count':len(candidates),'candidate_before_allocated_bytes':sum(r['inventory']['allocated'] for r in candidates),'processed_count':sum(r['status']=='byte-exact-sparse' for r in rows),'skips_and_failures':[r for r in rows if r['status']!='byte-exact-sparse'],'stopped_reason':stopped,'remaining_unprocessed':len(candidates)-len(rows),'allocated_bytes_recovered':sum(r.get('allocated_bytes_recovered',0) for r in rows),'free_before':free_before,'free_after':free_after,'observed_free_space_delta':free_after-free_before,'free_space_caveat':'Other Part6 captures/reviews write concurrently; wholefilesystemfree delta is separate from exact targetallocation recovery.','protected306_count':len(protected_before),'protected306_exact_signatures_unchanged':protected_before==protected_after,'source_files':len(sources_before),'critical_source_bytes_unchanged':sources_before==sources_after,'activity_caveat':activity_after['caveat'],'all_successful_file_bytes_size_inode_device_mode_mtime_preserved':all(all(r['before'][k]==r['after'][k] for k in ['sha256','bytes','inode','device','mode','mtime_ns']) for r in rows if r['status']=='byte-exact-sparse'),'ctime_changes_explicitly_recorded':True,'rows':rows}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='rows'},indent=2),flush=True)
assert receipt['protected306_exact_signatures_unchanged'] and receipt['critical_source_bytes_unchanged'] and receipt['all_successful_file_bytes_size_inode_device_mode_mtime_preserved']
