from pathlib import Path
import json,hashlib,stat,datetime,shutil
O=Path('/workspace/runtime/capacity-ai6-snapshot-silent-wav-sparse-20261101');R=Path('/workspace/explainer-videos');B=Path('/workspace/runtime');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();inventory=json.loads((O/'inventory-unverified.json').read_text());rows=[]
for row in inventory['files']:
 p=Path(row['path']);base=B/p.relative_to(B).parts[0];entry={'path':str(p),'inventory':row};reason=None
 try:
  assert p.resolve()==p and not p.is_symlink() and stat.S_ISREG(p.stat().st_mode) and p.stat().st_nlink==1,'Not an independent regular snapshot'
  s=p.stat();assert s.st_size==row['bytes'] and s.st_ino==row['inode'] and s.st_mtime_ns==row['mtime_ns'],'Snapshot changed after initial inventory'
  marker=next(a for a in p.parents if a.name in ['frozen','completed']);case=marker.parent
  if marker.name=='frozen':
   witness=case/'complete.json';d=json.loads(witness.read_text());assert d['status'] in ['passed','needs-review'],'Incomplete/failed capture'
   artifact=next(a for a in d['files'] if Path(a['copy'])==p);canonical=Path(artifact['canonical']);expected=artifact['sha256'];count=artifact['bytes'];silent_evidence='Own completed copy2 capture ledger; silent-QA task/driver; independent canonical inode checked and zero interior will be proved.'
  else:
   witness=case/'receipt.json';d=json.loads(witness.read_text());assert d.get('runtime_completed') is True and not d.get('aborted') and d.get('mode')=='motion' and d['freeze'].get('present') is True,'No complete capture witness'
   artifact=next(a for a in d['freeze']['artifacts'] if base/a['destination']==p);assert artifact.get('independent_copy2') is True,'No independent copy2 witness'
   canonical=R/artifact['source'];expected=artifact['sha256'];count=artifact['bytes'];command=case/'command.json';cmd=json.loads(command.read_text());assert cmd['env_overrides']['EXPLAINER_TTS']=='silent','Not explicitly silent QA';entry['command']={'path':str(command),'sha256':sha(command)};silent_evidence='Completed runtime receipt + explicit EXPLAINER_TTS=silent command + independent_copy2 artifact.'
  assert s.st_size==count and sha(p)==expected,'Completed artifact bytes/hash mismatch'
  if canonical.exists():assert (canonical.stat().st_dev,canonical.stat().st_ino)!=(s.st_dev,s.st_ino),'Snapshot shares canonical inode'
  assert witness.stat().st_mtime_ns>=s.st_mtime_ns,'Completion witness predates copied data'
  entry.update(eligible=True,expected_sha256=expected,witness={'path':str(witness),'sha256':sha(witness),'artifact':artifact},canonical=str(canonical),silent_evidence=silent_evidence)
 except (AssertionError,FileNotFoundError,KeyError,StopIteration) as e:reason=str(e) or type(e).__name__;entry.update(eligible=False,skip_reason=reason)
 rows.append(entry)
plan={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Only initial30 stable completed runtime/ai6-*/ frozen orcompleted silentQA WAV copies; no canonicalactive WAV orvoice/model/cachepaths. No punching yet.','files':rows,'eligible_count':sum(r['eligible'] for r in rows),'eligible_allocated_bytes':sum(r['inventory']['allocated'] for r in rows if r['eligible']),'free_before':shutil.disk_usage('/workspace').free};(O/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print({k:v for k,v in plan.items() if k!='files'});print('skips',[(r['path'],r.get('skip_reason')) for r in rows if not r['eligible']]);print('plan_sha',sha(O/'plan.json'))
