"""Actual AST-consumer/text geometry tests; no scene/producer imports or renders."""
import os,sys,ast,copy,json,hashlib,math,unittest
from pathlib import Path
os.environ['EXPLAINER_LANG']='zh';os.environ['EXPLAINER_VIDEO']='ai5'
R=Path('/workspace/explainer-videos');O=Path(__file__).parent;B=Path('/workspace/runtime/ai5-mc-score-mcmc-brownian-endpoint-review')
sys.path.insert(0,str(R))
import numpy as np
from manim import *
from explainer import lang,zh_text
from explainer.ai import *
from videos.ai.ai5.plotting import clipped_curve
D=json.loads((O/'proposed-zh-overlay.json').read_text());T=json.loads((R/'videos/ai/ai_text_zh.json').read_text());T['strings'].update(D['strings']);zh_text._TABLE=T;zh_text._BY_NUMBERS=None
HELPER='1d76a9c4145eedf0f3a65549223ba4b8edae1397f6d8696c146b45037542d845'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def method(f,name,before=False):
 t=ast.parse(((O/'before'/f) if before else (R/'videos/ai/ai5'/f)).read_text());return next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name==name)
def execute(node,env):exec(compile(ast.fix_missing_locations(ast.Module(body=[copy.deepcopy(node)],type_ignores=[])),'<actual-consumer-AST>','exec'),env)
def assigned(fn,name):return next(n for n in fn.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
def source_env():
 env=dict(globals());env.update(DATA=C.TRUE_P,MODEL=C.MODEL_Q,WALK='#7FD3FF',SF=C.INTERVAL)
 common=ast.parse((R/'videos/ai/ai5/common.py').read_text());execute(next(n for n in common.body if isinstance(n,ast.FunctionDef) and n.name=='curve'),env);return env

def data(scene,item):
 p=next((B/'cases').glob('en-'+scene+'-*'));receipt=json.loads((p/'freeze.json').read_text());files={x['original_path']:B/x['copy'] for x in receipt['inputs']};prefix='.cache/ai5/'+item
 d=json.loads(files[prefix+'.json'].read_text())
 with np.load(files[prefix+'.npz'],allow_pickle=False) as z:d.update({k:z[k] for k in z.files})
 return d
MC=data('MonteCarlo','montecarlo');QV=data('Brownian','qv');GEOM=[]

def mc_env(language):
 lang.LANG=language;os.environ['EXPLAINER_LANG']=language;env=source_env();fn=method('s13_montecarlo.py','darts');env.update(N=int(MC['N']),est=MC['est'])
 for name in ['ax','xl','xn','yl','zoom_note','pi_l','pi_t','ns','t','ev','colors','f']:execute(assigned(fn,name),env)
 expr=next(n for n in fn.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n).startswith('VGroup(f, ev).arrange'))
 execute(expr,env)
 for name in ['path','offscale']:execute(next(n for n in fn.body if isinstance(n,ast.FunctionDef) and n.name==name),env)
 return env

def bounds(obj):return [float(obj.get_left()[0]),float(obj.get_right()[0]),float(obj.get_bottom()[1]),float(obj.get_top()[1])]
class Tests(unittest.TestCase):
 def test_helper_freeze_and_no_production_import(self):
  self.assertEqual(sha(R/'videos/ai/ai5/plotting.py'),HELPER)
  self.assertFalse(any(n.startswith(('videos.ai.ai5.compute','videos.ai.ai5.common','videos.ai.ai5.s13','videos.ai.ai5.s14','videos.ai.ai5.s16')) for n in sys.modules))
 def test_all_vo_bookmarks_timing_and_unowned_methods_unchanged(self):
  def vos(t):return [ast.dump(n.args[0]) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover']
  for f,allowed in [('s13_montecarlo.py','darts'),('s14_scorefn.py','derive'),('s16_brownian.py','quadratic')]:
   old=ast.parse((O/'before'/f).read_text());new=ast.parse((R/'videos/ai/ai5'/f).read_text());self.assertEqual(vos(old),vos(new))
   def plays(t):return [(n.func.attr,[(k.arg,ast.dump(k.value)) for k in n.keywords]) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['play','wait','voiceover']]
   self.assertEqual(plays(old),plays(new))
   for name in [n.name for n in next(n for n in old.body if isinstance(n,ast.ClassDef)).body if isinstance(n,ast.FunctionDef) and n.name!=allowed]:self.assertEqual(ast.dump(method(f,name,True)),ast.dump(method(f,name)))
 def test_darts_actual_start_and_all206_vertices_trueclipped(self):
  e=mc_env('en');self.assertEqual(float(e['ev'].get_value()),4.0)
  for n,count in [(1,1),(2,2),(4000,9)]:
   e['t'].set_value(n);marks=e['offscale']();self.assertEqual(len(marks),count)
   curve_=e['path']();xs=np.log10(e['ns'][e['ns']<=n]);ys=e['est'][e['ns'][e['ns']<=n]-1]
   for sub in curve_.get_subpaths():
    for curvepts in [sub[i:i+4] for i in range(0,len(sub)-3,4)]:
     for p in curvepts:
      x,y=e['ax'].p2c(p)[:2];self.assertGreaterEqual(y,2.6-1e-9);self.assertLessEqual(y,3.7+1e-9)
      self.assertAlmostEqual(y,float(np.interp(x,xs,ys)),places=8)
   for marker in marks:
    x,y=e['ax'].p2c(marker.get_center())[:2];self.assertTrue(abs(y-2.6)<1e-8 or abs(y-3.7)<1e-8)
  self.assertEqual(e['est'][0],4.0);self.assertEqual(e['est'][1],4.0)
 def test_score_line_is_really_linear_without_horizontal_caps(self):
  fn=method('s14_scorefn.py','derive');call=next(n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='clipped_curve')
  env=source_env();env['pa_']=Axes(x_range=[-3,3,1],y_range=[-2.5,2.5,1],x_length=3.6,y_length=1.6,tips=False);env['xx']=np.linspace(-3,3,150)
  obj=eval(compile(ast.Expression(call),'<actual-score-call>','eval'),env)
  pts=np.array([env['pa_'].p2c(p)[:2] for p in obj.points]);self.assertTrue(np.allclose(pts[:,0],pts[:,1],atol=1e-12));self.assertAlmostEqual(pts[:,0].min(),-2.5);self.assertAlmostEqual(pts[:,0].max(),2.5)
 def test_brownian_all_raw_vertices_preserved_and_clear_of_boundary(self):
  fn=method('s16_brownian.py','quadratic');env=source_env();env['path']=QV['path'].copy()
  for name in ['path_bound','ax','tt','pc']:execute(assigned(fn,name),env)
  self.assertAlmostEqual(env['path_bound'],1.6194496921359833)
  self.assertGreaterEqual(env['path_bound']-np.max(np.abs(env['path'])),.1-1e-14)
  self.assertTrue(np.array_equal(env['path'],QV['path']))
  anchors=env['pc'].get_anchors();coords=np.array([env['ax'].p2c(p)[1] for p in anchors]);self.assertLess(coords.min(),-1.5)
  self.assertTrue(all(np.any(np.isclose(coords,v,atol=1e-12,rtol=0)) for v in QV['path'][QV['path']<-1.5]))
 def test_bilingual_caption_geometry_and_fields(self):
  fn=method('s16_brownian.py','quadratic')
  for language in ['en','zh']:
   e=mc_env(language);objects={k:e[k] for k in ['zoom_note','yl','xl','xn','f','ev']};b={k:bounds(v) for k,v in objects.items()}
   self.assertGreater(b['zoom_note'][2],e['ax'].get_top()[1]);self.assertLess(b['zoom_note'][3],min(b['f'][2],b['ev'][2]));self.assertLess(b['zoom_note'][1],config.frame_width/2-.2)
   self.assertAlmostEqual(e['zoom_note'].font_size,18)
   env=source_env();env.update(ns=QV['ns'],qm=QV['qv_mean'],qs=QV['qv_sd'],tvm=QV['tv_mean'])
   for name in ['k','tbl']:execute(assigned(fn,name),env)
   execute(next(n for n in fn.body if isinstance(n,ast.Expr) and ast.unparse(n).startswith('tbl.move_to')),env);execute(assigned(fn,'tl'),env)
   tb=env['tl'];self.assertAlmostEqual(tb.font_size,20);self.assertLess(tb.get_right()[0],config.frame_width/2-.2);self.assertGreater(tb.get_bottom()[1],env['tbl'].get_top()[1])
   GEOM.append({'language':language,'mc_objects':b,'mc_zoom_font_size':e['zoom_note'].font_size,'brownian_new_caption_bounds':bounds(tb),'brownian_caption_font_size':tb.font_size,'brownian_caption_to_table_gap_world':float(tb.get_bottom()[1]-env['tbl'].get_top()[1]),'scope':'Actual Manim text geometry from exact consumer AST, no scene import/render; pixel readability must be verified in root render.'})
  lang.LANG='zh'
  for en,zh in D['strings'].items():
   self.assertEqual(zh_text._NUM.findall(en),zh_text._NUM.findall(zh));translated=zh_text.translate(en)
   self.assertTrue(any('\u4e00'<=c<='\u9fff' for c in translated));self.assertEqual(zh_text._NUM.findall(translated),zh_text._NUM.findall(en))
 def test_cached_input_and_producer_identity_unchanged(self):
  for p in (B/'cases').iterdir():
   d=json.loads((p/'freeze.json').read_text())
   for inp in d['inputs']:self.assertEqual(sha(R/inp['original_path']),inp['sha256'])
  for item in ['montecarlo','ess','scorefn','mcmc','langevin','brownian','qv']:
   d=json.loads((R/'.cache/ai5'/f'{item}.json').read_text())
   for path,h in d['_cache']['recipe']['sources'].items():self.assertEqual(sha(R/path),h)

if __name__=='__main__':
 with tempconfig({'media_dir':str(O/'geometry-media'),'tex_dir':str(O/'geometry-media/Tex'),'verbosity':'ERROR','pixel_width':854,'pixel_height':480}):
  suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests);result=unittest.TextTestRunner(verbosity=2).run(suite)
  (O/'geometry-results.json').write_text(json.dumps(GEOM,indent=2)+'\n')
  raise SystemExit(not result.wasSuccessful())
