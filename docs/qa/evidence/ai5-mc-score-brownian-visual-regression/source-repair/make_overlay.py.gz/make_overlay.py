import ast,hashlib,json
from pathlib import Path
R=Path('/workspace/explainer-videos');O=Path(__file__).parent
strings={r'vertical zoom: $[2.6,3.7]$ \\ triangles: estimates outside this window':r'纵轴放大：$[2.6,3.7]$ \\ 三角标记超出显示范围的估计值',r'means over $400$ paths, $t = 1$ \\ $\pm$: across-path standard deviation':r'在$400$条路径上取均值，$t = 1$ \\ $\pm$表示路径间的标准差'}
files=['s13_montecarlo.py','s14_scorefn.py','s16_brownian.py'];sources={};voproof=[];caption=[]
def vos(t):return [n.args[0] for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover']
for f in files:
 p=R/'videos/ai/ai5'/f;old=O/'before'/f;before=ast.parse(old.read_text());after=ast.parse(p.read_text())
 assert [ast.dump(n) for n in vos(before)]==[ast.dump(n) for n in vos(after)]
 sources[f]={'before_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 voproof.append({'file':f,'voiceover_count':len(vos(after)),'all_arguments_bookmarks_identical':True})
 for n in ast.walk(after):
  if isinstance(n,ast.Constant) and n.value in strings if isinstance(n,ast.Constant) and isinstance(n.value,str) else False:
   caption.append({'file':f,'line':n.lineno,'en':n.value,'zh':strings[n.value]})
assert len(caption)==2
out={'schema':1,'scope':'PRIVATE on-screen caption proposals only for the approved3scene local clipping/readability repair. All voiceovers/bookmarks unchanged; no main translation-table edits.','sources':sources,'strings':strings,'ZH_updates':{},'PHRASES':{},'obsolete_keys':{},'caption_handoff':caption,'narration_ast_proof':voproof,'numeric_scope':'Only exact fixed window limits2.6/3.7 and400paths,t=1; no invented empirical numeric templates or changed cached values.'}
(O/'proposed-zh-overlay.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'caption_keys':len(strings),'sources':sources,'voiceovers':voproof},indent=2))
