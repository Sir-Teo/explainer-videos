# Chinese silent-preview join review

**PRE-HISTORY-QUALIFICATION BASELINE — dated 2026-11-01T00:52:38.328476+00:00**

**All 18 reviewed joins pass.** No join defect observed. This approves the selected join windows of this exact frozen baseline; Gradient narration history qualification is pending, so this is not final current-source assembly approval.

Movie: `/workspace/runtime/ai4-silent-preview-assembly/current-reviewed/zh/ai4-silent-preview-zh-480p15.mp4`  
SHA256: `0f0400b5e454ef9b50476cd37f067a8897a7d6146f4797790eeaa58e65e908fc`  
Duration: 3479.019813s; silent 854×480 at 15fps.

All 41 chronological sheets (325 exact-unique PNGs) actually viewed. The 342 selected times include 17 exact-PNG duplicates, mapped only to an actually viewed image. All 18 native before/after pairs (36 images) actually viewed and logged after inspection. Movie, all selected PNGs, receipt, subtitles, chapter list, input freeze and frozen chapter movies/results hash-verified.

| Join | Transition | First incoming PTS | Reviewed PTS range | Result |
|---:|---|---:|---|---|
| 1 | Hook → Derivative | 140.088021 | 139.087695–141.088021 | Clear |
| 2 | Derivative → Gradient | 302.354362 | 301.354362–303.354362 | Clear |
| 3 | Gradient → Jacobian | 475.620378 | 474.620378–476.620378 | Clear |
| 4 | Jacobian → Layers | 627.153711 | 626.153711–628.153711 | Clear |
| 5 | Layers → Modes | 792.219727 | 791.219401–793.219727 | Clear |
| 6 | Modes → Backprop | 1028.086719 | 1027.086393–1029.086719 | Clear |
| 7 | Backprop → Library | 1234.419076 | 1233.419076–1235.419076 | Clear |
| 8 | Library → Train | 1404.285091 | 1403.285091–1405.285091 | Clear |
| 9 | Train → Floats | 1602.151107 | 1601.151107–1603.151107 | Clear |
| 10 | Floats → GradCheck | 1813.151107 | 1812.150781–1814.151107 | Clear |
| 11 | GradCheck → Memory | 1995.684115 | 1994.684115–1996.684115 | Clear |
| 12 | Memory → Newton | 2178.550130 | 2177.550130–2179.550130 | Clear |
| 13 | Newton → HVP | 2340.083138 | 2339.083138–2341.083138 | Clear |
| 14 | HVP → Quadratic | 2520.816146 | 2519.816146–2521.816146 | Clear |
| 15 | Quadratic → Lagrange | 2727.149154 | 2726.148828–2728.149154 | Clear |
| 16 | Lagrange → KKT | 2920.615169 | 2919.615169–2921.615169 | Clear |
| 17 | KKT → Implicit | 3130.548177 | 3129.548177–3131.548177 | Clear |
| 18 | Implicit → Outro | 3307.414193 | 3306.413867–3308.414193 | Clear |

Each join covers ±1 second around the first incoming frame: every encoded frame within ±0.4 seconds, plus ±0.6, ±0.8 and ±1.0 seconds. Exact source indices, times, PNG hashes, sheet receipts and native pairs are in JSON.

Outgoing contexts and incoming titles follow the expected 19-chapter order. Native views confirm readable titles, bounds and margins. Outgoing diagrams fade down, brief dark centers occur, then incoming titles fade up; no unexpected extended blank, wrong title, flash or clipping was observed. The Outro intentionally enters as a sparse heading and bottom qualifier before recap tiles appear.

The exact-movie validator reports a complete 52,185-frame decode, increasing video timestamps, monotonic packet DTS, all 19 chapters, 959 soft-subtitle cues with exact text/millisecond roundtrip and chapter bounds, and zero nonzero bytes in the full decoded PCM audio. These existing reports were hash-bound and inspected; this reviewer did not rerun decoders or listen.

No continuous playback, audio/listening, narrated sync, player subtitle display, production or 1080p approval. There are 51,843 full-movie frame indices outside this selected join review. Source snapshot observations do not prove historical module loading; original warning cases and broad fingerprints remain retained.

Gradient history wording is being qualified separately. This baseline movie and its files remain preserved. A later revision requires exact replacement clip identities and separate validation; no revised build or Library upload was performed here. No blocker remains for the dated baseline join review.

Evidence: [actual join receipts](/workspace/runtime/ai4-silent-preview-assembly/current-reviewed/zh/validation/join-review.json), [full review](/workspace/runtime/ai4-silent-preview-assembly/current-reviewed/zh-join-review.json), [technical validation](/workspace/runtime/ai4-silent-preview-assembly/current-reviewed/zh/validation/validation.json), [history status](/workspace/runtime/ai4-silent-preview-assembly/current-reviewed/history-qualification-pending.json).
