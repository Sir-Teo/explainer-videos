from pathlib import Path
import ast,json,math,copy,sys,hashlib,re
import numpy as np
O=Path(__file__).parent;B=Path('/workspace/explainer-videos');P=B/'videos/ai/ai4';sys.path.insert(0,str(O))
from zh_proposals import MAIN,FUNCTION_RETURNS,ASSIGNMENTS,CAPTION_FRAGMENT_REPLACEMENTS,STATIC_CAPTIONS
H=json.loads((O/'bilingual-handoff.json').read_text());data={};proof={}
for name in ['valley','quad','lagrange','kkt','deq','hessian','linapprox','vcurve']:
 p=B/'.cache/ai4'/f'{name}.json';data[name]=json.loads(p.read_text());q=p.with_suffix('.npz')
 if q.exists():
  with np.load(q,allow_pickle=False) as z:data[name].update({k:z[k] for k in z.files})
 proof[name]={'json_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'npz_sha256':hashlib.sha256(q.read_bytes()).hexdigest() if q.exists() else None}
# Pure math/text helpers only, copied as AST; no producer or scene import.
base={'math':math,'np':np};t=ast.parse((B/'explainer/analysis/__init__.py').read_text());n=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='sci');exec(compile(ast.Module([n],type_ignores=[]),'sci','exec'),base)
base_zh=base.copy()
for f in ['s15_quadratic.py','s16_lagrange.py','s17_kkt.py','s18_implicit.py']:
 t=ast.parse((P/f).read_text());nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in set(FUNCTION_RETURNS)|{'svm_checks_pass','diagnostic_number','metric_tex'}]
 exec(compile(ast.Module(nodes,type_ignores=[]),f,'exec'),base)
 translated=copy.deepcopy(nodes)
 for fn in translated:
  if fn.name not in FUNCTION_RETURNS:continue
  ret=sorted([n for n in ast.walk(fn) if isinstance(n,ast.Return) and isinstance(n.value,(ast.Constant,ast.JoinedStr)) and (not isinstance(n.value,ast.Constant) or isinstance(n.value.value,str))],key=lambda n:n.lineno)
  for node,zh in zip(ret,FUNCTION_RETURNS[fn.name]):node.value=ast.parse('f'+repr(zh),mode='eval').body if '{' in zh else ast.Constant(zh)
 exec(compile(ast.fix_missing_locations(ast.Module(translated,type_ignores=[])),f,'exec'),base_zh)

def text_replace(node,replacements):
 q=copy.deepcopy(node)
 if isinstance(q,ast.Constant) and isinstance(q.value,str):
  for a,b in replacements:q.value=q.value.replace(a,b)
 elif isinstance(q,ast.JoinedStr):
  for v in q.values:
   if isinstance(v,ast.Constant):
    for a,b in replacements:v.value=v.value.replace(a,b)
 return q

def method(file,name):return next(n for n in ast.walk(ast.parse((P/file).read_text())) if isinstance(n,ast.FunctionDef) and n.name==name)
def expression(file,m,name):return next(n.value for n in ast.walk(method(file,m)) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
def evaluate(n,env):return eval(compile(ast.Expression(n),'caption-pure-expression','eval'),env,env)
def add_assigned(env,zh,file,m,name):
 n=expression(file,m,name)
 if zh and name in ASSIGNMENTS:
  props=ASSIGNMENTS[name]
  if isinstance(n,ast.IfExp):n=ast.IfExp(n.test,ast.parse('f'+repr(props[0]),mode='eval').body,ast.parse('f'+repr(props[1]),mode='eval').body)
  else:n=ast.parse('f'+repr(props[0]),mode='eval').body
 elif zh and name in CAPTION_FRAGMENT_REPLACEMENTS:
  if isinstance(n,ast.IfExp):n=ast.IfExp(n.test,text_replace(n.body,CAPTION_FRAGMENT_REPLACEMENTS[name]),text_replace(n.orelse,CAPTION_FRAGMENT_REPLACEMENTS[name]))
  else:n=text_replace(n,CAPTION_FRAGMENT_REPLACEMENTS[name])
 env[name]=evaluate(ast.fix_missing_locations(n),env)

def environment(file,m,zh=False):
 e=(base_zh if zh else base).copy();V,Q,L,K,D,He,La,Vc=[data[n] for n in ['valley','quad','lagrange','kkt','deq','hessian','linapprox','vcurve']]
 if file=='s15_quadratic.py':
  if m=='derive':return e
  if m=='valley':
   e.update(v=V,gd_final=float(np.linalg.norm(V['gd'][-1])),mom_final=float(np.linalg.norm(V['momentum'][-1])));add_assigned(e,zh,file,m,'gd_summary');add_assigned(e,zh,file,m,'momentum_verdict')
  elif m=='rates':
   runs=Q['convergence']['opt'];ro,rp=np.asarray(Q['rate_opt']),np.asarray(Q['rate_opt_pred']);edge=float(Q['etas'][np.argmax(Q['final']>np.linalg.norm([-4.5,.9]))]) if np.any(Q['final']>np.linalg.norm([-4.5,.9])) else float('nan')
   e.update(q=Q,runs=runs,resolved=np.array([r['status']=='converged' and r['first_hit_step'] is not None for r in runs]),worst=float(np.abs(ro-rp).max()),edge=edge,k_big=int(Q['kappas'][-1]));
   for name in ['verdict','step_verdict','stability_verdict']:add_assigned(e,zh,file,m,name)
  elif m=='saddle':
   runs=Q['convergence']['escape'];solved=np.array([r['status']=='converged' and r['first_hit_step'] is not None for r in runs]);xx=-np.log10(Q['y0s']);slope=float(np.polyfit(xx[solved],np.asarray(Q['esc'])[solved],1)[0]);e.update(q=Q,solved=solved,slope=slope,pslope=math.log(10)/math.log(1.1),sg=Q['stuck_grad']);add_assigned(e,zh,file,m,'slope_note');add_assigned(e,zh,file,m,'verdict')
 elif file=='s16_lagrange.py':
  e.update(d=L,x=L['x_star'],report=L['solvers']['circle'])
  if m=='derive':add_assigned(e,zh,file,m,'circle_verdict')
  elif m in ['maxent','rl']:add_assigned(e,zh,file,m,'agreement')
 elif file=='s17_kkt.py':
  e.update(d=K,grid=K['grid'],X=K['X'],alpha_tol=K['tolerances']['alpha'],margin_tol=K['tolerances']['margin'],sv=np.flatnonzero(K['alpha']>K['tolerances']['alpha']).tolist(),tight=np.flatnonzero(np.abs(K['margins']-1)<=K['tolerances']['margin']).tolist())
  if m=='svm':add_assigned(e,zh,file,m,'solver_verdict')
 elif file=='s18_implicit.py':
  errs=D['errs'];cv=D['curve'];e.update(d=D,initial=D['solves']['initial'],rho=D['rho'],errs=errs,ok=np.isfinite(errs)&(errs>=0),it=D['iters_curve'],cv=cv,training=D['solves']['training'],fit=D['solves']['fit'])
  if m=='check':
   for name in ['solve_verdict','rho_note','rate_note','verdict','rate_statement','floor_verdict']:add_assigned(e,zh,file,m,name)
  elif m=='train':
   e['ok']=(cv[:,0]>0)&np.isfinite(cv[:,1])&(cv[:,1]>0)
   for name in ['final_solve','end_note','residual_note','it_v','loss_verdict','solve_counts']:add_assigned(e,zh,file,m,name)
 elif file=='s19_outro.py':
  ev=np.sort(He['eig'+str(len(He['keep'])-1)]);e.update(la=La,vc=Vc,he=He,kk=K,high_positive=int(np.count_nonzero(ev>.1*np.max(np.abs(ev)))))
  omitted=sum(int(np.count_nonzero(~(np.isfinite(La['hs'])&(La['hs']>0)&np.isfinite(La[k])&(La[k]>0)))) for k in ['err','err_bad']);limited=bad=0
  for k in ['fp64','fp32']:
   v=Vc['central_'+k];ok=np.isfinite(v)&(v>=0);limited+=int(np.count_nonzero((v[ok]<1e-14)|(v[ok]>1)));bad+=int(np.count_nonzero(~ok))
  e.update(omitted=omitted,v_limited=limited,v_omitted=bad);add_assigned(e,zh,file,'tiles','line_fit')
 return e
strings=dict(H['static_caption_strings']);resolution=[];pending=[]
# Exact main/helper local table keys; old obsolete keys are explicit.
zh_updates={r['new_zh_key']:r['new_zh_value'] for r in H['main_voiceover_updates']+H['subphrase_updates']}
obsolete=sorted({r['old_zh_key'] for r in H['main_voiceover_updates'] if r['old_zh_key'] and r['old_zh_key']!=r['new_zh_key']})
for row in H['caption_call_updates']:
 expr=row['expression'];file=row['file'];matches=[]
 for fn in [n for c in ast.parse((P/file).read_text()).body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef)]:
  if any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.args and ast.unparse(n.args[0])==expr for n in ast.walk(fn)):matches.append(fn.name)
 if expr in ['title','cap[1]'] or row['index']==36:continue
 assert len(matches)==1,(expr,matches)
 m=matches[0];en=evaluate(ast.parse(expr,mode='eval').body,environment(file,m));
 if row.get('proposed_zh_expression'):zh=evaluate(ast.parse(row['proposed_zh_expression'],mode='eval').body,environment(file,m,True))
 else:zh=evaluate(ast.parse(expr,mode='eval').body,environment(file,m,True))
 assert isinstance(en,str) and isinstance(zh,str),(expr,type(en),type(zh));strings[en]=zh;resolution.append({'file':file,'method':m,'source_expression':expr,'english':en,'chinese':zh,'provenance':'current completed immutable raw JSON/NPZ plus actual pure AST helpers; no scene import or model computation'})
# All newly constructed tuple-footers resolve independently of Manim geometry.
t=ast.parse((P/'s19_outro.py').read_text());existing=json.loads((B/'videos/ai/ai_text_zh.json').read_text())['strings']
for call in [n for n in ast.walk(method('s19_outro.py','tiles')) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='append' and isinstance(n.args[0],ast.Tuple)]:
 cap=call.args[0].elts[1]
 if not isinstance(cap,ast.Tuple):continue
 for leaf in cap.elts:
  en=evaluate(leaf,environment('s19_outro.py','tiles'))
  if isinstance(leaf,ast.Name):zh=evaluate(leaf,environment('s19_outro.py','tiles',True))
  elif isinstance(leaf,ast.Constant):zh=STATIC_CAPTIONS.get(en,existing.get(en))
  else:zh=evaluate(text_replace(leaf,[('limited','按边界显示'),('omitted','未绘出'),('directions:','个方向：'),('points','个点')]),environment('s19_outro.py','tiles',True))
  if zh is None:pending.append({'english':en,'reason':'tuple literal needs explicit translation'});continue
  strings[en]=zh;resolution.append({'file':'s19_outro.py','method':'tiles','source_expression':ast.unparse(leaf),'english':en,'chinese':zh,'provenance':'actual completed cache tuple-footer expression; no scene invocation'})
# Caption-side named helper/fallback fragments, including constant unavailability
# prose, are added exactly even when the current data uses the successful branch.
for r in H['subphrase_updates']:
 if not r['new_zh_key'].startswith(('f"',"f'")):strings.setdefault(r['new_zh_key'],r['new_zh_value'])
for r in H['caption_fragment_updates']:
 n=ast.parse(r['expression'],mode='eval').body;z=ast.parse(r['proposed_zh_expression'],mode='eval').body
 if isinstance(n,ast.Constant) and isinstance(z,ast.Constant):strings.setdefault(n.value,z.value)
num=re.compile(r'(?<![A-Za-z\\])-?\d+(?:(?:\{,\}|,|\.)\d+)*')
numeric=[]
for en,zh in strings.items():
 a,b=num.findall(en),num.findall(zh)
 if a!=b:numeric.append({'english':en,'chinese':zh,'english_numbers':a,'chinese_numbers':b})
# A few narration-style literal phrases contain spelled-out English numbers and
# Chinese digits; they are exact keys only and deliberately not numeric templates.
# Separate these rather than claiming general numeric-role equivalence.
for x in numeric:x['scope']='exact string only; not a numeric-template proof'
result={'ZH_updates':zh_updates,'obsolete_keys':obsolete,'strings':strings,'patterns':[],'source_hashes':H['source_hashes'],'caption_resolution':resolution,'numeric_exact_only_entries':numeric,'pending':pending,'input_hashes':proof,'scope':'Exact English-caption keys resolved from completed data or unchanged static source, with Chinese values; no descriptive IDs used as global keys. Helper/availability literal captions included. No scene imports/producer/default loads, renders or cache writes.','limits':['Synthetic geometry is English-only; actual Chinese render pending.','Unexercised dynamic failure caption combinations beyond standalone helper/fallback phrases need future captured-string review; no claim those branches were rendered.']}
(O/'normalized-ch-overlay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(O/'caption-add.json').write_text(json.dumps({'strings':strings,'patterns':[]},ensure_ascii=False,indent=2)+'\n');(O/'caption-resolution.json').write_text(json.dumps({'resolution':resolution,'pending':pending,'numeric_exact_only_entries':numeric,'inputs':proof},ensure_ascii=False,indent=2)+'\n')
print('ZH_updates',len(zh_updates),'obsolete',len(obsolete),'exact_global_strings',len(strings),'actual_caption_expressions',len(resolution),'pending',pending,'numeric_exact_only',len(numeric))
print('numeric exceptions',json.dumps(numeric,ensure_ascii=False)[:1800])
