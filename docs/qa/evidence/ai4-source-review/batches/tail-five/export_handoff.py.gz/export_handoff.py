from pathlib import Path
import ast,json,hashlib,re,string,copy,sys
from functools import lru_cache
O=Path(__file__).parent;B=Path('/workspace/explainer-videos');P=B/'videos/ai/ai4';sys.path.insert(0,str(O));from zh_proposals import MAIN,FUNCTION_RETURNS,ASSIGNMENTS,CAPTION_REPLACEMENTS,CAPTION_FRAGMENT_REPLACEMENTS,STATIC_CAPTIONS,README_HANDOFF
# Match old prefixes with the real lightweight source-prefix implementation,
# extracted without importing any scene, producer or model module.
t=ast.parse((B/'explainer/zh_templates.py').read_text());N={'ast':ast,'re':re,'lru_cache':lru_cache}
for n in t.body:
 if (isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='IS_TPL' for x in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name in ['_source_body','source_startswith']):exec(compile(ast.Module([n],type_ignores=[]),'source-prefix','exec'),N)
z=ast.parse((P/'zh_lines.py').read_text());Z=next(ast.literal_eval(n.value) for n in z.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='ZH' for x in n.targets))
def english(n):return n.value if isinstance(n,ast.Constant) else ast.unparse(n)
def fields(n):
 if not isinstance(n,ast.JoinedStr):return []
 return [(ast.dump(x.value,include_attributes=False),ast.unparse(x.format_spec) if x.format_spec else '') for x in n.values if isinstance(x,ast.FormattedValue)]
def zh_fields(s):
 out=[]
 for _,field,spec,_ in string.Formatter().parse(s):
  if field is not None:out.append((ast.dump(ast.parse(field,mode='eval').body,include_attributes=False),ast.unparse(ast.JoinedStr([ast.Constant(spec)])) if spec else ''))
 return out
# AST format-spec spelling is f'...' while Formatter gives raw spec.
def normalized_fields(node):
 result=[]
 if isinstance(node,ast.JoinedStr):
  for v in node.values:
   if isinstance(v,ast.FormattedValue):result.append((ast.dump(v.value,include_attributes=False),''.join(x.value for x in v.format_spec.values) if v.format_spec else ''))
 return result

def check(n,zh):
 expected=normalized_fields(n)
 actual=[(ast.dump(ast.parse(k,mode='eval').body,include_attributes=False),fmt) for _,k,fmt,_ in string.Formatter().parse(zh) if k is not None]
 assert sorted(expected)==sorted(actual),(ast.unparse(n),zh,expected,actual)
 bm=lambda s:re.findall(r'<bookmark[^>]+/>',s)
 en=n.value if isinstance(n,ast.Constant) else ''.join(v.value for v in n.values if isinstance(v,ast.Constant))
 assert bm(en)==bm(zh),(en,zh)
 return bm(en)

def vo(t):
 out=[]
 for cls in [n for n in t.body if isinstance(n,ast.ClassDef)]:
  for fn in [n for n in cls.body if isinstance(n,ast.FunctionDef)]:
   for call in sorted([n for n in ast.walk(fn) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover'],key=lambda n:n.lineno):out.append((fn.name,call.args[0],call.lineno))
 return out
main=[];sub=[];all_sources={};hashes=[]
for before in sorted((O/'before').glob('*.py')):
 f=before.name;old=ast.parse(before.read_text());new=ast.parse((P/f).read_text());all_sources[f]=new;hashes.append({'file':f,'before_sha256':hashlib.sha256(before.read_bytes()).hexdigest(),'after_sha256':hashlib.sha256((P/f).read_bytes()).hexdigest()})
 for (m,a,la),(mm,b,lb) in zip(vo(old),vo(new)):
  assert m==mm
  if ast.dump(a,include_attributes=False)!=ast.dump(b,include_attributes=False):
   zh=MAIN[(f,m)];marks=check(b,zh);hits=[k for k in Z if N['source_startswith'](english(a),k)]
   main.append({'file':f,'method':m,'old_line':la,'new_line':lb,'old_expression':ast.unparse(a),'new_expression':ast.unparse(b),'old_zh_key':max(hits,key=len) if hits else None,'new_zh_key':english(b),'new_zh_value':zh,'bookmarks':marks,'placeholder_roles_and_formats_match':True})
 for fn in [n for n in new.body if isinstance(n,ast.FunctionDef) and n.name in FUNCTION_RETURNS]:
  returns=sorted([n.value for n in ast.walk(fn) if isinstance(n,ast.Return) and isinstance(n.value,(ast.Constant,ast.JoinedStr)) and not(isinstance(n.value,ast.Constant) and not isinstance(n.value.value,str))],key=lambda n:n.lineno)
  props=FUNCTION_RETURNS[fn.name];assert len(returns)==len(props),(fn.name,len(returns),len(props))
  for n,zh in zip(returns,props):check(n,zh);sub.append({'file':f,'origin':fn.name,'new_expression':ast.unparse(n),'new_zh_key':english(n),'new_zh_value':zh})
 for n in ast.walk(new):
  if not isinstance(n,ast.Assign) or len(n.targets)!=1 or not isinstance(n.targets[0],ast.Name) or n.targets[0].id not in ASSIGNMENTS:continue
  name=n.targets[0].id;leaves=[n.value.body,n.value.orelse] if isinstance(n.value,ast.IfExp) else[n.value];props=ASSIGNMENTS[name];assert len(leaves)==len(props),(name,len(leaves),len(props))
  for leaf,zh in zip(leaves,props):check(leaf,zh);sub.append({'file':f,'origin':name,'new_expression':ast.unparse(leaf),'new_zh_key':english(leaf),'new_zh_value':zh})
assert len(main)==14
captions=json.loads((O/'caption-expressions-draft.json').read_text());capout=[]
def replace_text(node,replacements):
 q=copy.deepcopy(node)
 if isinstance(q,ast.Constant) and isinstance(q.value,str):
  for a,b in replacements:q.value=q.value.replace(a,b)
 elif isinstance(q,ast.JoinedStr):
  for v in q.values:
   if isinstance(v,ast.Constant):
    for a,b in replacements:v.value=v.value.replace(a,b)
 return q
for i,row in enumerate(captions,1):
 n=ast.parse(row['expression'],mode='eval').body
 if i in CAPTION_REPLACEMENTS:
  tr=replace_text(n,CAPTION_REPLACEMENTS[i]);assert normalized_fields(n)==normalized_fields(tr);capout.append({**row,'index':i,'proposed_zh_expression':ast.unparse(tr),'kind':'literal' if isinstance(n,ast.Constant) else 'format_template','numeric_roles_preserved':True})
 else:capout.append({**row,'index':i,'kind':'named_or_composite','resolution':'Use named-fragment proposals below or unchanged existing table entries. Only problem6 changed in the problem list.'})
fragments=[]
for f,t in all_sources.items():
 for n in ast.walk(t):
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in CAPTION_FRAGMENT_REPLACEMENTS:
   name=n.targets[0].id;leaves=[n.value.body,n.value.orelse] if isinstance(n.value,ast.IfExp) else[n.value]
   for leaf in leaves:
    tr=replace_text(leaf,CAPTION_FRAGMENT_REPLACEMENTS[name]);fragments.append({'file':f,'name':name,'expression':ast.unparse(leaf),'proposed_zh_expression':ast.unparse(tr)})
# Extra tuple-footer numeric expressions; only translate their text portions.
t=all_sources['s19_outro.py']
for n in ast.walk(t):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='append' and isinstance(n.args[0],ast.Tuple):
  cap=n.args[0].elts[1]
  for leaf in cap.elts if isinstance(cap,ast.Tuple) else [cap]:
   if isinstance(leaf,ast.JoinedStr):
    tr=replace_text(leaf,[('limited','按边界显示'),('omitted','未绘出'),('directions:','个方向：'),('points','个点')]);fragments.append({'file':'s19_outro.py','name':'tuple-footer','expression':ast.unparse(leaf),'proposed_zh_expression':ast.unparse(tr)})
problem=next(n for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='problem_set').args[0].elts[5].value
static=dict(STATIC_CAPTIONS);static[problem]=r"若$\beta > 0$且$\pi_{\mathrm{ref}}(a)>0$，在概率分布$\pi$上最大化$\mathbb E_\pi[r] - \beta\,\mathrm{KL}(\pi \,\|\, \pi_{\mathrm{ref}})$。\ 用拉格朗日乘子证明$\pi^* \propto \pi_{\mathrm{ref}}\, e^{r/\beta}$，且最优值为$\beta \log \textstyle\sum_a \pi_{\mathrm{ref}}(a)\, e^{r(a)/\beta}$。"
result={'status':'five scene sources frozen; exact narration proposals ready for parent atomic merge','source_hashes':hashes,'main_voiceover_updates':main,'subphrase_updates':sub,'caption_call_updates':capout,'caption_fragment_updates':fragments,'static_caption_strings':static,'README_handoff':README_HANDOFF,'scope':'No shared Chinese/global-caption/README mutations by this reviewer. Caption f-expressions are exact source templates/proposals, not measured fixtures. Parent can resolve against completed cached data or captured strings.14main and all helper proposals have validated bookmark/placeholder role+format parity.','limits':['All actual rendered output and listening remain untested for Part4.','English synthetic Manim geometry only; actual Chinese text/layout validation follows parent merge.','The training solve cohort38448 includes final loss/gradient evaluation on48training samples as well as800update stages. It is not38448optimizer updates.']}
(O/'bilingual-handoff.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
(O/'narration-additions.json').write_text(json.dumps({'ZH':{x['new_zh_key']:x['new_zh_value'] for x in main+sub}},indent=2,ensure_ascii=False)+'\n')
print('main',len(main),'sub',len(sub),'captioncalls',len(capout),'fragments',len(fragments),'static',len(static),'README',len(README_HANDOFF))
print('bilingual-handoff SHA256',hashlib.sha256((O/'bilingual-handoff.json').read_bytes()).hexdigest())
