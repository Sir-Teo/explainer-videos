"""Selected Manim object geometry only; no Scene execution/import/data loader."""
from pathlib import Path
import ast,json,math,hashlib
import numpy as np
from manim import *
from explainer.ai import *
O=Path(__file__).parent;B=Path('/workspace/explainer-videos');PART=B/'videos/ai/ai4'
config.media_dir=str(O/'geometry-media');config.verbosity='ERROR'
E=globals().copy();E.update(GRAD=C.SCORE,HESS=C.PENALTY,HIST=C.HUMAN,VALUE=C.VALUE if hasattr(C,'VALUE') else C.TRUE_P,CONS=C.CONTEXT)
# Only pure function definitions needed by small synthetic fixtures.
for name,functions in [('common.py',['log_axes']),('s16_lagrange.py',['bars']),('s17_kkt.py',['diagnostic_number']),('s18_implicit.py',['metric_tex','fixed_point_summary'])]:
 t=ast.parse((PART/name).read_text());nodes=[n for n in t.body if isinstance(n,ast.FunctionDef) and n.name in functions];exec(compile(ast.Module(nodes,type_ignores=[]),name,'exec'),E)
def assignments(file,method,targets,env,expr_prefixes=()):
 t=ast.parse((PART/file).read_text());fn=next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name==method)
 for n in fn.body:
  if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id in targets for x in n.targets):exec(compile(ast.Module([n],type_ignores=[]),file,'exec'),env)
  elif isinstance(n,ast.Expr) and ast.unparse(n).startswith(expr_prefixes) and expr_prefixes:exec(compile(ast.Module([n],type_ignores=[]),file,'exec'),env)
 return env
def box(m):return {'left':float(m.get_left()[0]),'right':float(m.get_right()[0]),'bottom':float(m.get_bottom()[1]),'top':float(m.get_top()[1]),'width':float(m.width),'height':float(m.height)}
results={}
e=E.copy();assignments('s18_implicit.py','derive',{'box','zin','zout','a1','a2','back','cap','loop','tagl'},e,('box[1].move_to','box.move_to','cap.next_to'))
results['implicit_loop']={k:box(e[k]) for k in ['box','back','cap','loop','tagl']}
e=E.copy();e.update(pref=np.array([.1,.15,.2,.25,.1,.2]),ps=np.array([.3,.1,.05,.2,.3,.05]),d={'kl_beta':.5,'rl_diff':1e-8,'comparisons':{'tolerance':1e-4}},vmax=.3)
assignments('s16_lagrange.py','rl',{'eq','sub','b1','b2','l1','l2'},e)
results['kl_layout']={k:box(e[k]) for k in ['eq','sub','b1','b2','l1','l2']}
e=E.copy();e.update(PRIMAL=WHITE,DUAL=C.CONTEXT,alpha=np.array([2.,2.,0.]+[0.]*17),amax=2.,amin=0.,sv=[0,1],tight=[0,1,2],alpha_tol=2e-6,margin_tol=1e-6,solver_verdict='Both optimizers report success and all listed feasibility, stationarity, slackness and gap checks pass their tolerances.',d={'p_star':2.,'d_star':2.,'tolerances':dict(feasibility=1e-6,stationarity=1e-4,complementarity=1e-6),'residuals':dict(primal_feasibility=1e-10,dual_nonnegative=0.,dual_equality=1e-12,stationarity_w=1e-8,stationarity_b=1e-12,complementarity=1e-10,duality_gap=1e-10)})
assignments('s17_kkt.py','svm',{'ax','g2','eqs','hist'},e,('VGroup(eqs[','eqs['))
results['svm_layout']={**{'eq'+str(i):box(m) for i,m in enumerate(e['eqs'])},'plot':box(e['g2']),'history':box(e['hist']),'data_plot':box(e['ax'])}
# Data-free final derivative rows are measured without calling ladder's Scene callback.
e=E.copy();assignments('s15_quadratic.py','derive',{'col','rows','whys','head','dc'},e,('head.to_edge',));ladder(None,e['rows'],e['whys'],keep=4,top=2.6,x=-2.4,buff=.6,edge=6.9)
y=2.6
for r,w in zip(e['rows'],e['whys']):
 off=w.get_y()-r.get_y();extra=max(0.,r.get_bottom()[1]-w.get_bottom()[1]);r.set_y(y-r.height/2);w.set_y(r.get_y()+off);y-=r.height+.6+extra
results['quadratic_derivation']={'head':box(e['head']),'definition':box(e['dc']),'rows':[box(r) for r in e['rows']],'reasons':[box(w) for w in e['whys']]}
# Dynamic DEQ labels use explicit synthetic fixtures, never cache/model data.
e=E.copy();initial=dict(status='converged',iterations=17,cap=2000,tolerance=1e-12,residual=4e-13);d=dict(initial_state_dimension=8,contraction_caps={'initial':.8},rate=.45)
e.update(initial=initial,d=d,rho=.4,high=0,rho_note=r'$\rho(J)=0.400$; \ $\|W\|_2\le0.8$',rate_note=r'fitted gradient-gap factor: \ $0.450$',solve_verdict='the iteration met its residual tolerance after17updates',errs=np.array([.1,1e-15,0.]),ok=np.array([True,True,True]))
assignments('s18_implicit.py','check',{'rho_note','rate_note','solve_verdict','g','info','leg','floor_note'},e)
results['implicit_check']={k:box(e[k]) for k in ['g','info','leg','floor_note']}
e=E.copy();training=dict(count=38448,converged=38448,capped=0,nonfinite=0,max_residual=8e-11,cap=2000,tolerance=1e-10);fit=dict(count=540,converged=540,capped=0,nonfinite=0,max_residual=8e-11,cap=2000,tolerance=1e-10)
d=dict(steps=800,training_state_dimension=12,parameter_count=181,first_loss=.106,final_loss=1.9e-6,solves={'training':training,'fit':fit})
e.update(d=d,training=training,fit=fit,low=-1.6,high=1.6,bottom=-6,top=0,it=np.array([[0,12],[800,40]]),end_note=r'against $200$ unrolled steps: relative gradient gap $10^{-12}$',residual_note=r'max training residual $10^{-10}$',cv=np.array([[0,.106],[5,.1],[800,1.9e-6]]),ok=np.array([False,True,True]))
assignments('s18_implicit.py','train',{'ax','g2','info','solves_note','uses','cite_'},e)
results['implicit_train']={k:box(e[k]) for k in ['ax','g2','info','solves_note','uses','cite_']}
report={'scope':'Synthetic standalone Manim object bounds only; no scene imports/construct/voiceover/render, no production inputs or numerical producer work. Fixture numbers are illustrative, not measured outputs. English only; actual Chinese/rendered evidence pending parent translation/QA.','frame':{'half_width':float(config.frame_width/2),'half_height':float(config.frame_height/2)},'results':results}
(O/'geometry-en.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(results,indent=2))
