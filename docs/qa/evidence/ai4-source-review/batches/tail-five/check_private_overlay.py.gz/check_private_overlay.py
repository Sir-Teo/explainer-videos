from pathlib import Path
import ast,json,copy,re
import explainer.zh_templates as T
O=Path(__file__).parent;d=json.loads((O/'normalized-ch-overlay.json').read_text());original=T.table

def overlay(video):
 out=copy.deepcopy(original(video))
 if video=='ai4':
  for key in d['obsolete_keys']:out['ZH'].pop(key,None)
  out['ZH'].update(d['ZH_updates'])
 return out
T.table=overlay;translator=T.Translator('ai4');results=[]
for key,expected in d['ZH_updates'].items():
 if key.startswith(('f"',"f'")):
  node=ast.parse(key,mode='eval').body
  en=''.join(value if kind=='text' else ('1.25' if T.numeric(value) else 'SAMPLE') for kind,value in T._parts(node))
 else:en=key
 zh=translator(en)
 assert zh is not None,(key,en)
 assert re.search(r'[\u4e00-\u9fff]',zh),(key,zh)
 assert not re.search(r'\{[^{}]+\}',zh),(key,zh)
 assert re.findall(r'<bookmark[^>]+/>',en)==re.findall(r'<bookmark[^>]+/>',zh),(key,zh)
 results.append({'lookup_key':key,'english_fixture':en,'chinese':zh,'scope':'Synthetic source-template placeholder probe, not measured output or listening.'})
(O/'private-overlay-fixtures.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print('55 exact new narration/helper lookups pass private actual Translator resolution, field expansion, Chinese text and bookmark parity. No shared writes.')
