"""Read complete published raw caches only; execute isolated consumer helper ASTs, never scene modules/loaders."""
import ast,math,json,hashlib,datetime
from pathlib import Path
import numpy as np
ROOT=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai4-vcurve-hvp-implementation')
def helpers(filename):
 tree=ast.parse((ROOT/'videos/ai/ai4'/filename).read_text());ns={'np':np,'math':math};exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<frozen-consumer-helper>','exec'),ns);return ns
receipts=[];data={}
for name in ['cancel','vcurve','checkpoint','newton','hessian']:
 d={}
 for suffix in ['.json','.npz']:
  p=ROOT/'.cache/ai4'/(name+suffix);before=(p.stat().st_size,p.stat().st_mtime_ns);b=p.read_bytes();sha=hashlib.sha256(b).hexdigest()
  if suffix=='.json':d.update(json.loads(b))
  else:
   with np.load(p,allow_pickle=False) as a:d.update({k:a[k].copy() for k in a.files})
  assert before==(p.stat().st_size,p.stat().st_mtime_ns)
  receipts.append({'path':str(p.relative_to(ROOT)),'sha256':sha,'signature':list(before)})
 data[name]=d
results={};checks=[]
def check(name,ok):checks.append({'check':name,'passed':bool(ok)});assert ok,name
f=helpers('s11_vcurve.py');d=data['vcurve'];opts={}
check('paired precision contract published',d['precision_comparison']=='paired identical normalized directions' and d['directions'].shape==(8,256))
for k in ['fp64','fp32']:
 check(k+' pointwise median matches all8 directions',np.allclose(d[f'central_{k}'],np.median(d[f'central_{k}_all'],axis=0),rtol=0,atol=0))
 o=f['aggregate_minimum'](d['hs'],d[f'central_{k}']);yy,count=f['error_window'](d[f'central_{k}'],-14,0)
 check(k+' actual marker uses exact plotted median index',float(d[f'central_{k}'][o['index']])==o['error'])
 check(k+' actual optimum agrees with repaired producer fields',o['h']==d['meas'][k]['central'] and o['error']==d['meas'][k]['central_err'])
 check(k+' marker inside display axes',-13<=math.log10(o['h'])<=0 and -14<=yy[o['index']]<=0)
 opts[k]={'curve_optimum':o,'predicted_step':d['pred'][k]['central'],'old_per_direction_median':d['meas'][k].get('per_direction_central_median'),'display_count':count}
results['GradCheck']={'actual_optima':opts,'prediction_verdict':f['prediction_verdict']([opts[k]['curve_optimum']['h']/opts[k]['predicted_step'] for k in ['fp64','fp32']]),'fp64_right_slope':d['slope_right_fp64'],'fp32_right_slope_is_unavailable':not math.isfinite(d['slope_right_fp32'])}
c=data['cancel'];check('float32 cancellation example agrees with narration',float(c['cos32_x0'])==1 and c['naive32_x0']==0)
m=helpers('s12_memory.py');d=data['checkpoint'];rt=int(round(math.sqrt(d['n'])));check('sqrt reference interval exists in actual sweep',np.any(d['ks']==rt));interval,scaling=m['checkpoint_verdict'](d['n'],d['klo'],d['khi'],d['ns'],d['best_k'])
results['Memory']={'n':d['n'],'min_logical_peak':int(d['peak'].min()),'minimizer_span':[d['klo'],d['khi']],'sqrt_reference':rt,'worst_gradient_difference':d['worst'],'timing_ratio_this_machine':d['t_ck']/d['t_all'],'memory_scope':d['memory_scope'],'interval_verdict':interval,'scaling_verdict':scaling}
n=helpers('s13_newton.py');d=data['newton'];check('final-inclusive GD sampled error steps align',len(d['gd_err'])==len(d['gd_err_steps']) and d['gd_err_steps'][0]==0 and d['gd_err_steps'][-1]==d['convergence']['gd']['iterations'])
check('final-inclusive GD spatial steps align',len(d['gd'])==len(d['gd_path_steps']) and d['gd_path_steps'][-1]==d['gd_err_steps'][-1])
check('GD uses actual conservative1/L step',math.isclose(d['eta']*d['L'],1,rel_tol=1e-14))
check('GD final objective matches published stopping residual',d['gd_err'][-1]==d['convergence']['gd']['residual'])
check('Newton path indices align every row',len(d['newton_path_steps'])==len(d['newton']) and np.array_equal(d['newton_path_steps'],np.arange(len(d['newton']))))
results['Newton']={'convergence':d['convergence'],'reference':d['reference'],'GD_first_last_sample_steps':[int(d['gd_err_steps'][0]),int(d['gd_err_steps'][-1])],'trajectory_bounds':n['trajectory_bounds'](d['gd'],d['newton'],d['w_star']),'eta_times_L':d['eta']*d['L'],'actual_digit_summary':n['digit_summary'](d['newton_err'][1:4]),'gd_summary':n['convergence_summary'](d['convergence']['gd'],'Gradient descent'),'newton_summary':n['convergence_summary'](d['convergence']['newton'],'Newton')}
h=helpers('s14_hvp.py');d=data['hessian'];states=[h['spectrum_state'](d[f'eig{k}'],d['spectrum_thresholds']) for k in range(len(d['keep']))]
for k,s in enumerate(states):
 check(f'checkpoint{k} threshold counts match producer',s['negative']==d[f'nneg{k}'] and s['high_positive']==d[f'nout{k}'] and s['flat']==d[f'flat{k}'])
 check(f'checkpoint{k} every finite normalized eigenvalue is visible',np.isfinite(s['normalized']).all() and np.max(np.abs(s['normalized']))<=1)
 row=d['curve'][d['curve'][:,0]==d['keep'][k]];check(f'checkpoint{k} loss marker matches exact curve step and value',len(row)==1 and row[0,1]==d[f'loss{k}'])
power=h['power_comparison'](d['lam_est'],d['eig5']);check('signed dominant magnitude matches producer',power['target']==d['lam_dominant']);check('default final power comparison is finite',power['available'] and np.isfinite(power['relative'][-1]))
results['HVP']={'power_target':power['target'],'largest_algebraic':d['lam_top'],'lam_power':d['lam_power'],'final_relative_error':float(power['relative'][-1]),'thresholds':d['spectrum_thresholds'],'checkpoints':[{'step':int(t),'rho':s['rho'],'negative':s['negative'],'high_positive':s['high_positive'],'flat':s['flat']} for t,s in zip(d['keep'],states)],'negative_verdict':h['curvature_verdict'](states[0],states[-1]),'radius_verdict':h['radius_verdict'](states[0],states[-1]),'metrics_scope':d['metrics']}
for r in receipts:
 p=ROOT/r['path'];check(r['path']+' unchanged through validation',r['signature']==[p.stat().st_size,p.stat().st_mtime_ns] and r['sha256']==hashlib.sha256(p.read_bytes()).hexdigest())
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual published raw JSON/NPZ cache validation against frozen isolated consumer helper ASTs; no scene imports/defaultload/compute/render','inputs':receipts,'checks':checks,'all_passed':all(c['passed'] for c in checks),'results':results,'limits':['No rendered layout, animation, continuous perceptual playback or audio approval. Actual production values may have different layout from synthetic fixtures; root render required.']}
(OUT/'actual-cache-validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print('checks',len(checks),'allpass',report['all_passed']);print(json.dumps(results,indent=2,ensure_ascii=False))
