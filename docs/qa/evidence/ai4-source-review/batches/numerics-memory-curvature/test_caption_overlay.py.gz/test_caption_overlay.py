from pathlib import Path
import json,re,hashlib,sys
BASE=Path('/workspace/runtime/ai4-vcurve-hvp-implementation');sys.path.insert(0,'/workspace/explainer-videos')
from explainer import lang
from explainer import zh_text as T
p=BASE/'proposed-zh-overlay.json';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='8475c20a8ec0496b51ba8460b95eba7b849cfc908c2b43db95ae4f45f2ea49a9';d=json.loads(b)
lang.LANG='zh';T._TABLE=json.loads(Path('/workspace/explainer-videos/videos/ai/ai_text_zh.json').read_text());T._TABLE['strings'].update(d['strings']);T._BY_NUMBERS=None
checks=[]
for en,zh in d['strings'].items():
 actual=T.translate(en);expected=T._SPACE.sub(r'\1\\ }',zh)
 assert actual==expected,(en,actual,expected)
 assert T._NUM.findall(en)==T._NUM.findall(zh),(en,zh,T._NUM.findall(en),T._NUM.findall(zh))
 checks.append({'en':en,'zh':zh,'exact_lookup_passed':True,'number_order_preserved':True})
key=next(k for k in d['strings'] if k.startswith('max product discrepancy vs. full Hessian:'))
variant=T._NUM.sub(lambda m: '2.2' if '.' in m.group() else '-16',key)
z=T.translate(variant);assert z!=variant and '黑塞' in z and T._NUM.findall(variant)==T._NUM.findall(z)
report={'overlay_sha256':hashlib.sha256(b).hexdigest(),'exact_English_lookup_entries_tested':len(checks),'exact_lookup_and_number_preservation_all_passed':True,'numeric_template_variant':{'en':variant,'zh':z},'checks':checks,'scope':'Actual explainer.zh_text.translate privateinmemoryoverlay; no shared table edit/defaultloader/render'}
(BASE/'caption-overlay-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS',len(checks),'exact lookup entries, numericfield/orderpreservation; numericvariantpassed')
