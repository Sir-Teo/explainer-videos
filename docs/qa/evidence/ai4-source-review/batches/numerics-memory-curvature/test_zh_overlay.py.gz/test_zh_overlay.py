import ast,json,math,re,hashlib,sys
from pathlib import Path
import numpy as np
ROOT=Path('/workspace/explainer-videos');BASE=Path('/workspace/runtime/ai4-vcurve-hvp-implementation');sys.path[:0]=[str(ROOT),str(BASE)]
import proposed_zh as P
from explainer.zh_templates import Translator,_parts,source_startswith,sources,ambiguous
tr=Translator('ai4');tr.zh=dict(tr.zh);tr.phrases=dict(tr.phrases)
for key in P.obsolete_keys:tr.zh.pop(key,None)
tr.zh.update(P.ZH_updates);tr.phrases.update(P.PHRASES_updates)
for key in P.obsolete_phrases:tr.phrases.pop(key,None)
records=[]
def check(en,kind,contains=None):
 out=tr(en);assert out is not None,(kind,en);assert re.findall(r"<bookmark mark=['\"]([^'\"]+)",out)==re.findall(r"<bookmark mark=['\"]([^'\"]+)",en),(kind,out)
 assert not re.search(r'\b(The |first meets|Correct-digit|counts increase|counts do not|Gradient descent|gradient norm|objective gap|unavailable|decreases|increases|nonfinite|capped)\b',out),(kind,out)
 assert not re.search(r'\{[^{}]+\}',out),(kind,out)
 if contains:assert contains in out,(kind,out,contains)
 records.append(dict(kind=kind,en=en,zh=out));return out

def ns(f):
 env={'math':math,'np':np};exec(compile(ast.Module(body=[n for n in P.trees[f].body if isinstance(n,ast.FunctionDef)],type_ignores=[]),'<actual-helper-source>','exec'),env);return env

def method(f,name):return next(n for n in ast.walk(P.trees[f]) if isinstance(n,ast.FunctionDef) and n.name==name)
def assignment(f,name,var):return next(n for n in ast.walk(method(f,name)) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==var for t in n.targets))
def assign(f,name,var,env):exec(compile(ast.Module(body=[assignment(f,name,var)],type_ignores=[]),'<actual-narration-branch>','exec'),env)
def voice(f,name,env):
 arg=next(n.args[0] for n in ast.walk(method(f,name)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover');en=eval(compile(ast.Expression(arg),'<actual-voiceover>','eval'),env);return check(en,f'{f}:{name}:whole-voiceover')
def data(name):
 d=json.loads((ROOT/'.cache/ai4'/f'{name}.json').read_text());p=ROOT/'.cache/ai4'/f'{name}.npz'
 if p.exists():
  with np.load(p,allow_pickle=False) as a:d.update({k:a[k].copy() for k in a.files})
 return d
f='s11_vcurve.py';env=ns(f);d=data('vcurve');env.update(d=d,e64=d['meas']['fp64']['central_err'],e32=d['meas']['fp32']['central_err'],e6=10**d['at_1e-6_fp64'],slope=d['slope_right_fp64'])
env['verdict']=env['prediction_verdict']([d['meas'][k]['central']/d['pred'][k]['central'] for k in ['fp64','fp32']])
for var in ['slope_v','error_v','step_v']:assign(f,'measured',var,env);check(env[var],var)
voice(f,'cancellation',env);voice(f,'derive',env);voice(f,'measured',env)
for ratios in ([1000,1],[np.nan,1],[1,1]):check(env['prediction_verdict'](ratios),'prediction helper')
env.update(e64=np.nan,e32=np.nan,e6=np.nan,slope=np.nan)
for var in ['slope_v','error_v','step_v']:assign(f,'measured',var,env);check(env[var],var+' unavailable')
env['verdict']=env['prediction_verdict']([np.nan,1]);voice(f,'measured',env)
f='s12_memory.py';env=ns(f);d=data('checkpoint');env.update(d=d,n=d['n'],peak=d['peak'],lo=d['klo'],hi=d['khi'],evals=d['evals'],k_rt=int(np.flatnonzero(d['ks']==16)[0]),ratio=d['t_ck']/d['t_all']);env['verdict'],env['scaling']=env['checkpoint_verdict'](d['n'],d['klo'],d['khi'],d['ns'],d['best_k']);assign(f,'measured','gradient_v',env)
for m in ['stores','derive','measured']:voice(f,m,env)
for args in [(256,2,3,[16,64],[1,80]),(256,2,3,[],[])]:
 for v in env['checkpoint_verdict'](*args):check(v,'checkpoint adverse')
env['d']={**d,'worst':np.nan};assign(f,'measured','gradient_v',env);voice(f,'measured',env)
f='s13_newton.py';env=ns(f);d=data('newton');env.update(d=d,gd_result=d['convergence']['gd'],nw_result=d['convergence']['newton'],ne=d['newton_err'])
for var in ['gd_summary','nw_summary','digit_v']:assign(f,'race',var,env)
for m in ['hessian','derive','race']:voice(f,m,env)
for method_name in ['Newton','Gradient descent']:
 for status,criterion,contains in [('converged','gradient norm < threshold','首次满足'),('capped','gradient norm < threshold','迭代上限'),('nonfinite','gradient norm < threshold','非有限值'),('reference-unconverged','objective-gap comparison unavailable: numerical reference not stationary','不可用')]:
  r=dict(status=status,first_hit_step=4 if status=='converged' else None,cap=12,iterations=12,criterion=criterion)
  check(env['convergence_summary'](r,method_name),'convergence '+method_name+' '+status,contains)
for errors,contains in [([1e-1,1e-3,1e-6],'增加'),([1e-5,1e-3,1e-1],'并非每一步'),([0,np.nan],'缺少')]:check(env['digit_summary'](errors),'digits branch',contains)
env.update(gd_summary=env['convergence_summary'](dict(status='capped',first_hit_step=None,cap=8,criterion='objective gap < threshold'),'Gradient descent'),nw_summary=env['convergence_summary'](dict(status='reference-unconverged',first_hit_step=None,cap=12,criterion='unavailable reference'),'Newton'),digit_v=env['digit_summary']([1e-5,1e-3,1e-1]));voice(f,'race',env)
f='s14_hvp.py';env=ns(f);d=data('hessian');env.update(d=d,ratio=d['t_hvp']/d['t_grad'],P=d['P'],K=len(d['keep']),y=d['y']);env['power']=env['power_comparison'](d['lam_est'],d['eig5']);env['last']=float(env['power']['relative'][-1]);assign(f,'checks','power_v',env);voice(f,'checks',env)
power_assignments=[n for n in ast.walk(method(f,'checks')) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='power_v' for t in n.targets)]
env['power']={'target':-2.};env['last']=.000001;exec(compile(ast.Module(body=[power_assignments[0]],type_ignores=[]),'<signed-target-template>','exec'),env);check(env['power_v'],'negative target','-2');voice(f,'checks',env)
exec(compile(ast.Module(body=[power_assignments[1]],type_ignores=[]),'<unavailable-target-template>','exec'),env);voice(f,'checks',env)
thresholds=d['spectrum_thresholds'];states=[env['spectrum_state'](d[f'eig{k}'],thresholds) for k in range(6)];env.update(initial=states[0],final=states[-1],mixed=True)
for var in ['initial_v','neg_v','radius_v','final_v']:assign(f,'replay',var,env)
voice(f,'replay',env)
for a,b in [(states[0],states[0]),(states[-1],states[0]),(env['spectrum_state']([np.nan],thresholds),states[0])]:
 check(env['curvature_verdict'](a,b),'curvature branch');check(env['radius_verdict'](a,b),'radius branch')
env.update(initial=env['spectrum_state']([1],thresholds),final=env['spectrum_state']([np.nan],thresholds),mixed=False)
for var in ['initial_v','neg_v','radius_v','final_v']:assign(f,'replay',var,env)
voice(f,'replay',env)
# Overlay must cover every source-discovered branch in these four scene classes.
source_coverage=[]
for s in sources('ai4'):
 if s['scene'] not in {'GradCheck','Memory','Newton','HVP'}:continue
 text=s.get('en',s.get('tpl'));hits=[k for k in tr.zh if source_startswith(text,k)];assert hits,(s,'missing coverage');source_coverage.append(s)
report={'actual_translator':'explainer.zh_templates.Translator with private in-memory overlay; no shared table writes','changed_whole_voiceovers':11,'actual_and_adverse_translation_cases':len(records),'source_entries_covered':len(source_coverage),'new_overlay_entries':len(P.ZH_updates),'outputs':records,'source_coverage':source_coverage,'ambiguous_templates_for_scoped_scenes':[s for s in ambiguous('ai4') if any(s.startswith(k) for k in P.ZH_updates)],'sources':{f:__import__('hashlib').sha256((ROOT/'videos/ai/ai4'/f).read_bytes()).hexdigest() for f in P.files}}
(BASE/'zh-overlay-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS',len(records),'actual/adverse translated cases;',len(source_coverage),'source entries covered')
