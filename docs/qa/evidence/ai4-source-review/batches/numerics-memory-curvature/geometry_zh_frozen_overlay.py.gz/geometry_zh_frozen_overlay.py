"""Actual AST-extracted Manim layout construction with wholly synthetic numeric fixtures.
No Part4 scene module import, scene rendering, cache load or production compute.
"""
import ast,math,json,hashlib,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/explainer-videos')
from explainer.ai import *
from manim import tempconfig
ROOT=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai4-vcurve-hvp-implementation');OUT=OUT/'zh-layout-frozen-overlay';OUT.mkdir(exist_ok=True);(OUT/'geometry-Tex').mkdir(exist_ok=True)
captured=set()
def record_caption_ns(ns):
 for obj in ns.values():
  if isinstance(obj,Mobject):
   for m in obj.get_family():
    value=getattr(m,'tex_string',getattr(m,'text',None))
    if isinstance(value,str):captured.add(value)
def actual_cache(name):
 d=json.loads((ROOT/'.cache/ai4'/f'{name}.json').read_text())
 with np.load(ROOT/'.cache/ai4'/f'{name}.npz',allow_pickle=False) as a:d.update({k:a[k].copy() for k in a.files})
 return d
from explainer import lang as _L
from explainer import zh_text as _T
_L.LANG='zh'
_overlay_path=Path('/workspace/runtime/ai4-vcurve-hvp-implementation/proposed-zh-overlay.json')
_overlay_bytes=_overlay_path.read_bytes()
assert hashlib.sha256(_overlay_bytes).hexdigest()=='8475c20a8ec0496b51ba8460b95eba7b849cfc908c2b43db95ae4f45f2ea49a9'
_overlay=json.loads(_overlay_bytes)
_T._TABLE=json.loads((ROOT/'videos/ai/ai_text_zh.json').read_text())
_T._TABLE['strings'].update(_overlay['strings'])
_T._TABLE.setdefault('patterns',[]).extend(_overlay['patterns'])
_T._BY_NUMBERS=None

class LayoutOnly:
 def play(self,*anims,**kw):
  for a in anims:
   if hasattr(a,'build'):a=a.build()
   a.begin();a.interpolate(1);a.finish()

def execute(nodes,ns):exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-scene-layout-AST>','exec'),ns)
base=dict(globals(),GRAD='#FF9F45',HESS=C.TRUE_P,HIST=C.HUMAN,PART=4,VALUE='#58A6FF',C64=C.TRUE_P,C32='#FF9F45',ACT=C.ACTS,CKP=C.BITS,GDC=WHITE,NEWC=C.BITS,CLASS_COL=[C.TRUE_P,'#FF9F45',C.BITS],self=LayoutOnly())
common=ast.parse((ROOT/'videos/ai/ai4/common.py').read_text());execute([n for n in common.body if isinstance(n,ast.FunctionDef) and n.name=='log_axes'],base)
results=[]
def build(filename,method,d,groups,pairs):
 tree=ast.parse((ROOT/'videos/ai/ai4'/filename).read_text());ns=dict(base)
 execute([n for n in tree.body if isinstance(n,ast.FunctionDef)],ns)
 func=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==method)
 nodes=[]
 for n in func.body:
  if isinstance(n,ast.With):break
  # production load statement replaced by an explicit fixture; no loader exists in this namespace.
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='d' for t in n.targets):continue
  nodes.append(n)
 if d and not d.get('_variant'):
  d=actual_cache({'s11_vcurve.py':'cancel' if method=='cancellation' else 'vcurve','s12_memory.py':'checkpoint','s14_hvp.py':'hessian'}.get(filename,'newton'))
 ns['d']=d;execute(nodes,ns);record_caption_ns(ns)
 if method=='derive':
  for i in range(len(ns['rows'])):ns['step'](i)
  ns['all_rows']=VGroup(*ns['rows']);ns['all_whys']=VGroup(*[w for w in ns['whys'] if w is not None])
  groups=groups+['all_rows','all_whys']
 def box(m):return [float(m.get_left()[0]),float(m.get_right()[0]),float(m.get_bottom()[1]),float(m.get_top()[1])]
 if filename=='s14_hvp.py' and method=='replay':
  ns['first_read'],ns['last_read']=ns['reads'][0],ns['reads'][-1]
  groups=groups+['first_read','last_read']
  pairs=pairs+[('first_read','cutoff_note'),('last_read','cutoff_note'),('first_read','title'),('last_read','title')]
 boxes={g:box(ns[g]) for g in groups}
 checks=[]
 for g,b in boxes.items():checks.append({'kind':'frame','object':g,'pass':b[0]>=-config.frame_width/2-.03 and b[1]<=config.frame_width/2+.03 and b[2]>=-4-.03 and b[3]<=4+.03,'bounds':b})
 for a,b in pairs:
  x,y=boxes[a],boxes[b];dx=min(x[1],y[1])-max(x[0],y[0]);dy=min(x[3],y[3])-max(x[2],y[2]);checks.append({'kind':'nonoverlap','objects':[a,b],'pass':dx<=0 or dy<=0,'bbox_overlap':[dx,dy]})
 rec={'scene':filename,'method':method,'source_sha256':hashlib.sha256((ROOT/'videos/ai/ai4'/filename).read_bytes()).hexdigest(),'synthetic_fixture':True,'language':'zh with frozen private overlay8475c20a; actual completed cache values for ordinary cases','variant':d.get('_variant','ordinary synthetic'),'checks':checks}
 results.append(rec);(OUT/'geometry-checkpoint.json').write_text(json.dumps(results,indent=2));print(filename,method,[(c.get('object',c.get('objects')),c['pass'],c.get('bbox_overlap')) for c in checks],flush=True)
 return ns
with tempconfig({'media_dir':str(OUT),'tex_dir':str(OUT/'geometry-Tex'),'disable_caching':False}):
 xs=np.logspace(-6,0,241)
 cancel=dict(xs=xs,naive_fp32=np.minimum(1e-7/xs**2,1),naive_fp64=np.minimum(1e-16/xs**2,1),stable_fp32=np.full(241,1e-7),pred_fp32=1e-7/(xs*xs/2),cos32_x0=1.,naive32_x0=0.)
 build('s11_vcurve.py','cancellation',cancel,['g','leg','ex','limits'],[('g','leg'),('g','ex'),('g','limits'),('ex','limits')])
 build('s11_vcurve.py','derive',{},['head'],[('head','all_rows')])
 build('s13_newton.py','derive',{},['hist'],[('hist','all_rows'),('hist','all_whys')])
 hs=np.logspace(-13,0,66);errors64=hs**2+1e-16/hs;errors32=hs**2+1e-7/hs
 vc={'hs':hs,'pred':{'fp64':{'central':3e-6},'fp32':{'central':3e-3}},'central_fp64':errors64,'central_fp32':errors32,'central_fp64_all':np.array([errors64*(1+i/10) for i in range(8)]),'central_fp32_all':np.array([errors32*(1+i/10) for i in range(8)]),'slope_right_fp64':1.95,'at_1e-6_fp64':-10}
 build('s11_vcurve.py','measured',vc,['g','table','tag'],[('g','table'),('g','tag'),('table','tag')])
 badvc={**vc,'_variant':'all median/prediction values unavailable','central_fp64':np.full(66,np.nan),'central_fp32':np.full(66,np.nan),'central_fp64_all':np.full((8,66),np.nan),'central_fp32_all':np.full((8,66),np.nan),'pred':{'fp64':{'central':np.nan},'fp32':{'central':np.nan}},'slope_right_fp64':np.nan,'at_1e-6_fp64':np.nan}
 build('s11_vcurve.py','measured',badvc,['g','table','tag'],[('g','table'),('g','tag'),('table','tag')])
 ns=build('s12_memory.py','derive',{},['row','lab','hist'],[('row','lab'),('lab','hist')]);print('memory ladder bottom',min(float(m.get_bottom()[1]) for m in ns['rows']), 'history top',float(ns['hist'].get_top()[1]),flush=True)
 ks=np.arange(1,257);peak=np.ceil(256/ks)+ks
 ck=dict(n=256,ks=ks,peak=peak,evals=np.full(256,500),klo=14,khi=18,worst=1e-15,none_peak=3,none_evals=33152,ns=[16,64,256,1024,4096],best_k=[4,8,16,32,64],best_peak=[8,16,32,64,128],t_ck=2,t_all=1)
 build('s12_memory.py','measured',ck,['g','tab','sc','model_note','rl','leg'],[('g','tab'),('g','sc'),('sc','model_note'),('rl','leg')])
 build('s12_memory.py','measured',{**ck,'worst':np.nan,'_variant':'gradient comparison unavailable'},['g','tab','sc','model_note','rl','leg'],[('g','tab'),('g','sc'),('sc','model_note'),('rl','leg')])
 # Only changed Newton plot/text assignments: contour evaluation and scene axes are deliberately excluded.
 tree=ast.parse((ROOT/'videos/ai/ai4/s13_newton.py').read_text());fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='race');start=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='gd_result' for t in ast.walk(n.targets[0])))
 nodes=[]
 for n in fn.body[start:]:
  if isinstance(n,ast.With):break
  nodes.append(n)
 ns=dict(base,ge=np.logspace(-1,-10,50),ne=np.array([.1,.01,1e-4,1e-8,1e-15]),stride=100)
 ns['d']={'gd_err_steps':np.arange(50)*100,'kappa':180,'convergence':{k:dict(status='converged',first_hit_step=first,iterations=iterations,cap=cap,threshold=1e-10,criterion=criterion) for k,first,iterations,cap,criterion in [('gd',5000,5000,200000,'objective gap to final Newton reference < threshold'),('newton',4,12,12,'gradient norm < threshold')]}}
 ns['d']=actual_cache('newton');ns['ge']=ns['d']['gd_err'];ns['ne']=ns['d']['newton_err'];execute([n for n in tree.body if isinstance(n,ast.FunctionDef)],ns);execute(nodes,ns);record_caption_ns(ns)
 boxes={name:[float(ns[name].get_left()[0]),float(ns[name].get_right()[0]),float(ns[name].get_bottom()[1]),float(ns[name].get_top()[1])] for name in ['g2','info','tag']};checks=[]
 for name,b in boxes.items():checks.append({'kind':'frame','object':name,'pass':b[0]>=-7.141 and b[1]<=7.141 and b[2]>=-4.03 and b[3]<=4.03,'bounds':b})
 for a,b in [('info','g2'),('g2','tag')]:
  x,y=boxes[a],boxes[b];over=[min(x[1],y[1])-max(x[0],y[0]),min(x[3],y[3])-max(x[2],y[2])];checks.append({'kind':'nonoverlap','objects':[a,b],'pass':min(over)<=0,'bbox_overlap':over})
 results.append({'scene':'s13_newton.py','method':'race changed plots/text','source_sha256':hashlib.sha256((ROOT/'videos/ai/ai4/s13_newton.py').read_bytes()).hexdigest(),'checks':checks});print('Newton',checks,flush=True)
 eig=np.r_[-np.linspace(.4,.01,20),np.linspace(-.001,.001,300),np.linspace(.01,.3,51)]
 h=dict(hs=np.logspace(-10,-1,37),fd_err=np.logspace(-9,-3,37),fd_best=1e-9,fd_best_h=1e-10,hv_full_diff=1e-15,lam_est=np.linspace(-.1,-.4,300),lam_power=-.4,lam_dominant=-.4,keep=[0,30,100,300,1000,3000],sizes=[2,16,16,3],P=371,t_hvp=.003,t_grad=.001,steps=3000,grid_xs=np.linspace(-1.25,1.25,4),X=np.array([[-.5,-.5],[.5,.5]]),y=[0,1],curve=np.array([[0,1],[10,.9],[100,.1],[3000,.001]]),spectrum_thresholds={'negative_relative':.01,'flat_relative':.01,'outlier_relative':.1,'scale':'spectral_radius'})
 for k in range(6):h.update({f'eig{k}':eig/(k+1),f'loss{k}':1/(k+1),f'acc{k}':.5+.08*k,f'region{k}':np.tile([.3,.4,.3],(16,1))})
 build('s14_hvp.py','checks',h,['g1','g2','info','fdl','pwl','limits'],[('g1','g2'),('g1','info'),('g2','info'),('g1','fdl'),('g2','pwl'),('fdl','limits'),('pwl','limits')])
 build('s14_hvp.py','replay',h,['title','cutoff_note','g2','g1','tag'],[('title','cutoff_note'),('cutoff_note','g2'),('g1','tag'),('g2','tag')])
 badh={**h,'_variant':'opposite signed tied dominant magnitudes','eig5':np.array([-1.,1.])}
 build('s14_hvp.py','checks',badh,['g1','g2','info','fdl','pwl','limits'],[('g1','g2'),('g1','info'),('g2','info'),('g1','fdl'),('g2','pwl'),('fdl','limits'),('pwl','limits')])
 zeroh={**h,'_variant':'all spectra and losses zero',**{f'eig{k}':np.zeros(371) for k in range(6)},**{f'loss{k}':0. for k in range(6)}}
 build('s14_hvp.py','replay',zeroh,['title','cutoff_note','g2','g1','tag'],[('title','cutoff_note'),('cutoff_note','g2'),('g1','tag'),('g2','tag')])
(OUT/'geometry-result.json').write_text(json.dumps({'scope':'AST-extracted actual Manim geometry in Chinese with frozen8475c20a private overlay, raw complete caches in ordinary cases, synthetic adverse variants; no scene import/defaultloader/render','cases':results,'all_passed':all(c['pass'] for r in results for c in r['checks'])},indent=2))

(OUT/'captured-english-strings.json').write_text(json.dumps(sorted(captured),ensure_ascii=False,indent=2))
print('CAPTION_STRINGS',len(captured))
