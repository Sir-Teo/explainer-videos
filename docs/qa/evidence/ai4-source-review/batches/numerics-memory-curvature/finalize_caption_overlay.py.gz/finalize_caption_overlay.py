from pathlib import Path
import json,re,sys
BASE=Path('/workspace/runtime/ai4-vcurve-hvp-implementation');sys.path[:0]=[str(BASE),'/workspace/explainer-videos']
import proposed_zh as P
from explainer import lang
from explainer import zh_text as T
lang.LANG='zh';T._TABLE=json.loads(Path('/workspace/explainer-videos/videos/ai/ai_text_zh.json').read_text());T._BY_NUMBERS=None
texts=json.loads((BASE/'caption-capture/captured-english-strings.json').read_text());strings={};remaining=[]
# Unwrapped literal arguments are real lookup keys before history-card wrapping.
for tree in P.trees.values():
 for node in __import__('ast').walk(tree):
  if isinstance(node,__import__('ast').Call) and isinstance(node.func,__import__('ast').Name) and node.func.id in ('history_card','label','note','why'):
   texts += [a.value for a in node.args if isinstance(a,__import__('ast').Constant) and isinstance(a.value,str)]
texts=sorted(set(texts))
for s in texts:
 z=P.caption_translate(T.translate(s))
 if z!=s:strings[s]=z
 # Report only descriptive Latin, ignoring formula commands, math and accepted technical acronyms/names.
 clean=re.sub(r'\$[^$]*\$',' ',z);clean=re.sub(r'\\(?:begin|end)\{[^}]+\}', ' ',clean);clean=re.sub(r'\\[A-Za-z]+',' ',clean)
 words=re.findall(r'\b[A-Za-z][A-Za-z-]{2,}\b',clean)
 words=[w for w in words if w not in {'FP64','FP32','Adam','Pearlmutter','Newton','Griewank','Chen','Xu','Zhang','Guestrin','Raphson','Simpson','Isaac','Andreas','Tianqi','Bing','Chiyuan','Carlos','Joseph','Thomas','Hessian','PyTorch','FlashAttention','log','tanh'}]
 if words:remaining.append({'en':s,'zh':z,'remaining':words})
P.emit(strings)
(BASE/'caption-overlay-remaining.json').write_text(json.dumps(remaining,ensure_ascii=False,indent=2));print('exactstrings',len(strings),'remaining',len(remaining));print(json.dumps(remaining,ensure_ascii=False,indent=2))
