"""Resolve handoff captions from completed raw payloads; never import scenes/loaders."""
import ast
import hashlib
import json
import math
from pathlib import Path

import numpy as np

repo = Path('/workspace/explainer-videos')
out = Path(__file__).parent
handoff = json.loads((out / 'bilingual-handoff.json').read_text())
overlay_path = out / 'normalized-bilingual-overlay.json'
overlay = json.loads(overlay_path.read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(name):
    cache = repo / '.cache/ai4'
    data = json.loads((cache / f'{name}.json').read_text())
    path = cache / f'{name}.npz'
    if path.exists():
        with np.load(path, allow_pickle=False) as arrays:
            data.update({k: arrays[k].copy() for k in arrays.files})
    return data

def function(path, name, env):
    tree = ast.parse(path.read_text())
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module([node], type_ignores=[]), str(path), 'exec'), env)
    return env[name]

env = dict(math=math, np=np)
function(repo / 'explainer/analysis/__init__.py', 'sci', env)
function(repo / 'videos/ai/ai4/s10_floats.py', 'big', env)
function(repo / 'videos/ai/ai4/s09_train.py', 'training_readout', env)
by_name = {Path(f['path']).name: f for f in handoff['files']}
templates = handoff['proposed_caption_templates']
rows = []

def resolve(template_id, scene_file, line, values, comma_escape=False):
    entry = next(x for x in by_name[scene_file]['new_or_changed_caption_expressions'] if x['line'] == line)
    scope = dict(env, **values)
    english = eval(compile(ast.parse(entry['expression'], mode='eval'), '<actual-caption-expression>', 'eval'), scope)
    chinese = eval(compile(ast.parse('fr' + repr(templates[template_id]), mode='eval'), '<caption-proposal>', 'eval'), scope)
    if comma_escape:
        chinese = chinese.replace(',', '{,}')
    rows.append(dict(template_id=template_id, source=by_name[scene_file]['path'], line=line,
                     english=english, chinese=chinese))

modes = read('modes')
scope = dict(d=modes, cr=modes['madds_fwd']/modes['madds_rev'],
             tr_=modes['t_param_fwd']/modes['t_param_rev'], bench=modes['benchmark'])
for template_id, line in [('modes_dense_ratio', 176), ('modes_reverse_gap', 178), ('modes_timing_protocol', 181)]:
    resolve(template_id, 's06_modes.py', line, scope)
mlp = read('mlp2')
sv1, svB = np.asarray(mlp['sv_one']), np.asarray(mlp['sv_all'])
din, dh, _ = mlp['dims']
scope = dict(m=mlp, sv1=sv1, B=int(mlp['B']), din=din, dh=dh,
             rank_b=int((svB > 1e-10*svB[0]).sum()))
for template_id, line in [('backprop_one_singular', 216), ('backprop_batch_rank', 219),
                          ('backprop_library_gap', 220), ('backprop_torch_gap', 221)]:
    resolve(template_id, 's07_backprop.py', line, scope)
train = read('train')
measured = env['training_readout'](train)
scope = dict(d=train, measured=measured, corr_info=measured['correlation'])
for template_id, line in [('counting_reference',180), ('final_corpus_bits',194), ('masked_correlation',201)]:
    resolve(template_id, 's09_train.py', line, scope)
shown_steps = [0, *train['snap_steps']]
for k in range(len(shown_steps)):
    resolve('sample_after_update', 's09_train.py',216, dict(shown_steps=shown_steps,k=k),comma_escape=True)
gdlr = read('gdlr')
loss_clipped = curvature_clipped = thresholds_omitted = 0
for k, eta in enumerate(gdlr['etas']):
    b, lm = np.asarray(gdlr[f'bitcurve{k}']), np.asarray(gdlr[f'lamcurve{k}'])
    loss_clipped += int(((b < 3.2) | (b > 5)).sum())
    curvature_clipped += int(((lm < 0) | (lm > .08)).sum())
    thresholds_omitted += int(2/eta >= .08)
resolve('step_plot_window','s09_train.py',306,dict(loss_clipped=loss_clipped,
        curvature_clipped=curvature_clipped,thresholds_omitted=thresholds_omitted))
floats = read('floats')
for key in ('fp32','bf16','fp16','e5m2','e4m3'):
    resolve('float_format_stats','s10_floats.py',55,dict(i=floats['info'][key]))
strings = dict(handoff['proposed_static_captions'])
for row in rows:
    key, value = row['english'], row['chinese']
    assert key not in strings or strings[key] == value
    strings[key] = value
overlay['strings'] = strings
assert not set(templates) & set(strings), 'descriptive template IDs must not become global lookup keys'
overlay_path.write_text(json.dumps(overlay,ensure_ascii=False,indent=2)+'\n')
receipt = dict(handoff_sha256=sha(out/'bilingual-handoff.json'), overlay_sha256=sha(overlay_path),
               ZH_updates=len(overlay['ZH_updates']), obsolete_keys=len(overlay['obsolete_keys']),
               static_strings=len(handoff['proposed_static_captions']),
               dynamic_template_ids_resolved=len(templates), resolved_dynamic_strings=len(rows),
               strings=len(strings), resolved_caption_ledger=rows,
               scope='Actual completed immutable raw payload values; AST-extracted pure formatting helpers only. '
                     'No scene imports/default loaders/producer execution/rendering. All strings keys are exact English captions; '
                     'descriptive dynamic-template IDs are excluded. These resolved captions cover this measured default run; '
                     'new numerical results need regenerated mappings.',
               sources_match_handoff=all(sha(repo/f['path'])==f['after_sha256'] for f in handoff['files']))
assert receipt['sources_match_handoff']
(out/'normalized-bilingual-overlay-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='resolved_caption_ledger'},indent=2))
