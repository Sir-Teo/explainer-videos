"""Development-only proposed-overlay simulation; portable tests have no runtime dependency."""
import importlib.util,json,sys,unittest
from pathlib import Path
from explainer.zh_templates import Translator
root=Path('/workspace/explainer-videos');runtime=Path('/workspace/runtime')
paths=[runtime/'ai4-first-five-implementation/bilingual-handoff.json',runtime/'ai4-mid-head-implementation/normalized-bilingual-overlay.json',runtime/'ai4-vcurve-hvp-implementation/proposed-zh-overlay.json',runtime/'ai4-tail-implementation/normalized-ch-overlay.json']
updates={};phrases={};obsolete=[]
for p in paths:
 j=json.loads(p.read_text());updates.update(j['ZH_updates']);phrases.update(j.get('PHRASES_updates',{}));obsolete.extend(j.get('obsolete_keys',j.get('remove_or_replace_obsolete_narration_keys',[])))
original=Translator.__init__
def patched(self,video):
 original(self,video)
 if video=='ai4':
  self.zh={k:v for k,v in self.zh.items() if k not in obsolete};self.zh.update(updates);self.phrases.update(phrases)
Translator.__init__=patched
spec=importlib.util.spec_from_file_location('ai4_narration_review',root/'tests/test_ai4_narration_review.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module));sys.exit(not r.wasSuccessful())
