"""Consume completed immutable raw Part4 JSON/NPZ; never invoke loaders/producers."""
from pathlib import Path
import ast,datetime,hashlib,json,math,shutil
import numpy as np

repo=Path('/workspace/explainer-videos');out=Path(__file__).parent;cache=repo/'.cache/ai4'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();receipts={}
def read(name):
    jp=cache/(name+'.json');d=json.loads(jp.read_text());paths=[jp];ap=cache/(name+'.npz')
    if ap.exists():
        with np.load(ap,allow_pickle=False) as arrays:d.update({k:arrays[k].copy() for k in arrays.files})
        paths.append(ap)
    receipts[name]={}
    for p in paths:
        s=p.stat();q=out/'actual-data-snapshot'/p.name;q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
        receipts[name][p.name]={'sha256':sha(p),'bytes':s.st_size,'mtime_ns':s.st_mtime_ns,'snapshot':str(q)}
    for rel,expected in d['_cache']['recipe']['source_hashes'].items():assert sha(repo/rel)==expected
    if ap.exists():assert sha(ap)==d['_cache']['arrays_sha256']
    return d
def fn(file,name):
    tree=ast.parse((repo/'videos/ai/ai4'/file).read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);env=dict(np=np,math=math);exec(compile(ast.Module([node],type_ignores=[]),'actual-scene-helper','exec'),env);return env[name]

m=read('modes');p=read('params');network=read('mlp2');tiny=read('tiny');check=read('check');tape=read('tape');first=read('grad0');train=read('train');gdlr=read('gdlr');floats=read('floats')
assert m['madds_rev']==37888 and m['madds_fwd']/m['madds_rev']==m['P']==874
wins,total=fn('s06_modes.py','cheaper_mode_agreement')(m['fwd'],m['rev'],m['t_fwd'],m['t_rev'])
normal=fn('s09_train.py','row_log_probabilities');summary=fn('s09_train.py','training_readout')(train)
assert train['snaps'].shape==train['snaps_logp'].shape==(4,27,27)
normal_errors=[]
for raw,logp in zip(train['snaps'],train['snaps_logp']):
    expected=normal(raw);normal_errors.append(float(np.abs(expected-logp).max()));np.testing.assert_allclose(expected,logp,atol=1e-13)
    np.testing.assert_allclose(np.exp(logp).sum(1),1,atol=1e-13)
np.testing.assert_allclose(train['snaps'][-1],train['z_final']);np.testing.assert_allclose(normal(train['z_final']),train['logp'],atol=1e-13)
mask=np.exp(train['logcond'])>train['metrics']['correlation']['threshold']
assert int(mask.sum())==train['metrics']['correlation']['count']
corr=float(np.corrcoef(train['logp'][mask],train['logcond'][mask])[0,1]);assert abs(corr-train['corr'])<1e-12
yr=np.r_[train['curve'][:,1],train['H_cond'],train['bits_train'],train['bits_valid']];ylo=math.floor(2*(float(yr.min())-.15))/2;yhi=math.ceil(2*(float(yr.max())+.15))/2
assert np.isfinite(yr).all() and ylo<=yr.min()<=yr.max()<=yhi
assert train['metrics']['curve_parameter_step']=='t-1' and train['metrics']['snapshot_parameter_step']=='t'
assert abs(train['curve'][0,1]-math.log2(27))<1e-12
assert len(train['snap_steps'])+1==5
ops=[v['op'] for v in tape['tape']];assert ops==['input','*','input','+','sigmoid','+','*']
destinations=[v['i'] for v in tape['tape'] for a in sorted(set(v['args']))];assert destinations==[1,3,3,4,5,6]
gap_words=fn('s08_library.py','gap_report');fd_words=gap_words(check['fd_diff']);pt_words=gap_words(check['torch_diff'])
sv1,svB=network['sv_one'],network['sv_all'];one_rank=int((sv1>1e-10*sv1[0]).sum());batch_rank=int((svB>1e-10*svB[0]).sum())
loss_clipped=curvature_clipped=thresholds_omitted=0
for i,eta in enumerate(gdlr['etas']):
    bits=gdlr[f'bitcurve{i}'];lam=gdlr[f'lamcurve{i}'];assert np.isfinite(bits).all() and np.isfinite(lam).all()
    loss_clipped+=int(((bits<3.2)|(bits>5)).sum());curvature_clipped+=int(((lam<0)|(lam>.08)).sum());thresholds_omitted+=int(2/eta>=.08)
keys=('fp32','bf16','fp16','e5m2','e4m3');all_logs=np.concatenate([np.log10(floats[f'ulp_{k}'][np.isfinite(floats[f'ulp_{k}'])&(floats[f'ulp_{k}']>0)]) for k in keys]);ulo=min(-14,math.floor(float(all_logs.min())));uhi=max(4,math.ceil(float(all_logs.max())))
assert floats['info']['fp16']['min_normal']==2**-14 and floats['info']['fp16']['min_sub']==2**-24
assert all(v=='inf' for v in floats['lse_naive_e']) and all(v=='nan' for v in floats['lse_naive_p'])
assert np.isfinite(floats['lse_p']).all() and abs(floats['lse_p'].sum()-1)<1e-6
actual={'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Completed producer outputs consumed directly from immutable JSON/NPZ; no compute/load/helper or scene import/render. Tiny AST-extracted pure scene helpers evaluate the existing data contract.','inputs':receipts,'Modes':{'parameters':m['P'],'dense_forward_work':m['madds_fwd'],'parameter_only_reverse_work':m['madds_rev'],'count_ratio':m['madds_fwd']/m['madds_rev'],'recorded_call_time_ratio':m['t_param_fwd']/m['t_param_rev'],'cheaper_count_faster_cases':wins,'different_count_cases':total,'grad_diff':m['grad_diff'],'work_count':m['work_count'],'benchmark':m['benchmark'],'parameter_provenance':p['provenance']},'Backprop':{'single_rank':one_rank,'batch_rank':batch_rank,'shape':network['dims'],'lib_gap':network['d_lib'],'torch_gap':network['d_torch'],'tiny_loss':tiny['values']['L'],'tiny_weight_gradient':tiny['grads']['w']},'Library':{'actual_forward_destinations':destinations,'fd_diff':check['fd_diff'],'torch_diff':check['torch_diff'],'fd_words':fd_words,'torch_words':pt_words,'default_exact_zero_trigger':False},'Train':{'bits_train':train['bits_train'],'bits_valid':train['bits_valid'],'counting_reference':train['H_cond'],'gap_bits':summary['gap'],'correlation':corr,'correlation_count':int(mask.sum()),'metrics':train['metrics'],'snapshot_steps':train['snap_steps'],'snapshot_shapes':list(train['snaps'].shape),'max_snapshot_normalization_error':max(normal_errors),'first_curve_is_uniform_preupdate':True,'plot_bounds':[ylo,yhi],'actual_loss_verdict':summary['loss_verdict'],'actual_correlation_verdict':summary['correlation_verdict'],'full_and_sampled_loss_range':[float(yr.min()),float(yr.max())]},'Train_steps':{'etas':gdlr['etas'],'last_mean':gdlr['last_mean'],'last_spread':gdlr['last_spread'],'metrics':gdlr['metrics'],'display_clipped_loss_samples':loss_clipped,'display_clipped_curvature_samples':curvature_clipped,'threshold_lines_omitted':thresholds_omitted,'units_note':'Loss is plotted in bits; gradient update and curvature use the natural-log objective. Existing first-gradient narration bridges nats/bits, but an explicit curvature-axis unit caption would be clearer; reported before changing frozen source.'},'Floats':{'actual_log_gap_range':[float(all_logs.min()),float(all_logs.max())],'new_plot_bounds':[ulo,uhi],'fp16_min_normal':floats['info']['fp16']['min_normal'],'fp16_subnormal_gap':floats['info']['fp16']['min_sub'],'e4m3_max':floats['info']['e4m3']['max'],'accumulation_endpoints':{k:float(floats['acc_'+k][-1]) for k in ('fp32','fp16','bf16','bf16_fp32acc')},'stable_probabilities':floats['lse_p'].tolist()},'source_edits_after_freeze':False,'remaining':'Actual native EN/ZH scene output and playback/audio remain untested.'}
for name,files in receipts.items():
    for filename,row in files.items():
        assert sha(cache/filename)==row['sha256'] and (cache/filename).stat().st_mtime_ns==row['mtime_ns']
(out/'actual-data-contract-check.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'receipt_sha256':sha(out/'actual-data-contract-check.json'),'modes_count_ratio':actual['Modes']['count_ratio'],'modes_time_ratio':actual['Modes']['recorded_call_time_ratio'],'wins_total':[wins,total],'train_gap':summary['gap'],'corr':corr,'corr_count':int(mask.sum()),'ulp_bounds':[ulo,uhi],'gdlr_display_clipped':[loss_clipped,curvature_clipped],'default_contract_mismatches':[],'pending_unit_caption':'Explicit natural-log objective for curvature scale; source unchanged.'},indent=2))
