# Part4 first five: source repair handoff

Source batch frozen; actual bilingual rendered QA remains pending. No Part4 loader/production compute/import/render was run.

- AI4-FH01: Jacobians multiply; spectral norms give a submultiplicative bound, not equality or growth in every direction. Small norm shrinks every unit direction; large norm permits some-direction growth. Correct measured mean-log/seed min-max interpretation, no data/range endpoint clamping; curve limits include all finite records.
- AI4-FIRST5-02: Surface/tangent-plane illustration shares BOWL_P0 with measured errors and later contour sweep; steepest-ascent theorem explicitly assumes differentiability; perpendicular direction is tangent to contour.
- AI4-FIRST5-03: Finite pictured intervals do not have stretches exactly2/e; labels now explicitly identify local derivative factors as step tends to0, preserving6x last-line scale.
- AI4-FIRST5-04: Mapped square-grid corners can lie outside circular lens; clip actual sampled segments to0.98radius without altering map or Jacobian coordinates. Independent numeric and actual-Manim control-point checks pass.
- AI4-FIRST5-05: Preserve signed tiny computed eigenvalues rather than clamping softmax negatives/absolute-value layernorm roundoff; theory vs numeric distinction explicit, semantic sign keys and pre-affine epsilon sensitivity retained.
- AI4-FIRST5-06: Per-model pinned-header/historical-fallback/unknown provenance labels, schematic per-square scale, dynamic recorded count narration and full-parameter-training qualifier; schema aligned to proposed producer contract.
- AI4-FIRST5-07: q-minus-target cross-entropy gradient identified as natural-log objective; loss in bits includes1/ln2.
- AI4-FIRST5-08: 1986 historical claim now describes hidden representations learned via backpropagation, avoiding implying neural training began then.

Validation:17 focused tests;18 isolated actual-Manim grid objects;7 isolated text/layout sections per language;8 actual narration-translator cases with bookmarks/placeholders; py_compile and scoped diff checks.

Bilingual handoff: `/workspace/runtime/ai4-first-five-implementation/bilingual-handoff.json`.

- Root merges21 proposed on-screen caption entries and7 narration entries plus2 depth verdicts, replacing obsolete prefix keys; numeric caption examples are template anchors, not current cache measurements.
- Producer owner still finalizing exact params contract; current consumer accepts proposed per-model source literals and safely labels unknown/missing provenance unverified.
- Actual bilingual endpoints, full-silent motion/selected-frame inspection, native-resolution layout and narrated playback/listening not yet performed.
- Current math/text fixtures do not establish current training outcomes or numeric cache freshness.
