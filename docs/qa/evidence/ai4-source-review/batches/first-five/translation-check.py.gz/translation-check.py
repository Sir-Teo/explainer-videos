import ast,json,re
from pathlib import Path
from explainer.zh_templates import Translator
O=Path('/workspace/runtime/ai4-first-five-implementation');h=json.loads((O/'bilingual-handoff.json').read_text());tr=Translator('ai4')
for k in h['remove_or_replace_obsolete_narration_keys']:tr.zh.pop(k,None)
tr.zh.update(h['ZH_updates']);ns={'p':{'gpt2':124439808,'qwen3_4b':4022468096},'L':60,'gains':[.5,.9,1,1.5,2],'m0':-17.4,'m4':4.6,'verdict':next(iter(h['spliced_verdicts'])),'d':{'dmax':.81263,'gnorm':.81263},'off':.21}
checks=[]
for e in h['narration']:
 for verdict in (list(h['spliced_verdicts']) if e['method']=='depth' else [ns['verdict']]):
  ns['verdict']=verdict;en=eval(compile(ast.parse(e['english_source'],mode='eval'),'<literal-synthetic-template>','eval'),{},ns) if e['template'] else e['english_source'];zh=tr(en);assert zh is not None and re.search(r'[\u4e00-\u9fff]',zh);assert re.findall(r"<bookmark[^>]+>",en)==re.findall(r"<bookmark[^>]+>",zh);assert not re.search(r'\{[^{}]+\}',zh)
  if e['method']=='softmax':assert '自然对数' in zh and '比特' in zh and 'ln 2' in zh
  if e['method']=='depth':assert '不一定相等' in zh and '并不代表每个方向' in zh and '所有方向都缩小' in zh
  checks.append({'file':e['file'],'method':e['method'],'sample_en':en,'sample_zh':zh,'bookmarks_match':True,'placeholders_resolved':True})
(O/'translation-check.json').write_text(json.dumps({'scope':'In-memory proposed tables; synthetic numbers, actual source templates. No table/source changes or production load.','checks':checks},indent=2,ensure_ascii=False));print(len(checks),'narration cases pass actual template translator/bookmarks/placeholders')
