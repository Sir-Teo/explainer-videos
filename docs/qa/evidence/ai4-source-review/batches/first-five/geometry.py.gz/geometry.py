"""Isolated source-layout fixtures; no scene import, load, construct or render."""
import ast,json,math,os,sys
from pathlib import Path
import numpy as np
from explainer.ai import *
ROOT=Path('/workspace/explainer-videos');PART=ROOT/'videos/ai/ai4';OUT=Path('/workspace/runtime/ai4-first-five-implementation')
config.media_dir=str(OUT/'geometry-media');config.verbosity='ERROR'
if os.environ.get('EXPLAINER_LANG')=='zh':
 import explainer.zh_text as z
 z._TABLE=z._table();z._TABLE.setdefault('strings',{}).update(json.loads((OUT/'bilingual-handoff.json').read_text())['strings']);z._BY_NUMBERS=None


def node(file,name):return next(n for n in ast.walk(ast.parse((PART/file).read_text())) if isinstance(n,ast.FunctionDef) and n.name==name)
def run(nodes,ns):exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-layout-AST>','exec'),ns)
def before_vo(file,name,data=None):
 n=node(file,name);ns=dict(globals());ns.update(GRAD='#FF9F45',VALUE='#58A6FF',HIST=C.HUMAN,PART=4,self=object(),d=data,p=data)
 names=({'s05_layers.py':['gap','gap_tex','eigenvalue_tex','signed_heat_key'],'s01_hook.py':['parameter_count_source'],'s04_jacobian.py':['depth_plot_range','jac']}).get(file,[])
 if names:run([node(file,k) for k in names],ns)
 common=ast.parse((PART/'common.py').read_text());heat=next(x for x in common.body if isinstance(x,ast.FunctionDef) and x.name=='matrix_heat');run([heat],ns)
 keep=[]
 for x in n.body:
  if isinstance(x,ast.With):break
  if isinstance(x,ast.Assign) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Name) and x.value.func.id=='load':continue
  keep.append(x)
 run(keep,ns);return ns

def bounds(m):return dict(left=float(m.get_left()[0]),right=float(m.get_right()[0]),top=float(m.get_top()[1]),bottom=float(m.get_bottom()[1]),width=float(m.width),height=float(m.height))
def inside(m):b=bounds(m);return b['left']>=-6.95 and b['right']<=6.95 and b['bottom']>=-3.85 and b['top']<=3.85
# Synthetic eigensystems include measured signs and tiny roundoff, not production outputs.
p=np.array([.1,.15,.2,.25,.3]);j=np.diag(p)-np.outer(p,p)
data=dict(p=p,J_sm=j,eig_sm=np.array([-2.3e-17,.11,.17,.22,.28]),sm_diff=5.6e-17,sm_null=1e-16,
          J_ln=np.eye(6)-np.ones((6,6))/6,eig_ln=np.array([-3.1e-17,4e-6,.7,.7,.7,.7]),ln_diff=1.9e-16)
report={'scope':__doc__,'lang':os.environ.get('EXPLAINER_LANG','en'),'layout':{}}
for method,items in [('softmax',['heat','key','hl','props']),('layernorm',['heat','key','hl','ev'])]:
 n=before_vo('s05_layers.py',method,data);report['layout'][method]={name:dict(bounds(n[name]),inside=inside(n[name])) for name in items}
n=before_vo('s02_derivative.py','rules');report['layout']['rules']={name:dict(bounds(n[name]),inside=inside(n[name])) for name in ['r1','r2','r3','lines','names','stretch','local','scale_note','notation']}
params={'gpt2':124439808,'qwen3_4b':4022468096,'provenance':{'gpt2':{'source':'pinned-safetensors-headers'},'qwen3_4b':{'source':'historical-fallback'}}}
n=before_vo('s01_hook.py','recall',params);report['layout']['recall']={name:dict(bounds(n[name]),inside=inside(n[name])) for name in ['f','cap','units','n1','n2','each','scale']}
depth={'gains':[.5,.9,1.,1.5,2.], 'L':60,'seeds':8}
for k,final in enumerate([-17.,-2.5,-.2,2.1,4.6]):
 depth[f'mean{k}']=np.linspace(0,final,60);depth[f'lo{k}']=depth[f'mean{k}']-.5;depth[f'hi{k}']=depth[f'mean{k}']+.5
n=before_vo('s04_jacobian.py','depth',depth);report['layout']['depth']={name:dict(bounds(n[name]),inside=inside(n[name])) for name in ['g','head','bound','meaning','spread','labs']}
n=before_vo('s03_gradient.py','steepest');report['layout']['steepest']={name:dict(bounds(n[name]),inside=inside(n[name])) for name in ['head','thm']}
n=before_vo('s04_jacobian.py','det_and_chain');report['layout']['jacobian_definition']={name:dict(bounds(n[name]),inside=inside(n[name])) for name in ['dc','chain','cw','shapes','shape_pic','dl']}
assert not any(k.startswith('videos.ai.ai4') for k in sys.modules);report['production_part4_modules_imported']=False
print(json.dumps(report,indent=2));(OUT/('geometry-'+report['lang']+'.json')).write_text(json.dumps(report,indent=2))
