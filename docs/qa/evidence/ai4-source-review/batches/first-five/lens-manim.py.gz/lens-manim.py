import ast,json,math
from pathlib import Path
import numpy as np
from manim import *
p=Path('/workspace/explainer-videos/videos/ai/ai4/s04_jacobian.py');tree=ast.parse(p.read_text());names=['warp','jac','clip_segment_to_disk','grid_lines'];nodes=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in names];assert len(nodes)==4
exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-pure-lens-helpers>','exec'),globals())
center=np.array([4.,-1.,0]);p0=np.array([1.2,.6]);J=jac(*p0);R=2.2;records=[]
for rr in np.linspace(1.6,.08,9):
 k=R*.62/rr
 maps=[lambda q:center+k*(warp(p0+q)-warp(p0)),lambda q:center+k*np.r_[J@q,0]]
 for name,f in zip(['warped','Jacobian'],maps):
  g=grid_lines(-rr,rr,7,f,clip_disk=(center,R*.98));points=np.concatenate([m.points for m in g if len(m.points)])
  maximum=float(np.max(np.linalg.norm(points-center,axis=1)));assert maximum<=R*.98+1e-12
  records.append({'radius':float(rr),'map':name,'lines':len(g),'native_manim_points':len(points),'max_point_distance_from_lens_center':maximum,'limit':R*.98})
r={'scope':'Actual AST-extracted local Manim helpers only; no scene imports/load/construct/render. Checks every native cubic control point in both mapped-grid objects through9 zoom radii.','records':records}
Path('/workspace/runtime/ai4-first-five-implementation/lens-manim.json').write_text(json.dumps(r,indent=2));print(len(records),'actual Manim grid cases passed')
