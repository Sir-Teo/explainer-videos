from pathlib import Path
import ast,datetime,difflib,gzip,hashlib,json,subprocess,re
B=Path('/workspace/explainer-videos');R=Path('/workspace/runtime');D=B/'docs/qa/evidence/ai4-source-review'
# Explicit final-freeze receipt is required: do not capture while parent repair owners are active.
freeze=json.loads((R/'ai4-source-review-package/final-freeze.json').read_text())
assert freeze['capture_authorized'] is True
D.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest();records=[]
def raw(path,data,origin=None):
 p=D/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 if origin:records.append({'origin':str(origin),'package':path,'raw_sha256':sha(data),'raw_bytes':len(data),'compressed':False})
 return p

def zipped(path,data,origin=None):
 p=D/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,compresslevel=9,mtime=0));assert gzip.decompress(p.read_bytes())==data
 records.append({'origin':str(origin) if origin else None,'package':path,'raw_sha256':sha(data),'raw_bytes':len(data),'compressed_sha256':sha(p.read_bytes()),'compressed_bytes':p.stat().st_size,'compressed':True})
 if path.endswith('.json.gz'):json.loads(data)
 return p

def include(source,destination):
 p=R/source;assert p.is_file(),p;return zipped(destination+'.gz',p.read_bytes(),p)
base=subprocess.check_output(['git','rev-parse','f00be66'],cwd=B,text=True).strip();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=B,text=True).strip()
manifest=B/'videos/ai/ai4/manifest.py';tree=ast.parse(manifest.read_text());scenes=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SCENES' for t in n.targets));assert len(scenes)==19
scene_paths=[f'videos/ai/ai4/{module}.py' for module,_,_ in scenes]
paths=list(dict.fromkeys(scene_paths+list(freeze['source_sha256'])+['explainer/ai/autodiff.py']+[str(p.relative_to(B)) for p in sorted((B/'tests').glob('test_ai4*.py'))]))
snapshots=[];captured={};patches=[]
for name in paths:
 p=B/name;current=p.read_bytes();captured[name]=current;zipped('snapshots/current/'+name+'.gz',current,p)
 result=subprocess.run(['git','show',base+':'+name],cwd=B,capture_output=True)
 if result.returncode:
  assert name.startswith('tests/') or name in freeze['source_sha256'],(name,result.stderr.decode());before=None
 else:before=result.stdout;zipped('snapshots/baseline-f00be66/'+name+'.gz',before,base+':'+name)
 snapshots.append({'path':name,'baseline_commit':base,'baseline_sha256':sha(before) if before is not None else None,'baseline_bytes':len(before) if before is not None else None,'current_sha256':sha(current),'current_bytes':len(current),'changed':before!=current})
 oldlines=before.decode().splitlines(keepends=True) if before is not None else[];newlines=current.decode().splitlines(keepends=True)
 patches.extend(difflib.unified_diff(oldlines,newlines,fromfile='baseline-f00be66/'+name,tofile='current/'+name,n=3))
zipped('source-and-table-diff.patch.gz',''.join(patches).encode(),f'Exact package snapshots compared; baseline {base}')
# Four source-owner batches, preserving originals rather than rewriting historical
# freezes/proposals to look as though the final root merge already existed.
batches={
 'first-five':('ai4-first-five-implementation',[
  'before.json','bilingual-handoff.json','implementation-report.json','implementation-report.md','math-tests.log','geometry-en.json','geometry-zh.json','lens-manim.json','translation-check.json','geometry.py','lens-manim.py','translation-check.py']),
 'middle-five':('ai4-mid-head-implementation',[
  'before-sources.json','bilingual-handoff.before-curvature.json','bilingual-handoff.json','normalized-bilingual-overlay.json','normalized-bilingual-overlay-receipt.json','report.json','report.md','actual-data-contract-check.json','final-freeze-receipt.json','curvature-caption-final.json','curvature-caption-geometry.json','curvature-caption-geometry.log','scene-contract-tests.log','autodiff-zero-power-tests.log','producer-autodiff-related-tests.log','narration-regression-initial.log','narration-regression-proposed.log','narration-test-handoff.json','autodiff-freeze.json','autodiff-power0-probe.json','source.patch','check_actual_data.py','test_narration_proposed_overlay.py','normalize_overlay.py']),
 'numerics-memory-curvature':('ai4-vcurve-hvp-implementation',[
  'before-provenance.json','bilingual-handoff.json','proposed-zh-overlay.json','tests-initial.log','tests-final.log','geometry-result.json','geometry-checkpoint.json','geometry-zh-frozen-overlay.log','zh-layout-frozen-overlay/geometry-result.json','zh-layout-frozen-overlay/geometry-checkpoint.json','zh-layout-frozen-overlay/captured-english-strings.json','zh-overlay-validation.json','zh-overlay-validation.log','caption-overlay-validation.json','caption-overlay-validation.log','caption-overlay-remaining.json','actual-cache-validation.json','actual-cache-validation.log','test_zh_overlay.py','test_caption_overlay.py','finalize_caption_overlay.py','validate_actual_cache.py','geometry.py','geometry_zh_frozen_overlay.py']),
 'tail-five':('ai4-tail-implementation',[
  'README.md','before.json','source-freeze.json','bilingual-handoff.json','normalized-ch-overlay.json','caption-add.json','caption-resolution.json','narration-additions.json','implementation-report.json','actual-cache-review.json','geometry-en.json','geometry_fixture.py','tests-final.log','private-overlay-fixtures.json','private-overlay-test.log','check_private_overlay.py','normalize_overlay.py','export_handoff.py','zh_proposals.py'])}
for group,(folder,names) in batches.items():
 for name in names:include(folder+'/'+name,'batches/'+group+'/'+name)
# Root integration receipts and exact parent-run full-suite log.
for name in ['merge-receipt.json','todo.log']:
 include('ai4-bilingual-integration/'+name,'integration/'+name)
include('ai4-integrated-full-tests.log','integration/full352-tests.log')
full=(R/'ai4-integrated-full-tests.log').read_text();match=re.search(r'Ran (\d+) tests in ([\d.]+)s\s+OK',full);assert match and int(match[1])==352 and float(match[2])==54.535
integration=json.loads((R/'ai4-bilingual-integration/merge-receipt.json').read_text());assert integration['local_after']==sha(captured['videos/ai/ai4/zh_lines.py'])
assert sha(captured['videos/ai/ai_text_zh.json'])==freeze['global_sha256']
for name,expected in freeze['source_sha256'].items():assert sha(captured[name])==expected,(name,expected,sha(captured[name]))
raw('integration/final-freeze.json',json.dumps(freeze,indent=2).encode()+b'\n')
# The full-suite log and integrated table receipt predate the actual-render corrections.
pre_delta_table=(R/'ai12-shared-caption-regression-part4/current-ai_text_zh.json').read_bytes()
assert sha(pre_delta_table)==integration['global_after_root_scope_preservation']
old_table_root=json.loads(pre_delta_table);final_table_root=json.loads(captured['videos/ai/ai_text_zh.json'])
assert old_table_root.keys()==final_table_root.keys()
for section in ['phrases','patterns']:assert old_table_root[section]==final_table_root[section],('unexpected non-caption section delta',section)
old_table=old_table_root['strings'];final_table=final_table_root['strings']
assert isinstance(old_table,dict) and isinstance(final_table,dict)
# Record rather than hide later scoped additions/corrections; the original zero-difference receipt is historical.
final_delta={'pre_delta_sha256':sha(pre_delta_table),'final_sha256':sha(captured['videos/ai/ai_text_zh.json']),'added':{k:v for k,v in final_table.items() if k not in old_table},'removed':{k:v for k,v in old_table.items() if k not in final_table},'changed':{k:{'before':old_table[k],'after':v} for k,v in final_table.items() if k in old_table and old_table[k]!=v},'qualification':'Exact table delta since the parent-run352-test/captured-caption regression checkpoint; this delta is not a rerun of those gates.'}
raw('integration/post-test-table-delta.json',json.dumps(final_delta,indent=2,ensure_ascii=False).encode()+b'\n')
# Read-only shared-caption regression: reuse complete mapping and both table bytes.
for source,dest in [
 ('ai12-shared-caption-regression-part4.json','shared-caption-regression/report.json'),
 ('ai12-shared-caption-regression-part4.md','shared-caption-regression/report.md'),
 ('ai12-shared-caption-regression-part4.log','shared-caption-regression/execution.log'),
 ('ai12-shared-caption-regression-part4/used-caption-results.json','shared-caption-regression/used-caption-results.json'),
 ('regress_ai12_shared_caption_tables_part4.py','shared-caption-regression/regression-script.py')]:include(source,dest)
aliases={}
for role in ['baseline','current']:
 p=R/'ai12-shared-caption-regression-part4'/f'{role}-ai_text_zh.json';content=p.read_bytes();h=sha(content)
 if h==sha(captured['videos/ai/ai_text_zh.json']):target='snapshots/current/videos/ai/ai_text_zh.json.gz'
 else:
  x=next((s for s in snapshots if s['path']=='videos/ai/ai_text_zh.json' and s['baseline_sha256']==h),None)
  target='snapshots/baseline-f00be66/videos/ai/ai_text_zh.json.gz' if x else 'shared-caption-regression/'+role+'-ai_text_zh.json.gz'
  if not x:zipped(target,content,p)
 aliases[role]={'original':str(p),'raw_sha256':h,'package_table_bytes':target,'note':'Alias preserves identical bytes without duplicate payload; regression baseline commit remains the one in original regression receipt, not inferred from this alias.'}
raw('shared-caption-regression/table-aliases.json',json.dumps(aliases,indent=2).encode()+b'\n')
# Derivative's root layout-only correction supersedes its first-five owner freeze.
for name in ['source-before.py','source-after.py','before-result.json','rerender-en.log']:
 include('ai4-derivative-axis-regression/'+name,'derivative-layout-transition/'+name)
a=(R/'ai4-derivative-axis-regression/source-before.py').read_bytes();b=(R/'ai4-derivative-axis-regression/source-after.py').read_bytes();assert sha(a)=='8958372838269201b5430a8eb4b24bc7298cc2e0a3b8b34a03aad2ce7d248d10';assert b==captured['videos/ai/ai4/s02_derivative.py']
def voiceovers(data):return [ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(data)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover']
assert voiceovers(a)==voiceovers(b)
transition={'before_sha256':sha(a),'after_sha256':sha(b),'before_is_first_five_owner_freeze':True,'after_is_current_packaged_source':True,'voiceover_call_ASTs_unchanged':True,'scope':'Root moved Derivative red axis label inside plot after the first-five freeze; source transition and historical record only. No images copied or rendered/visually approved by this packager.','historical_record':'before-result.json.gz','new_process_log':'rerender-en.log.gz'}
raw('derivative-layout-transition/receipt.json',json.dumps(transition,indent=2).encode()+b'\n')
zipped('derivative-layout-transition/root-label-position.patch.gz',''.join(difflib.unified_diff(a.decode().splitlines(keepends=True),b.decode().splitlines(keepends=True),fromfile='owner-freeze-89583728',tofile='root-current-'+sha(b)[:12])).encode())
# Library's bounded root correction: exact old module, retained warning record and 2-key append receipt.
for source,dest in [
 ('ai4-library-caption-regression/source-before.py','library-layout-caption-transition/source-before.py'),
 ('ai4-library-caption-regression/table-update.json','library-layout-caption-transition/table-update.json'),
 ('ai4-library-caption-regression/before-result.json','library-layout-caption-transition/before-result.json'),
 ('ai4-mid-head-endpoint-review/library-gap-caption-overlay.json','library-layout-caption-transition/owner-caption-overlay.json')]:include(source,dest)
lib_before=(R/'ai4-library-caption-regression/source-before.py').read_bytes();lib_after=captured['videos/ai/ai4/s08_library.py']
assert sha(lib_before)=='c5c6318143c677e08743d974a9789a23ed62bb7ac9c80550029c322064731790'
assert voiceovers(lib_before)==voiceovers(lib_after)
lib_update=json.loads((R/'ai4-library-caption-regression/table-update.json').read_text())
assert lib_update['before']==integration['global_after_root_scope_preservation']
assert len(lib_update['strings'])==2
for key,value in lib_update['strings'].items():assert key not in old_table and final_table[key]==value
zipped('library-layout-caption-transition/source-after.py.gz',lib_after,'Final package current Library snapshot')
zipped('library-layout-caption-transition/root-result-inset.patch.gz',''.join(difflib.unified_diff(lib_before.decode().splitlines(keepends=True),lib_after.decode().splitlines(keepends=True),fromfile='owner-freeze-'+sha(lib_before)[:12],tofile='root-current-'+sha(lib_after)[:12])).encode())
lib_transition={'before_sha256':sha(lib_before),'after_sha256':sha(lib_after),'voiceover_call_ASTs_unchanged':True,'caption_append_receipt':'table-update.json.gz','scope':'Root moved only Library result-group clamp6.9 to6.65 and appended2 measured-default MathTex caption translations. Original missing-caption warning record is retained; this source package grants no refreshed render approval. Later final table changes are recorded separately.'}
raw('library-layout-caption-transition/receipt.json',json.dumps(lib_transition,indent=2).encode()+b'\n')
# All later endpoint-derived source/table deltas stay explicit and retain their original receipts.
for source,dest in [
 ('ai4-source-review-final-freeze.json','integration/parent-final-freeze.json'),
 ('ai4-layers-unit-regression/table-update.json','post-checkpoint-deltas/layers-unit/table-update.json'),
 ('ai4-layers-unit-regression/before-result.json','post-checkpoint-deltas/layers-unit/before-result.json'),
 ('ai4-floats-ulp-card-repair/s10_floats.before.py','post-checkpoint-deltas/floats/s10_floats.before.py'),
 ('ai4-floats-ulp-card-repair/s10_floats.after.py','post-checkpoint-deltas/floats/s10_floats.after.py'),
 ('ai4-floats-ulp-card-repair/freeze.json','post-checkpoint-deltas/floats/owner-freeze.json'),
 ('ai4-floats-ulp-card-repair/before-result.json','post-checkpoint-deltas/floats/before-result.json'),
 ('ai4-floats-ulp-card-repair/before-snapshot.json','post-checkpoint-deltas/floats/before-snapshot.json'),
 ('ai4-floats-ulp-card-repair/caption-corrections-overlay.json','post-checkpoint-deltas/floats/caption-corrections-overlay.json'),
 ('ai4-floats-ulp-card-repair/geometry-and-caption-compile.json','post-checkpoint-deltas/floats/geometry-and-caption-compile.json'),
 ('ai4-floats-ulp-card-repair/geometry-and-caption-compile.log','post-checkpoint-deltas/floats/geometry-and-caption-compile.log'),
 ('ai4-floats-ulp-card-repair/check_geometry_and_captions.py','post-checkpoint-deltas/floats/check_geometry_and_captions.py'),
 ('ai4-floats-ulp-card-repair/root-integration/table-update.json','post-checkpoint-deltas/floats/root-table-update.json'),
 ('ai4-nested-caption-regression/table-update.json','post-checkpoint-deltas/nested-readouts/table-update.json'),
 ('ai4-theory-endpoint-review/hvp-readout-caption-overlay.json','post-checkpoint-deltas/nested-readouts/hvp-caption-overlay.json'),
 ('ai4-theory-endpoint-review/hvp-readout-caption-compile.json','post-checkpoint-deltas/nested-readouts/hvp-caption-compile.json'),
 ('ai4-theory-endpoint-review/hvp-readout-caption-compile.log','post-checkpoint-deltas/nested-readouts/hvp-caption-compile.log'),
 ('ai4-tail-endpoint-review/quadratic-caption-add.json','post-checkpoint-deltas/nested-readouts/quadratic-caption-overlay.json'),
 ('ai4-tail-endpoint-review/quadratic-caption-compile.json','post-checkpoint-deltas/nested-readouts/quadratic-caption-compile.json'),
 ('ai4-tail-endpoint-review/compile_quadratic_captions.py','post-checkpoint-deltas/nested-readouts/compile_quadratic_captions.py')]:include(source,dest)
# Verify the complete approved table chain, preserving exact intermediate table bytes where available.
chain=[('Library',lib_update['before'],lib_update['after']),('Layers',None,None),('Floats',None,None),('Nested',None,None)]
layers_update=json.loads((R/'ai4-layers-unit-regression/table-update.json').read_text())
floats_update=json.loads((R/'ai4-floats-ulp-card-repair/root-integration/table-update.json').read_text())
nested_update=json.loads((R/'ai4-nested-caption-regression/table-update.json').read_text())
assert lib_update['after']==layers_update['global_before']
assert layers_update['global_after']==floats_update['global_before']
assert floats_update['global_after']==nested_update['before']
assert nested_update['after']==freeze['global_sha256']
expected=dict(old_table);expected.update(lib_update['strings']);assert expected[layers_update['key']]==layers_update['before'];expected[layers_update['key']]=layers_update['after']
for change in floats_update['changes']:
 assert expected.get(change['key'])==change['before'];expected[change['key']]=change['after']
for key,value in nested_update['strings'].items():assert key not in expected;expected[key]=value
assert expected==final_table,'Unexpected final caption difference outside approved chain'
assert not final_delta['removed']
for folder,file,expected_sha in [('ai4-layers-unit-regression','ai_text_zh-before.json',layers_update['global_before']),('ai4-floats-ulp-card-repair/root-integration','global-before.json',floats_update['global_before']),('ai4-nested-caption-regression','ai_text_zh-before.json',nested_update['before'])]:
 content=(R/folder/file).read_bytes();assert sha(content)==expected_sha;zipped('post-checkpoint-deltas/intermediate-tables/'+expected_sha+'.json.gz',content,R/folder/file)
fb=(R/'ai4-floats-ulp-card-repair/s10_floats.before.py').read_bytes();fa=(R/'ai4-floats-ulp-card-repair/s10_floats.after.py').read_bytes();assert fa==captured['videos/ai/ai4/s10_floats.py'];assert voiceovers(fb)==voiceovers(fa)
zipped('post-checkpoint-deltas/floats/readable-card.patch.gz',''.join(difflib.unified_diff(fb.decode().splitlines(keepends=True),fa.decode().splitlines(keepends=True),fromfile='owner-before-'+sha(fb)[:12],tofile='final-'+sha(fa)[:12])).encode())
raw('post-checkpoint-deltas/chain-validation.json',json.dumps({'approved_table_chain_verified':True,'pre_delta_global_sha256':integration['global_after_root_scope_preservation'],'final_global_sha256':freeze['global_sha256'],'added_keys':len(final_delta['added']),'changed_keys':len(final_delta['changed']),'removed_keys':len(final_delta['removed']),'floats_voiceover_ASTs_unchanged':True,'floats_current_sha256':sha(fa),'historical_gates_not_rerun':True,'scope':'Exact final table mapping is derived solely by applying the four approved delta receipts to the tested historical table. Unchanged phrases/patterns and all untargeted entries verified. Original compile/geometry receipts remain limited to their declared fixtures.'},indent=2).encode()+b'\n')
# Per-scene ownership/current-hash reconciliation.
first=json.loads((R/'ai4-first-five-implementation/bilingual-handoff.json').read_text())['source_sha256'];mid=json.loads((R/'ai4-mid-head-implementation/bilingual-handoff.json').read_text())['files'];num=json.loads((R/'ai4-vcurve-hvp-implementation/bilingual-handoff.json').read_text())['files'];tail=json.loads((R/'ai4-tail-implementation/bilingual-handoff.json').read_text())['source_hashes'];owners={}
for name,h in first.items():owners[name]=('first-five',h)
for row in mid:owners[Path(row['path']).name]=('middle-five',row['after_sha256'])
for row in num:owners[Path(row['file']).name]=('numerics-memory-curvature',row['sha256'])
for row in tail:owners[row['file']]=('tail-five',row['after_sha256'])
assert len(owners)==19
zt=ast.parse(captured['videos/ai/ai4/zh_lines.py']);chapters=next(ast.literal_eval(n.value) for n in zt.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CHAPTERS' for t in n.targets))
coverage=[]
for i,(module,cls,title) in enumerate(scenes,1):
 name=module+'.py';group,owner_sha=owners[name];current=sha(captured['videos/ai/ai4/'+name]);same=current==owner_sha
 assert same or name in freeze['owner_freeze_exceptions'],(name,owner_sha,current)
 coverage.append({'manifest_position':i,'scene':cls,'title_en':title,'title_zh':chapters[cls],'module':'videos/ai/ai4/'+name,'source_owner_batch':group,'owner_freeze_sha256':owner_sha,'current_source_sha256':current,'owner_freeze_matches_current':same,'qualification':freeze['owner_freeze_exceptions'][name] if not same else 'Owner source bytes match current snapshot; its original coverage limits still apply.'})
# Source bytes stay stable through packaging; record snapshots, not historical imports.
for name,content in captured.items():assert (B/name).read_bytes()==content,('source changed during packaging',name)
reg=json.loads((R/'ai12-shared-caption-regression-part4.json').read_text())
summary={'packaged_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Reviewable source/translation/test checkpoint for all19 Part4 scenes in EN/ZH; not rendered or listening approval.','baseline_commit':base,'local_HEAD_at_packaging':head,'snapshots':snapshots,'scene_coverage':coverage,'derivative_transition':transition,'library_transition':lib_transition,'final_freeze':freeze,'integration':{'local_zh_sha256':sha(captured['videos/ai/ai4/zh_lines.py']),'global_zh_sha256':sha(captured['videos/ai/ai_text_zh.json']),'README_sha256':sha(captured['videos/ai/ai4/README.md']),'full_suite':{'tests':352,'seconds':54.535,'log_success_trailer_verified':True,'historical_checkpoint_global_sha256':integration['global_after_root_scope_preservation'],'final_table_changed_after_gate':sha(captured['videos/ai/ai_text_zh.json'])!=integration['global_after_root_scope_preservation'],'execution':'Parent-run suite; this packager verified and preserved the complete log, did not rerun it.'},'merge_receipt':'integration/merge-receipt.json.gz'},'shared_caption_regression':{'original_report':'shared-caption-regression/report.json.gz','tested_global_sha256':integration['global_after_root_scope_preservation'],'historical_before_final_render_corrections':True,'scope':'The actual translator at the historical integrated checkpoint on4,550 collected rows/2,265 unique captured English keys,17Part1+16Part2collections plus Logic alpha-renaming supplement; zero changed outputs per preserved root receipt. Later table changes are separately itemized and are not represented as a rerun.','limits':'Table-effect comparison only. No scene/data/narration equality, geometry, fresh source fingerprints, continuous playback or audio approval.'},'preserved_source_owner_limit_disclosures':['All source owner reports and older freezes remain unchanged as historical receipts.','Some caption anchors are explicitly synthetic numeric templates; later actual-data resolvers are separately preserved.','Producer compute/raw-result evidence and README numerical validation are in sibling packages, not copied as raw caches here.','Derivative/Library owner geometry predates the corresponding root label/inset corrections; exact transitions are preserved without inventing refreshed visual approval.'],'rendered_evidence_scope':'No unique images or movies copied. Source/geometry fixtures do not constitute endpoint, motion, continuous-playback, player or audio approval. Separate actual-render reports may exist or arrive later.','provenance_file':'compressed-origins.json'}
raw('summary.json',json.dumps(summary,indent=2,ensure_ascii=False).encode()+b'\n')
raw('compressed-origins.json',json.dumps(records,indent=2).encode()+b'\n')
readme='''# Part 4 source review checkpoint

All **19 manifest scenes** are covered by four source-review batches, with English/Chinese narration and caption handoffs, mathematical/conditional-outcome fixtures and explicit limits. This package preserves the original evidence and current source bytes; it is **not a rendered, continuous-playback or audio sign-off**.

| Batch | Scenes | Preserved evidence |
|---|---|---|
| First five | Hook through Layers | Source repairs,17math tests, isolated EN/ZH geometry and translation fixtures; original captions include explicitly synthetic numeric anchors |
| Middle five | Modes through Floats | Count/timing units, graph and rank semantics, stable normalized-log displays, precision conventions;13scene tests and separately authorized zero-exponent autodiff tests; actual caption resolver and translator receipts |
| Numerics, memory and curvature | GradCheck, Memory, Newton, HVP | Median-curve marker, disclosed floors/gaps, logical activation memory/work, conservative steps, status/curvature semantics; focused tests, isolated EN/ZH geometry and adverse translation/caption cases |
| Tail five | Quadratic through Outro | Correct SVM dual/slackness, beta conventions, caps/solver/grid/DEQ status, unclamped ranges and recap parity;12math tests,55private translator cases and actual-data caption resolution |

At the pre-render-correction checkpoint (global table4e9d628a…), the parent-run repository suite passed **352 tests in54.535s**. That receipt is historical and does not establish a full rerun after the later bounded layout/table changes. `integration/full352-tests.log.gz` preserves the complete log; the packager checked its success trailer without rerunning it. Original intermediate/focused logs remain in their batch directories and are not silently rewritten as current passes.

`summary.json` indexes all19 scenes, English/Chinese titles, owner freezes and current SHA256 values. `snapshots/baseline-f00be66/` preserves the exact requested baseline commit bytes; `snapshots/current/` preserves all19 current scene modules, local Chinese/global table, manifest, README, relevant producer/common/autodiff support and six current Part4 test modules. Snapshots and patches are compressed, with raw-byte and payload hashes recorded. No raw numerical caches or model files are included.

Derivative is one explicit owner-freeze exception: its owner froze89583728…, then the parent moved the red axis label inside the plot. The current module is c0701489…. Both exact sources, their compressed diff, unchanged-voiceover AST proof and historical process record are in `derivative-layout-transition/`. Older owner geometry remains historical; it is not used to manufacture visual approval for the later layout. Other parent-approved post-render corrections are explicitly named per scene in `summary.json` and preserved in their transition directories.

The current local Chinese and global table hashes are recorded in `summary.json` and `integration/final-freeze.json`. The earlier integrated global table4e9d628a… is preserved separately. `integration/post-test-table-delta.json` itemizes all later additions/corrections; no old352-test or captured-caption receipt is silently relabeled as a current rerun. The integration receipt preserves how the parent retained existing valid sign and Backprop translations while accepting scoped Memory spacing changes. Batch proposals are proposals; current snapshots and the root merge receipt identify what actually landed. `integration/todo.log.gz` records118/118direct source lines covered and retains the scanner warning. Its `f'{name}{k}'` concatenation is a cache-key expression at `s04_jacobian.py:61`, not a narrated paragraph. Helper-return coverage is supported separately by actual translator/semantic fixtures, rather than inferred from the simple scanner's unused-key list.

`shared-caption-regression/` preserves the historical pre-render-correction root comparison of4550collected rows and2265unique captured English strings across17Part1+16Part2collections, including the Logic alpha-renaming supplement: **zero changed translation outputs**. Full mapping/context evidence, the exact script and baseline/current table byte references are retained. Its baseline is927fba66…, distinct from the source-snapshot baseline above. Both passes used the same translator at that checkpoint and the tested global table4e9d628a…. This is not a rerun against the later final table. This result establishes only shared-table effects on those captured keys; absent dynamic values/branches, verbatim text excluded by collection, source/data/narration equivalence, geometry, fresh fingerprints, continuous playback and audio remain outside its scope.

The final frozen global table is9154c3fb…; local Chinese narration is e853cee9…. The chain from4e9d628a… contains exactly the separately preserved Library2-key append, Layers scalar-operation-unit correction,15 foundation TeX/spacing corrections plus the readable Floats key, and12 HVP plus3 Quadratic additions. `post-checkpoint-deltas/chain-validation.json` verifies every targeted value and all untargeted entries; it does not rerun the historical gates. Floats’ current source is929bceef… and has its own exact before/after patch,92 actual isolated TeX compilations and six-line card geometry receipt. No corresponding images are copied or visually approved by this source package.

Current README SHA256 begins1095c935…. Its independent [README validation](../ai4-readme-validation/README.md) and the [producer/data validation](../ai4-data-source-validation/README.md) provide adjacent evidence. They are referenced rather than duplicating raw caches here.

All source-owner limits remain in the compressed reports. The mathematical and synthetic geometry fixtures do not establish current rendered layout, motion, speaking pace, pronunciation, synchronization or player behavior. Actual English/Chinese render review continues separately; no unique images or movies are copied into this source checkpoint.
'''
for a,b in [('17math','17 math'),('13scene','13 scene'),('12math','12 math'),('55private','55 private'),('in54.535','in 54.535'),('all19','all 19'),('froze895','froze 895'),('is4e9','is 4e9'),('records118/118direct','records 118/118 direct'),('of4550collected','of 4,550 collected'),('and2265unique','and 2,265 unique'),('across17Part1+16Part2collections','across 17 Part 1 and 16 Part 2 collections')]:readme=readme.replace(a,b)
raw('README.md',readme.encode())
files={str(p.relative_to(D)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(D.rglob('*')) if p.is_file()}
raw('manifest.json',json.dumps(files,indent=2).encode()+b'\n')
for name,v in files.items():assert sha((D/name).read_bytes())==v['sha256']
assert not list(D.rglob('*.png')) and not list(D.rglob('*.mp4'))
print(json.dumps({'package':str(D),'files':len(files)+1,'payload_bytes':sum(x['bytes'] for x in files.values()),'manifest_sha256':sha((D/'manifest.json').read_bytes()),'baseline_commit':base,'current_global_sha256':sha(captured['videos/ai/ai_text_zh.json']),'current_derivative_sha256':sha(captured['videos/ai/ai4/s02_derivative.py']),'full_suite_tests':352,'unique_images_copied':0},indent=2))
