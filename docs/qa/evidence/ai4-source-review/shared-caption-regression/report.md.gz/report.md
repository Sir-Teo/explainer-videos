# Shared Chinese caption regression: Parts 1 and 2

Compared the shared caption table at `927fba668656a682b3e29a288de64130ddc680dd` with the current table using the actual current `explainer.zh_text.translate` in a single nice-10 process. All 17 Part 1 and 16 Part 2 endpoint text collections were included.

Collected 4550 rows; compared 2265 unique English strings including the Logic alpha-renaming supplement. Changed unique outputs: 0.

Baseline output-map SHA256: `c5c51d809b47e418f38d74405a0297f2c0a191d24fe28c2fd552a617145ab6a0`.
Current output-map SHA256: `c5c51d809b47e418f38d74405a0297f2c0a191d24fe28c2fd552a617145ab6a0`.

The JSON report retains raw translator outputs, source/record/table hashes and every collected context. Full used-caption evidence is in `ai12-shared-caption-regression-part4/used-caption-results.json`.

Raw translate() output is compared for every collected string, including needs=false math/raw-symbol candidates. Each difference retains its original record context.
The needs flag only says whether English prose was detected; it does not establish that a value is raw model data. Verbatim data_text/Code Text is skipped by this collector and is outside this used-caption sample.
No caption difference is dismissed as harmless raw data without source-context evidence.
This compares shared-table effects on these captured English strings using the current translation implementation for both passes.
This does not establish scene/data/narration equivalence, fresh production fingerprints, rendered geometry, continuous playback or audio.
Dynamic values or branches absent from the 33 endpoint text collections and the one static supplement are not exercised.
No production scene/data/model imports or loads; no table edit, compute or render. Source hashes are bytes at comparison time, not proof of code imported by historical render workers.
