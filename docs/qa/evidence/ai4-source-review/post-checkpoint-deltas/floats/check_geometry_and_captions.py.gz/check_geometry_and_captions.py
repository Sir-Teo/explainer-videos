"""Actual Manim TeX/geometry checks; no scene/common/producer import or rendering."""
from pathlib import Path
import ast,hashlib,json,math,re,time
import numpy as np
from explainer.ai import *
from explainer import lang,zh_text
import explainer.analysis as analysis

repo=Path('/workspace/explainer-videos');out=Path(__file__).parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=repo/'videos/ai/ai4/s10_floats.py';tree=ast.parse(source.read_text())
ulp=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='ulp')
dc_node=next(n for n in ulp.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='dc')
body=ast.literal_eval(dc_node.value.func.value.args[1])
chinese=(r"到下一个浮点数的间隔。 \\ "
         r"舍入到最近值；限定正规有限范围， \\ "
         r"且不发生上溢： \\ "
         r"相对误差$\le 2^{-(m+1)}$（$m$位尾数）。 \\ "
         r"次正规数：固定的绝对间隔； \\ "
         r"绝对舍入误差$\le \tfrac12$该间隔。")
original=json.loads((Path('/workspace/runtime/ai4-mid-head-implementation')/'normalized-bilingual-overlay.json').read_text())['strings']
table=json.loads((repo/'videos/ai/ai_text_zh.json').read_text())
mapping={};audit=[]
for key,proposal in original.items():
    current=table['strings'].get(key)
    # Root deliberately retained three older correct Backprop mappings.
    preserve=current is not None and current!=proposal
    target=current if preserve else re.sub(r'\\{2,}',lambda m:'\\'*(len(m.group())//2),proposal)
    mapping[key]=target
    audit.append(dict(english=key,original_proposal=proposal,current_table=current,corrected_target=target,
                      retained_existing_root_target=preserve,changed_from_current=target!=current))
mapping[body]=chinese
overlay=dict(strings=mapping,scope='Only 45 owned mid-head caption keys plus new six-line Floats definition. '
             'Raw-string double escaping corrected; numerical sci() output remains untouched. '
             'Three root-retained correct Backprop targets are preserved exactly. FP8 technical identifier is not changed.')
(out/'caption-corrections-overlay.json').write_text(json.dumps(overlay,ensure_ascii=False,indent=2)+'\n')
zh_text.install(analysis.WIDE_TEX);analysis._zh=zh_text.translate
table['strings'].update(mapping);zh_text._TABLE=table
compiled=[]
for language in ['en','zh']:
    lang.LANG=language
    for i,key in enumerate(mapping):
        started=time.monotonic()
        obj=label(key,font_size=20)
        compiled.append(dict(lang=language,key=key,tex=[getattr(m,'tex_string','') for m in obj.get_family()
                                                       if getattr(m,'tex_string','')],seconds=time.monotonic()-started))
        print(json.dumps(dict(stage='caption-compiled',lang=language,index=i+1,total=len(mapping))),flush=True)

def bounds(obj):return [float(obj.get_left()[0]),float(obj.get_right()[0]),float(obj.get_bottom()[1]),float(obj.get_top()[1])]
geometries=[]
for language in ['en','zh']:
    lang.LANG=language;env=dict(globals())
    exec(compile(ast.Module([dc_node],type_ignores=[]),'actual-card-call','exec'),env)
    card=env['dc'];b=bounds(card);bb=bounds(card.body)
    right_margin=config.frame_width/2-b[1]
    assert right_margin>=.3,(language,b,right_margin)
    assert b[2]>-3.6 and b[3]<.6,(language,b)
    assert card.body.font_size>=18,(language,card.body.font_size)
    assert len((body if language=='en' else chinese).split(r'\\'))==6
    geometries.append(dict(lang=language,card_bounds=b,body_bounds=bb,body_font_size=float(card.body.font_size),
        right_margin=right_margin,body_height_px_at480=(bb[3]-bb[2])*60,
        tex=[getattr(m,'tex_string','') for m in card.body.get_family() if getattr(m,'tex_string','')]))
result=dict(source_sha256=sha(source),overlay_sha256=sha(out/'caption-corrections-overlay.json'),
            audited_original_captions=len(original),changed_existing_targets=sum(x['changed_from_current'] for x in audit),
            preserved_existing_root_targets=sum(x['retained_existing_root_target'] for x in audit),
            actual_tex_compilations=len(compiled),audit=audit,compiled=compiled,card_geometry=geometries,
            scope='Actual generic Manim label and actual scene card AST geometry only; no full scene import/render, '
                  'no common/producer/default loader, no data edits or global-table writes. Rendered appearance still pending.')
(out/'geometry-and-caption-compile.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['audit','compiled']},ensure_ascii=False),flush=True)
