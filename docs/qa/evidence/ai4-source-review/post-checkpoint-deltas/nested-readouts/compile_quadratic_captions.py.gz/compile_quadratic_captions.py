from pathlib import Path
import json,hashlib,os
os.environ['EXPLAINER_LANG']='zh';os.environ['EXPLAINER_VIDEO']='ai4'
from manim import config
from explainer.ai import label
from explainer import zh_text,lang
O=Path('/workspace/runtime/ai4-tail-endpoint-review');config.media_dir=str(O/'caption-tex');config.verbosity='ERROR';lang.LANG='zh'
strings={'norm-error factor per step':'每步范数误差因子','updates: \\ relative norm below $10^{-6}$':'更新次数：\\ 相对范数低于 $10^{-6}$','updates until $|y|>0.5$':'达到 $|y|>0.5$ 的更新次数'}
zh_text._TABLE={'strings':strings,'phrases':{},'patterns':[]};zh_text._BY_NUMBERS=None
rows=[]
for en,zh in strings.items():
 assert zh_text.translate(en)==zh
 m=label(en,font_size=18)
 rows.append({'en':en,'zh':zh,'width':float(m.width),'height':float(m.height),'tex_string':m.tex_string})
(O/'quadratic-caption-add.json').write_text(json.dumps({'strings':strings},indent=2,ensure_ascii=False)+'\n')
(O/'quadratic-caption-compile.json').write_text(json.dumps({'scope':'Actual isolated Chinese Manim Tex construction only, no scene import/data/model/producer/render, no global table write. English warning keys exactly from preserved Quadratic result.','rows':rows},indent=2,ensure_ascii=False)+'\n')
print(json.dumps(rows,indent=2,ensure_ascii=False))
