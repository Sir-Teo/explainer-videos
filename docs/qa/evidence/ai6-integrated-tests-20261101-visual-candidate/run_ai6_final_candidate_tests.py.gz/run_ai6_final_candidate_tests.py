from pathlib import Path
import hashlib,json,datetime,subprocess,sys,os,time
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/integrated-20261101-ai6-visual-candidate');D.mkdir(exist_ok=False)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def inventory():
 paths=set()
 for name in ['explainer','videos','tools','tests']:
  for p in (R/name).rglob('*'):
   if p.is_file() and p.suffix in ['.py','.json'] and '__pycache__' not in p.parts:paths.add(p)
 for name in ['pyproject.toml','uv.lock','requirements.txt','manim.cfg']:
  p=R/name
  if p.is_file():paths.add(p)
 H=R/'docs/qa/evidence/production-handoff-parts1-3'
 paths.update(p for p in H.glob('*') if p.is_file() and p.suffix in ['.py','.json']);paths.update((H/'overlays').glob('*.json'))
 return [dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(paths)]
started=now();t=time.monotonic();before=inventory();(D/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();env=os.environ.copy();env.pop('EXPLAINER_CACHED_ONLY',None);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
with (D/'full-unittest.log').open('w') as f:result=subprocess.run(['nice','-n','15',sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=600)
after=inventory();(D/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');receipt=dict(started_utc=started,ended_utc=now(),elapsed_s=time.monotonic()-t,returncode=result.returncode,sources_unchanged=before==after,source_files=len(before),git_head=head,source_scope='AllPython/JSON inexplainer/videos/tools/tests plusprojectconfiguration andcurrentstrictproductionhandoffhelper/manifests/overlays; uncommittedcandidatebytes explicitlyinventoried. Runtimewitnesses/generateddocs arenottestedsource.',numeric_threads='OMP/OpenBLAS/MKL=1; cached-only deliberatelynotset because intentional temporary-generation cachefixtures requiretheirnormal path.',test_scope='Repositoryunittest suite only. Actualrender/perception/listening/sourceprovenance gates remain separate. Countsnotaddedtoearlier575/518runs.')
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert before==after,'Inventoried source drift';assert result.returncode==0
