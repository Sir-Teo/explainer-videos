# Part 3 documentation and mathematical consistency review

The complete Part 3 README was read: introduction, 19-scene outline, run instructions, references, eight English and eight Chinese solutions, and glossary. No separate local solutions or notes files exist in `videos/ai/ai3`. This was a read-only cache/source review followed by four authorized README repairs; no scene, producer, data, model or global caption was changed.

| Finding | Verified evidence | Documentation repair |
|---|---|---|
| Random reference claimed the same shape as all learned matrices | `norms.random.shape=[768,3072]`, stable rank 345.3184; all 48 learned matrices cover four shapes | Name the single 768×3072 MLP-shaped reference |
| Every random pair claimed within “a few degrees” of perpendicular | 10,000 directions in 768 dimensions; worst angle 78.717495°, worst deviation 11.282505°, typical angular spread 2.070872° | State the conservative measured 78°–102° range and typical ≈2° spread |
| Standalone projection solution omitted its domain | Both current scene problem and derivation require full column rank; `A=[[1,1],[2,2]]` gives singular `AᵀA` | Restore full-column-rank assumption in English and Chinese |
| Standalone SGNS solution omitted its domain | Current problem has `a,b>0` and scene treats observed pairs/free dot products; `a=0,b=1` has derivative negative for every finite x | Restore positive coefficients and free scalar x in English and Chinese |

The last two are qualification omissions for a reader of the standalone guide, not algebra errors when the on-screen problem assumptions are inherited. The random-reference entry is a residual documentation location for a scene issue already repaired, not a new numerical defect.

Previously accepted guide repairs remain correct and verbatim: smoothed-negative generalized shifted-PMI target, finite full-rank fit without an exact-convergence claim, 95% JL confidence and unavailable-bound handling, standard macro recall with raw conditional-score inference, and vector-penalty versus bias-penalty distinction. The measured full-rank SGNS median error is 0.0013163; the guide does not claim it is zero. Retrieval cold recall is below popularity in the cache, and the guide does not claim universal superiority.

Other checked values match: GPT-2 vocabulary 50,257 and width 768; 102 displayed words; Paris first for the saved prompt; 10,000-word vocabulary; 710 analogy questions; 1,000 JL vectors and 499,500 pairs; and 4,000 users/1,200 synthetic films/six genres. Both measured power rates differ from predicted ratios by less than 0.01. The shown shuffled matrix has zero eigenvalues strictly beyond its limiting edge. The eight solution derivations have no additional confirmed algebra defect. The explicit tail-norm formula is correct; “tail” in the outline is shorthand, not a new error.

The existing 19 silent chapter records sum to 54.46 minutes in English and 57.49 in Chinese at the review snapshot. This is not a final narrated-length benchmark; the guide’s “about 50 minutes” remains an approximate historical estimate. No isolated fresh hardware benchmark establishes or refutes the stated 1–2 CPU-hour numerical estimate. Historical references were checked for internal consistency only, without a new external-source audit.

`report.json` preserves exact pre-edit references, source/cache hashes, selected cached values, tiny counterexamples and qualified duration receipts. `repair-validation.json` verifies the four edits, unchanged scene/cache bytes, both eight-problem lists, verbatim preservation of the accepted paragraphs and passing scoped diff check. No new prose-specific tests were added. `README.patch` and before/after files make the repair reviewable.
