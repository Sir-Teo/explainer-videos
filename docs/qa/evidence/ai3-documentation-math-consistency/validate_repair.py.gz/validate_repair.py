from pathlib import Path
import json,hashlib,math,re,subprocess,shutil
root=Path('/workspace/explainer-videos');out=Path(__file__).parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();r=json.load(open(out/'report.json'));before=(out/'README.snapshot.md').read_text();path=root/'videos/ai/ai3/README.md';after=path.read_text();assert hashlib.sha256(before.encode()).hexdigest()==r['readme_sha256']
for rel,h in r['file_hashes'].items():
 if rel!='videos/ai/ai3/README.md':assert sha(root/rel)==h,rel
norms=json.load(open(root/'.cache/ai3/norms.json'));h=json.load(open(root/'.cache/ai3/highdim.json'));assert norms['random']['shape']==[768,3072];assert round(norms['random']['stable'])==345;assert len(norms['rows'])==48
assert 78<h['worst_angle']<79 and 180-h['worst_angle']<102;assert round(h['angle_sd768'])==2
for s in ['single random 768 × 3072 MLP-shaped reference','all pairs among 10,000 random directions lie between 78° and\n  102°','For A with full column rank','若 A 列满秩','For a, b > 0 and a free scalar x','对 a, b > 0 及自由标量 x']:assert s in after,s
# Retain previously accepted complete outline paragraphs verbatim.
for chapter,nextchapter in [('13. word2vec is counting in disguise.','14. Life in 768 dimensions.'),('15. Johnson–Lindenstrauss, proved.','16. GPT-2\'s lopsided space.'),('17. Low rank in the wild.','Outro.')]:
 def para(t):return t.split('* **'+chapter+'**',1)[1].split('* **'+nextchapter+'**',1)[0]
 assert para(before)==para(after),chapter
for title,end in [('## Problems and solutions','## 题目与解答'),('## 题目与解答','## Glossary')]:
 s=after.split(title,1)[1].split(end,1)[0];assert re.findall(r'^([1-8])\. ',s,re.M)==[str(i) for i in range(1,9)]
proc=subprocess.run(['git','diff','--check','--','videos/ai/ai3/README.md'],cwd=root,capture_output=True,text=True);assert proc.returncode==0,proc.stderr+proc.stdout
patch=subprocess.run(['git','diff','--','videos/ai/ai3/README.md'],cwd=root,capture_output=True,text=True,check=True).stdout;(out/'README.patch').write_text(patch);shutil.copy2(path,out/'README.after.md')
result={'status':'passed','before_readme_sha256':r['readme_sha256'],'after_readme_sha256':sha(path),'patch_sha256':sha(out/'README.patch'),'measured_values':{'reference_shape':norms['random']['shape'],'reference_stable_rank':norms['random']['stable'],'learned_shapes':sorted({tuple(x['shape']) for x in norms['rows']}),'worst_angle':h['worst_angle'],'symmetric_conservative_range':[78,102],'angular_spread_degrees':h['angle_sd768']},'checks':['Exact non-README scene/cache hashes unchanged from read-only report.','Four bounded documentation repairs present, with both language solution domains restored.','Accepted SGNS/JL/Netflix outline fixes preserved verbatim.','Eight problems retained in each language; existing tiny singular-Gram and zero-count SGNS fixtures retained.','Scoped git diff --check passed.'],'limits':'Prose-only source/documentation validation; no producers, model loading, renders or audio/player assertions.'};(out/'repair-validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
