Bell local density and convolution-caption repair

The prior 77-image endpoint review remains immutable at ../ai5-bell-gauss-endpoint-review. It found an 11-native-pixel blue spline excursion below density zero in both Bell languages, plus the off-by-one convolution caption. Gauss had no additional concrete defect in that review.

New local helper API:
clipped_curve(ax, xs, ys, *, x_bounds, y_bounds, color, stroke_width=3, **kw) -> VMobject

The helper uses Liang–Barsky intersections in data coordinates, straight line segments, visible original vertices unchanged, and separate paths across outside/nonfinite gaps. It never smooths, projects outside vertices onto a flat boundary cap, or joins disconnected data. Empty/singleton input is safe; invalid array/bounds contracts are explicit errors. Arithmetic overflow at extreme finite coordinates is an explicit error. It imports no data/model/compute code and does not alter common.curve.

Bell uses this helper only for its sampled repeated-convolution density. Its new reason says n independent pieces require n−1 convolutions, matching the already-correct narration. Eight voiceover expressions and all 32 self.play calls/arguments remain identical. Restoring the authorized import, reason string, and one shapes assignment restores the entire old AST exactly. See invariants.json and source.patch.

Ten actual-VMobject/helper tests passed (helper-tests.log), including the actual Bell assignment extracted from its source with synthetic discontinuous/clipped data. Actual EN and ZH three-row ladder objects compiled; all row/reason pairs fit the frame and remain disjoint with the existing 0.4 gap. Chinese caption math spans are unchanged and its actual xelatex SVG is preserved. These are object/fixture checks, not fresh rendered scene acceptance.

Private proposed-zh-overlay.json has one exact caption entry and no narration updates. Only the parent may merge the shared table. Caller owners were notified of frozen helper SHA 1d76a9c4145eedf0f3a65549223ba4b8edae1397f6d8696c146b45037542d845.

Remaining gate: fresh bilingual Bell endpoint and full-silent motion renders, then actual image/motion inspection. No audio, listening, continuous playback, or production-resolution approval is conferred. No scientific producer, cache, main Chinese table, shared common helper, render, model, or commit operation was performed by this owner for this repair.
