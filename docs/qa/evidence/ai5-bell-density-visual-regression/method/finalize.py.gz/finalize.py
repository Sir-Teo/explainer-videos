from pathlib import Path
import datetime,gzip,hashlib,json,shutil
O=Path(__file__).parent;R=Path('/workspace/explainer-videos');B=Path('/workspace/runtime/ai5-bell-gauss-endpoint-review');D=R/'docs/qa/evidence/ai5-bell-density-visual-regression'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((O/'plan.json').read_text());views=[]
for c in p['cases']:
 l=c['lang'];q=O/l;old=B/(l+'-Bell');prior=json.loads((old/'review.json').read_text())
 for pg in c['changed_pages']:
  assert sha(Path(pg['path']))==pg['sha256'];pg.update(viewed=True,view_detail='original; unscaled854x480 tiles in1708x1016 page',observations='Changed convolution-count caption and both n=1/n=30 density plots fit and remain legible; support has no negative lobe or artificial flattened peak.')
 for f in c['frames']:
  assert sha(q/f['file'])==f['sha256']
  if f['actual_prior_matches']:
   for match in f['actual_prior_matches']:assert match['file'] in prior['viewed_images'] and sha(old/match['file'])==f['sha256']
  else:
   f['review_mode']='directly viewed changed original854x480 PNG; also viewed native-pixel page';f['actual_individual_view']=True;views.append({'case':l+'-Bell','file':f['file'],'time':f['time'],'sha256':f['sha256'],'actual_view':True,'detail':'original854x480'})
 assert c['same_narration_as_before'] and c['same_duration_as_before']
 assert all(i['same_bytes_as_before'] and i['stat_matches_now'] and sha(R/i['path'])==i['sha256'] for i in c['numerical_inputs'])
 assert sha(R/'renders/qa/series/ai5'/l/'Bell'/'result.json')==c['record_sha256']
 c['direct_sources_current_at_final_observation']=[{'path':s['path'],'sha256':s['sha256'],'same_now':sha(Path(s['path']))==s['sha256']} for s in c['sources_observed_now']]
 assert all(s['same_now'] for s in c['direct_sources_current_at_final_observation'])
for l,fn in [('en','013_00145.0s.png'),('zh','016_00151.9s.png')]:views.append({'case':l+'-Bell','phase':'before','file':fn,'sha256':sha(O/l/'before-critical'/fn),'actual_view':True,'detail':'original854x480; negative support-boundary lobe visible'})
base=json.loads((O/'historical-baseline-file-hashes.json').read_text());assert all(sha(B/n)==h for n,h in base.items())
summary={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Bilingual Bell held-endpoint regression only; Gauss not re-reviewed.','current_states':41,'exact_PNG_inheritance_from_actual_prior_views':35,'changed_images_actually_viewed_individually':6,'changed_native_pixel_pages_viewed':2,'additional_before_original_native_views':2,'source_sha256':sha(R/'videos/ai/ai5/s02_bell.py'),'helper_sha256':sha(R/'videos/ai/ai5/plotting.py'),'global_caption_sha256_observed':sha(R/'videos/ai/ai_text_zh.json'),'source_handoff':'../ai5-bell-clipped-density-repair/invariants.json (runtime original; exact copied source-repair-handoff/invariants.json)','baseline_77_case_package_all_files_unchanged':True,'baseline_manifest_sha256':sha(B/'manifest.json'),'raw_statuses':{c['lang']:c['raw_status'] for c in p['cases']},'raw_warnings':{c['lang']:c['raw_warnings'] for c in p['cases']},'findings':[{'id':'BELL-01','status':'resolved in current endpoint states','observed':'The prior blue below-zero spline lobe is absent in both native n=1 after images. Sharp sampled peak and baseline retained; no flattened clipping cap. n=30 after curves remain readable. An independent unchanged color mask finds41 pixels below the baseline in each before crop and0 after; different count from prior46 reflects documented stricter color mask, not changed review tolerance.'},{'id':'BELL-02','status':'resolved in current endpoint states','observed':'English and Chinese reason captions now correctly say n independent terms require n-1 convolutions; captions and adjacent formula fit without overlap.'}],'new_concrete_defects':[],'limits':['Endpoint-only: all temporal intervals/transition states between captures remain unreviewed here.','No continuous perceptual playback, audio/listening, narration synchronization or native 1080 approval.','Current source snapshots do not prove historical imported bytes or assert broad aggregate-source currency.','No production source/global-table/data/renderer/producer mutations; no movies packaged.'],'cases':p['cases'],'direct_views':views}
(O/'review.json').write_text(json.dumps(summary,indent=2)+'\n')
readme='''# Part5 Bell density endpoint regression

All **41 current Bell endpoint states** are accounted for: **35 exact PNG-byte matches** to the preserved actual baseline review, plus **6 changed images directly inspected individually at 854×480** and on 2 unscaled native-pixel pages. Both historical n=1 originals were additionally re-viewed. The old combined 77-state Bell/Gauss package is unchanged; Gauss was not re-reviewed.

Both endpoint findings are resolved in these captures. The n=1 density no longer has the below-zero interpolation lobe; its sharp sampled peak remains, with no flat cap. The n=30 density remains legible. Both language captions now correctly specify **n−1 convolutions** for n independent terms. Full before/after originals for the support/caption findings are included.

Both fresh raw records passed with zero warnings. Narration expressions, word/timing records and total durations exactly match the before records; consumed numerical payload hashes match the before observations and remained unchanged. This reviewer did not run a renderer or producer, or change production source/data/tables.

Source: `s02_bell.py` SHA f559484126011f7aae46fe30b932eaee37f406615d764029121524ae80db7249. Helper: `plotting.py` SHA 1d76a9c4145eedf0f3a65549223ba4b8edae1397f6d8696c146b45037542d845. Actual final source/table observations and raw fingerprints are recorded in `review.json.gz`; observation does not prove historical in-memory imports.

`review.json.gz` maps every current timestamp/frame hash to its direct view or exact prior actual-view proof. Raw current/before results, text, prior actual-view ledgers, repair invariants and image pixel corroboration remain separate evidence. The pixel check uses the same documented stricter blue mask before/after (41→0 selected blue pixels in rows 402–420 below baseline y400), distinct from the original broader 46-pixel mask; native images establish the finding.

**Scope:** endpoint acceptance only. Full silent-motion/transition review, continuous perceptual playback, listening/narration synchronization and native 1080 checks remain pending. No movies or Library/local transport artifacts are included.
'''
(O/'README.md').write_text(readme)
assert not D.exists(),D
D.mkdir(parents=True)
def copy(p,q):q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
def gz(p,q):
 b=p.read_bytes();q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(b,mtime=0));assert gzip.decompress(q.read_bytes())==b
copy(O/'README.md',D/'README.md')
for n in ['review.json','plan.json','historical-baseline-file-hashes.json','support-boundary-pixel-check.json']:gz(O/n,D/(n+'.gz'))
for l in ['en','zh']:
 for n in ['result.json','text.jsonl','render.log']:gz(O/l/n,D/l/(n+'.gz'))
 for n in ['result.json','snapshot.json','review.json','pages.json']:gz(O/l/'before-ledgers'/n,D/l/'before-ledgers'/(n+'.gz'))
 for f in next(c for c in p['cases'] if c['lang']==l)['frames']:
  if not f['actual_prior_matches']:copy(O/l/f['file'],D/l/'after'/f['file'])
 for q in (O/l/'before-critical').iterdir():copy(q,D/l/'before-critical'/q.name)
 for q in (O/l/'changed-pages').iterdir():copy(q,D/l/'changed-pages'/q.name)
for q in (O/'source-repair-handoff').iterdir():gz(q,D/'source-repair-handoff'/(q.name+'.gz'))
for q in ['prepare.py','finalize.py']:gz(O/q,D/'method'/(q+'.gz'))
files=[{'path':str(q.relative_to(D)),'bytes':q.stat().st_size,'sha256':sha(q)} for q in sorted(D.rglob('*')) if q.is_file()]
(D/'manifest.json').write_text(json.dumps({'files':files,'indexed_files':len(files),'payload_bytes':sum(f['bytes'] for f in files),'runtime_original':str(O),'limits':summary['limits']},indent=2)+'\n')
print('review',sha(O/'review.json'));print('manifest',sha(D/'manifest.json'),'files',len(files)+1,'payload_bytes',sum(f['bytes'] for f in files));print('direct source',summary['source_sha256'],'helper',summary['helper_sha256'],'global',summary['global_caption_sha256_observed'])
