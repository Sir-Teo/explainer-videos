from pathlib import Path
import datetime,hashlib,json,shutil
from PIL import Image,ImageDraw
R=Path('/workspace/explainer-videos');O=Path(__file__).parent;B=Path('/workspace/runtime/ai5-bell-gauss-endpoint-review');H=Path('/workspace/runtime/ai5-bell-clipped-density-repair')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(p,q):
 q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(p)==sha(q);return {'path':str(p),'copy':str(q.relative_to(O)),'sha256':sha(p),'bytes':p.stat().st_size}
base={str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()};(O/'historical-baseline-file-hashes.json').write_text(json.dumps(base,indent=2)+'\n')
rows=[]
for l in ['en','zh']:
 old=B/(l+'-Bell');oldrec=json.loads((old/'result.json').read_text());oldsn=json.loads((old/'snapshot.json').read_text());view=json.loads((old/'review.json').read_text());assert view['complete']
 mapping={}
 for f in oldsn['images']:
  assert sha(old/f['file'])==f['sha256'] and f['file'] in view['viewed_images'];mapping.setdefault(f['sha256'],[]).append(f)
 p=R/'renders/qa/series/ai5'/l/'Bell';rr=p/'result.json';recordsha=sha(rr);d=json.loads(rr.read_text());dest=O/l;dest.mkdir(exist_ok=True)
 copied=[cp(p/n,dest/n) for n in ['result.json','text.jsonl','render.log','sheet.png']+[f['file'] for f in d['frames']]];assert sha(rr)==recordsha
 sources=[cp(R/q,O/'source-snapshot'/q) for q in ['videos/ai/ai5/s02_bell.py','videos/ai/ai5/plotting.py','videos/ai/ai5/common.py','videos/ai/ai5/zh_lines.py','videos/ai/ai_text_zh.json']]
 inputs=[]
 for q,signature in d['inputs'].items():
  f=R/q;st=f.stat();oldentry=next(i for i in oldsn['input_hashes_at_review'] if i['path']==q);inputs.append({'path':q,'sha256':sha(f),'recorded_stat':signature,'stat_matches_now':[st.st_size,st.st_mtime_ns]==signature,'same_bytes_as_before':sha(f)==oldentry['sha256_at_review']})
 for n in ['result.json','snapshot.json','review.json','pages.json']:cp(old/n,dest/'before-ledgers'/n)
 frames=[];changed=[]
 for i,f in enumerate(d['frames']):
  h=sha(dest/f['file']);m=mapping.get(h,[]);row={**f,'index':i,'sha256':h,'review_mode':'exact-PNG inheritance from actual before review' if m else 'pending actual changed-image view','actual_prior_matches':m}
  if m:row['prior_actual_view_proof']={'path':str(old/'review.json'),'sha256':sha(old/'review.json')}
  else:changed.append(row)
  frames.append(row)
 pages=[]
 for a in range(0,len(changed),4):
  ff=changed[a:a+4];im=Image.new('RGB',(1708,1016),'#161b24');dr=ImageDraw.Draw(im)
  for k,f in enumerate(ff):
   tile=Image.open(dest/f['file']).convert('RGB');assert tile.size==(854,480);x=k%2*854;y=k//2*508;dr.text((x+5,y+4),f"{l}-Bell {f['index']:03d} t={f['time']:.3f}s",fill='white');im.paste(tile,(x,y+28))
  q=dest/'changed-pages'/f'{a//4:03d}.png';q.parent.mkdir(exist_ok=True);im.save(q);pages.append({'path':str(q),'sha256':sha(q),'indices':[f['index'] for f in ff],'viewed':False})
 rows.append({'lang':l,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_status':d['status'],'raw_warnings':d['warnings'],'record_fingerprint':d['fingerprint'],'record_sha256':recordsha,'before_record_sha256':sha(old/'result.json'),'same_narration_as_before':d['narration']==oldrec['narration'],'same_duration_as_before':d['duration']==oldrec['duration'],'copied':copied,'sources_observed_now':sources,'numerical_inputs':inputs,'frames':frames,'changed_pages':pages})
 for i in ([12,13] if l=='en' else [15,16]):cp(old/oldrec['frames'][i]['file'],dest/'before-critical'/oldrec['frames'][i]['file'])
for n in ['README.md','invariants.json','source.patch','manifest.json','helper-tests.log','geometry-result.json','caption-compile-proof.json']:cp(H/n,O/'source-repair-handoff'/n)
(O/'plan.json').write_text(json.dumps({'cases':rows,'limits':'Endpoint-only current image regression. Source observations do not prove historical imports; all raw runtime warnings retained. No scene/source/data edits or own render/compute.'},indent=2)+'\n')
print([(r['lang'],len(r['frames']),sum(bool(f['actual_prior_matches']) for f in r['frames']),len(r['changed_pages'])) for r in rows])
