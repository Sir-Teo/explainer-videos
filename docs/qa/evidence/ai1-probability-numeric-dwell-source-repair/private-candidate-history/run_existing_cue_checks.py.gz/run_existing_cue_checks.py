import importlib.util,unittest
from pathlib import Path
D=Path(__file__).parent;P=Path('/workspace/explainer-videos/tests/test_ai1_probability_timing.py');spec=importlib.util.spec_from_file_location('existing_probability_v5_timing_tests',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.SOURCE=D/'s02_probability.proposed.py'
names=['test_verified_diagnostic_source_and_all_eleven_masters','test_old_actual_spans_reproduce_all_three_reported_overruns','test_actual_scene_spans_fit_measured_cues_with_adverse_frame_phases','test_generous_cues_keep_nominal_durations_and_unavoidable_gaps_stay_positive'];r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(m.ProbabilityTiming(n) for n in names));assert r.wasSuccessful()
