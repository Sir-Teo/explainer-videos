"""Cached metadata + actual AST scheduling calls; no models, audio access or renderer."""
import ast,copy,gzip,hashlib,inspect,json,math,re,types,platform
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from explainer import lang
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=ast.parse((D/'s02_probability.before.py').read_text());new=ast.parse((D/'s02_probability.proposed.py').read_text())
def method(t,name):return next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name==name)
def blocks(t):return [n for n in ast.walk(method(t,'chain_rule')) if isinstance(n,ast.With)]
# Only one post-Write timestamp and the adaptive hold may differ anywhere in the source.
norm=copy.deepcopy(new);chain=method(norm,'chain_rule');removed=[]
class RemoveHold(ast.NodeTransformer):
 def visit_Assign(self,n):
  names=[x.id for x in n.targets if isinstance(x,ast.Name)]
  if names in [['num_readable_at'],['num_hold_remaining']]:removed.extend(names);return None
  return self.generic_visit(n)
 def visit_If(self,n):
  if ast.unparse(n.test)=='num_hold_remaining > 0':removed.append('adaptive-if');return None
  return self.generic_visit(n)
RemoveHold().visit(norm);assert sorted(removed)==['adaptive-if','num_hold_remaining','num_readable_at'];assert ast.dump(norm,include_attributes=False)==ast.dump(old,include_attributes=False)
voargs=lambda t:[ast.dump(n.args[0],include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover']
assert voargs(old)==voargs(new) and len(voargs(new))==11
markrx=re.compile(r"<bookmark\s+mark\s*=\s*['\"]([^'\"]+)['\"]\s*/>")
assert sum(len(markrx.findall(n.value)) for n in ast.walk(new) if isinstance(n,ast.Constant) and isinstance(n.value,str))==18
receipt=json.loads((D/'production-v2-receipt.json').read_text());diagpath=R/'docs/qa/evidence/ai1-probability-narrated-timing-repair/readable-diagnostic.json.gz';diag=json.loads(gzip.decompress(diagpath.read_bytes()));narr=diag['schedule-report.json']['narration'];masters=diag['real-audio-ready.json']['utterances']
for a,b in zip(receipt['utterance_masters'],masters):assert (a['key'],a['duration'],a['float_master_sha256'])==(b['key'],b['duration'],b['float_master_sha256'])
assert len(masters)==len(receipt['utterance_masters'])==11
votree=ast.parse((D/'voiceover.observed.py').read_text());actual_vo=method(votree,'voiceover');actual_tracker=next(x for x in votree.body if isinstance(x,ast.ClassDef) and x.name=='VoiceoverTracker');actual_strip=method(votree,'_strip_bookmarks')
import importlib.util
scene_path=Path(importlib.util.find_spec('manim').origin).parent/'scene/scene.py';st=ast.parse(scene_path.read_text());nodes=[copy.deepcopy(method(st,n)) for n in ['get_time_progression','validate_run_time']]
# Execute installed frame progression and minimum-run validation with a no-output iterable adapter.
class Config(dict):
 __getattr__=dict.__getitem__
defaults=json.loads((D/'write-defaults.json').read_text());rows=[];generous=[]
for fps in [15,30,60]:
 for phase in [0,.49,1]:
  for variant,tree in [('before',old),('candidate',new)]:
   cfg=Config(frame_rate=fps,progress_bar='none');scope={'np':np,'config':cfg,'tqdm':lambda ts,**kw:ts,'platform':platform,'logger':SimpleNamespace(warning=lambda *a:None)}
   cls=ast.ClassDef(name='InstalledFrameQuantizer',bases=[],keywords=[],body=copy.deepcopy(nodes),decorator_list=[]);module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),cls],type_ignores=[]);exec(compile(ast.fix_missing_locations(module),'installed-Manim-no-render-frame-progression','exec'),scope);quant=scope['InstalledFrameQuantizer']();quant.renderer=SimpleNamespace(skip_animations=False)
   events=[];number_complete=[];starts=[];requested=[]
   class FakeScene:
    def __init__(self):self.renderer=SimpleNamespace(time=receipt['utterance_masters'][6]['start']+phase/fps);self._narration=[]
    def advance(self,dur,kind,args):
     dur=quant.validate_run_time(dur,self.advance);frames=len(quant.get_time_progression(dur,'no-render fixture'));before=self.renderer.time;self.renderer.time+=frames/fps;events.append(dict(kind=kind,start=before,end=self.renderer.time,requested=dur,frames=frames,args=repr(args)))
    def play(self,*args,run_time=None):
     if run_time is None:run_time=max(defaults['number_Write_default_run_time'] if x==('Write',('num',),{}) else defaults['eq0_Write_default_run_time'] if x==('Write',('eq0',),{}) else 1 for x in args)
     self.advance(run_time,'play',args)
     if any(x==('Write',('num',),{}) for x in args):number_complete.append(self.renderer.time)
    def wait(self,dt):self.advance(dt,'wait',())
    def _add_narration(self,*args):starts.append(self.renderer.time)
   scene=FakeScene();cache_index=[6]
   def cached_only_metadata(text):
    i=cache_index[0];cache_index[0]+=1;b=narr[i];assert text==b['text'];return SimpleNamespace(duration=b['duration'],audio_path='not-opened-existing-master',words=[SimpleNamespace(text=w,start=s-b['start'],end=e-b['start']) for w,s,e in b['words']])
   env={'contextmanager':contextmanager,'lang':lang,'Path':Path,'inspect':SimpleNamespace(getfile=lambda _:str(R/'videos/ai/ai1/s02_probability.py')),'tts':SimpleNamespace(synthesize=cached_only_metadata),'_BOOKMARK':markrx,'config':cfg}
   mod=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),copy.deepcopy(actual_strip),copy.deepcopy(actual_tracker),copy.deepcopy(actual_vo)],type_ignores=[]);exec(compile(ast.fix_missing_locations(mod),'actual-voiceover-source-cached-metadata-only','exec'),env);scene.voiceover=types.MethodType(env['voiceover'],scene)
   originalwait=env['VoiceoverTracker'].wait_until
   def tracedwait(tracker,mark):requested.append(dict(mark=mark,requested_at=scene.renderer.time,target=tracker.start+tracker.mark_time(mark)));return originalwait(tracker,mark)
   env['VoiceoverTracker'].wait_until=tracedwait
   env.update(self=scene,morph=lambda self,*a,run_time=1.4,**kw:self.advance(run_time,'morph',a),eqs=['eq0','eq1','eq2','eq3'],pt=['col','out','labs','frame','rays'],out=['out0'],hi=0,WHITE='white')
   for k in ['head','lit_cell','names','b_w','b_h','b_h_l','cell3','rays3','c3l','b3','b3_l','num','cells','box','cap','cap2']:env[k]=k
   for k in ['FadeIn','FadeOut','VGroup','Write','GrowFromCenter','Indicate','TransformFromCopy','Create']:env[k]=lambda *a,_k=k,**kw:(_k,a,kw)
   exec(compile(ast.Module(body=[copy.deepcopy(method(tree,'show_pull')),copy.deepcopy(method(tree,'_bookmark_run_times'))],type_ignores=[]),'actual-scene-scheduler-methods','exec'),env);scene.show_pull=types.MethodType(env['show_pull'],scene)
   c=method(tree,'chain_rule');ws=blocks(tree);first_index=c.body.index(ws[0]);second_index=c.body.index(ws[1]);body=c.body[first_index:second_index+1]
   # Skip only geometry constructors between the two actual voiceover blocks.
   body=[x for x in body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['cap','cap2','box'] for t in x.targets)) and not(isinstance(x,ast.Expr) and ast.unparse(x).startswith(('cap.next_to','cap2.next_to')))]
   exec(compile(ast.fix_missing_locations(ast.Module(body=copy.deepcopy(body),type_ignores=[])),'actual-chain-source-calls','exec'),env)
   complete=number_complete[0];nextstart=starts[1];dwell=nextstart-complete;row=dict(fps=fps,phase_frames=phase,variant=variant,number_Write_complete=complete,next_block_start=nextstart,full_brightness_dwell=dwell,added_hold_request=env.get('num_hold_remaining'),events=events,requested_bookmarks=requested,narration_starts=starts)
   if variant=='candidate':assert dwell>=1.5-1e-10 and dwell<1.5+1/fps+1e-8
   rows.append(row)
  before,after=rows[-2:];assert after['number_Write_complete']==before['number_Write_complete'];after['extra_silence_and_subsequent_timeline_shift']=after['next_block_start']-before['next_block_start'];assert after['extra_silence_and_subsequent_timeline_shift']>1.2
  # Actual candidate post-exit source calls: long residual audio/hold already supplies minimum => no wait.
  hold=[x for x in method(new,'chain_rule').body if (isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='num_hold_remaining' for t in x.targets)) or (isinstance(x,ast.If) and ast.unparse(x.test)=='num_hold_remaining > 0')]
  for credit in [0.,.15,1.,1.5,2.,4.]:
   scene=FakeScene();scene.renderer.time=credit;calls=[];scene.wait=lambda t:calls.append(t);ns={'self':scene,'num_readable_at':0.};exec(compile(ast.Module(copy.deepcopy(hold),type_ignores=[]),'actual-adaptive-hold-residual-credit','exec'),ns);assert calls==([] if credit>=1.5 else [1.5-credit]);generous.append(dict(fps=fps,phase_frames=phase,residual_credit=credit,extra_wait=calls))
(D/'phase-probes.json').write_text(json.dumps({'scope':'Actual source-call AST/VoiceoverTracker/context exit and installed Manim frame progression/validation; animation objects mocked, metadata-only synthesize stub returns existing cached words. No TTS, audio I/O, rendering, decoding, models or producer. Not a perceptual frame/listening test.','source_sha256':sha(D/'s02_probability.proposed.py'),'voiceover_source_sha256':sha(D/'voiceover.observed.py'),'installed_manim_scene_source':str(scene_path),'installed_manim_scene_sha256':sha(scene_path),'cached_diagnostic_gzip_sha256':sha(diagpath),'actual_Write_defaults':defaults,'rows':rows,'residual_credit_cases':generous},indent=2))
summary={'status':'passed','candidate_source_sha256':sha(D/'s02_probability.proposed.py'),'base_source_sha256':sha(D/'s02_probability.before.py'),'all_other_source_AST_exact':True,'all_11_VO_expressions_and_18_bookmarks_exact':True,'all_11_cached_utterance_master_keys_hashes_durations_match_exact_production_receipt':True,'requested_existing_animation_wait_order_and_run_times_unchanged_except_new_adaptive_wait':True,'complete_Library_receipt_bytes':(D/'production-v2-receipt.json').stat().st_size,'Library_receipt_sha256':sha(D/'production-v2-receipt.json'),'phase_cases':len(rows),'residual_credit_cases':len(generous),'minimum_candidate_dwell':min(r['full_brightness_dwell'] for r in rows if r['variant']=='candidate'),'maximum_candidate_dwell':max(r['full_brightness_dwell'] for r in rows if r['variant']=='candidate'),'base_dwell_range':[min(r['full_brightness_dwell'] for r in rows if r['variant']=='before'),max(r['full_brightness_dwell'] for r in rows if r['variant']=='before')],'extra_timeline_shift_range':[min(r['extra_silence_and_subsequent_timeline_shift'] for r in rows if r['variant']=='candidate'),max(r['extra_silence_and_subsequent_timeline_shift'] for r in rows if r['variant']=='candidate')],'rendered_visual_pacing_listening_status':'UNVERIFIED; parent sampled-frame lead is not continuous/listening proof; new guarded captures required','strict_gate_status':'NEW v7 allowlist required; default/v5/v6 must reject candidate. Gate-owner validation not executed by this task.'};(D/'invariants.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
