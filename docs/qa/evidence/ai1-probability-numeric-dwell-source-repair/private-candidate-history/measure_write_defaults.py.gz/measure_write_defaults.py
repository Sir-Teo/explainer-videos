"""Mobject/animation construction only; no Scene, camera, frames, TTS or loads."""
import ast,copy,hashlib,json
from pathlib import Path
D=Path(__file__).parent;R=Path('/workspace/explainer-videos')
from explainer.ai import *
config.media_dir=str(D/'mobject-measurement');config.tex_dir=str(D/'mobject-measurement/Tex')
s=ast.parse((D/'s02_probability.proposed.py').read_text());fn=next(n for n in ast.walk(s) if isinstance(n,ast.FunctionDef) and n.name=='chain_rule');jpath=R/'.cache/ai1/chain.json';ch=json.loads(jpath.read_text());
with np.load(R/'.cache/ai1/chain.npz',allow_pickle=False) as archive:ch.update({k:archive[k] for k in archive.files})
env=globals().copy();env.update(ch=ch,pt_=float(ch['p1'][20]),ph=float(ch['after_t'][8]),pe=float(ch['after_th'][5]))
# The actual source picks indices from ALPHA27, where space=0,a=1,... .
rows=[]
for node in fn.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['K1','colors','steps','eqs','num'] for t in node.targets):rows.append(node)
 # K1,K2,K3 is a tuple assignment.
 elif isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Tuple) and any(isinstance(t,ast.Name) and t.id=='K1' for t in node.targets[0].elts):rows.append(node)
exec(compile(ast.fix_missing_locations(ast.Module(copy.deepcopy(rows),type_ignores=[])),'actual-equation-and-number-mobject-constructors','exec'),env)
out={'scope':'Actual cached-JSON AST-extracted mobject and Write construction only; no Scene/camera/frame render.','numeric_tex':env['num'].tex_string,'number_family_points':len(env['num'].family_members_with_points()),'number_Write_default_run_time':Write(env['num']).run_time,'eq0_family_points':len(env['eqs'][0].family_members_with_points()),'eq0_Write_default_run_time':Write(env['eqs'][0]).run_time,'chain_JSON_sha256':hashlib.sha256(jpath.read_bytes()).hexdigest(),'chain_NPZ_sha256':hashlib.sha256((R/'.cache/ai1/chain.npz').read_bytes()).hexdigest()};assert out['number_Write_default_run_time']==2 and out['eq0_Write_default_run_time']==2;(D/'write-defaults.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
