from pathlib import Path
import hashlib,json,difflib,shutil
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;p=R/'videos/ai/ai1/s02_probability.py';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()=='50ff2a79121a6429eaf30950094d2157e6118d3b390e4544185f27cc44ecf0ed';s=b.decode();old='            self.play(Write(num))\n        cap = label';new='''            self.play(Write(num))
            num_readable_at = self.renderer.time
        # Credit the voiceover tail and pad before adding a finished-line reading hold.
        num_hold_remaining = 1.5 - (self.renderer.time - num_readable_at)
        if num_hold_remaining > 0:
            self.wait(num_hold_remaining)
        cap = label''';assert s.count(old)==1;a=s.replace(old,new);(D/'s02_probability.before.py').write_bytes(b);(D/'s02_probability.proposed.py').write_text(a);(D/'source.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),a.splitlines(True),fromfile='a/videos/ai/ai1/s02_probability.py',tofile='b/videos/ai/ai1/s02_probability.py')));shutil.copyfile(R/'explainer/voiceover.py',D/'voiceover.observed.py');print(hashlib.sha256(a.encode()).hexdigest())
