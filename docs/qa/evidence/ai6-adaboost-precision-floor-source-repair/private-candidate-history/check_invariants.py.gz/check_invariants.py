import ast,copy,hashlib,json,re
from pathlib import Path
import numpy as np
from explainer.zh_templates import Translator
D=Path(__file__).parent;R=Path('/workspace/explainer-videos');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=ast.parse((D/'s15_adaboost.before.py').read_text());b=ast.parse((D/'s15_adaboost.proposed.py').read_text());n=copy.deepcopy(b)
def method(t,name):return next(x for x in ast.walk(t) if isinstance(x,ast.FunctionDef) and x.name==name)
def vo(t,name):return next(x for x in ast.walk(method(t,name)) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='voiceover').args[0]
oldvo=vo(a,'derive');newvo=vo(b,'derive');oldtext=ast.literal_eval(oldvo);text=ast.literal_eval(newvo)
assert oldtext.replace('Searching for alpha numerically gives the same answer, to the sixth decimal.','Searching for alpha numerically agrees with the formula to within a few millionths here.')==text
assert re.findall(r"<bookmark mark='(.*?)'/>",text)==re.findall(r"<bookmark mark='(.*?)'/>",oldtext)==list('abcde')
for x in ast.walk(method(n,'derive')):
 if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='voiceover':x.args[0]=copy.deepcopy(oldvo)
c=method(n,'curves');c.body=[x for x in c.body if not(isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='floor_note' for t in x.targets)) and not(isinstance(x,ast.Expr) and ast.unparse(x).startswith('floor_note.next_to'))]
changedplays=0
for x in ast.walk(c):
 if isinstance(x,ast.Call) and ast.unparse(x.func)=='self.play':
  before=len(x.args);x.args=[v for v in x.args if ast.unparse(v)!='FadeIn(floor_note)'];changedplays+=before-len(x.args)
assert changedplays==1
assert ast.dump(n,include_attributes=False)==ast.dump(a,include_attributes=False)
# Actual local dictionary and update order, without importing scenes/data producers.
def zhmap(path):
 out={}
 for x in ast.parse(path.read_text()).body:
  if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ZH' for t in x.targets):out.update(ast.literal_eval(x.value))
  elif isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and ast.unparse(x.value.func)=='ZH.update':out.update(ast.literal_eval(x.value.args[0]))
 return out
oldzh=zhmap(D/'zh_lines.before.py');newzh=zhmap(D/'zh_lines.proposed.py');changed=[k for k in oldzh if oldzh[k]!=newzh[k]];assert set(oldzh)==set(newzh) and changed==['Why those weights, and that alpha?']
t=Translator('ai6');t.zh=dict(t.zh);t.zh.update({k:newzh[k] for k in changed});zh=t(text);assert zh==newzh[changed[0]] and '百万分之几' in zh and '第六位' not in zh;assert re.findall(r"<bookmark mark='(.*?)'/>",zh)==list('abcde');assert not re.findall(r'\{[^{}]+\}',zh)
cache=R/'.cache/ai6/adaboost.json';d=json.loads(cache.read_text());v=np.array(d['exp_loss_70']);tr=np.array(d['train_err_70']);assert 1e-6<d['alpha_check']<5e-6;assert 0<v[-1]<1e-4
report={'status':'passed','scope':'Private candidate AST/actual Translator and direct cached JSON checks; no scene import, data producer, render or decoding.','same_AST_after_reverting_only_derive_VO_floor_note_and_its_FadeIn':True,'all_math_data_arrays_curve_floors_bookmarks_play_wait_requested_timings_other_methods_unchanged':True,'changed_local_ZH_keys':changed,'derive_VO_changed':True,'duration_equivalence':'NOT CLAIMED; fresh narration-sidecar/timing validation required','English':text,'Chinese':zh,'alpha_check':d['alpha_check'],'smallest_exp_loss':float(v.min()),'final_exp_loss':float(v[-1]),'first_below_plot_floor_round':int(np.flatnonzero(v<1e-4)[0])+1,'first_zero_train_error_round':int(np.flatnonzero(tr==0)[0])+1,'base_source_sha256':sha(D/'s15_adaboost.before.py'),'candidate_source_sha256':sha(D/'s15_adaboost.proposed.py'),'base_local_ZH_sha256':sha(D/'zh_lines.before.py'),'candidate_local_ZH_sha256':sha(D/'zh_lines.proposed.py'),'cached_JSON_sha256':sha(cache),'cached_NPZ_sha256':sha(R/'.cache/ai6/adaboost.npz')}
(D/'invariants.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));print(json.dumps(report,ensure_ascii=False))
