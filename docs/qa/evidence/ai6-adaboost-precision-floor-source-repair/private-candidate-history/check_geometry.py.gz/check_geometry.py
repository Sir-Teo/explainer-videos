import ast,copy,hashlib,json,os
from pathlib import Path
import numpy as np
D=Path(__file__).parent;R=Path('/workspace/explainer-videos');qa_language=os.environ['EXPLAINER_LANG'];proposal=json.loads((D/'proposal.json').read_text())
if qa_language=='zh':
 import explainer.zh_text as z
 z._TABLE=json.loads((R/'videos/ai/ai_text_zh.json').read_text());z._TABLE['strings'].update(proposal['captions']);z._BY_NUMBERS=None
from explainer.ai import *
config.media_dir=str(D/'geometry-media'/qa_language);config.tex_dir=str(D/'geometry-media'/qa_language/'Tex')
src=ast.parse((D/'s15_adaboost.proposed.py').read_text());fn=next(x for x in ast.walk(src) if isinstance(x,ast.FunctionDef) and x.name=='curves');common=ast.parse((R/'videos/ai/ai6/common.py').read_text());env=globals().copy()
exec(compile(ast.Module(body=[copy.deepcopy(x) for x in common.body if isinstance(x,ast.FunctionDef) and x.name=='plot'],type_ignores=[]),'actual-pure-plot-wrapper','exec'),env)
a=json.loads((R/'.cache/ai6/adaboost.json').read_text());L,tr,te=(np.asarray(a[k]) for k in ['exp_loss_70','train_err_70','test_err_70']);n=len(L);env.update(L=L,tr=tr,te=te,n=n,r=np.arange(1,n+1),lr=np.log10(np.arange(1,n+1)),floor=-4,EXPC='#B48EF0',HL=C.BITS,z0=int(np.flatnonzero(tr==0)[0])+1,best=int(np.argmin(te))+1);env['te_z']=te[env['z0']-1]
selected=[]
for x in fn.body:
 if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ('g','key','bound','res','floor_note') for t in x.targets):selected.append(x)
 elif isinstance(x,ast.Expr) and ast.unparse(x).startswith(('key.move_to','floor_note.next_to')):selected.append(x)
exec(compile(ast.fix_missing_locations(ast.Module(body=copy.deepcopy(selected),type_ignores=[])),'actual-proposed-adaboost-mobject-constructors','exec'),env)
def box(m):return [float(m.get_left()[0]),float(m.get_right()[0]),float(m.get_bottom()[1]),float(m.get_top()[1])]
objs={k:box(env[k]) for k in ['g','key','bound','res','floor_note']};f=objs['floor_note'];res=objs['res'];assert f[0]>=-config.frame_width/2+.1 and f[1]<=config.frame_width/2-.1 and f[2]>=-config.frame_height/2+.1 and f[3]<=config.frame_height/2-.1,objs
assert f[3]<res[2]-.2,objs
# Cue lies entirely right of authentic plotted rectangle; it cannot cover curves/ticks.
ax=env['g'].ax;assert env['floor_note'].get_left()[0]>ax.get_right()[0]+.2
# Capture exact actual label translation output, no scene/camera render.
from explainer.zh_text import translate
cue=next(iter(proposal['captions']));actual=translate(cue) if qa_language=='zh' else cue
assert actual==proposal['captions'][cue] if qa_language=='zh' else actual==cue
out={'status':'passed','language':qa_language,'scope':'Isolated AST-extracted actual cached-default label/plot mobject bounds only; in-memory candidate caption overlay, no scene import/camera render/decoder/compute. Actual rendered text remains pending.','bounds':objs,'axis_bounds':box(ax),'frame':[config.frame_width,config.frame_height],'caption':actual,'source_sha256':hashlib.sha256((D/'s15_adaboost.proposed.py').read_bytes()).hexdigest()};(D/f'geometry-{qa_language}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False));print(json.dumps(out,ensure_ascii=False))
