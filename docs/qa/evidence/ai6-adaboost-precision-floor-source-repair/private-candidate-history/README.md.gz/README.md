# AdaBoost private source candidate

No repository changes applied. Frozen candidate corrects two independently verified source/data/actual-endpoint issues:

- Numerical alpha search differs from the formula by3.1611917665763656e-6 (shown3.2×10^-6), so “same answer,to the sixth decimal” overstates agreement. Proposed EN: “Searching for alpha numerically agrees with the formula to within a few millionths here.” Matching Chinese says the difference is only a few millionths.
- Original log curve flooring is preserved, but a new bilingual three-line cue explicitly says zero training error and positive loss below10^-4 share the plotted baseline. Current cache reaches zero training error at round19, positive loss belowfloor at78, and finalpositive loss3.209364758370775e-17.

AST normalization proves only the derive VO, new local floor-note construction/placement and FadeIn change; all equations, data references, existing plot vertices/flooring, other methods, bookmarks and requested play/wait arguments remain unchanged. Only one localZH dictionary value changes. Actual Translator and isolated AST-extracted cached-default mobject constructors pass EN/ZH checks. The cue has0.28scene-unit clearance below readouts, remains insideframe and clear of the plotted rectangle. No scene/camera render or decoder ran; actual visual/timing acceptance remains pending root application and fresh bilingual captures.

`proposal.json` contains the one new exact global caption lookup plus one local narration handoff; it does not modify shared tables. `handoff.json` pins candidate/base/cache/validation hashes. `after-validation-plan.json` states required rendered checks. Four original native endpoint witnesses were actually viewed; parent owns complete movie baseline review. No disappearing-points claim is made.
