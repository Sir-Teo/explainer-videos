#!/usr/bin/env python3
"""Explicitly requested local chapter groups; no render/transcode/upload."""
from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,shutil,zipfile
ROOT=Path('/workspace/explainer-videos');RUNTIME=Path(__file__).resolve().parent;OUT=ROOT/'renders/qa/current-review';ORIGINAL=OUT/'AI-Built-Part3-Silent-Review-480p15-EN-ZH-20261031';LIMIT=14_000_000;MIN_FREE=1024**3
spec=importlib.util.spec_from_file_location('compact_original','/workspace/runtime/ai3-compact-review-packaging/build_compact.py');base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base)
sha=base.sha;write=base.write;SOURCE='927fba668656a682b3e29a288de64130ddc680dd';MAP_SHA='7cca99a8ce8a27f460fdd85ad273ace41ac757f1cd99abbdd04e51ad190d59b6'
original=json.loads((ORIGINAL/'bundle-manifest.json').read_text());authority_path=ORIGINAL/'provenance/root-authoritative38case-map.json';assert sha(authority_path)==MAP_SHA;authority=json.loads(authority_path.read_text());assert authority['source_commit']==SOURCE
for approved in authority['cases'].values():assert sha(ROOT/approved['source_file'])==approved['source_sha256']
all_rows=original['cases'];assert len(all_rows)==38
old_names=['AI-Built-Part3-Silent-Review-480p15-EN-ZH-20261031','AI-Built-Part3-Compact-Sampler-EN-ZH-20261031','AI-Built-Part3-English-Silent-480p15-20261031','AI-Built-Part3-Chinese-Silent-480p15-20261031']
original_zip_sha={name:sha(OUT/(name+'.zip')) for name in old_names}
plan=[]
for language in ['en','zh']:
 rows=sorted((c for c in all_rows if c['lang']==language),key=lambda c:c['index']);assert len(rows)==19 and [c['index'] for c in rows]==list(range(1,20));groups=[];group=[];size=0
 for c in rows:
  if group and size+c['movie_bytes']>13_600_000:groups.append(group);group=[];size=0
  group.append(c);size+=c['movie_bytes']
 if group:groups.append(group)
 for number,group in enumerate(groups,1):
  word='English' if language=='en' else 'Chinese';name=f'AI-Built-Part3-{word}-Group{number:02d}-Positions{group[0]["index"]:02d}-{group[-1]["index"]:02d}-Silent-20261031'
  plan.append({'name':name,'lang':language,'number':number,'groups_in_language':len(groups),'keys':[c['key'] for c in group],'manifest_positions':[c['index'] for c in group],'movie_bytes':sum(c['movie_bytes'] for c in group)})
assert shutil.disk_usage(OUT).free>=MIN_FREE+2*sum(x['movie_bytes'] for x in plan)+20_000_000,'Insufficient disk above1GiB reserve for all groups'
write(RUNTIME/'plan.json',{'source_commit':SOURCE,'authoritative_map_sha256':MAP_SHA,'limit_bytes':LIMIT,'minimum_free_disk_bytes':MIN_FREE,'free_before':shutil.disk_usage(OUT).free,'preserved_original_ZIP_sha256':original_zip_sha,'groups':plan})
limits=[
'Silent 854×480 chapter previews at nominal15fps; existing original MP4 bytes are copied exactly, without transcode or data computation. Audio tracks are silent timing placeholders, not synthesized narration.',
'Included chapters are a contiguous manifest-order subset. Other groups contain the remaining chapters. Group boundaries use 1-based manifest positions (Hook is position1); numbered scene titles keep their original numbering.',
'Individual chapter selected-time/native-endpoint reviews are separate from raw runtime statuses. Brief defects can occur between selected times; no uninterrupted perceptual playback, listening or full1080p motion approval is claimed.',
'Final full-part silent concatenation and all36 selected join windows were checked separately; these packages contain individual chapter clips, not a new assembly or a narrated production export.',
'Original source-change warnings and provenance limits remain unchanged. Packaging hashes verify retained bytes, not historical renderer imports or original data consumption beyond the preserved evidence.',
'This chapter-group edition omits most endpoint PNGs, contact sheets and complete review ledgers. Original full bundle,37MB language packages,sampler and repository evidence remain preserved.',
'Every playback asset is local within this archive. Static index/authority assets are included once per group. Local link/hash/ZIP checks do not establish browser/player compatibility or responsive layout. No upload is performed by this builder.'
]
receipts=[]
for part in plan:
 rows=[c for c in all_rows if c['key'] in part['keys']];rows.sort(key=lambda c:c['index']);name=part['name'];folder=OUT/name;archive=OUT/(name+'.zip');temp=OUT/(name+'.building');ztmp=OUT/(name+'.zip.building')
 for p in [folder,archive,temp,ztmp]:assert not p.exists(),f'Existing output; reconcile before retry: {p}'
 free=shutil.disk_usage(OUT).free;assert free>=MIN_FREE+2*part['movie_bytes']+5_000_000,'Disk reserve gate stopped before group creation'
 temp.mkdir();cases=[]
 for c in rows:
  assert shutil.disk_usage(OUT).free>=MIN_FREE+part['movie_bytes']+2_000_000,'Disk reserve gate stopped; preserve current partial'
  approved=authority['cases'][c['lang']+'/'+c['scene']];assert approved['movie_sha256']==c['movie_sha256'] and approved['record_sha256']==c['runtime_record_sha256']
  source=ORIGINAL/c['movie_relative'];assert sha(source)==c['movie_sha256'];media=f'media/{c["lang"]}/{c["index"]:02d}-{c["scene"]}.mp4';target=temp/media;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);assert sha(target)==c['movie_sha256']
  record=f'records/{c["key"]}-runtime.json.gz';r=base.gzcopy(ORIGINAL/c['runtime_record_relative'],temp/record);assert r['raw_sha256']==c['runtime_record_sha256']
  provenance=f'provenance/{c["key"]}.json.gz';p=base.gzcopy(ORIGINAL/c['provenance_file'],temp/provenance)
  row={k:c[k] for k in ['key','index','lang','scene','title','movie_sha256','movie_bytes','runtime_record_sha256','runtime_status_raw','runtime_warnings_raw','runtime_fingerprint','selected_times_claim','decoded_frames','largest_selected_time_gap','source_frames_unviewed','coverage_packages']};row.update(media=media,record=record,provenance=provenance,original_provenance_sha256=p['raw_sha256'],original_movie=c['original_movie'],original_record=c['runtime_record'],original_review_ledgers=c['matching_review_ledgers'],original_native_endpoint_scope=c.get('native1080_runtime'),stream_metadata=c['stream_probe']);cases.append(row)
 for src,dst in [(authority_path,temp/'provenance/root-authoritative38case-map.json'),(ORIGINAL/'provenance/release-source.json',temp/'provenance/release-source-at-original-packaging.json')]:dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
 extent=f'{part["lang"].upper()} group{part["number"]} of{part["groups_in_language"]}: manifest positions{part["manifest_positions"][0]}–{part["manifest_positions"][-1]}, {len(cases)} of19chapters. Extract and open index.html; no server/account/network is needed.'
 manifest={'title':f'AI, Built · Part3 · {part["lang"].upper()} chapter group{part["number"]}','extent':extent,'source_commit':SOURCE,'root_case_map_sha256':MAP_SHA,'group':{k:v for k,v in part.items() if k not in ['keys','movie_bytes']},'cases':cases,'examples':[],'scope_limits':limits,'original_bundle':str(ORIGINAL),'original_bundle_preserved':True,'chapter_list':'chapters.txt','build_script_sha256':sha(__file__),'reused_compact_builder_sha256':sha('/workspace/runtime/ai3-compact-review-packaging/build_compact.py')}
 write(temp/'manifest.json',manifest);page=base.page(manifest).replace('<h2>Selected before / after examples</h2><div id="examples" class="gallery"></div>','').replace('<a href="README.txt">Readme</a>','<a href="README.txt">Readme</a> · <a href="chapters.txt">Group chapter list</a>');(temp/'index.html').write_text(page)
 chapter_lines=[f'{c["index"]:02d}. {c["scene"]} — {c["title"]}' for c in cases];(temp/'chapters.txt').write_text('Part3 '+part['lang'].upper()+' · manifest positions (not timestamps)\n'+'\n'.join(chapter_lines)+'\n')
 (temp/'README.txt').write_text(manifest['title']+'\n\n'+extent+'\n\n'+'\n'.join(chapter_lines)+'\n\nKeep all folders together after extraction. Each MP4 matches the frozen source exactly; SHA256 values and original uncompressed runtime/provenance identities are in manifest.json.\n\n'+'\n\n'.join(limits)+'\n\nSource commit '+SOURCE+'. Case-map SHA256 '+MAP_SHA+'. This group is a distinct requested delivery artifact; it does not replace or delete any previous bundle or sampler.\n')
 checks=[{'file':str(p.relative_to(temp)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(temp.rglob('*')) if p.is_file()];write(temp/'file-checksums.json',{'scope':'Every payload except checksum manifest and validation receipt','files':checks});validation=base.validate(temp);validation.update(group_chapter_order_matches_manifest=True,manifest_positions=part['manifest_positions'],source_map_identity_verified=True,all_original_movie_bytes_preserved=True,minimum_disk_reserve_bytes=MIN_FREE,upload='not attempted');write(temp/'validation.json',validation)
 assert shutil.disk_usage(OUT).free>=MIN_FREE+sum(p.stat().st_size for p in temp.rglob('*') if p.is_file())+1_000_000,'Disk reserve stopped before ZIP; partial group preserved'
 with zipfile.ZipFile(ztmp,'x',compression=zipfile.ZIP_STORED) as z:
  for p in sorted(temp.rglob('*')):
   if p.is_file():z.write(p,f'{name}/{p.relative_to(temp)}')
 assert ztmp.stat().st_size<=LIMIT,'ZIP exceeds explicit bound; partial preserved'
 with zipfile.ZipFile(ztmp) as z:
  assert z.testzip() is None
  for p in sorted(temp.rglob('*')):
   if p.is_file():assert hashlib.sha256(z.read(f'{name}/{p.relative_to(temp)}')).hexdigest()==sha(p)
 temp.rename(folder);ztmp.rename(archive);assert shutil.disk_usage(OUT).free>=MIN_FREE
 row={**part,'folder':str(folder),'zip':str(archive),'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive),'manifest_sha256':sha(folder/'manifest.json'),'cases':len(cases),'selected_times':sum(c['selected_times_claim'] for c in cases),'validation':validation,'free_disk_after':shutil.disk_usage(OUT).free,'upload':'not attempted'};receipts.append(row);write(RUNTIME/'receipts.json',receipts);print(json.dumps(row),flush=True)
for language in ['en','zh']:
 covered=[k for row in receipts if row['lang']==language for k in row['keys']];expected=[c['key'] for c in sorted(all_rows,key=lambda c:c['index']) if c['lang']==language];assert covered==expected and len(set(covered))==19
for name,h in original_zip_sha.items():assert sha(OUT/(name+'.zip'))==h
write(RUNTIME/'handoff.json',{'source_commit':SOURCE,'authoritative_case_map_sha256':MAP_SHA,'zip_limit_bytes':LIMIT,'groups':receipts,'all38_cases_exactly_once_in_manifest_order':True,'all_previous_packages_preserved':True,'previous_ZIP_sha256':original_zip_sha,'all_group_ZIP_CRC_and_every_archived_byte_hash_verified':True,'minimum_disk_reserve_bytes':MIN_FREE,'free_disk_after':shutil.disk_usage(OUT).free,'upload':'not attempted; root owns delivery','limits':limits})
