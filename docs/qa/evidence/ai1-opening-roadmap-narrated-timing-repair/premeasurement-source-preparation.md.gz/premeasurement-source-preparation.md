# Part1 opening-roadmap timing: read-only preparation

The six-act roadmap is `Hook.question()` lines305–324. It performs1.5s introduction, six sequential1.2s act reveals and a default1s box reveal (minimum9.7s animation). Existing `wait_until()` only waits for future marks; it does not catch up after a previous animation passes a mark. Short actual bookmark intervals could therefore cause accumulating delay. This is a source-level hypothesis, not identification of the external narrated-render defect. The following `Hook.plan()` is a separate objective-list block.

All pinned source and audio-input dependencies are enumerated in report.json. No external production movie, master WAV/alignment or measured visual/audio times were received during this preparation; no audio master was opened or changed. Current map, tracker, language, TTS and voice-profile code were read without scene/model/producer imports.

A bounded scene-only reveal schedule can preserve utterances, bookmarks and cached speech if measurements confirm fixed-duration overrun. A wrong alignment must be diagnosed separately. No patch or production clearance is provided. Root must reconcile the exact production source/overlay and receive measurements before selecting a fix.
