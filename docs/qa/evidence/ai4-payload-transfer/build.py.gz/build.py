from pathlib import Path
import json,hashlib,zipfile,subprocess,datetime
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;S=R/'docs/qa/evidence/ai4-production-handoff';m=json.loads((S/'handoff-metadata.json').read_text());pin=m['recommended_source_commit'];assert pin=='1927e6b7a99192344bd4c00ca7aae3abdd499369';sha=lambda b:hashlib.sha256(b).hexdigest();files={};payloads=[];absent=[]
for item in m['items']:
 for rel,sig in item['payloads'].items():
  p=R/rel
  if sig is None:assert not p.exists(),rel;absent.append(rel);continue
  b=p.read_bytes();assert len(b)==sig['bytes'] and sha(b)==sig['sha256'] and p.stat().st_mtime_ns==sig['mtime_ns'],rel;files[rel]=b;payloads.append({'path':rel,'bytes':len(b),'sha256':sha(b),'source_mtime_ns_observed_unchanged':sig['mtime_ns']})
assert len(payloads)==42 and sum(x['bytes'] for x in payloads)==796899
for row in m['source_inventory']:
 b=subprocess.check_output(['git','show',pin+':'+row['path']],cwd=R);assert len(b)==row['pinned_bytes'] and sha(b)==row['pinned_sha256'],row['path']
 if row['path'].startswith('videos/ai/ai4/'):assert (R/row['path']).read_bytes()==b,row['path']
for n in ['handoff-metadata.json','payload-files.sha256']:files[n]=(S/n).read_bytes()
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_commit':pin,'payloads':payloads,'optional_npz_absence':absent,'payload_count':42,'payload_bytes':796899,'original_metadata_sha256':sha(files['handoff-metadata.json']),'scope':'Exact preserved frozen Part4 payload transport. No producer/load/render or metadata retag during packaging. Original metadata observation remains historical; this receipt records later byte verification/archive assembly.'};files['transfer-manifest.json']=(json.dumps(receipt,indent=2)+'\n').encode();guide='''# Part4 frozen numerical payload transfer

Approved source pin:1927e6b7a99192344bd4c00ca7aae3abdd499369. This archive contains exactly42 completed numerical payloads796,899bytes for23items, preserving every original completion/provenance field. OptionalNPZabsences are recorded. All bytes/hash/size/mtime match the earlier frozen handoff. No producer or scene was invoked while packaging.

Use the pinned source and its pinned global captions from Git, not movingHEAD. Exact source inventory, original guarded-load23item receipt and runtime/provenance limits are in handoff-metadata.json; transfer-manifest.json is the later transport observation. Original metadata scope says metadata-only because that historical observation preceded this archive.

Strict cached recipes require NumPy2.5.4,SciPy1.18.1,Torch2.15.0+cpu. The repository lockfile differs(Torch2.14.1); a GPU/cu-suffixed package also differs. Stop on mismatch; never rewrite metadata, weaken guards or silently regenerate. Every production renderer needs inherited fail-on-producer guards before importing scenes. Upstream Part1 cache inputs come from the existing Parts1–3transfer, not duplicate weights here.

Source/data/selected silent preview and native endpoint scopes are recorded in docs/qa/production-handoff-part4.md. Narration/listening/continuous perception/full4K motion remain open. This is production input, not Final_Upload_Package. Parent/cloud production owner owns actual gated export/Drive delivery. No local rendering, CI/CD, merge or public-platform publication.
''';files['README.md']=guide.encode();entries=[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(files.items())];files['archive-manifest.json']=(json.dumps(entries,indent=2)+'\n').encode();z=D/'ai4-frozen-payloads-1927e6b7-20261101.zip';assert not z.exists()
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as a:
 for n,b in sorted(files.items()):i=zipfile.ZipInfo(n,date_time=(2026,11,1,5,0,0));i.compress_type=zipfile.ZIP_DEFLATED;a.writestr(i,b)
with zipfile.ZipFile(z) as a:
 assert a.testzip()is None
 for e in entries:assert sha(a.read(e['path']))==e['sha256']
(D/'transfer-manifest.json').write_bytes(files['transfer-manifest.json']);(D/'archive-manifest.json').write_bytes(files['archive-manifest.json']);(D/'README.md').write_bytes(files['README.md']);out={'file':str(z),'bytes':z.stat().st_size,'sha256':sha(z.read_bytes()),'source_commit':pin,'payload_count':42,'payload_bytes':796899,'entries':len(files)};(D/'archive-receipt.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
