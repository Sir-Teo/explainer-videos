"""Read-only final Part5 cache closure and actual v3 decoding audit.

No producer, trained-model import/load/inference, scene construction or render.
Cached BPE tokenizer decoding alone verifies the selected prompt fingerprint.
"""
import ast
import builtins
import datetime
import hashlib
import json
import math
from pathlib import Path
import sys
from unittest.mock import Mock, patch

import numpy as np

ROOT=Path('/workspace/explainer-videos')
sys.path.insert(0,str(ROOT))
OUT=Path('/workspace/runtime/ai5-completed-28-decoding-audit');OUT.mkdir(exist_ok=True)
RUN=Path('/workspace/runtime/ai5-production-compute/run-20261101T014158.404427Z')
FREEZE=Path('/workspace/runtime/ai5-production-compute/source-freeze-after-draws-fix.json')
PRIOR=Path('/workspace/runtime/ai5-completed-27-numerical-audit/report.json')
start=datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def sig(p):
 p=Path(p)
 if not p.exists():return None
 s=p.stat();return dict(bytes=s.st_size,mtime_ns=s.st_mtime_ns,sha256=sha(p))

def serial(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 raise TypeError(type(x).__name__)

original_import=builtins.__import__;forbidden=[]
def guarded_import(name,*args,**kwargs):
 if name.split('.')[0] in {'torch','transformers'} or name in {'explainer.ai.novels','explainer.lm.pocket'}:
  forbidden.append(name);raise AssertionError('No trained models/scenes permitted: '+name)
 return original_import(name,*args,**kwargs)

checks=[]
def check(label,condition,**evidence):
 row=dict(check=label,passed=bool(condition),**evidence);checks.append(row)
 if not condition:
  (OUT/'failure.json').write_text(json.dumps(row,indent=2,default=serial));raise AssertionError(label)

from manim import Scene
scene_fail=Mock(side_effect=AssertionError('No Scene construction/render in numerical audit'))
with patch('builtins.__import__',side_effect=guarded_import),patch.object(Scene,'__init__',scene_fail),patch.object(Scene,'render',scene_fail):
 from videos.ai.ai5 import compute,decoding,decoding_contract as dc
 names=list(compute.ITEMS);check('exact28registereditems',len(names)==28,names=names)
 paths=[p for n in names for p in (compute.CACHE.path(n),compute.CACHE.path(n).with_suffix('.npz'))]
 before={str(p):sig(p) for p in paths}
 partials={str(p):sig(p) for p in compute.CACHE.dir.glob('*partial*.json')}
 freeze=json.loads(FREEZE.read_text());sources=[Path(p) for p in freeze['files'] if p.endswith('.py')]
 source_before={str(p):sig(p) for p in sources}
 check('all16frozennumericalsourcesmatch',all(v['sha256']==freeze['files'][p]['sha256'] for p,v in source_before.items()))
 prior=json.loads(PRIOR.read_text())
 check('prior54completedpayloadsretainexactsignatures',all(before[p]==v for p,v in prior['payload_signatures_after'].items()),prior_report_sha256=sha(PRIOR),prior_checks=len(prior['checks']))
 children={}
 for n in names:
  matches=list(RUN.glob(f'[0-9][0-9]-{n}-child.json'));check('onechildreceipt-'+n,len(matches)==1)
  p=matches[0];v=json.loads(p.read_text())
  check('passed-current-child-'+n,v['status']=='passed' and v['cache_current'] is True)
  check('actual-output-hashes-'+n,all(before[p]['sha256']==row['sha256'] and before[p]['bytes']==row['bytes'] for p,row in v['outputs'].items()))
  children[n]=dict(path=str(p),signature=sig(p),started_utc=v['started_utc'],ended_utc=v['ended_utc'])
 fail=Mock(side_effect=AssertionError('Producer/save must never run in read-only audit'))
 data={}
 with patch.object(compute.CACHE,'_produce',fail),patch.object(compute.CACHE,'items',{n:fail for n in names}),patch.dict(compute.ITEMS,{n:fail for n in names}),patch.object(compute.CACHE,'save',fail):
  current={n:compute.cache_current(n) for n in names}
  check('all28current',all(current.values()),current=current)
  for n in names:data[n]=compute.CACHE.load(n)
  fail.assert_not_called()
 check('zero-producer-save-calls',fail.call_count==0,count=fail.call_count)

 d=data['decoding'];config=decoding.configuration()
 keys=[f'{k}{v}' for k,v in decoding.SETTINGS]
 check('v3inventory-and-cohortmetadata',d['metric_version']==3 and d['settings']==keys and len(keys)==16 and d['prompt_count']==12 and d['stochastic_samples']==8 and d['greedy_samples']==1,config=config)
 identity=decoding.cache_identity();stored=dict(d['provenance']);stored_prompt_digest=stored.pop('selected_prompts_sha256')
 check('full-current-contract-provenance',stored==identity,selected_prompts_sha256=stored_prompt_digest)
 check('all16metricrowsandhuman-valid',all(dc.valid_piece(k,d[k],12) for k in keys) and dc.valid_piece('human',d['human'],12))
 check('saved-prompt-means-finite12each',all(len(d[k]['nll_prompt'])==12 and np.isfinite(d[k]['nll_prompt']).all() for k in keys))
 # BPE parsing/decoding only: no LM, generator, GPT-2 judge or upstream loader.
 from tokenizers import Tokenizer
 tok=Tokenizer.from_file(str(ROOT/'.cache/novels/tokenizer.json'))
 valid=np.load(ROOT/'.cache/novels/valid.npy',allow_pickle=False)
 P=decoding.prompts(valid,tok)
 texts=[tok.decode([int(x) for x in p[:decoding.PROMPT_LEN]],skip_special_tokens=False) for p in P]
 calculated_digest=dc.prompt_identity(P,texts)
 check('actual-selected-prompt-digest',P.shape==(12,72) and calculated_digest==stored_prompt_digest,shape=list(P.shape),digest=calculated_digest)
 check('stored-prompttexts-humanreference-match',texts[0]==d['prompt0'] and texts[3]==d['prompt3'] and tok.decode([int(x) for x in P[0,32:]],skip_special_tokens=False)==d['human']['text'])
 example_chars={k:dict(examples=[len(x) for x in d[k]['examples']],ex_prompt=[len(x) for x in d[k]['ex_prompt']]) for k in keys}
 check('all-retained-example-characters-nonzero',all(min(v['examples']+v['ex_prompt'])>0 for v in example_chars.values()) and len(d['human']['text'])>0,retained_character_counts=example_chars,human_example_characters=len(d['human']['text']))
 metrics=[]
 for key,kind,value in zip(d['settings'],d['kinds'],d['values']):
  row=d[key];samples=1 if kind=='greedy' else 8;continuations=12*samples
  repeats=row['rep']*(40-3)*continuations
  pairs=None if kind=='greedy' else row['div']*12*8*(40-1)
  check('fixed-cohort-metric-lattice-'+key,abs(repeats-round(repeats))<1e-8 and (pairs is None or abs(pairs-round(pairs))<1e-8))
  metrics.append(dict(key=key,kind=kind,value=value,nll=row['nll'],diversity=row['div'],repetition=row['rep'],kept=row['kept'],prompt_mean=float(np.mean(row['nll_prompt'])),prompt_sd=float(np.std(row['nll_prompt'],ddof=1)),prompt_mean_se=float(np.std(row['nll_prompt'],ddof=1)/math.sqrt(12)),expected_continuations=continuations,derived_repeated_4gram_count=round(repeats),derived_distinct_bigram_count=None if pairs is None else round(pairs),count_scope='Derived from fixed40token/source cohort and saved ratio; full generation rows were not saved for independent recount.'))
 kinds=['temp','topk','topp','minp']
 result=dc.comparison([(kind,d[key]) for key,kind in zip(keys,d['kinds']) if kind in kinds],kinds)
 scene_path=ROOT/'videos/ai/ai5/s11_decoding.py';scene_bytes=scene_path.read_bytes();scene=ast.parse(scene_bytes)
 helper=next(n for n in scene.body if isinstance(n,ast.FunctionDef) and n.name=='comparison_verdict');env={}
 exec(compile(ast.Module([helper],type_ignores=[]),'actual-decoding-scene-verdict','exec'),env)
 spoken={'temp':'temperature alone','topk':'top-k','topp':'top-p','minp':'min-p'}
 verdict=env['comparison_verdict'](result,spoken)
 greedy_verdict=dc.judge_verdict(d['greedy0.0']['nll'],[d[k]['nll'] for k,kind in zip(keys,d['kinds']) if kind!='greedy'])
 def assignment(name):
  return next(n.value for n in ast.walk(scene) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
 mean_se=eval(compile(ast.Expression(assignment('mean_se')),'actual-se-assignment','eval'),dict(np=np,math=math),dict(d=d))
 sel=next(n.args[0] for n in ast.walk(scene) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='note' and n.args and 'standard error' in ast.unparse(n.args[0]))
 footer=eval(compile(ast.Expression(sel),'actual-se-caption','eval'),{},dict(mean_se=mean_se))
 check('actual-SE-formula-and-caption',abs(mean_se-np.mean([r['prompt_mean_se'] for r in metrics]))<1e-12 and 'standard error' in footer and 'not passage SD or CI' in footer and r'\pm' not in footer,mean_se=mean_se,mean_prompt_sd=float(np.mean([r['prompt_sd'] for r in metrics])),caption=footer)
 # Extract judge/generate source evidence rather than rerunning either.
 decoder_tree=ast.parse((ROOT/'videos/ai/ai5/decoding.py').read_text())
 judge=next(n for n in decoder_tree.body if isinstance(n,ast.FunctionDef) and n.name=='judge')
 judge_source=ast.unparse(judge)
 nonempty_guard=any(isinstance(n,ast.BoolOp) and isinstance(n.op,ast.Or) and [v.operand.id for v in n.values if isinstance(v,ast.UnaryOp) and isinstance(v.op,ast.Not) and isinstance(v.operand,ast.Name)]==['pa','cb','b'] for n in ast.walk(judge))
 char_len=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='len' and len(n.args)==1 and isinstance(n.args[0],ast.Name) and n.args[0].id=='b' for n in ast.walk(judge))
 check('frozenjudge-char-and-truncation-guards',nonempty_guard and char_len and 'no continuation was truncated' in judge_source and 'add_special_tokens=False' in judge_source)
 partial_status=[]
 for p in partials:
  raw=json.loads(Path(p).read_text());done=raw.get('done',{})
  partial_status.append(dict(path=p,signature=partials[p],excluded_from_completed_payloads=True,done_keys=list(done),params_match_completed_provenance=raw.get('params')==d['provenance'],pieces_equal_completed={k:done[k]==d[k] for k in done if k in d},preserved=True))
 after={str(p):sig(p) for p in paths};source_after={str(p):sig(p) for p in sources}
 check('all56completedpayloadsignatures-unchanged',before==after,count=len(paths),bytes=sum(v['bytes'] for v in before.values() if v))
 check('all16frozennumericalsources-unchanged',source_before==source_after)
 check('partial-bytes-mtime-preserved',partials=={p:sig(p) for p in partials})
 check('no-forbidden-imports-or-model-modules',not forbidden and not any(n in sys.modules for n in ('torch','transformers','explainer.lm.pocket')),attempts=forbidden)
 check('zero-scene-construction-render',scene_fail.call_count==0,calls=scene_fail.call_count)
 check('scene-source-stable-through-AST-only-check',scene_path.read_bytes()==scene_bytes,scene_sha256=hashlib.sha256(scene_bytes).hexdigest())

report=dict(started_utc=start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='All28 current completed-cache reads with producers/save fail-on-call; newdecodingv3 metric/provenance/scene-helper audit only. Prior27science audit referenced, not rerun.',completed_items=names,current=current,actual_load_count=len(data),producer_save_calls=fail.call_count,forbidden_import_attempts=forbidden,completed_payload_signatures_before=before,completed_payload_signatures_after=after,source_signatures_before=source_before,source_signatures_after=source_after,prior27audit=dict(path=str(PRIOR),sha256=sha(PRIOR),checks=len(prior['checks']),status='Exact54payloadsignatures stillmatch; scopedscience results inherited byreference only.'),children=children,checks=checks,decoding=dict(metric_version=3,configuration=config,identity=identity,selected_prompts_sha256=calculated_digest,selected_prompt_ids=P.tolist(),selected_prompt_texts=texts,metrics=metrics,human=d['human'],comparison=result,comparison_verdict=verdict,greedy_verdict=greedy_verdict,mean_prompt_mean_se=mean_se,mean_prompt_sd=float(np.mean([r['prompt_sd'] for r in metrics])),SE_caption=footer,character_weighted_nll_vs_unweighted_prompt_mean={r['key']:r['nll']-r['prompt_mean'] for r in metrics}),preserved_partials=partial_status,limits=['No models, inference, neuralgenerator/judge, Scene construction, render, TTS, Drive or package activity. The cache API imports sharedManim module definitions indirectly; Scene init/render were fail-on-call.', 'Full1452continuationstrings/tokenIDs and percontinuationcharacter denominators were not saved: cannot independently recount actual perrowchar totals or rerun scoring without inference. Positivechars/cohortshape are enforced by frozen source; retainedexamples are nonempty; savedperpromptmeans/cohortmetadata andmetriclattices are checked.', 'SE describes the unweighted promptwise mean; reported overallNLL is characterweighted. Characterweights unavailable, so this is not a weighted-meanSE or calibratedCI/model/run uncertainty.', 'Prior27boundedsciencecheck15results are referenced, not falsely counted as newtests. No finalvisual/audio/fullseriesapproval.'])
(OUT/'report.json').write_text(json.dumps(report,indent=2,default=serial)+'\n')
table=['| Setting | NLL (nats/character) | Distinct token bigrams | Repeated token4-grams | Mean tokens kept |','|---|---:|---:|---:|---:|']
for r in metrics:
 div='—' if r['diversity'] is None else format(r['diversity'],'.6f')
 table.append(f"| {r['key']} | {r['nll']:.6f} | {div} | {100*r['repetition']:.4f}% | {r['kept']:.3f} |")
table.append(f"| Held-out human reference | {d['human']['nll']:.6f} | — | {100*d['human']['rep']:.4f}% | — |")
proposal='''# Proposed replacement for historical README decoding results (not applied)

These are the completed current metric-v3 results, rather than historical v2 numbers. Twelve deterministic held-out prompts each contain32generator tokens; every stochastic setting generates8continuations perprompt and greedy generates1, all40tokens long. Sixteen settings total produce1,452generated continuations (58,080tokens) plus12human-referencecontinuations. These cohort totals follow the frozen implementation/configuration; all generated strings/per-rowcharacter totals were not retained for an independent raw-row recount.

GPT-2 revision607a30d783dfa663caf39e06633721c8d4cfcd7e scores separately tokenized prompt/continuation boundaries in nats per true continuationUnicodecharacter, without silenttruncation. This new boundary convention and changed promptselection are not numerically comparable with the prior v2 table. Diversity pools generator-token bigrams within each prompt; repetition counts generator-token4-grams, not wordsequences.

'''+ '\n'.join(table)+f'''\n\nAll four rules cover diversity0.85 in this run. Linear interpolation within their actual sampled supports gives: '''+', '.join(f'{k} {v:.6f}' for k,v in result['at'].items())+f''' nats/character. {verdict} This is a descriptive interpolation of one run, not a significance/generalization claim.

{greedy_verdict}. Its repeated4-tokenfraction is{100*d['greedy0.0']['rep']:.4f}%; the largest sampledsettingfraction is{100*max(d[k]['rep'] for k,kind in zip(keys,d['kinds']) if kind!='greedy'):.4f}%. Likelihood alone does not measure textquality.

The mean of the16per-setting descriptive SD(promptwiseNLL/char)/sqrt(12) values is{mean_se:.6f}nats/character; the mean passageSD is{report['decoding']['mean_prompt_sd']:.6f}. This SE applies to an unweighted average over promptwise ratios, whereas the headline NLL scores pool NLL/characters acrosscontinuations. It is not the standarderror of that characterweighted headline, not passage-to-passageSD, and not a calibrated confidenceinterval or model/run-to-rununcertainty. Raw characterweights were notsaved for independently estimating weighted-meanuncertainty.
'''
(OUT/'README-result-proposal.md').write_text(proposal)
(OUT/'README.md').write_text(f'''# Completed Part5 closure and decoding-v3 audit

All28 registered items were actually current and loaded once through the production cache API with `_produce`, all producerentries and `save` fail-on-call. Calls:0. All56completedJSON/NPZ files (including the newdecodingpair) retained exact SHA256/size/mtime; every producerchild receipt was passed/current and its outputhashesmatch. All16 frozen numerical/driverPythonfiles retained hashes/mtimes. Prior27scienceproof15checks is inherited by exact54payloadidentity and reporthash, not rerun or newly counted.\n\n+The selected12×72token held-out prompt array/digest andprompt0/prompt3/humanexample were independently reconstructed from the existing cachedBPE tokenizer and validarray only. No trainedmodel orjudge was imported orcalled; modelartifacts were fingerprinted as rawbytes by the currentcontract. All16metricrows have12finitepromptvalues andvalid domains, expected1vs8cohortmetadata andmetriclatticeconsistency. Retainedexamplecharacters are positive. Full generation rows/percontinuationcharacterdenominators were notsaved; those cannot be independently recounted. Frozenjudge/generationcode enforces nonempty/fullcontinuation/cohort behavior, and exactprovenance+completedchildreceipt bind that path.\n\n+Current actual interpolation: {result['at']}. {verdict} {greedy_verdict}. Mean descriptive prompt-meanSE={mean_se:.9f}; meanpromptSD={report['decoding']['mean_prompt_sd']:.9f}. HeadlineNLL is characterweighted, whereas this SE uses unweightedpromptmeans; see the explicit method limits and proposed README wording.\n\n+The completed decoding.partial.json remains preserved, intentionally outside completedpayloadcohort. Its params/pieces were compared withfinalresult and statusrecorded; nothing was removed.\n\n+`report.json` preserves every rawoutcome/signature/childreference/actualprompt/metric/helperverdict andscope; `README-result-proposal.md` supplies a fresh complete16-settingtable andqualified prose for root to review, without editing repositoryREADME. No source/data/cache changes, inference/render/TTS/Drive/package/localactivity or finalvisual/audioapproval.\n''')
manifest={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='manifest.json'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(items=len(names),loads=len(data),producer_calls=fail.call_count,completed_payloads=len(paths),checks=len(checks),report_sha256=sha(OUT/'report.json'),mean_se=mean_se,comparison=result,verdict=verdict,greedy_verdict=greedy_verdict),indent=2))
