# Proposed replacement for historical README decoding results (not applied)

These are the completed current metric-v3 results, rather than historical v2 numbers. Twelve deterministic held-out prompts each contain32generator tokens; every stochastic setting generates8continuations perprompt and greedy generates1, all40tokens long. Sixteen settings total produce1,452generated continuations (58,080tokens) plus12human-referencecontinuations. These cohort totals follow the frozen implementation/configuration; all generated strings/per-rowcharacter totals were not retained for an independent raw-row recount.

GPT-2 revision607a30d783dfa663caf39e06633721c8d4cfcd7e scores separately tokenized prompt/continuation boundaries in nats per true continuationUnicodecharacter, without silenttruncation. This new boundary convention and changed promptselection are not numerically comparable with the prior v2 table. Diversity pools generator-token bigrams within each prompt; repetition counts generator-token 4-grams, not wordsequences.

| Setting | NLL (nats/character) | Distinct token bigrams | Repeated token 4-grams | Mean tokens kept |
|---|---:|---:|---:|---:|
| greedy0.0 | 0.540234 | — | 35.1351% | 1.000 |
| temp0.5 | 0.851139 | 0.695246 | 2.1396% | 4096.000 |
| temp0.7 | 0.997609 | 0.833600 | 0.4223% | 4096.000 |
| temp1.0 | 1.281646 | 0.936165 | 0.0282% | 4096.000 |
| temp1.3 | 1.613097 | 0.989049 | 0.0000% | 4096.000 |
| topk5 | 0.827322 | 0.733707 | 0.9009% | 5.000 |
| topk20 | 0.997796 | 0.883814 | 0.0282% | 20.000 |
| topk100 | 1.170755 | 0.923077 | 0.0845% | 100.000 |
| topp0.5 | 0.885511 | 0.767628 | 0.5349% | 11.448 |
| topp0.8 | 1.059453 | 0.889957 | 0.1126% | 63.650 |
| topp0.9 | 1.147806 | 0.930288 | 0.0000% | 145.573 |
| topp0.95 | 1.189928 | 0.928152 | 0.0282% | 272.284 |
| minp0.02 | 1.042255 | 0.894765 | 0.0563% | 45.579 |
| minp0.05 | 0.983257 | 0.846955 | 0.5068% | 21.750 |
| minp0.1 | 0.902881 | 0.810897 | 0.4223% | 11.161 |
| minp0.2 | 0.841291 | 0.709402 | 1.4640% | 5.484 |
| Held-out human reference | 1.012341 | — | 0.0000% | — |

All four rules cover diversity0.85 in this run. Linear interpolation within their actual sampled supports gives: temp 1.043026, topk 0.959394, topp 1.002637, minp 0.987015 nats/character. At the target diversity, All four rules cover this target diversity. Among the covered rules, top-k has the lowest interpolated surprise, 0.959 nats per character. This is a descriptive interpolation of one run, not a significance/generalization claim.

Greedy decoding has the lowest surprise in this run. Its repeated4-tokenfraction is35.1351%; the largest sampledsettingfraction is2.1396%. Likelihood alone does not measure textquality.

The mean of the16per-setting descriptive SD(promptwiseNLL/char)/sqrt(12) values is0.051391nats/character; the mean passageSD is0.178025. This SE applies to an unweighted average over promptwise ratios, whereas the headline NLL scores pool NLL/characters acrosscontinuations. It is not the standarderror of that characterweighted headline, not passage-to-passageSD, and not a calibrated confidenceinterval or model/run-to-rununcertainty. Raw characterweights were notsaved for independently estimating weighted-meanuncertainty.

The four rules jointly cover diversity from **0.767628 to 0.894765**; 0.85 lies inside that observed range. Parent-recorded elapsed intervals were **651.410 seconds** for decoding and **781.241 seconds** summed across all 28 children, including setup/imports. The 56 completed payload files total **3,090,034 bytes**. These are observations from this cloud run, not a portable runtime promise.
