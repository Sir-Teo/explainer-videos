"""Record ONLY pages/native originals actually inspected by the reviewer."""
from pathlib import Path
import argparse,datetime,hashlib,json
p=argparse.ArgumentParser(description=__doc__);p.add_argument('case');p.add_argument('kind',choices=['page','native']);p.add_argument('indices',help='Comma-separated page numbers or zero-based nativeframe indices');p.add_argument('observation');a=p.parse_args();case=Path(a.case).resolve();plan=json.loads((case/'plan.json').read_text());views=json.loads((case/'views.json').read_text());now=datetime.datetime.now(datetime.timezone.utc).isoformat()
for index in map(int,a.indices.split(',')):
 if a.kind=='page':
  row=next(r for r in plan['pages'] if r['page']==index);file=case/row['file'];assert not any(r['page']==index for r in views['pages']);out=dict(row,viewed_utc=now,observation=a.observation,scope='Actualscaled960x540pernative1920x1080frame;notalloriginalsviewedunscaled')
 else:
  row=plan['frames'][index];file=case/'native'/row['file'];assert not any(r['index']==index for r in views['native']);out={'index':index,'file':str(file.relative_to(case)),'time':row['time'],'sha256':row['sha256'],'viewed_utc':now,'observation':a.observation,'scope':'Actualoriginal1920x1080nativeview'}
 assert hashlib.sha256(file.read_bytes()).hexdigest()==row['sha256'];views['pages' if a.kind=='page' else 'native'].append(out)
(case/'views.json').write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
