from pathlib import Path
import ast,hashlib,json,os,math,datetime
import numpy as np
from explainer.ai import *
from manim import config
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;language=os.environ['EXPLAINER_LANG'];config.media_dir=str(D/'tex-artifacts'/language);config.tex_dir=str(D/'tex-artifacts'/language/'Tex')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();payload=R/'.cache/ai6/bagging.json';pin={'sha256':sha(payload),'bytes':payload.stat().st_size,'mtime_ns':payload.stat().st_mtime_ns};b=json.loads(payload.read_text());common=ast.parse((R/'videos/ai/ai6/common.py').read_text())
scope=dict(globals(),HIST=C.HUMAN,HL=C.BITS,BAD=C.PENALTY,GOOD=C.REWARD,FOREST=C.INTERVAL)
exec(compile(ast.Module([x for x in common.body if isinstance(x,ast.FunctionDef) and x.name=='plot'],type_ignores=[]),'actual-pure-plot','exec'),scope)
def construct(path):
 t=ast.parse(path.read_text());f=next(x for x in ast.walk(t) if isinstance(x,ast.FunctionDef) and x.name=='forest');nodes=[]
 for n in f.body:
  if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='n_te' for x in n.targets):break
  nodes.append(n)
 s=dict(scope,load=lambda name:b,self=None);exec(compile(ast.Module(nodes,type_ignores=[]),'actual-forest-constructor-prefix','exec'),s);return s
before=construct(D/'before.py');after=construct(D/'candidate.py');bb=lambda g:[float(g.get_left()[0]),float(g.get_right()[0]),float(g.get_bottom()[1]),float(g.get_top()[1])]
def clearance(a,b):
 A,B=bb(a),bb(b);dx=max(0,A[0]-B[1],B[0]-A[1]);dy=max(0,A[2]-B[3],B[2]-A[3]);return math.hypot(dx,dy)
unchanged={}
for name in ['g','one','cf','co','cb']:
 np.testing.assert_allclose(after[name].get_all_points()-before[name].get_all_points(),np.broadcast_to([0,-.45,0],after[name].get_all_points().shape),atol=1e-12);unchanged[name]={'shape':list(after[name].get_all_points().shape),'exact_same_points_up_to_uniform_downshift':.45}
for name in ['key','oob']:
 np.testing.assert_array_equal(before[name].get_all_points(),after[name].get_all_points());unchanged[name]='exact same actual geometry'
# History's only operation is a rigid relocation; every original family point is retained up to translation.
np.testing.assert_allclose(after['hist'].get_all_points()-before['hist'].get_all_points(),np.broadcast_to(after['hist'].get_center()-before['hist'].get_center(),after['hist'].get_all_points().shape),atol=1e-12)
px_per_world=60.;bounds={n:bb(after[n]) for n in ['g','one','cf','co','cb','key','oob','hist']};frame_margin={n:min(v[0]+config.frame_width/2,config.frame_width/2-v[1],v[2]+config.frame_height/2,config.frame_height/2-v[3])*px_per_world for n,v in bounds.items()}
assert min(frame_margin.values())>=15-1e-8,frame_margin
separations=[]
for offset in [0,-.2]:
 h=after['hist'].copy().shift(UP*offset)
 for name,obj in [(f'g.component{i}',obj) for i,obj in enumerate(after['g'])]+[(name,after[name]) for name in ['one','cf','co','cb','key','oob']]:
  gap=clearance(h,obj)*px_per_world;assert gap>=15-1e-8,(offset,name,gap);separations.append({'history_vertical_offset':offset,'other':name,'rectangle_clearance_px':gap})
# Explicit actual-source y-axis title against card, not just a proxy glyph rectangle.
ylabel=after['g'][-1];oldgap=clearance(before['hist'],before['g'][-1])*px_per_world
assert clearance(after['hist'],ylabel)*px_per_world>=15
old=ast.parse((D/'before.py').read_text());new=ast.parse((D/'candidate.py').read_text());oldtext=(D/'before.py').read_text();newtext=(D/'candidate.py').read_text();assert newtext.replace('center=[-2.0, -0.85, 0]','center=[-2.0, -0.4, 0]').replace('.to_corner(UR, buff=0.3)','.to_corner(UL, buff=0.2)')==oldtext
assert sha(R/'videos/ai/ai6/s14_forests.py')==sha(D/'before.py');assert pin=={'sha256':sha(payload),'bytes':payload.stat().st_size,'mtime_ns':payload.stat().st_mtime_ns}
voiceovers=lambda t:[ast.dump(n,include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.With)];assert voiceovers(old)==voiceovers(new)
for name in ['construct','formula','decorrelate']:
 get=lambda t:next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name==name);assert ast.dump(get(old))==ast.dump(get(new))
report={'language':language,'candidate_sha256':sha(D/'candidate.py'),'before_sha256':sha(D/'before.py'),'source_still_unapplied':True,'actual_Manim_geometry':True,'proper_language_process':os.environ['EXPLAINER_LANG'],'translated_y_title':getattr(ylabel,'tex_string',None),'original_card_title_clearance_px':oldgap,'after_bounds':bounds,'minimum_frame_margins_px':frame_margin,'history_separations':separations,'y_title_history_clearance_px':clearance(after['hist'],ylabel)*px_per_world,'unchanged_geometry':unchanged,'history_rigid_shift':(after['hist'].get_center()-before['hist'].get_center()).tolist(),'payload_unchanged':pin,'all_VO_bookmarks_math_strings_and_requested_timing_exact':True,'other3methods_AST_exact':True,'limits':'Source/constructor geometry only; two originalbefore854images actuallyviewed. No new scene render/decode, no continuous/audio/currentproductionapproval.'}
(D/f'geometry-{language}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'language':language,'PASS':True,'margins':frame_margin,'separations':separations,'y_title_history_clearance_px':report['y_title_history_clearance_px']},indent=2))
