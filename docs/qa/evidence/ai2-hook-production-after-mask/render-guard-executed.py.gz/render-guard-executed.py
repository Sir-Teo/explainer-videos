from pathlib import Path
import json,os,signal,shutil,subprocess,sys,time
ROOT=Path('/workspace/explainer-videos');OUT=ROOT/'renders/qa/production-motion-1080-after-year-mask';OUT.mkdir(parents=True,exist_ok=True);CG=Path('/sys/fs/cgroup');limit=int((CG/'memory.max').read_text());base_events=dict((k,int(v)) for k,v in (x.split() for x in (CG/'memory.events').read_text().splitlines()));start=time.monotonic();env=dict(os.environ)
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):env[key]='1'
log=(OUT/'hook-en-render.log').open('w');guard=(OUT/'hook-en-resource.jsonl').open('w');p=subprocess.Popen(['nice','-n','15',sys.executable,'/workspace/runtime/qa_production_motion_after_year_mask.py','ai2','en','Hook'],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);stop=None
while True:
 elapsed=time.monotonic()-start;ms=dict((k,int(v)) for k,v in (x.split() for x in (CG/'memory.stat').read_text().splitlines()));events=dict((k,int(v)) for k,v in (x.split() for x in (CG/'memory.events').read_text().splitlines()));free=shutil.disk_usage(ROOT).free;hard=ms.get('anon',0)+ms.get('shmem',0)+ms.get('kernel',0)-ms.get('slab_reclaimable',0);exitcode=p.poll();sample={'elapsed_seconds':round(elapsed,2),'pid':p.pid,'disk_free_bytes':free,'cgroup_memory_bytes':int((CG/'memory.current').read_text()),'anonymous_bytes':ms.get('anon',0),'file_cache_bytes':ms.get('file',0),'nonreclaimable_estimate_bytes':hard,'memory_limit_bytes':limit,'oom_kill_delta':events.get('oom_kill',0)-base_events.get('oom_kill',0),'exit_code':exitcode};guard.write(json.dumps(sample)+'\n');guard.flush()
 if exitcode is not None:break
 if free<3*2**30:stop='disk below3GiB'
 elif hard>limit-2*2**30:stop='less than2GiB beyond anonymous/nonreclaimable estimate'
 elif sample['oom_kill_delta']>0:stop='new cgroup OOM kill observed'
 elif elapsed>1800:stop='30minute bounded pilot timeout'
 if stop:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=20)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  break
 time.sleep(3)
log.close();guard.close();receipt={'pid':p.pid,'exit_code':p.returncode,'stop_reason':stop,'elapsed_seconds':time.monotonic()-start,'outcome':'stopped guard' if stop else 'process completed; inspect render result','baseline_memory_events':base_events};(OUT/'hook-en-guard-result.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(0 if p.returncode==0 and stop is None else 1)
