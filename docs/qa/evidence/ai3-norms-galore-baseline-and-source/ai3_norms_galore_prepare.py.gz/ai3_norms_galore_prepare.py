from pathlib import Path
import json,hashlib,math,datetime,shutil,sys,subprocess
from PIL import Image,ImageDraw
R=Path('/workspace/explainer-videos');P=Path('/workspace/runtime/ai3-norms-galore-motion-review.json');key=sys.argv[1];lang,scene=key.split('/');base=Path('/workspace/runtime/ai3-norms-galore-motion-evidence')/key;base.mkdir(exist_ok=True,parents=True);folder=R/f'renders/qa/temporal/ai3-{lang}-{scene}-dense-final';ap=folder/'result.json';a=json.loads(ap.read_text());cp=R/f'renders/qa/series/ai3/{lang}/{scene}_motion/result.json';cap=json.loads(cp.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
source={'Power':'s07_power.py','SVD':'s08_svd.py','LowRank':'s09_lowrank.py','Norms':'s10_norms.py','GaLore':'s12_galore.py'}[scene];sp=R/'videos/ai/ai3'/source
r=json.loads(P.read_text()) if P.exists() else {'scope':'Dense selected-frame visual review of Part3 Norms/GaLore EN+ZH; complete-file decoding automatic. Continuous perceptual playback, audio/listening and final-resolution review remain unverified.','created_utc':now,'expected_cases':[f'{l}/{s}' for s in ['Norms','GaLore'] for l in ['en','zh']],'cases':{}}
assert key not in r['cases'],'Already prepared; do not reset reviewed pages'
shutil.copy2(R/'tools/qa_motion.py',base/'qa_motion.snapshot.py');shutil.copy2(cp,base/'capture-result.json');shutil.copy2(ap,base/'temporal-audit-result.json');shutil.copy2(a['source'],base/'reviewed-movie.mp4');shutil.copy2(sp,base/source);assert sha(a['source'])==a['source_sha256'];seen=set();picks=[]
for f in a['selected_frames']:
 if f['sha256'] not in seen:picks.append(f);seen.add(f['sha256'])
pages=[]
for n,start in enumerate(range(0,len(picks),8),1):
 chunk=picks[start:start+8];tiles=[]
 for f in chunk:
  assert sha(folder/f['file'])==f['sha256']
  with Image.open(folder/f['file']) as im:
   w=640;h=round(im.height*w/im.width);t=Image.new('RGB',(w,h+34),'#202732');t.paste(im.convert('RGB').resize((w,h)),(0,34));d=ImageDraw.Draw(t);d.text((8,3),f"{f['time']:.3f}s / frame {f['source_frame']}",fill='white');d.text((8,18),'Exact PNG representative; duplicate times mapped separately',fill='#c6d6e9');tiles.append(t)
 w,h=tiles[0].size;sheet=Image.new('RGB',(2*w,math.ceil(len(tiles)/2)*h),'#0e1117')
 for i,t in enumerate(tiles):sheet.paste(t,((i%2)*w,(i//2)*h))
 p=base/f'unique-{n:03}.png';sheet.save(p);pages.append({'page':n,'file':str(p),'sha256':sha(p),'frames':chunk})
inputs={}
for rel,recorded in cap.get('inputs',{}).items():
 p=R/rel
 if p.exists():
  dst=base/'inputs'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
  s=p.stat();inputs[rel]={'sha256':sha(p),'size':s.st_size,'mtime_ns':s.st_mtime_ns,'capture_size_mtime_match':[s.st_size,s.st_mtime_ns]==recorded}
 else:inputs[rel]={'missing_at_review':True}
c={'scene':scene,'lang':lang,'capture_record':str(cp),'capture_sha256':sha(cp),'capture_snapshot':str(base/'capture-result.json'),'capture_status':cap['status'],'capture_warnings':cap['warnings'],'capture_fingerprint':cap['fingerprint'],'capture_inputs':cap.get('inputs',{}),'input_hashes_at_review':inputs,'scene_source':str(sp),'scene_source_sha256':sha(sp),'scene_source_snapshot':str(base/source),'audit_folder':str(folder),'audit_sha256':sha(ap),'audit_snapshot':str(base/'temporal-audit-result.json'),'audit_provenance':a['provenance'],'tool_sha256':a['tool_sha256'],'movie':a['source'],'movie_sha256':a['source_sha256'],'movie_snapshot':str(base/'reviewed-movie.mp4'),'duration':a['duration'],'decoded_frames':a['analysis']['decoded_frames'],'selected_frames':len(a['selected_frames']),'unique_pngs':len(picks),'maximum_selected_time_gap':a['largest_selected_time_gap'],'pages':pages,'reviewed_pages':[],'frame_coverage':[{'frame':f['source_frame'],'time':f['time'],'sha256':f['sha256'],'file':str(folder/f['file']),'coverage':'not_yet_reviewed'} for f in a['selected_frames']],'unselected_source_intervals':[{'after_frame':x['source_frame'],'before_frame':y['source_frame'],'start':x['time'],'end':y['time'],'unextracted_frames':y['source_frame']-x['source_frame']-1} for x,y in zip(a['selected_frames'],a['selected_frames'][1:]) if y['source_frame']>x['source_frame']+1],'findings':[],'native_followups':[],'review_status':'in_progress','prepared_utc':now}
r['cases'][key]=c;P.write_text(json.dumps(r,indent=2)+'\n');print(key,'decoded',c['decoded_frames'],'selected',c['selected_frames'],'unique',len(picks),'pages',len(pages))
