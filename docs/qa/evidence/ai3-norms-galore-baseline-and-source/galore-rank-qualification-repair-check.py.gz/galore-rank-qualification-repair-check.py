from pathlib import Path
import ast,json,hashlib,re,copy
import numpy as np
from explainer.ai import *
from explainer import zh_text,lang
from explainer.analysis import WIDE_TEX
repo=Path('/workspace/explainer-videos');out=Path(__file__).parent;p=repo/'videos/ai/ai3/s12_galore.py';t=ast.parse(p.read_text());old=ast.parse((out/'s12_galore.py.before').read_text());cls=next(x for x in t.body if isinstance(x,ast.ClassDef));method=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='lora')
strings={r'a sum of outer products: \ rank at most one each':r'外积之和：每个的秩至多为$1$',r'LoRA (2021): \ the \textit{change} has rank $\le r$, \ always':r'LoRA（2021）：变化的秩始终$\le r$',r'GaLore: \ each \textit{step} has rank $\le r$; \ the window moves':r'GaLore：每一步的秩$\le r$；窗口会移动'}
(out/'captions-handoff.json').write_text(json.dumps({'strings':strings},ensure_ascii=False,indent=2)+'\n')
zh_text.install(WIDE_TEX);table=json.loads((repo/'videos/ai/ai_text_zh.json').read_text());table['strings'].update(strings);zh_text._TABLE=table
measure=[]
for language in ['en','zh']:
 lang.LANG=language;env=dict(globals());nodes=[x for x in method.body if isinstance(x,ast.Assign) and isinstance(x.targets[0],ast.Name) and x.targets[0].id in ['lo','ga'] or isinstance(x,ast.For) and ast.unparse(x.target)=='v' or isinstance(x,ast.Expr) and ast.unparse(x).startswith('VGroup(lo, ga)')];exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual-LoRA-panels','exec'),env)
 lo,ga=env['lo'],env['ga'];bounds=[]
 for obj in [lo,ga]:
  b=[float(obj.get_left()[0]),float(obj.get_right()[0]),float(obj.get_bottom()[1]),float(obj.get_top()[1])];bounds.append(b);assert b[0]>-config.frame_width/2 and b[1]<config.frame_width/2 and b[2]>-4 and b[3]<4
 assert lo.get_right()[0]+1.19<ga.get_left()[0]
 whyexpr=next(x.args[0] for x in ast.walk(t) if isinstance(x,ast.Call) and getattr(x.func,'id','')=='why' and x.args and isinstance(x.args[0],ast.Constant) and 'outer products' in str(x.args[0].value));msg=why(eval(compile(ast.Expression(whyexpr),'actual-why','eval'),env));measure.append({'lang':language,'comparison_bounds':bounds,'outerproduct_why_width':float(msg.width)})
vo=lambda tr:[x for x in ast.walk(tr) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='voiceover'];changes=[]
for a,b in zip(vo(old),vo(t)):
 if ast.dump(a)!=ast.dump(b):
  aa,bb=ast.unparse(a.args[0]),ast.unparse(b.args[0]);assert re.findall(r"<bookmark[^>]+/>",aa)==re.findall(r"<bookmark[^>]+/>",bb);changes.append({'before':aa,'after':bb})
assert len(changes)==2
# Tiny numerical rank edge cases only, never production data/model computation.
x=np.array([1.,2.]);zero=np.zeros(3);assert np.linalg.matrix_rank(np.outer(zero,x))==0
B=np.array([[1.,0.],[0.,0.],[0.,0.]]);A=np.eye(2);assert np.linalg.matrix_rank(B@A)==1<2
r={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'zh_lines_sha256':hashlib.sha256((p.parent/'zh_lines.py').read_bytes()).hexdigest(),'voiceover_changes':changes,'bookmarks_preserved':True,'geometry':measure,'rank_counterexamples':{'zero_outerproduct_rank':0,'rank_deficient_BA_rank':1,'factor_rank_bound_r':2},'limits':'Pure AST-selected text geometry and tiny symbolic fixtures only. New caption/VO timing and movie appearance pending.'};(out/'checks.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(r,ensure_ascii=False))
