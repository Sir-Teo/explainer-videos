import ast,hashlib,json,os
from pathlib import Path
import numpy as np
from explainer.ai import *
p=Path('/workspace/explainer-videos/videos/ai/ai3/s10_norms.py');t=ast.parse(p.read_text());m=next(x for x in t.body if isinstance(x,ast.ClassDef));method=next(x for x in m.body if isinstance(x,ast.FunctionDef) and x.name=='two_sizes')
env=dict(globals(),SIG=C.BITS);node=method.body[0];exec(compile(ast.Module(body=[node],type_ignores=[]),'actual-defs','exec'),env);defs=env['defs']
play=next(x for x in ast.walk(method) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='play' and any(isinstance(a,ast.Call) and getattr(a.func,'id','')=='Circumscribe' for a in x.args));assert ast.literal_eval(next(k.value for k in play.keywords if k.arg=='run_time'))==1.5
out=[]
for call,target in zip(play.args,defs):
 anim=eval(compile(ast.Expression(call),'actual-emphasis','eval'),env);family=target.family_members_with_points();points=[x.get_points().copy() for x in family];styles=[(x.get_fill_color().to_hex(),x.get_fill_opacity(),x.get_stroke_color().to_hex(),x.get_stroke_opacity(),x.get_stroke_width()) for x in family]
 anim._setup_scene(Scene());anim.begin();bounds=[]
 for a in np.linspace(0,1,41):
  anim.interpolate(float(a))
  for x,pts,style in zip(family,points,styles):
   np.testing.assert_array_equal(x.get_points(),pts);assert (x.get_fill_color().to_hex(),x.get_fill_opacity(),x.get_stroke_color().to_hex(),x.get_stroke_opacity(),x.get_stroke_width())==style
  outline=anim.animations[0].mobject
  b=[float(outline.get_left()[0]),float(outline.get_right()[0]),float(outline.get_bottom()[1]),float(outline.get_top()[1])];bounds.append(b)
  assert b[0]>-config.frame_width/2 and b[1]<config.frame_width/2 and b[2]>-4 and b[3]<4
 anim.finish();out.append({'41_actual_animation_samples':True,'target_geometry_and_styles_unchanged':True,'outline_bounds_minmax':np.array(bounds).min(axis=0).tolist()+np.array(bounds).max(axis=0).tolist()})
r={'lang':os.environ.get('EXPLAINER_LANG','en'),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'run_time':1.5,'cards':out,'limits':'Actual Manim object animation fixture; no production scene import/render/load; fresh rendered appearance pending.'};q=Path(__file__).parent/('fixture-'+r['lang']+'.json');q.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
