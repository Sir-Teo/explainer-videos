from pathlib import Path
import json,hashlib,gzip,shutil,datetime
B=Path('/workspace/explainer-videos');R=Path('/workspace/runtime');O=R/'ai4-tail-endpoint-review';D=B/'docs/qa/evidence/ai4-tail-endpoint-review';D.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
r=json.loads((O/'endpoint-review-checkpoint-10cases.json').read_text());assert r['reviewed_case_count']==10 and r['reviewed_endpoint_count']==124 and r['native_views']==35 and not r['pending_cases']
origins=[]
def gz(src,dest):
 data=src.read_bytes();p=D/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(data,compresslevel=9,mtime=0));assert gzip.decompress(p.read_bytes())==data
 origins.append({'origin':str(src),'package':dest,'raw_sha256':sha(data),'raw_bytes':len(data),'compressed_sha256':sha(p.read_bytes()),'compressed_bytes':p.stat().st_size})
for scene in r['scenes']:
 lang=scene['lang'];name=scene['scene'];src=O/lang/name;dst=D/lang/name;dst.mkdir(parents=True)
 for file in ['sheet.png']+[f['file'] for f in scene['frames']]:
  p=src/file;shutil.copyfile(p,dst/file)
  expected=scene['sheet_sha256'] if file=='sheet.png' else next(f['sha256'] for f in scene['frames'] if f['file']==file)
  assert sha((dst/file).read_bytes())==expected
 for file in ['result.json','text.jsonl','render.log','snapshot.json','current-source.py']:
  p=src/file
  if p.exists():gz(p,f'{lang}/{name}/{file}.gz')
for file in ['quadratic-caption-add.json','quadratic-caption-compile.json','compile_quadratic_captions.py','update_review.py']:
 gz(O/file,'caption-fix-and-procedure/'+file+'.gz')
gz(O/'endpoint-review-checkpoint-10cases.json','full-review.json.gz');gz(R/'ai4-source-review-final-freeze.json','source-checkpoint.json.gz')
freeze=json.loads((R/'ai4-source-review-final-freeze.json').read_text());fm={x['path']:x['sha256'] for x in freeze['files']};direct=[]
for scene in r['scenes']:
 module={'Quadratic':'s15_quadratic','Lagrange':'s16_lagrange','KKT':'s17_kkt','Implicit':'s18_implicit','Outro':'s19_outro'}[scene['scene']];path=f'videos/ai/ai4/{module}.py'
 assert scene['disk_source_snapshot_sha256']==fm[path]==sha((B/path).read_bytes())
 assert all(i['metadata_matches'] for i in scene['inputs'])
 direct.append({'scene':scene['scene'],'lang':scene['lang'],'source':path,'sha256':fm[path],'disk_bytes_still_match_checkpoint':True,'input_size_mtime_matches_record':True})
summary={'scope':r['scope'],'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewed_cases':10,'endpoint_images_actually_viewed_on_sheets':124,'native854x480_followups':35,'contact_sheet_tile_scale':'427x240 pixels; no perceptual/identical-image inheritance claimed','direct_source_checks':direct,'review_status':'Sampled endpoint review completed; runtime statuses/warnings preserved unchanged. No full-playback or audio approval.','new_issue_found':'Minor Chinese KKT comma begins wrapped second line; correct readable meaning, no clipping. Parent notified; frozen source/table unchanged.','resolved_warning':'Initial ENQuadratic3missing captions exact-proposed and actually TeX-compiled; final ZHcomparison/escape native images verify all3 captions visible. Original ENwarning record preserved.','full_report':'full-review.json.gz','source_checkpoint_sha256':sha((R/'ai4-source-review-final-freeze.json').read_bytes()),'source_proof_limit':'Same direct scene disk bytes at snapshot and final check; not loaded-module proof inferred from later hash. Original broad source-changed warnings remain.','images':'All124 declared endpoint PNGs and10 actual contact sheets preserved exactly; no silent/full/narrated movie copied.','limitations':['No intervening animation, continuous playback, narrated listening, pronunciation, AV synchronization or player/responsive review.','No native1080p tail output reviewed; actual native priority images here are854x480.','English/Chinese wording branches beyond rendered default outcomes are not visually reviewed.','Technical footers are small at480p; higher-resolution verification is separate.','Outros first endpoint occurs67.51sEN/73.46sZH, so the lead-in animation is not visually covered by this endpoint review.'],'source_package_immutable':'../ai4-source-review remains the distinct200-file78ae73checkpoint; this package neither mutates it nor reclassifies its old test receipts.'}
(D/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
rows=[]
for s in r['scenes']:
 link=f"[{s['lang'].upper()} {s['scene']}]({s['lang']}/{s['scene']}/sheet.png)"
 warnings=', '.join(w['kind'] for w in s['warnings']) or 'none'
 rows.append(f"| {link} | {s['captured_frames_reviewed']} | {len(s['native_priority_frames_actually_viewed'])} | {s['record_status']} | {warnings} |")
md='''# Part 4 tail endpoint image review

All **10 English/Chinese cases** (Quadratic through Outro) are covered by actual review of **124 declared endpoint PNGs**, with **35 additional native854×480 inspections** of critical states. Every image was viewed on its427×240contact-sheet tile; exact filenames, times, SHA256 values, native followups and unobserved gaps are in `full-review.json.gz`. There was no visual inheritance from unviewed older output.

| Contact sheet | Endpoint images reviewed | Native followups | Original runtime status | Preserved warnings |
|---|---:|---:|---|---|
'''+ '\n'.join(rows)+'''

No concrete clipping, overlap or mathematical/label contradiction was found in the sampled states. Native checks cover the contraction-factor definition and measured comparisons; Lagrange necessary-only regularity and distinct beta conventions; the complete free-intercept SVM dual, solver residuals and one-way slackness; finite-grid limitations and honest vertical range; implicit differentiation and solve/status cohorts; recap/problem/payoff/reference layouts.

The initial English Quadratic record had three untranslated captions. Exact proposed keys and actual isolated Chinese TeX compilations are preserved. Native final Chinese comparison/escape frames show all three translations correctly without clipping or overlap; the original English warnings remain intact rather than being rewritten as a pass.

One minor actual typography concern remains: [Chinese KKT final state](zh/KKT/012_00184.9s.png) starts the second line of its upper-left slackness caption with a comma. Its mathematical meaning remains correct and readable. The parent was notified; frozen source/table bytes were not changed by this review.

The exact five direct scene modules still match the parent's78ae73source checkpoint, as recorded in `summary.json`. Original broad source-changed warnings remain preserved; later disk hashes alone are not used to assert loaded-module identity. Raw input file SHA256 values and recorded/current size/mtime comparisons are retained without importing producers, loading models or computing results.

This evidence is **sampled endpoint review only**. Intervening motion, continuous playback, narrated listening, pronunciation, audio synchronization and player behavior remain unreviewed. Native priority images here are854×480, not1080p production output. Technical footers are small at480p. Outro’s first selected summary state occurs at67.51sEN/73.46sZH; the earlier animation has no endpoint coverage in these records. No full movie is included or approved.

All124 declared PNGs,10 sheets and original result/text/process receipts are preserved, with compressed source snapshots and a complete payload manifest. This separate package leaves the [200-file source checkpoint](../ai4-source-review/README.md) unchanged; it does not extend historical source/test receipts into playback or audio approval. No scene/shared-table/STATUS edits, production renders, numerical producer jobs, model loads, commits or pushes were performed by this review.
'''
for a,b in [('native854','native 854'),('its427','its 427'),('240contact','240 contact'),("parent's78ae73source","parent's 78ae73 source"),('are854','are 854'),('not1080','not 1080'),('at480','at 480'),('at67.51sEN/73.46sZH','at 67.51s EN / 73.46s ZH'),('All124','All 124'),('PNGs,10','PNGs, 10')]:md=md.replace(a,b)
(D/'README.md').write_text(md)
gz(Path(__file__),'package-builder.py.gz');(D/'compressed-origins.json').write_text(json.dumps(origins,indent=2)+'\n')
files={str(p.relative_to(D)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(D.rglob('*')) if p.is_file()};(D/'manifest.json').write_text(json.dumps(files,indent=2)+'\n')
for file,v in files.items():assert sha((D/file).read_bytes())==v['sha256']
source_manifest=B/'docs/qa/evidence/ai4-source-review/manifest.json';assert sha(source_manifest.read_bytes())=='2df0b6d5d20e3cb49dfb826c0efa4c3a8f6b8e5d3b01b7b50631738b9cd7848a'
print(json.dumps({'package':str(D),'files':len(files)+1,'total_bytes':sum(p.stat().st_size for p in D.rglob('*') if p.is_file()),'manifest_sha256':sha((D/'manifest.json').read_bytes()),'reviewed_endpoint_images':124,'native_followups':35,'old_source_package_manifest_unchanged':True},indent=2))
