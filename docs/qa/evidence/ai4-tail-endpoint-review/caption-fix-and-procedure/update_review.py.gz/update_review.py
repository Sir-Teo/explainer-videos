from pathlib import Path
import json,hashlib,datetime,os
O=Path(__file__).parent;B=Path('/workspace/explainer-videos')
VIEWS={
 ('en','Quadratic'):['004_00036.0s.png','011_00116.0s.png','015_00183.2s.png'],
 ('en','Lagrange'):['013_00118.9s.png','016_00172.9s.png'],
 ('en','KKT'):['001_00005.2s.png','008_00108.8s.png','011_00162.3s.png','012_00178.2s.png'],
 ('en','Implicit'):['003_00040.9s.png','007_00105.2s.png','010_00152.8s.png'],
 ('en','Outro'):['000_00067.5s.png','001_00100.6s.png','002_00105.6s.png','003_00125.5s.png','004_00142.5s.png'],
 ('zh','Quadratic'):['004_00035.6s.png','011_00115.5s.png','015_00179.7s.png'],
 ('zh','Lagrange'):['009_00080.0s.png','013_00124.1s.png','016_00181.0s.png'],
 ('zh','KKT'):['001_00005.6s.png','008_00113.1s.png','011_00166.0s.png','012_00184.9s.png'],
 ('zh','Implicit'):['003_00035.5s.png','007_00102.5s.png','010_00157.4s.png'],
 ('zh','Outro'):['000_00073.5s.png','001_00112.1s.png','002_00117.1s.png','003_00138.3s.png','004_00156.9s.png'],
}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
scenes=[]
for (lang,scene),native in VIEWS.items():
 d=O/lang/scene;x=json.loads((d/'result.json').read_text());snap=json.loads((d/'snapshot.json').read_text())
 frames=[{'file':f['file'],'time':f['time'],'reason':f['reason'],'sha256':sha(d/f['file']),'actual_view':'Native854x480 and contact-sheet tile' if f['file'] in native else 'Contact-sheet tile427x240'} for f in x['frames']]
 gaps=[{'from':frames[i]['time'],'to':frames[i+1]['time'],'seconds':frames[i+1]['time']-frames[i]['time']} for i in range(len(frames)-1)]
 inputs=[]
 for name,recorded in x['inputs'].items():
  p=B/name;st=p.stat();inputs.append({'path':name,'recorded_size_mtime_ns':recorded,'current_size_mtime_ns':[st.st_size,st.st_mtime_ns],'metadata_matches':recorded==[st.st_size,st.st_mtime_ns],'current_raw_sha256':sha(p)})
 findings=[]
 if scene=='Quadratic' and lang=='en':findings.append({'kind':'untranslated-on-screen','scope':'All3 original warning keys exact-proposed and isolated-Tex-compiled; actual refreshed Chinese view reported separately. Historical ENresult warning remains preserved.'})
 if scene=='KKT' and lang=='zh':findings.append({'kind':'minor-typography','file':'012_00184.9s.png','scope':'Upper-left complementary-slackness caption wraps comma to start of second line. Meaning remains correct/readable; no clipping. Reported to parent without editing frozen source/table.'})
 if scene=='Quadratic' and lang=='zh':findings.append({'kind':'caption-fix-verified-sampled','scope':'All3 previously missing axis-caption translations are visible in actual native final benchmark/escape frames without clipping or overlap; no full-animation approval.'})
 scenes.append({'scene':scene,'lang':lang,'record_status':x['status'],'warnings':x['warnings'],'fingerprint':x['fingerprint'],'inputs':inputs,'duration':x['duration'],'result_sha256':snap['result_sha256'],'disk_source_snapshot_sha256':snap['source_snapshot_sha256'],'source_proof_limit':snap['scope'],'sheet_sha256':sha(d/'sheet.png'),'all_sheet_tiles_actually_viewed':True,'captured_frames_reviewed':len(frames),'native_priority_frames_actually_viewed':native,'frames':frames,'first_selected_time':frames[0]['time'],'last_selected_time':frames[-1]['time'],'uncovered_intervals_between_endpoints':gaps,'max_selected_time_gap':max(g['seconds'] for g in gaps),'findings':findings,'visual_assessment':'No concrete overlap, clipping or mathematical/label contradiction found in the inspected sampled states. Technical footers are small at480p; production-resolution verification remains separate.'})
r={'checkpoint_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual sampled endpoint review. Every declared image in each listed case maps to a viewed contact-sheet tile; listed priority images additionally viewed native854x480. Does not inspect intervening animation or audio. No continuous playback, narrated listening/synchronization, responsive-player or unrendered branch approval. Broad source-changed warnings remain distinct from direct disk source snapshots; later source hash alone does not prove loaded-module identity.','reviewed_case_count':len(scenes),'reviewed_endpoint_count':sum(s['captured_frames_reviewed'] for s in scenes),'native_views':sum(len(s['native_priority_frames_actually_viewed']) for s in scenes),'scenes':scenes,'pending_cases':[f'{lang}/{scene}' for lang in ['en','zh'] for scene in ['Quadratic','Lagrange','KKT','Implicit','Outro'] if (lang,scene) not in VIEWS],'source_or_global_edits':False,'source_package_unchanged':'docs/qa/evidence/ai4-source-review is a separate source checkpoint; these later endpoint notes do not alter or extend its validation claims.'}
output=O/f'endpoint-review-checkpoint-{len(scenes)}cases.json';assert not output.exists();output.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
print(output, r['reviewed_endpoint_count'],'endpoints',r['native_views'],'native',r['pending_cases'])
