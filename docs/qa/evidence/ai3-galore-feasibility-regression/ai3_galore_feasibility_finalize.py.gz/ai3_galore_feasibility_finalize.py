from pathlib import Path
import datetime,hashlib,json,shutil
from PIL import Image,ImageDraw
repo=Path('/workspace/explainer-videos');rt=Path('/workspace/runtime');p=rt/'ai3-galore-feasibility-motion-review.json';d=json.loads(p.read_text());e=rt/'ai3-galore-feasibility-endpoints/review.json';endpoints=json.loads(e.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected='a5dbaa9950a3386c48974486571251dc85f851e7c2d0806223177feba80d4ed4'
assert sha(repo/'videos/ai/ai3/s12_galore.py')==expected
tool='1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e'
old=json.loads((rt/'ai3-norms-galore-repair-motion-review.json').read_text())
for key,c in d['cases'].items():
    assert c['tool_sha256']==tool and c['scene_source_sha256']==expected
    assert c['coverage_counts']['not_yet_reviewed']==0 and len(c['reviewed_pages'])==len(c['pages'])
    assert sha(c['movie_snapshot'])==c['movie_sha256'] and sha(c['capture_snapshot'])==c['capture_sha256']
    assert c['maximum_selected_time_gap']<=1.00001
    for pg in c['reviewed_pages']:assert sha(pg['file'])==pg['sha256']
    for f in c['frame_coverage']:
        assert sha(f['file'])==f['sha256']
        if f['coverage']=='exact_png_inherited_from_completed_baseline':
            assert sha(f['baseline_file'])==f['sha256'] and sha(f['baseline_report'])==f['baseline_report_sha256']
    for value in c['input_hashes_at_review'].values():
        if not value.get('missing_at_review'):assert value['capture_size_mtime_match']
    target=99.133 if c['lang']=='en' else 103.2
    f=min(c['frame_coverage'],key=lambda f:abs(f['time']-target))
    c['native_followups']=[{'file':f['file'],'sha256':f['sha256'],'time':f['time'],'source_frame':f['frame'],'observations':'Actual854x480encoded native: feasibility wording, both projection/update rows, left-projection qualifier and optimizer-state readouts clear. No clipping or overlap.'}]
    c['table_snapshot']=str(Path(c['scene_source_snapshot']).parent/'ai_text_zh.snapshot.json');c['table_sha256']=sha(c['table_snapshot'])
    c['zh_lines_snapshot']=str(Path(c['scene_source_snapshot']).parent/'zh_lines.snapshot.py');c['zh_lines_sha256']=sha(c['zh_lines_snapshot'])
    c['silent_duration_change_from_baseline']=c['duration']-old['cases'][key]['duration']
    c['findings']=[{'status':'repair_verified_at_selected_frame_scope','observation':'Corrected memory-feasibility caption stays legible through reveal, derivation, optimizer-memory display, longer narration placeholder hold and fade. No new defect found.','caveat':'Whole-file decoding is automatic; selected-frame coverage is not continuous perceptual playback or listening.'}]
    c['review_status']='completed_bounded_selected_frame_regression'
for key,c in endpoints['cases'].items():
    assert c['source_sha256']==expected
    for pg in c['pages']:assert pg['reviewed'] and sha(pg['file'])==pg['sha256']
    for f in c['frames']:
        assert f['coverage']!='not_yet_reviewed' and sha(f['file'])==f['sha256']
        if f['coverage']=='exact_png_inherited':assert sha(f['baseline_file'])==f['sha256']
    for val in c['input_receipts'].values():
        if not val.get('absent'):assert val['size_mtime_matches_capture']
    c['review_status']='completed_bounded_endpoint_regression'
comparison=rt/'ai3-galore-feasibility-native-before-after';comparison.mkdir(exist_ok=True)
prior=json.loads((rt/'ai3-production1080-foundations/review.json').read_text())
before_after=[]
for language in ['en','zh']:
    before=prior['cases'][language+'/GaLore']['frames'][13]
    after=endpoints['cases'][language+'/1080']['frames'][13]
    assert sha(before['file'])==before['sha256'] and sha(after['file'])==after['sha256']
    images=[]
    for tag,f in [('Before: completed-run overstatement',before),('After: memory feasibility',after)]:
        dest=comparison/(language+'-'+tag.split(':')[0].lower()+'.png');shutil.copy2(f['file'],dest)
        with Image.open(dest) as im:
            im=im.convert('RGB');assert im.size==(1920,1080);tile=Image.new('RGB',(960,570),'#202732');tile.paste(im.resize((960,540)),(0,30));ImageDraw.Draw(tile).text((10,8),f"{language}: {tag} ({f['time']:.3f}s)",fill='white');images.append(tile)
    sheet=Image.new('RGB',(1920,570),'#101318');sheet.paste(images[0],(0,0));sheet.paste(images[1],(960,0));dest=comparison/(language+'-before-after.png');sheet.save(dest)
    before_after.append({'lang':language,'file':str(dest),'sha256':sha(dest),'before_file':before['file'],'before_sha256':before['sha256'],'after_file':after['file'],'after_sha256':after['sha256'],'note':'Derived comparison uses actual1920x1080endpoint images, scaled to960x540tiles; originals preserved alongside. It is an endpoint comparison,not motion.'})
d['summary']={'selected_frames':sum(c['selected_frames'] for c in d['cases'].values()),'decoded_source_frames':sum(c['decoded_frames'] for c in d['cases'].values()),'new_directly_inspected':sum(c['coverage_counts']['directly_inspected'] for c in d['cases'].values()),'new_exact_duplicate_times':sum(c['coverage_counts']['exact_png_duplicate_of_inspected'] for c in d['cases'].values()),'exact_inherited_times':sum(c['coverage_counts']['exact_png_inherited_from_completed_baseline'] for c in d['cases'].values()),'new_reviewed_pages':sum(len(c['reviewed_pages']) for c in d['cases'].values()),'native_motion_followups':2,'endpoint_images':sum(len(c['frames']) for c in endpoints['cases'].values()),'endpoint_new_direct_images':sum(sum(f['coverage']=='directly_inspected_on_recorded_page' for f in c['frames']) for c in endpoints['cases'].values()),'endpoint_exact_inherited_images':sum(sum(f['coverage']=='exact_png_inherited' for f in c['frames']) for c in endpoints['cases'].values()),'endpoint_changed_pages':sum(len(c['pages']) for c in endpoints['cases'].values()),'native1080followups':2,'before_after':before_after,'unreviewed_selected_times':0,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limits':'No continuous perceptual playback,real speech/audio synchronization,listening,full-production motion or player/responsive claim. Source-change warning captures retain their raw status; scoped source/data/caption equivalence does not establish historical whole-part worker imports.'}
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');e.write_text(json.dumps(endpoints,ensure_ascii=False,indent=2)+'\n')
lines=['# GaLore memory-feasibility correction: actual regression','',
'Fresh English and Chinese full silent preview movies were decoded completely. Every selected appearance is accounted for using direct chronological views or exact PNG hashes tied to the completed owned baseline. New method-card wording, derivation, memory bars, added narration placeholder hold and transitions have no new observed defect. Native 1920×1080 endpoint views confirm readable text and mathematical labels.','',
'| Case | Decoded frames | Selected | New viewed | New exact duplicates | Exact baseline | Native follow-ups | Raw capture status |','|---|---:|---:|---:|---:|---:|---:|---|']
for k,c in d['cases'].items():
    cc=c['coverage_counts'];lines.append(f"|{k}|{c['decoded_frames']}|{c['selected_frames']}|{cc['directly_inspected']}|{cc['exact_png_duplicate_of_inspected']}|{cc['exact_png_inherited_from_completed_baseline']}|1|{c['capture_status']}|")
lines+=['','The maximum selected-time gap is1second,with RGB-detected transition extras. All unselected source intervals remain enumerated in the complete JSON ledger. All147new representatives were inspected on20pages,with58byte-identical duplicate times and640exact inherited appearances. All86fresh endpoint images across preview/native resolutions are covered:16new images viewed on4pages and70exact inherited images. Two native preview-motion follow-ups and two native1920×1080endpoint follow-ups checked the actual encoded card,projection/update formulas,memory cells and readouts.','',
'The six original capture outcomes remain unchanged: ENpreview endpoints passed; ZHpreview endpoints need review for source change; ENmotion needs review for source change; ZHmotion passed; EN1080endpoints passed; ZH1080endpoints need review for source change. All three warnings are preserved. The scoped GaLore module and data match the frozen repair; the exact caption-table snapshot and displayed wording are pinned. These scoped checks do not prove historical whole-part worker imports.','',
'The added wording changes silent estimated duration by approximately5.33seconds in English and5.67seconds in Chinese. This is not a listening or real narration-alignment result. Full production-resolution motion,continuous perceptual playback,real speech/audio synchronization and player behavior remain unverified.','',
'The complete ledger preserves every selected timestamp,source frame,PNG SHA,viewed page and time range,exact inheritance receipt,full movie/tool/source/input provenance,raw warnings and unselected intervals. Before/after native endpoint originals and derived comparison sheets are preserved separately. No scene,caption,data,producer or model was changed during this regression.','']
(rt/'ai3-galore-feasibility-motion-review.md').write_text('\n'.join(lines))
print(json.dumps({'report_sha256':sha(p),'endpoint_report_sha256':sha(e),'summary':d['summary']},ensure_ascii=False,indent=2))
