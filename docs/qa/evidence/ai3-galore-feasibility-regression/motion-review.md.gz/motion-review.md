# GaLore feasibility wording: actual rendered regression

The fresh English and Chinese full silent preview movies were decoded completely. Every selected appearance is accounted for through chronological direct views or exact PNG hashes tied to the completed owned baseline. The corrected method card, derivation, memory readouts, extended narration placeholder hold and transitions have no new observed defect. Native 1920×1080 endpoint views confirm readable text and mathematical labels.

| Case | Decoded frames | Selected | New views | New exact duplicates | Exact baseline | Raw motion capture |
|---|---:|---:|---:|---:|---:|---|
| English |3151|410|73|24|313|needs review: source changed|
| Chinese |3224|435|74|34|327|passed, zero warnings|

All 845 selected times are covered: 147 new representatives viewed on 20 pages, 58 byte-identical duplicate times and 640 exact inherited appearances. The maximum selected-time gap is one second, with additional RGB-detected transition frames. All unselected source intervals remain enumerated in the JSON ledger. Full decoding is automated and does not establish continuous perceptual playback.

All 86 fresh endpoint images across preview and native resolutions are covered: 16 new images viewed on four pages and 70 exact inherited images. Two native encoded-preview motion follow-ups and two native 1920×1080 endpoint follow-ups checked the actual card, projection/update formulas, state cells and all three memory counts. Before/after comparison sheets were also viewed; original native images are preserved.

All six original capture outcomes remain unchanged. English preview endpoints, Chinese motion and English 1080p endpoints passed. Chinese preview endpoints, English motion and Chinese 1080p endpoints each retain a source-change warning and `needs-review` status. The scoped GaLore module, inputs and displayed caption match the frozen repair. The caption table hash is pinned. The Chinese method entry is identical to its freeze despite unrelated Chinese entries changing during the batch. These scoped checks do not establish historical whole-part worker imports or convert broad-warning results into passes.

The new wording lengthens the silent estimated duration by approximately 5.33 seconds in English and 5.67 seconds in Chinese. This is not a listening or real narration-alignment result. Full production-resolution motion, continuous perceptual playback, real speech/audio synchronization and player behavior remain unverified.

The full ledger records every selected timestamp, source frame, PNG hash, viewed page and time range, exact inheritance receipt, movie/tool/source/input provenance, original warning and unselected interval. No scene, caption, data, producer or model was changed during this regression.
