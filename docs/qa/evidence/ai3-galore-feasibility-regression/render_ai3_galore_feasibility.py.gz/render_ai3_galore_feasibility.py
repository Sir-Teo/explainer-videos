from pathlib import Path
import subprocess,hashlib,json,sys,time,os
R=Path('/workspace/explainer-videos');L=sys.argv[1];assert L in ('en','zh');O=Path('/workspace/runtime/ai3-galore-24gb-feasibility-repair')/('render-'+L);O.mkdir(exist_ok=True);S=R/'videos/ai/ai3/s12_galore.py';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();expected='a5dbaa9950a3386c48974486571251dc85f851e7c2d0806223177feba80d4ed4';assert H(S)==expected
rows=[]
for phase,args,record in [('endpoints',['tools/qa_series.py','ai3','--lang',L,'--only','GaLore','--cached-only','--timeout','1200'],R/f'renders/qa/series/ai3/{L}/GaLore/result.json'),('motion',['tools/qa_series.py','ai3','--lang',L,'--only','GaLore','--cached-only','--motion','--timeout','1200'],R/f'renders/qa/series/ai3/{L}/GaLore_motion/result.json'),('native1080',['/workspace/runtime/qa_production_endpoint_galore_feasibility.py','ai3',L,'GaLore'],R/f'renders/qa/production-endpoints-1080-galore-feasibility/ai3/{L}/GaLore/result.json')]:
 assert H(S)==expected;cmd=['nice','-n','10',sys.executable,*args];start=time.monotonic()
 with (O/(phase+'.log')).open('w') as f:p=subprocess.run(cmd,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 d=json.loads(record.read_text());rows.append({'phase':phase,'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-start,'record':str(record),'record_sha256':H(record),'status':d['status'],'warnings':d['warnings'],'scene_hash_after':H(S)});(O/'execution.json').write_text(json.dumps(rows,indent=2)+'\n');print(L,phase,p.returncode,d['status'],d['warnings'],flush=True)
 assert H(S)==expected
