from pathlib import Path
import json,hashlib,shutil,datetime,sys,math
from PIL import Image,ImageDraw
repo=Path('/workspace/explainer-videos');out=Path('/workspace/runtime/ai3-galore-feasibility-endpoints');out.mkdir(exist_ok=True)
language,resolution=sys.argv[1:];assert language in ['en','zh'] and resolution in ['480','1080']
key=language+'/'+resolution;report=out/'review.json';d=json.loads(report.read_text()) if report.exists() else {'scope':'Actual GaLore feasibility endpoint comparison at preview480p and native1920x1080. Exact PNG inheritance from completed owned baseline only. No motion/audio claim from endpoints.','cases':{}}
assert key not in d['cases']
base=repo/(f'renders/qa/series/ai3/{language}/GaLore' if resolution=='480' else f'renders/qa/production-endpoints-1080-galore-feasibility/ai3/{language}/GaLore')
capture=base/'result.json';c=json.loads(capture.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
receipt=json.loads((Path('/workspace/runtime/ai3-galore-24gb-feasibility-repair')/f'render-{language}/execution.json').read_text());execution=next(x for x in receipt if x['phase']==('endpoints' if resolution=='480' else 'native1080'))
assert sha(capture)==execution['record_sha256']
dest=out/key;dest.mkdir(parents=True,exist_ok=True);shutil.copy2(capture,dest/'capture-result.json')
baseline=Path('/workspace/runtime')/('ai3-norms-galore-final-endpoints/review.json' if resolution=='480' else 'ai3-production1080-foundations/review.json');b=json.loads(baseline.read_text())['cases'][language+'/GaLore'];old={f['sha256']:f for f in b['frames'] if f['reviewed']};frames=[];new=[]
for f in c['frames']:
    p=base/f['file'];assert p.exists();h=sha(p);target=dest/p.name;shutil.copy2(p,target)
    with Image.open(p) as im:dimensions=list(im.size)
    if resolution=='1080':assert dimensions==[1920,1080]
    row={'file':str(target),'sha256':h,'time':f['time'],'reason':f['reason'],'texts':f.get('texts',[]),'dimensions':dimensions,'coverage':'not_yet_reviewed'}
    if h in old:
        assert sha(old[h]['file'])==h
        row.update(coverage='exact_png_inherited',baseline_report=str(baseline),baseline_report_sha256=sha(baseline),baseline_file=old[h]['file'],baseline_time=old[h]['time'])
    else:new.append(row)
    frames.append(row)
pages=[]
for n,start in enumerate(range(0,len(new),6),1):
    chunk=new[start:start+6];tiles=[]
    for f in chunk:
        with Image.open(f['file']) as im:
            im=im.convert('RGB');w=960 if resolution=='1080' else 854;h=round(im.height*w/im.width);tile=Image.new('RGB',(w,h+30),'#202732');tile.paste(im.resize((w,h)),(0,30));ImageDraw.Draw(tile).text((8,8),f"{language}/{resolution} {f['time']:.3f}s {f['reason']}",fill='white');tiles.append(tile)
    w,h=tiles[0].size;sheet=Image.new('RGB',(2*w,math.ceil(len(tiles)/2)*h),'#0e1117')
    for i,t in enumerate(tiles):sheet.paste(t,((i%2)*w,(i//2)*h))
    p=dest/f'changed-page-{n:02}.png';sheet.save(p);pages.append({'page':n,'file':str(p),'sha256':sha(p),'frames':[f['sha256'] for f in chunk],'reviewed':False})
sp=repo/'videos/ai/ai3/s12_galore.py';shutil.copy2(sp,dest/'s12_galore.py');shutil.copy2(repo/'videos/ai/ai_text_zh.json',dest/'ai_text_zh.snapshot.json')
inputs={}
for rel,stat in c.get('inputs',{}).items():
    p=repo/rel
    if p.exists():
        s=p.stat();target=dest/'inputs'/p.name;target.parent.mkdir(exist_ok=True);shutil.copy2(p,target);inputs[rel]={'sha256':sha(p),'snapshot':str(target),'size':s.st_size,'mtime_ns':s.st_mtime_ns,'size_mtime_matches_capture':[s.st_size,s.st_mtime_ns]==stat}
    else:inputs[rel]={'absent':True}
d['cases'][key]={'lang':language,'resolution':resolution,'capture_snapshot':str(dest/'capture-result.json'),'capture_sha256':sha(capture),'capture_status':c['status'],'warnings':c['warnings'],'fingerprint':c['fingerprint'],'execution':execution,'source_snapshot':str(dest/'s12_galore.py'),'source_sha256':sha(sp),'table_snapshot':str(dest/'ai_text_zh.snapshot.json'),'table_sha256':sha(dest/'ai_text_zh.snapshot.json'),'input_receipts':inputs,'frames':frames,'pages':pages,'native_followups':[],'review_status':'in_progress','prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
report.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');print(key,'frames',len(frames),'inherited',sum(f['coverage']=='exact_png_inherited' for f in frames),'changed',len(new),'pages',len(pages))
