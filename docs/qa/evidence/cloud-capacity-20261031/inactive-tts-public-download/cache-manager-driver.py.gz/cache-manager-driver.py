from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, os, shutil
from huggingface_hub import HfApi, scan_cache_dir

root = Path('/workspace/explainer-videos')
cache = Path('/workspace/runtime/huggingface/hub')
repo_id = 'Qwen/Qwen3-TTS-12Hz-1.7B-Base'
revision = 'fd4b254389122332181a7c3db7f27e918eec64e3'
out = root / 'docs/qa/evidence/cloud-capacity-20261031/inactive-tts-public-download'
out.mkdir(parents=True, exist_ok=False)

# Normal configured SDK/proxy access verifies the exact public release. No
# authentication changes, route changes, or alternate identities are used.
info = HfApi().model_info(repo_id, revision=revision)
assert info.private is False and info.sha == revision
active_tts, unreadable = [], []
for p in Path('/proc').iterdir():
    if not p.name.isdigit() or int(p.name) == os.getpid():
        continue
    try:
        if not (p/'comm').read_text().strip().startswith('python'):
            continue
        args = (p/'cmdline').read_bytes().split(b'\0')
        for arg in args:
            a = arg.decode(errors='replace').lower()
            if a.startswith('/workspace/runtime/tts/') or any(t in a for t in ['qwen_tts.server', 'qwen3_tts.server', 'serve_tts.py', 'tts_server.py']):
                active_tts.append(int(p.name))
    except (PermissionError, FileNotFoundError, ProcessLookupError):
        unreadable.append(int(p.name))
assert not active_tts, ('Known TTS service still running; do not reclaim', active_tts)
scan = scan_cache_dir(cache)
repo = next(r for r in scan.repos if r.repo_id == repo_id and r.repo_type == 'model')
assert len(repo.revisions) == 1 and next(iter(repo.revisions)).commit_hash == revision
plan = scan.delete_revisions(revision)
assert set(plan.repos) == {repo.repo_path}
assert all(p.is_relative_to(repo.repo_path) for p in [*plan.blobs, *plan.refs, *plan.snapshots])
inventory = [{'file':str(f.file_path),'blob':str(f.blob_path),'bytes':f.size_on_disk} for rev in repo.revisions for f in rev.files]
with gzip.open(out/'download-inventory.json.gz','wt') as f:
    json.dump(inventory,f)
protected = [p for part in ['ai3','ai4'] for p in (root/'.cache'/part).glob('*') if p.suffix in ('.json','.npz')]
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = {str(p.relative_to(root)):[p.stat().st_size,p.stat().st_mtime_ns,digest(p)] for p in protected}
free_before = shutil.disk_usage(root).free
plan.execute()
free_after = shutil.disk_usage(root).free
after = {str(p.relative_to(root)):[p.stat().st_size,p.stat().st_mtime_ns,digest(p)] for p in protected}
assert before == after and not repo.repo_path.exists()
receipt = {'observed_utc':datetime.now(timezone.utc).isoformat(),'action':'Normal Hugging Face cache-manager eviction of one inactive public pretrained TTS download revision','repo_id':repo_id,'revision':revision,'verified_public_metadata':{'private':info.private,'sha':info.sha},'cache_manager_expected_bytes':plan.expected_freed_size,'free_before':free_before,'free_after':free_after,'known_active_tts_processes':active_tts,'unreadable_or_vanished_process_ids':unreadable,'protected_unchanged':before,'scope':['The root-owned TTS service was stopped earlier; all current render workers use silent narration.','Process visibility is incomplete; this is not a claim of full system liveness observation.','Only the single standard pretrained-download repository was evicted. Numerical/trained checkpoints, generated voices/speech, source files and unique QA evidence are outside the exact deletion plan.','A future TTS run requires downloading this exact public revision again through normal authorized access. No new credentials or bypass.']}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='protected_unchanged'},indent=2))
