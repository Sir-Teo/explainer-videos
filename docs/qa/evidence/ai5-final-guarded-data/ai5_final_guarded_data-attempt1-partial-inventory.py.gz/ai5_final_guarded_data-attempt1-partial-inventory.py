from pathlib import Path
import json,hashlib,datetime,time,sys
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai5-final-guarded-data');D.mkdir();sys.path.insert(0,str(R));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snap():return [{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'sha256':sha(p)} for p in sorted((R/'.cache/ai5').glob('*')) if p.suffix in ['.json','.npz']]
before=snap();assert len(before)==56;(D/'payloads-before.json').write_text(json.dumps(before,indent=2)+'\n');from videos.ai.ai5 import compute as c
calls=[]
def forbid(name,producer):calls.append(name);raise RuntimeError('Final QA forbids producer execution: '+name)
c.CACHE._produce=forbid;rows=[];t=time.monotonic()
for n in c.CACHE.items:
 current=c.cache_current(n);assert current,n;v=c.load(n);assert isinstance(v,dict);rows.append({'item':n,'cache_current':current,'guarded_load':'passed','keys':sorted(v)})
after=snap();assert before==after and not calls and len(rows)==28;(D/'payloads-after.json').write_text(json.dumps(after,indent=2)+'\n');src=[R/'videos/ai/ai5'/n for n in ['compute.py','cache_contract.py','contracts.py','decoding.py','decoding_contract.py']];r={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-t,'items':rows,'producer_calls':calls,'payload_count':len(after),'payload_bytes':sum(x['bytes'] for x in after),'all_payload_sha_size_mtime_unchanged':before==after,'source_observations':[{'path':str(p.relative_to(R)),'sha256':sha(p)} for p in src],'scope':'Post-visual-repair all28currentness and guarded loads, no producers. Cachecontracts/dependency facts scoped to actual current environment, not cross-runtime production approval.'};(D/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ['items','source_observations']},indent=2))
