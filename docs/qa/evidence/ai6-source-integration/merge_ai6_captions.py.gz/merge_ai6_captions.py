from pathlib import Path
import json,hashlib,datetime,os,sys,re,collections,time
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-caption-integration');D.mkdir();p=R/'videos/ai/ai_text_zh.json';raw=p.read_bytes();sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(raw)=='c2914a2973672064f4cc508af8659a00ad0a07bce7398490e157b49439c494ef';(D/'before-ai_text_zh.json').write_bytes(raw);tab=json.loads(raw);delta=json.loads(Path('/workspace/runtime/ai6-scene-teaching-repairs/local-caption-delta.json').read_text());assert not delta['changed_existing_strings'] and not delta['removed_existing_strings'] and not delta['removed_patterns'];assert len(delta['added_strings'])==12 and len(delta['added_patterns'])==2
for k,v in delta['added_strings'].items():assert k not in tab['strings'] or tab['strings'][k]==v;tab['strings'][k]=v
for pat,rep in delta['added_patterns']:re.compile(pat);assert [pat,rep] not in tab['patterns'];tab['patterns'].append([pat,rep])
new=(json.dumps(tab,ensure_ascii=False,indent=2)+'\n').encode();tmp=p.with_suffix('.ai6-caption-merge.tmp');tmp.write_bytes(new);os.replace(tmp,p);(D/'after-ai_text_zh.json').write_bytes(new)
files=[];contexts=collections.defaultdict(list);counter=collections.Counter();parts={f'ai{i}' for i in range(1,6)}
for f in sorted((R/'renders').rglob('*text*.jsonl')):
 if not f.stat().st_size or not parts.intersection(f.parts):continue
 b=f.read_bytes();rows=[json.loads(line) for line in b.decode().splitlines() if line.strip()];assert all('s'in x for x in rows),str(f);files.append({'path':str(f.relative_to(R)),'bytes':len(b),'sha256':sha(b),'rows':len(rows)})
 for n,row in enumerate(rows,1):
  s=row['s'];counter[s]+=1;contexts[s].append({'file':str(f.relative_to(R)),'line':n,'kind':row.get('kind'),'needs':row.get('needs')})
assert len(files)>=180 and len(contexts)>3000
os.environ['EXPLAINER_VIDEO']='ai6';sys.path.insert(0,str(R));from explainer import lang,zh_text;lang.LANG='zh';out={};t=time.monotonic()
for name,data in [('before',json.loads(raw)),('after',tab)]:
 zh_text._TABLE=data;zh_text._BY_NUMBERS=None;out[name]={s:zh_text.translate(s) for s in contexts}
diff=[{'english':s,'before':out['before'][s],'after':out['after'][s],'contexts':contexts[s]} for s in contexts if out['before'][s]!=out['after'][s]]
used=[{'english':s,'before':out['before'][s],'after':out['after'][s],'occurrences':counter[s],'contexts':contexts[s]} for s in sorted(contexts)];(D/'used-caption-results.json').write_text(json.dumps(used,ensure_ascii=False,indent=2)+'\n');new_results={}
for s,expected in delta['added_strings'].items():
 actual=zh_text.translate(s);new_results[s]={'expected':expected,'actual':actual,'matched':actual==expected}
# Actual return may add control-spaces before closing CJK braces; plain exact new keys lack those forms.
assert all(v['matched'] for v in new_results.values()),new_results
for s in ['pairwise rank credit, half for ties: \\ $0.50$','sampled $|w|<10^{-12}$: \\ $3$']:
 actual=zh_text.translate(s);assert actual!=s,(s,actual);new_results[s]={'actual':actual,'translated':True}
assert p.read_bytes()==new;assert not any(n.startswith(tuple('videos.ai.ai'+str(i)+'.' for i in range(1,7))) for n in sys.modules)
report={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_table_sha256':sha(raw),'current_table_sha256':sha(new),'added_strings':len(delta['added_strings']),'added_patterns':len(delta['added_patterns']),'changed_or_removed_existing_entries':0,'collected_files':files,'collected_rows':sum(x['rows'] for x in files),'unique_strings':len(contexts),'changed_outputs':len(diff),'differences':diff,'new_caption_checks':new_results,'elapsed_translate_s':time.monotonic()-t,'lookup_code_sha256':{str(q.relative_to(R)):sha(q.read_bytes()) for q in [R/'explainer/zh_text.py',R/'explainer/lang.py',R/'explainer/zh_templates.py']},'limits':'Actual current raw translator outputs on retained nonempty Part1–5 captured strings only. Captures may be historical; source/data/render fingerprints, unseen dynamic branches, visual geometry, narration and audio are not refreshed. No production scene/compute import, load, producer or render. Verbatim Code/data_text strings omitted by original collector remain outside scope.'};(D/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['collected_files','differences','new_caption_checks','lookup_code_sha256']},indent=2));assert not diff,diff[:3]
