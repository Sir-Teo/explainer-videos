from pathlib import Path
import json,hashlib,datetime
from PIL import Image
R=Path('/workspace/explainer-videos');O=Path('/workspace/runtime/ai3-outro-review');A=O/'after';P=O/'footer-repair'
def read(p):return json.loads(Path(p).read_text())
def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
freeze=read(A/'freeze.json');baseline=read(O/'freeze.json');cases={}
for lang in ('en','zh'):
 p=A/f'motion/{lang}/review/review-map.json';m=read(p);old=read(O/f'motion/{lang}/review/review-map.json');oldhash={f['sha256'] for f in old['complete_mapping']};base=Path(m['audit']).parent
 assert len(m['actual_pages_viewed'])==len(m['pages'])==9
 for frame in m['complete_mapping']:
  assert h(base/frame['file'])==frame['sha256'];assert 'pending' not in frame['review']
  if 'inherited' in frame['review']:assert frame['sha256'] in oldhash
  else:assert frame['sha256']==m['representatives'][frame['unique_index']]['sha256']
 for page in m['actual_pages_viewed']:assert h(p.parent/page['file'])==page['sha256']
 for v in m['native_views']:assert h(v['file'])==v['sha256'];assert Image.open(v['file']).size==(854,480)
 assert h(m['audit'])==m['audit_sha256'];assert h(R/'tools/qa_motion.py')==m['tool_sha256']
 assert h(freeze['cases'][lang]['motion']['movie']['file'])==m['movie_sha256']
 assert m['largest_selected_time_gap']<=1+1e-9
 cases[lang]={k:m[k] for k in ('movie_sha256','selected_times','unique_pngs','exact_baseline_inherited_times','new_selected_times','new_unique_pngs','exact_new_duplicate_times','decoded_frames','duration','largest_selected_time_gap')}
 cases[lang].update(review_map=str(p),review_map_sha256=h(p),fresh_sheets_actually_viewed=9,fresh_encoded_native_followups_actually_viewed=3,unviewed_source_frames=m['decoded_frames']-m['selected_times'])
# Associate every native review and inherited endpoint with its exact frozen image.
views=read(P/'native1080-view-checkpoints.json');ep=read(P/'fresh-480-endpoint-review-map.json')
for lang in ('en','zh'):
 for v in views[lang]['actual_native_views']:
  p=A/f'1080endpoints/{lang}'/v['file'];assert h(p)==v['sha256'];assert Image.open(p).size==(1920,1080)
 for v in ep[lang]['mapping']:
  p=A/f'endpoints/{lang}'/v['file'];assert h(p)==v['sha256'];assert Image.open(p).size==(854,480)
 for mode in ('endpoints','motion','1080endpoints'):
  f=freeze['cases'][lang][mode];assert h(f['record'])==f['record_sha256'];assert f['record_status']=='passed' and f['record_warnings']==[]
  for d in f['data']:
   q=R/d['path'];assert (h(q) if q.exists() else None)==d['sha256'];assert (None if not q.exists() else [q.stat().st_size,q.stat().st_mtime_ns])==d['signature']
   old=next(x for x in baseline['cases'][lang]['endpoints']['data'] if x['path']==d['path']);assert old==d
# Record the exact four-key shared-caption delta; never broaden it silently.
before=O/'source-at-review/videos/ai/ai_text_zh.json';after=A/'source-at-review/videos/ai/ai_text_zh.json';before_table,after_table=read(before),read(after);assert before_table['phrases']==after_table['phrases'] and before_table['patterns']==after_table['patterns'];b,a=before_table['strings'],after_table['strings']
added={k:a[k] for k in a.keys()-b.keys()};removed={k:b[k] for k in b.keys()-a.keys()};changed={k:{'before':b[k],'after':a[k]} for k in a.keys()&b.keys() if a[k]!=b[k]}
expected=read(P/'new-caption-translations-for-root.json');assert set(added)|set(changed)==set(expected);assert not removed
for k,v in expected.items():assert a[k]==v
save(P/'shared-caption-delta.json',{'before_sha256':h(before),'after_sha256':h(after),'added':added,'changed':changed,'removed':removed,'scope':'Exact comparison of before-review and frozen after-render tables; four approved footer caption keys only.'})
# Geometry is vector glyph bounds in an actual captured frame; pixel comparisons separately retained.
geometry={}
for lang in ('en','zh'):
 geometry[lang]={}
 targets=set(expected) if lang=='en' else set(expected.values())
 for mode,height in (('endpoints',480),('1080endpoints',1080)):
  d=read(A/mode/lang/'render-result.json');lines=[]
  for t in d['frames'][0]['texts']:
   if t['text'] in targets:
    x0,x1,y0,y1=t['bounds'];lines.append({'text':t['text'],'scene_bounds':t['bounds'],'glyph_height_pixels':(y1-y0)*height/8,'glyph_width_pixels':(x1-x0)*height/8})
  assert len(lines)==4
  geometry[lang][mode]={'actual_dimensions':[854,480] if height==480 else [1920,1080],'lines':lines}
save(P/'captured-footer-glyph-bounds.json',geometry)
execution=read(P/'render-execution.json');assert len(execution)==6 and all(x['exit_code']==0 and x['status']=='passed' and not x['warnings'] for x in execution)
summary={'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scene':'ai3/Outro','status':'recap footer readability repair verified by scoped bilingual endpoint and selected-frame regression; no concrete remaining visual defect found','source_before_sha256':baseline['source_scene_sha256'],'source_after_sha256':freeze['source_scene_sha256'],'after_aggregate_fingerprint_at_freeze':freeze['aggregate_fingerprint_at_review'],'shared_caption_table_sha256':h(after),'cases':cases,'current_motion_coverage':{'selected_times':648,'exact_baseline_inherited_times':508,'new_unique_images_actually_inspected':140,'new_chronological_sheets_actually_inspected':18,'new_encoded_native_followups_actually_inspected':6,'decoded_source_frames':4514,'source_frames_visually_unviewed':3866},'endpoints':{'native480_total':12,'fresh_actual_native480':2,'exactPNG_inherited_baseline_native480':10,'fresh_actual_native1920x1080':12,'1080interpretation':'Skipped-animation endpoint capture at native1920x1080, not full1080motion or final export.'},'baseline_actual_coverage':read(O/'baseline-review.json')['aggregate'],'checks':{'footer_layout':'Two centered lines per long footer, original font22, no additional downscaling; full normalization/generalized-PMI qualifiers retained.','pixel_scope':'Both480recap comparisons have zero changed pixels outside the two approved footer rectangles.','continuity':'All newly selected footer entrances,held recaps and clears inspected; all other current selected frames accounted by exact PNG inheritance.','math_data':'Frozen twelve-result miniatures/source traced; read-only arithmetic checks retained; no data/model recomputation.','current_render_records':'All six fresh jobs passed/zero QA result warnings.','tests':'29 existing visual-math,narration and cloud-layout tests passed13.854s; no new mirroring test.'},'warnings_and_history':['Original baseline render records/fingerprints and review maps are retained unchanged.','Fresh motion logs contain Manim warnings that shortest/metadata mux options were unused; logs are preserved. Both output movies probed successfully and full decoder audits completed. This is not presented as a demonstrated playback failure.','Both movies contain AAC silent timing-placeholder audio streams. No no-audio-stream assertion or narration/listening approval.'],'provenance_limits':['All fresh records share the frozen after aggregate fingerprint and input signatures at review freeze; source snapshot94files retained byhashledger.','Before-review aggregate differs from original baseline render fingerprint after unrelated source changes; no false imported-source claim. Direct baseline scene/source and actual pixels preserved separately.','Numerical JSON/NPZ inputs are unchanged; historical QA input ledgers omit integrity sidecars. Later sidecar observations remain explicitly separate from producer/renderer consumed-input attestation.'],'coverage_limits':['Selected-time review is not continuous perceptual playback;3,866source frames remain individually unviewed.','No narration listening/synchronization,production1080fullmotion,final narrated export,player/responsive QA or primary bibliography verification.'],'evidence':{'freeze':str(A/'freeze.json'),'baseline':str(O/'baseline-review.json'),'execution':str(P/'render-execution.json'),'native1080_views':str(P/'native1080-view-checkpoints.json'),'endpoint480_views':str(P/'fresh-480-endpoint-review-map.json'),'glyph_bounds':str(P/'captured-footer-glyph-bounds.json'),'shared_caption_delta':str(P/'shared-caption-delta.json'),'pixel_source_scope':str(P/'source-and-pixel-scope-checks.json'),'stream_probe':str(P/'silent-movie-streams.json')}}
assert summary['source_after_sha256']=='4e1d29200637256128acf72ecffd0f02caaf6733a4222808dd0b32bf82981ed7'
save(O/'final-review.json',summary)
(O/'final-review.md').write_text('''# Outro footer repair: final scoped review\n\nThe two long recap captions now use two lines at the original font22. Their full separately peak-normalized and generalized shifted PMI meanings are retained. EN spectra glyph height increased from about6.7px to11.5/11.3px at854×480; SGNS changed from8.1px to11.6/9.1px. All12native1920×1080endpoints were actually inspected: footers clear, no clipping or diagram overlap. Pixel comparison at480p shows no changes outside the two footer rectangles.\n\nAll six fresh cached-only jobs passed with zero QA result warnings: both480pendpoints,both full silent480pmovies,and both native1080endpoint captures.29existing focused tests passed. Original warnings/history remain; motion logs retain the unused mux-option warning. Actual movies include AAC timing-placeholder streams, not reviewed narration.\n\nCurrent motion coverage is648selected times:508exact-PNG inheritances from the completed baseline review and140new unique images actually inspected across18chronological sheets,plus6fresh encoded native followups. Both movies were fully decoded,4,514frames.3,866source frames were not individually visually viewed. This is not continuous playback or listening approval.\n\nThe baseline separately records643selected times,558unique images,70actually inspected sheets,12encoded native followups and12native endpoints. Those historical counts are not added to the current selected total. Current480endpoint coverage is2actual new native recap inspections plus10exact-PNG inherited native reviews. Native1080coverage is12actual new image views, with animations skipped. No full1080movie,final export,player/responsive or narration/listening/sync claim is made.\n\nSourceafter4e1d29200637256128acf72ecffd0f02caaf6733a4222808dd0b32bf82981ed7; table075af7895f39456b287f7e8a6e7dbc4e2c36798e72d4adb2aafe6858251e1d3a; after fingerprint198fd0d4f6fb8f222bd2ab0506043e8f7be158187036539d81c490848dca3bbf. All record/movie/tool/input/image/sheet hashes and dimensions checked; numerical input bytes/signatures unchanged. Historical QA sidecar-ledger and original consumed-input provenance gaps remain explicit.\n''')
print('FINAL VALIDATION PASSED',summary['current_motion_coverage']);print('geometry',geometry)
