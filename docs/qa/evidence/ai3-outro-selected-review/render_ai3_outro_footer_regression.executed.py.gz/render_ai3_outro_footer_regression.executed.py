from pathlib import Path
import json,hashlib,os,shutil,subprocess,time
R=Path('/workspace/explainer-videos');O=Path('/workspace/runtime/ai3-outro-review/footer-repair');O.mkdir(exist_ok=True)
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert h(R/'videos/ai/ai3/s19_outro.py')=='4e1d29200637256128acf72ecffd0f02caaf6733a4222808dd0b32bf82981ed7'
assert h(R/'videos/ai/ai_text_zh.json')=='075af7895f39456b287f7e8a6e7dbc4e2c36798e72d4adb2aafe6858251e1d3a'
rows=[];env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
for mode,lang in [('endpoints','en'),('endpoints','zh'),('motion','en'),('motion','zh'),('1080endpoints','en'),('1080endpoints','zh')]:
 if shutil.disk_usage(R).free<3*1024**3:
  rows.append({'mode':mode,'lang':lang,'outcome':'not-started-disk-guard','freebytes':shutil.disk_usage(R).free});(O/'render-execution.json').write_text(json.dumps(rows,indent=2)+'\n');print('DISKGUARD',mode,lang,flush=True);break
 cmd=['nice','-n','10','python','tools/qa_series.py','ai3','--lang',lang,'--worker','Outro','--cached-only']
 if mode=='motion':cmd+=['--motion']
 if mode=='1080endpoints':cmd=['nice','-n','10','python','/workspace/runtime/qa_production_endpoint.py','ai3',lang,'Outro']
 log=O/f'{mode}-{lang}.log';start=time.monotonic()
 with log.open('w') as stream:p=subprocess.run(cmd,cwd=R,env=env,stdout=stream,stderr=subprocess.STDOUT)
 folder=R/(f'renders/qa/production-endpoints-1080/ai3/{lang}/Outro' if mode=='1080endpoints' else f'renders/qa/series/ai3/{lang}/'+('Outro_motion' if mode=='motion' else 'Outro'))
 record=folder/'result.json';r=json.loads(record.read_text()) if record.exists() else {}
 rows.append({'mode':mode,'lang':lang,'command':cmd,'exit_code':p.returncode,'elapsed':round(time.monotonic()-start,3),'record':str(record),'record_sha256':h(record) if record.exists() else None,'status':r.get('status'),'warnings':r.get('warnings'),'log':str(log),'log_sha256':h(log)})
 (O/'render-execution.json').write_text(json.dumps(rows,indent=2)+'\n');print(mode,lang,p.returncode,r.get('status'),'warnings',len(r.get('warnings',[])),flush=True)
