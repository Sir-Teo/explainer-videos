# Outro footer repair: final scoped review

The two long recap captions now use two lines at the original font22. Their full separately peak-normalized and generalized shifted PMI meanings are retained. EN spectra glyph height increased from about6.7px to11.5/11.3px at854×480; SGNS changed from8.1px to11.6/9.1px. All12native1920×1080endpoints were actually inspected: footers clear, no clipping or diagram overlap. Pixel comparison at480p shows no changes outside the two footer rectangles.

All six fresh cached-only jobs passed with zero QA result warnings: both480pendpoints,both full silent480pmovies,and both native1080endpoint captures.29existing focused tests passed. Original warnings/history remain; motion logs retain the unused mux-option warning. Actual movies include AAC timing-placeholder streams, not reviewed narration.

Current motion coverage is648selected times:508exact-PNG inheritances from the completed baseline review and140new unique images actually inspected across18chronological sheets,plus6fresh encoded native followups. Both movies were fully decoded,4,514frames.3,866source frames were not individually visually viewed. This is not continuous playback or listening approval.

The baseline separately records643selected times,558unique images,70actually inspected sheets,12encoded native followups and12native endpoints. Those historical counts are not added to the current selected total. Current480endpoint coverage is2actual new native recap inspections plus10exact-PNG inherited native reviews. Native1080coverage is12actual new image views, with animations skipped. No full1080movie,final export,player/responsive or narration/listening/sync claim is made.

Sourceafter4e1d29200637256128acf72ecffd0f02caaf6733a4222808dd0b32bf82981ed7; table075af7895f39456b287f7e8a6e7dbc4e2c36798e72d4adb2aafe6858251e1d3a; after fingerprint198fd0d4f6fb8f222bd2ab0506043e8f7be158187036539d81c490848dca3bbf. All record/movie/tool/input/image/sheet hashes and dimensions checked; numerical input bytes/signatures unchanged. Historical QA sidecar-ledger and original consumed-input provenance gaps remain explicit.
