from pathlib import Path
import json,hashlib,datetime
from PIL import Image,ImageDraw
R=Path('/workspace/explainer-videos');O=Path('/workspace/runtime/ai3-root-production-endpoints/spectra-review');O.mkdir(exist_ok=True)
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();report={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Native1080p endpoint captures only; actual sheet/native inspection recorded separately. No full1080p motion, listening or continuous perception approval.','source_sha256_at_review':H(R/'videos/ai/ai3/s11_spectra.py'),'cases':{}}
for lang in ['en','zh']:
 B=R/f'renders/qa/production-endpoints-1080/ai3/{lang}/Spectra';D=json.loads((B/'result.json').read_text());frames=[];pages=[]
 for i,f in enumerate(D['frames']):
  p=B/f['file'];assert Image.open(p).size==(1920,1080);frames.append({**f,'index':i,'path':str(p),'sha256':H(p),'review':'pending actual view'})
 for offset in range(0,len(frames),4):
  chunk=frames[offset:offset+4];page=Image.new('RGB',(1920,1136),'#202732');draw=ImageDraw.Draw(page)
  for k,f in enumerate(chunk):
   x=(k%2)*960;y=(k//2)*568
   draw.text((x+5,y+5),f"{lang} Spectra | endpoint {f['index']} | {f['time']:.3f}s",fill='white')
   with Image.open(f['path']) as pic:page.paste(pic.convert('RGB').resize((960,540)),(x,y+28))
  p=O/f'{lang}-page-{offset//4+1:02d}.png';page.save(p);pages.append({'path':str(p),'sha256':H(p),'indices':[f['index'] for f in chunk],'actual_view':'pending'})
 inputs={}
 for p,s in D['inputs'].items():
  file=R/p;stat=file.stat() if file.exists() else None;now=[stat.st_size,stat.st_mtime_ns] if stat else None;assert s==now,(p,s,now);inputs[p]={'signature':s,'sha256':H(file) if stat else None}
 report['cases'][lang]={'record':str(B/'result.json'),'record_sha256':H(B/'result.json'),'runtime_status':D['status'],'warnings':D['warnings'],'fingerprint':D['fingerprint'],'configuration':D['manual_capture_configuration'],'frames':frames,'pages':pages,'inputs_at_review':inputs,'actual_native_views':[]}
(O/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print([(l,len(x['frames']),len(x['pages'])) for l,x in report['cases'].items()])
