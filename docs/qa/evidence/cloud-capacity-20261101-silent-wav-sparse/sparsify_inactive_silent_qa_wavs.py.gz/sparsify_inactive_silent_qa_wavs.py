from pathlib import Path
import os,json,hashlib,stat,subprocess,datetime,shutil
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/capacity-silent-qa-sparse-20261101');D.mkdir(exist_ok=True)
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def stamp(p):
 s=p.stat();return dict(bytes=s.st_size,sha256=sha(p),mtime_ns=s.st_mtime_ns,mode=stat.S_IMODE(s.st_mode),inode=s.st_ino,device=s.st_dev,allocated_bytes=s.st_blocks*512,ctime_ns=s.st_ctime_ns)
protected0=json.loads(Path('/workspace/runtime/capacity-inactive-forced-aligner-20261101/protected-after.json').read_text());paths={x['path'] for x in protected0};paths.update(str(p) for p in (R/'.cache/ai6').glob('*') if p.is_file());protected={p:stamp(Path(p)) for p in sorted(paths) if Path(p).is_file()}
candidates=[]
for p in sorted((R/'renders/qa/series').rglob('*.wav')):
 if not any(x in p.parts for x in ['ai1','ai2','ai3','ai4','ai5']) or not any(x.endswith('_motion') for x in p.parts) or p.is_symlink():continue
 s=p.stat()
 if not stat.S_ISREG(s.st_mode) or s.st_size<8192:continue
 candidates.append(p)
targets={str(p.resolve()) for p in candidates};open_targets=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:
  for fd in (proc/'fd').iterdir():
   try:
    q=os.readlink(fd)
    if q in targets:open_targets.append(dict(pid=proc.name,path=q))
   except OSError:pass
  for line in (proc/'maps').read_text().splitlines():
   fields=line.split(maxsplit=5)
   if len(fields)==6 and fields[5] in targets:open_targets.append(dict(pid=proc.name,path=fields[5],kind='mapped'))
 except OSError:pass
assert not open_targets,open_targets
free0=shutil.disk_usage(R).free;rows=[];seen=set()
for p in candidates:
 s=p.stat();key=(s.st_dev,s.st_ino)
 if key in seen:continue
 seen.add(key);start=4096;length=(s.st_size//4096)*4096-start
 if length<=0:continue
 with p.open('rb') as f:
  f.seek(start);remaining=length;zero=True
  while remaining:
   b=f.read(min(1024*1024,remaining));assert b
   if b.strip(b'\0'):zero=False;break
   remaining-=len(b)
 if not zero:rows.append(dict(path=str(p),status='retained-nonzero-region'));continue
 before=stamp(p);assert p.stat().st_mtime_ns==s.st_mtime_ns
 completed=subprocess.run(['fallocate','--punch-hole','--keep-size','--offset',str(start),'--length',str(length),str(p)],capture_output=True,text=True)
 if completed.returncode:
  rows.append(dict(path=str(p),status='unsupported-or-failed',returncode=completed.returncode,stderr=completed.stderr));continue
 os.utime(p,ns=(s.st_atime_ns,s.st_mtime_ns));after=stamp(p)
 for field in ['bytes','sha256','mtime_ns','mode','inode','device']:assert before[field]==after[field],(p,field)
 rows.append(dict(path=str(p),status='byte-exact-sparse',before=before,after=after,punch_offset=start,punch_length=length))
 (D/'progress.json').write_text(json.dumps(dict(rows=rows),indent=2)+'\n')
protected1={p:stamp(Path(p)) for p in protected}
for p,before in protected.items():
 for key in ['bytes','sha256','mtime_ns','mode','inode','device']:assert protected1[p][key]==before[key],(p,key)
report=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Only inactive Part1–5 *_motion silent QA WAV files with entire aligned interior proved zero. Hole punching changes physical allocation only; full bytes/hash/size/mode/inode preserved, originalmtime restored, ctime change explicitly recorded. Nonzero audio retained. No deletion, no numerical/model/source mutation or audio approval.',candidate_count=len(candidates),seen_inode_count=len(seen),processed=rows,free_before=free0,free_after=shutil.disk_usage(R).free,allocated_bytes_recovered=sum(x['before']['allocated_bytes']-x['after']['allocated_bytes'] for x in rows if x['status']=='byte-exact-sparse'),protected_count=len(protected),protected_before=protected,protected_after=protected1,protected_signatures_unchanged=True,no_visible_open_target_files=True)
(D/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['processed','protected_before','protected_after']},indent=2))
