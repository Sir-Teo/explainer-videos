from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, shutil
from huggingface_hub import HfApi, scan_cache_dir

root = Path('/workspace/explainer-videos')
cache = Path('/workspace/runtime/huggingface/hub')
repo_id = 'Qwen/Qwen3-1.7B-Base'
revision = 'ea980cb0a6c2ae4b936e82123acc929f1cec04c1'
out = root / 'docs/qa/evidence/cloud-capacity-20261101/inactive-public-text-download'
out.mkdir(parents=True, exist_ok=False)
info = HfApi().model_info(repo_id, revision=revision, files_metadata=True)
assert info.private is False and info.gated is False and info.sha == revision
scan = scan_cache_dir(cache)
repo = next(r for r in scan.repos if r.repo_id == repo_id and r.repo_type == 'model')
assert len(repo.revisions) == 1 and next(iter(repo.revisions)).commit_hash == revision
remote = {s.rfilename: s for s in info.siblings}
inventory = []
for rev in repo.revisions:
    for file in rev.files:
        sibling = remote[file.file_name]
        lfs = sibling.lfs
        if lfs:
            expected = lfs.sha256
            h = hashlib.sha256()
        else:
            expected = sibling.blob_id
            h = hashlib.sha1()
            h.update(f'blob {file.size_on_disk}\0'.encode())
        with file.file_path.open('rb') as f:
            while chunk := f.read(1024 * 1024):
                h.update(chunk)
        assert h.hexdigest() == expected, ('Not an unmodified canonical download; preserve it', file.file_name)
        inventory.append({'file':file.file_name,'bytes':file.size_on_disk,'remote_digest':expected,'verified_original_public_download':True})
plan = scan.delete_revisions(revision)
assert set(plan.repos) == {repo.repo_path}
assert all(p.is_relative_to(repo.repo_path) for p in [*plan.blobs, *plan.refs, *plan.snapshots])
protected = []
for part in ['ai1','ai2','ai3','ai4','novels']:
    protected += [p for p in (root/'.cache'/part).rglob('*') if p.is_file() and not p.name.endswith('.lock')]
def signature(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while chunk := f.read(1024 * 1024):h.update(chunk)
    return [p.stat().st_size,p.stat().st_mtime_ns,h.hexdigest()]
before = {str(p.relative_to(root)):signature(p) for p in protected}
free_before = shutil.disk_usage(root).free
plan.execute()
after = {str(p.relative_to(root)):signature(p) for p in protected}
assert before == after and not repo.repo_path.exists()
receipt = {'observed_utc':datetime.now(timezone.utc).isoformat(),'repo_id':repo_id,'revision':revision,'public':info.private is False,'ungated':info.gated is False,'action':'Normal Hugging Face cache-manager eviction of one canonical inactive pretrained text-model download','expected_download_bytes':plan.expected_freed_size,'free_before':free_before,'free_after':shutil.disk_usage(root).free,'verified_download_inventory':inventory,'protected_unchanged':before,'operational_basis':['The root owns all numerical computation; all Parts1–4 numerical jobs completed and current workers are cached-only renders, image review, pure helper tests or hash/archive operations.','All current cloud collaborators are prohibited from model/data production; no current job requests this model. The cloud TTS service is stopped.','This is not a claim of complete system-wide process visibility. Only the exact unmodified public pretrained download repository is in the cache-manager deletion plan.'],'limits':['Original sources, generated speech, numerical payloads, raw corpus, trained/custom checkpoints, GPT2 validator weights and other model repositories remain.','Future recomputation needing this public text model requires a normal authorized redownload of the pinned revision.','No local-computer, credentials, network-policy, validation-metadata or producer operation.']}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with gzip.open(out/'driver.py.gz','wb') as f:f.write(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in receipt.items() if k not in ('protected_unchanged','verified_download_inventory')},indent=2))
