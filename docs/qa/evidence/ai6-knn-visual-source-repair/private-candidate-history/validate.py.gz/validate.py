from pathlib import Path
import ast,math,json,hashlib,os
import numpy as np
from explainer.ai import *
from explainer import lang
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();src=ast.parse((D/'candidate.py').read_text());old=ast.parse((D/'before.py').read_text())
vo=lambda t:[ast.dump(n,include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.With) and any(isinstance(i.context_expr,ast.Call) and isinstance(i.context_expr.func,ast.Attribute) and i.context_expr.func.attr=='voiceover' for i in n.items)]
assert vo(src)==vo(old)
scope=dict(globals(),NN1=C.MODEL_Q,NNK=C.REWARD,BAYES=C.TRUE_P,BOUND=C.PENALTY)
common=ast.parse((R/'videos/ai/ai6/common.py').read_text());nodes=[n for n in common.body if isinstance(n,ast.FunctionDef) and n.name in ['plot','pow10']];exec(compile(ast.Module(nodes,type_ignores=[]),'actual-pure-chart-helpers','exec'),scope)
cache=R/'.cache/ai6/coverhart.json';pin={'sha256':sha(cache),'mtime_ns':cache.stat().st_mtime_ns};ch=json.loads(cache.read_text());fn=next(n for n in ast.walk(src) if isinstance(n,ast.FunctionDef) and n.name=='cover_hart');prefix=[]
for n in fn.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='key_' for t in n.targets):break
 prefix.append(n)
receipts=[]
for l in ['en','zh']:
 lang.LANG=l;s=dict(scope,load=lambda name:ch,self=None,side_ladder=lambda *a,**kw:None)
 exec(compile(ast.Module(prefix,type_ignores=[]),'private-actual-cover-hart-constructors','exec'),s)
 assert math.isclose(s['bottom'],.15,abs_tol=1e-12) and math.isclose(s['top'],.55,abs_tol=1e-12)
 ax=s['ax'];coords=[]
 for key in ['e1','ek']:
  for n in ch['ns']:
   for field in ['mean','lo','hi']:
    v=ch[key][str(n)][field];assert s['bottom']<v<s['top'];p=ax.c2p(math.log10(n),v);assert np.isfinite(p).all();coords.append({'algorithm':key,'n':n,'field':field,'value':v,'point':p.tolist()})
 for i,(key,col) in enumerate([('e1',s['NN1']),('ek',s['NNK'])]):
  expected=band(ax,np.log10(ch['ns']),[ch[key][str(n)]['lo'] for n in ch['ns']],[ch[key][str(n)]['hi'] for n in ch['ns']],col,opacity=.2);np.testing.assert_array_equal(expected.get_all_points(),s['art'][i][0].get_all_points())
 bounds=[float(s['g'].get_left()[0]),float(s['g'].get_right()[0]),float(s['g'].get_bottom()[1]),float(s['g'].get_top()[1])];assert bounds[0]>-7.12 and bounds[1]<7.12 and bounds[2]>-4 and bounds[3]<4
 receipts.append({'language':l,'bottom':s['bottom'],'top':s['top'],'ticks':s['ticks'],'all42measuredvalues_unchanged_inside':True,'all3references_inside':all(s['bottom']<ch[k]<s['top'] for k in ['Rstar','lim1','bound']),'max_measured_hi':max(ch[k][str(n)]['hi'] for k in ['e1','ek'] for n in ch['ns']),'headroom':s['top']-max(ch[k][str(n)]['hi'] for k in ['e1','ek'] for n in ch['ns']),'chart_bounds':bounds,'measured_geometry':coords})
assert sha(cache)==pin['sha256'] and cache.stat().st_mtime_ns==pin['mtime_ns'];assert sha(R/'videos/ai/ai6/s10_knn.py')==sha(D/'before.py')
(D/'geometry.json').write_text(json.dumps({'cases':receipts,'cache_pin_unchanged':pin,'voiceovers_bookmarks_AST_exact':True,'physical_source_unchanged':True,'scope':'Private candidate actualManimgeometry only; no scene render/load/producer/model, no appliedsource/visualsignoff. Fullbaseline motion stillpending.'},indent=2)+'\n')
print('Private candidate EN/ZH actualManimgeometry passed;45numericvalues+references inside .15–.55, measuredvalues/bandvertices unchanged; VOexact. Physicalsource remainsbaseline.')
