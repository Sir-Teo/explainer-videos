from pathlib import Path
import ast,math,json,hashlib,copy,os
import numpy as np
from explainer.ai import *
from explainer import lang
R=Path('/workspace/explainer-videos');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=ast.parse((D/'before.py').read_text());new=ast.parse((D/'candidate.py').read_text())
vo=lambda t:[ast.dump(i.context_expr,include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.With) for i in n.items if isinstance(i.context_expr,ast.Call) and isinstance(i.context_expr.func,ast.Attribute) and i.context_expr.func.attr=='voiceover']
assert vo(old)==vo(new)
methods=lambda t:{n.name:n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name in ('construct','setup_data','vote','regions','cover_hart','curse')}
for k in ('construct','setup_data','vote','regions'):assert ast.dump(methods(old)[k])==ast.dump(methods(new)[k])
plays=lambda t:[ast.dump(n,include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('play','wait','wait_until','clear_scene')]
assert plays(old)==plays(new)
steps=[]
for n in ast.walk(methods(new)['cover_hart']):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='step':steps.append((n.args[0].value,[(k.arg,ast.literal_eval(k.value)) for k in n.keywords]))
assert sorted(steps)==[(0,[]),(1,[('transform',False)]),(2,[('transform',False)]),(3,[('transform',False)])]
common=ast.parse((R/'videos/ai/ai6/common.py').read_text());scope=dict(globals(),NN1=C.MODEL_Q,NNK=C.REWARD,BAYES=C.TRUE_P,BOUND=C.PENALTY,HL=C.BITS)
exec(compile(ast.Module([n for n in common.body if isinstance(n,ast.FunctionDef) and n.name in ('plot','pow10')],type_ignores=[]),'actual-pure-chart-helpers','exec'),scope)
files=[R/'.cache/ai6/coverhart.json',R/'.cache/ai6/curse.json'];pins={str(p):{'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in files};data={p.stem:json.loads(p.read_text()) for p in files}
def prefix(name,stop):
 out=[]
 for n in methods(new)[name].body:
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==stop for t in n.targets):break
  out.append(n)
 return out
receipts=[]
for language in (os.environ['EXPLAINER_LANG'],):
 lang.LANG=language;assert (os.environ['EXPLAINER_LANG']=='zh')==any('patched_mathtex' in str(type(x).__init__) for x in [MathTex('x')])
 for name,cache,stop,chart,xs,keys in [('cover_hart','coverhart','key_','g',data['coverhart']['ns'],['e1','ek']),('curse','curse','cite_','g2',data['curse']['noise'],['knn','lr'])]:
  s=dict(scope,load=lambda nm:data[nm],self=None,side_ladder=lambda *a,**kw:None)
  exec(compile(ast.Module(prefix(name,stop),type_ignores=[]),'actual-private-chart-prefix','exec'),s)
  low,hi=(s['bottom'],s['top']) if name=='cover_hart' else(s['noise_bottom'],s['noise_top'])
  ticks=s['ticks'] if name=='cover_hart' else s['noise_ticks'];g=s[chart];ax=g.ax;values=[]
  for i,key in enumerate(keys):
   lo=[data[cache][key][str(n)]['lo'] for n in xs];up=[data[cache][key][str(n)]['hi'] for n in xs];means=[data[cache][key][str(n)]['mean'] for n in xs]
   for n,a,b,c in zip(xs,means,lo,up):
    for field,value in [('mean',a),('lo',b),('hi',c)]:
     assert low<value<hi
     point=ax.c2p(math.log10(max(n,1)),value);assert np.isfinite(point).all();values.append({'key':key,'n':n,'field':field,'value':value,'point':point.tolist()})
   color=s['NN1'] if i==0 else s['NNK'] if name=='cover_hart' else s['HL']
   expected=band(ax,np.log10(np.maximum(xs,1)),lo,up,color,opacity=.2 if name=='cover_hart' else .25)
   np.testing.assert_array_equal(expected.get_all_points(),s['art'][i][0].get_all_points())
  full=VGroup(g,*s['art']);bounds=[float(full.get_left()[0]),float(full.get_right()[0]),float(full.get_bottom()[1]),float(full.get_top()[1])];assert -7.12<bounds[0] and bounds[1]<7.12 and -4<bounds[2] and bounds[3]<4
  assert min(np.diff([ax.c2p(0,t)[1] for t in ticks]))>.2
  receipts.append({'language':language,'method':name,'range':[low,hi],'ticks':ticks,'all_measurements_unchanged_inside':values,'min_vertical_clearance':min(min(v['value']-low,hi-v['value']) for v in values),'bounds':bounds,'band_vertices_exact':True})
for p in files:assert pins[str(p)]=={'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns}
assert sha(R/'videos/ai/ai6/s10_knn.py')==sha(D/'before.py')
report={'candidate_sha256':sha(D/'candidate.py'),'baseline_sha256':sha(D/'before.py'),'cases':receipts,'payloads_unchanged':pins,'unchanged_voiceover_bookmark_math_and_requested_play_timing_AST':True,'other4methods_AST_exact':True,'step_calls':steps,'physical_source_unchanged':True,'limits':'Actual EN/ZH Manim chart-constructor geometry only; no whole-scene render, no producer/load/model execution. Approved local retained-copy keywords inspected; actual encoded repair QA remains pending.'}
(D/f"final-geometry-{os.environ['EXPLAINER_LANG']}.json").write_text(json.dumps(report,indent=2)+'\n');print('PASS two actual correctly initialized language chart fixtures, all original mean/lo/hi vertices preserved and inside with clearance;3append keywords only; VO/bookmarks/playtiming exact; physical baseline unchanged.')
