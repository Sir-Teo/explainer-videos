from pathlib import Path
import hashlib,json,difflib,ast
D=Path(__file__).parent;p=D/'candidate.py';s=p.read_text();(D/'range-only-candidate.py').write_text(s)
start=s.index('    def cover_hart(');end=s.index('    def curse(')
a=s[start:end]
for i in (1,2,3):
 old=f'            step({i})';assert a.count(old)==1;a=a.replace(old,f'            step({i}, transform=False)')
s=s[:start]+a+s[end:]
old='''        g2 = plot([0, 3, 1], [0.85, 1.0, 0.05], x_length=4.8, y_length=3.6, xticks=[0, 1, 2, 3], yticks=[0.85, 0.9, 0.95, 1.0],'''
new='''        # Include the full measured uncertainty bands with one tick of clearance.
        noise_values = [cu[key][str(n)][field] for key in ("knn", "lr")
                        for n in noise for field in ("mean", "lo", "hi")]
        noise_bottom = max(0, math.floor((min(noise_values) - 0.01) / 0.05) * 0.05)
        noise_top = min(1, math.ceil(max(noise_values) / 0.05) * 0.05)
        noise_ticks = np.arange(noise_bottom, noise_top + 1e-9, 0.05).tolist()
        g2 = plot([0, 3, 1], [noise_bottom, noise_top, 0.05], x_length=4.8, y_length=3.6, xticks=[0, 1, 2, 3], yticks=noise_ticks,'''
assert s.count(old)==1;s=s.replace(old,new);ast.parse(s);p.write_text(s)
(D/'candidate.patch').write_text(''.join(difflib.unified_diff((D/'before.py').read_text().splitlines(True),s.splitlines(True),fromfile='before/s10_knn.py',tofile='candidate/s10_knn.py')))
print(hashlib.sha256(s.encode()).hexdigest())
