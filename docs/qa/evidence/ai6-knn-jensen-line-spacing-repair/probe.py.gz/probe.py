from pathlib import Path
import ast,hashlib,json,os,shutil
import numpy as np
from explainer.ai import *
from explainer import lang
from explainer.zh_text import translate as translate_caption
from manim import config
from manim.animation.animation import prepare_animation
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;language=os.environ['EXPLAINER_LANG'];assert shutil.disk_usage(D).free>=512*2**20
config.media_dir=str(D/'constructor-artifacts'/language);config.tex_dir=str(D/'constructor-artifacts'/language/'Tex')
class GeometryOnly:
    def __init__(self):self.calls=[]
    def play(self,*anims,**kw):
        self.calls.append({'types':[type(x).__name__ for x in anims],'kwargs':kw})
        for x in anims:
            a=prepare_animation(x);a.begin();a.interpolate(1);a.finish()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
common=ast.parse((R/'videos/ai/ai6/common.py').read_text());side=next(n for n in common.body if isinstance(n,ast.FunctionDef)and n.name=='side_ladder')
scope=dict(globals());exec(compile(ast.Module([side],type_ignores=[]),'actual-side-ladder-only','exec'),scope)
def build(path):
    tree=ast.parse(path.read_text());fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='cover_hart');nodes=[]
    for n in fn.body:
        if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id in {'rows','jensen','whys','step'}for t in n.targets):nodes.append(n)
        if isinstance(n,ast.If)and any(isinstance(x,ast.Name)and x.id=='jensen'for x in ast.walk(n)):nodes.append(n)
    dummy=GeometryOnly();s=dict(scope,self=dummy);exec(compile(ast.Module(nodes,type_ignores=[]),'actual-layout-only-constructors','exec'),s)
    for i in range(4):s['step'](i,transform=False)
    return s,dummy
before,bscene=build(D/'before.py');after,ascene=build(R/'videos/ai/ai6/s10_knn.py')
# These are Mobject/Animation geometryoperations only: neither Scene nor Camera
# nor a renderer/decoder is constructed. All productiondata/load code is excluded.
for old,new in zip(before['rows'],after['rows']):np.testing.assert_array_equal(old.get_all_points(),new.get_all_points())
for i in range(3):np.testing.assert_array_equal(before['whys'][i].get_all_points(),after['whys'][i].get_all_points())
if language=='en':
    for old,new in zip(before['whys'],after['whys']):np.testing.assert_array_equal(old.get_all_points(),new.get_all_points())
bounds=lambda m:[float(m.get_left()[0]),float(m.get_right()[0]),float(m.get_bottom()[1]),float(m.get_top()[1])]
def glyphs(m):
    # A single Tex argument's SVGglyphobjects retain sourceglyphorder.
    a=list(m[0].submobjects)
    return [{'index':i,'bounds':bounds(g),'points':len(g.get_all_points())}for i,g in enumerate(a)]
bo,af=before['whys'][3],after['whys'][3];oldglyphs,newglyphs=glyphs(bo),glyphs(af)
if language=='zh':
    # Existing firstline: 詹森不等式， (6glyphs), then math R* = E r (5glyphs).
    assert len(oldglyphs)==len(newglyphs)==11,(len(oldglyphs),len(newglyphs))
    def gap(gs):
        top=gs[:6];bottom=gs[6:];return min(x['bounds'][2]for x in top)-max(x['bounds'][3]for x in bottom)
    oldgap,newgap=gap(oldglyphs),gap(newglyphs);assert newgap>0 and newgap>oldgap
else:oldgap=newgap=None
b=bounds(af);inset=min(b[0]+config.frame_width/2,config.frame_width/2-b[1],b[2]+4,4-b[3]);assert inset*60>=15
r={'language':language,'source_before_sha256':sha(D/'before.py'),'source_after_sha256':sha(R/'videos/ai/ai6/s10_knn.py'),'current_table_sha256':sha(R/'videos/ai/ai_text_zh.json'),'no_Scene_Camera_renderer_decoder_or_productiondata':True,'original4proofrow_pointarrays_exact':True,'first3reason_pointarrays_exact':True,'all_EN_reason_pointarrays_exact':language=='en','before_final_reason_bounds':bounds(bo),'after_final_reason_bounds':b,'after_frame_inset_world':inset,'after_frame_inset_px480':inset*60,'before_glyphs':oldglyphs,'after_glyphs':newglyphs,'line_union_gap_world_before':oldgap,'line_union_gap_world_after':newgap,'line_union_gap_px1080_after':None if newgap is None else newgap*135,'constructor_text_before':list(bo.tex_strings),'constructor_text_after':list(af.tex_strings),'pretranslated_Jensen_variable':after.get('jensen'),'dummy_geometry_play_calls':ascene.calls,'scope':'IsolatedactualTex/side_ladder/animationgeometry only, notrenderedpixels. Nativeimagesnotviewedbyowner; hostreportseparateevidence.'}
(D/f'geometry-{language}.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in ['before_glyphs','after_glyphs','dummy_geometry_play_calls']},ensure_ascii=False,indent=2))
