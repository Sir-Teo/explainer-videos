# Matrices and Eigen motion repair regression

All four confirmed final silent movies pass the selected-time visual regression. The quarter turns preserve scale, the Eigen heading stays readable through the moving grid, and the Matrices rank/null-space captions remain protected.

| Case | Selected times covered | Newly viewed unique frames | Exact PNG inheritance | Changed pages | Native followups |
|---|---:|---:|---:|---:|---:|
| en-Matrices | 299 | 60 | 221 | 8 | 4 |
| en-Eigen | 340 | 54 | 226 | 7 | 5 |
| zh-Matrices | 293 | 63 | 209 | 8 | 4 |
| zh-Eigen | 361 | 10 | 277 | 2 | 5 |

Across four movies, 9,146 source frames were decoded and 1,293 selected times were covered: 187 newly viewed unique representatives on 25 pages, plus 933 unique representatives inherited only by exact PNG SHA equality to earlier actually viewed frames. Eighteen native followups were viewed. Each case retains all selected timestamps, page hashes and view checkpoints, exact inheritance mappings, native evidence, source/movie/tool hashes, and unextracted-frame gaps. The maximum selected gap is one second.

A magnified Chinese composition heading at 52.133 seconds confirms that the nearby grid stops at its mask boundary without covering the glyph ink. This was checked and is not an additional defect. The earlier negative-zero claim was a sign misread and was retracted; the preserved native shows +0.00, and no determinant-formatting fix is claimed.

Parent-confirmed source/movie hashes were independently matched before review. Final module hashes are Matrices `ddc663f7dddd7d9377b269a4aff97268316f944b3d3a532867f968962ee25e47` and Eigen `5f83069e33e325b05874f5b9c9a507bd5b06d5f2b10fa2ab7c2ee4bd86278fd0`; render fingerprint `138a87a47d0fd2dfb3be01795bc4678cd2afb28c878618761ab9a9eb70fd685e`. All four render records have zero warnings. Later unrelated source changes can stale the aggregate fingerprint; extraction-time comparisons remain preserved.

Continuous perceptual playback and audio listening/synchronization remain unverified. Full-file decoding and selected-frame coverage do not establish either. No source, data, model, compute, or render mutations were made during this review.

Before/after native comparisons are preserved in `en-eigen-before-after.png` and `en-matrices-before-after.png`. Detailed records are in each case's `review.json`; the original six-case review is preserved separately at `/workspace/runtime/ai3-matrices-projection-eigen-motion-review/`.
