from pathlib import Path
import json,gzip,hashlib,shutil
R=Path('/workspace/explainer-videos');O=Path('/workspace/runtime/ai4-first-five-integrated-endpoint-review');B=Path('/workspace/runtime/ai4-first-five-endpoint-review-en');P=R/'docs/qa/evidence/ai4-first-five-endpoint-review'
review=json.loads((O/'review.json').read_text());prior=json.loads((B/'coverage.json').read_text());unit=review['unit_repair'];assert len(review['cases'])==10
for case in review['cases'].values():
 assert case['runtime_status'] in ('passed','needs-review')
 if case['lang']=='zh':assert all(Path(f['path']).exists() for f in case['frames'])
 else:assert all(x['matches'] for x in case['mapping'])
P.mkdir(parents=True,exist_ok=False);origins=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def comp(src,rel):
 dst=P/rel;dst.parent.mkdir(parents=True,exist_ok=True);raw=src.read_bytes();dst.write_bytes(gzip.compress(raw,compresslevel=9,mtime=0));origins.append({'file':rel,'original_file':str(src),'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest()})
def copy(src,rel):
 dst=P/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(dst)==sha(src)
comp(O/'review.json','integrated-review.json.gz');comp(B/'coverage.json','prior-en-actual-review.json.gz');comp(O/'Layers-unit-regression/receipt.json','chinese-unit-repair.json.gz');comp(Path(__file__),'packaging-script.py.gz')
for key,case in review['cases'].items():
 lang,scene=key.split('/');record=Path(unit['after']['runtime_record']) if key=='zh/Layers' else Path(case['runtime_record']);comp(record,f'records/final/{lang}/{scene}.json.gz')
 if lang=='en':
  comp(O/'en'/scene/'exact-prior-map.json',f'english-exact-inheritance/{scene}.json.gz')
  comp(Path(prior['cases'][scene]['preserved_runtime_record']),f'records/historical-pretranslation/en/{scene}.json.gz')
  old=B/scene;copy(old/'sheet.png',f'images/sheets/en/{scene}-original-reviewed.png')
  for filename in prior['cases'][scene]['native_followups']:copy(old/filename,f'images/native/en/{scene}/{filename}')
 else:
  old=O/'zh'/scene;sheetname=scene+'-before-unit' if scene=='Layers' else scene
  copy(old/'sheet.png',f'images/sheets/zh/{sheetname}.png')
  for filename in case['native_followups']:copy(old/filename,f'images/native/zh/{scene}/{filename}')
comp(O/'zh/Layers/result.json','records/historical-before-unit/zh/Layers.json.gz')
comp(B/'Derivative-after/result.json','records/historical-axis-repair/en/Derivative.json.gz')
copy(B/'Derivative/008_00074.6s.png','images/repairs/Derivative-English-before.png');copy(B/'Derivative-after/008_00074.6s.png','images/repairs/Derivative-English-after.png');copy(O/'zh/Layers/005_00042.4s.png','images/repairs/Layers-Chinese-before.png');copy(Path(unit['after']['native_png']),'images/repairs/Layers-Chinese-after.png')
for rel in ['s01_hook.py','s02_derivative.py','s03_gradient.py','s04_jacobian.py','s05_layers.py','common.py','zh_lines.py','narration_zh.json']:
 comp(R/'videos/ai/ai4'/rel,'source-at-packaging/ai4/'+rel+'.gz')
comp(R/'videos/ai/ai_text_zh.json','source-at-packaging/ai_text_zh.json.gz');comp(B/'Derivative/scene-source-before.py','source-at-packaging/Derivative-before-axis-repair.py.gz')
summary={'scope':'First five Part4 bilingual 854x480endpoint review only. No continuous/silent-motion/narrated/full1080approval.',**review['summary'],'current_case_map':{k:{'record':f'records/final/{k}.json.gz','images':len(v.get('frames',v.get('mapping',[]))),'actual_coverage':'Chinese actual sheet/native review' if k.startswith('zh/') else 'English exact byte inheritance from completed prior actual review'} for k,v in review['cases'].items()},'observed_translation_freezes':review['observed_translation_freezes'],'source_snapshot_scope':'Source at packaging observation; capture-time/root-attested identities and known Floats overlap are retained separately in review/repair receipts.','final_layers_chinese':unit['after'],'no_source_or_numeric_cache_edits':True}
(P/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n');(P/'compressed-origins.json').write_text(json.dumps(origins,indent=2)+'\n')
print(json.dumps({'directory':str(P),'files_before_readme_manifest':sum(f.is_file() for f in P.rglob('*')),'bytes':sum(f.stat().st_size for f in P.rglob('*') if f.is_file())}))
