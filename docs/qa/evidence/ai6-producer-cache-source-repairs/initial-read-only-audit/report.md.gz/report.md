# Part6 data/evaluation source audit

Frozen compute SHA `9a382aa797733fb5d281864f7faca46ccbe135e9cb322749405424a3b3c21df3`. Reviewed all22 compute-item protocols and corresponding evaluation claims inEN/ZH. No production module import, model, download, default experiment, cache load, render or repository edit. Tiny isolated AST/stdlib counterexamples only. Part6 cache absent at open and close.

Seven concrete source findings follow. Source reasoning and synthetic probes do not establish that any historical/default measured number is wrong.

## AI6-D01: Heldout pages influence the chosen vocabulary; page split estimates same-novel chunks

**P2-protocol-mismatch; verified-source-path; default impact unmeasured.**

References: compute.py:69-102, s01_hook.py:112-115, s06_logistic.py:result, s17_metrics.py:227-236, zh_lines.py:36, zh_lines.py:134-135, zh_lines.py:352-353.

Top70 allw includes complete texts of all five novels before page holdout. Changing only heldout token frequencies can change selected features. Book IDs are stored but splitting is by individual page/author; neighboring pages of the same novel can span splits. This is unsupervised representation influence, not label leakage, and same-novel evaluation can be valid if declared.

Bounded repair: Declare fixed-corpus vocabulary and same-five-novel scope in both languages, or fit vocabulary strictly on outer-training content (and inner folds when claiming full-pipeline CV). Do not imply unseen-novel transfer without a separately defined grouped benchmark. Preserve shared split/standardize interfaces forParts7/8/11.

## AI6-D02: Completed and partial caches lack source/data/schema identities

**P1-cache-preflight; verified-source-control-flow; no actual staleai6 data loaded.**

References: compute.py:44-47, compute.py:1262-1263, compute.py:1704-1723, compute.py:1772-1777, explainer/ai/cache.py:38-42, explainer/ai/cache.py:74-95, explainer/ai/cache.py:130-137.

Completed items accepted by JSON existence. JSON/NPZ keys, shape, finiteness, corpus hashes and producer versions are not validated. Missing NPZ is silently skipped by load. Board resumeparams onlyfolds/seed/v1; bagging onlyRs/T/m. An old piece survives changed pages/settings/source if these params stay the same. The lock/atomic-save protocol prevents normal concurrent partial writes, but does not prove semantic currentness.

Bounded repair: Add a Part6-specific schema/cache contract with pure cached-only validation, complete source recipe and upstream rawbook/page hashes, runtime/seed/settings identity, required fields/shapes/finiteness. Resumepieces must match same contract/fold digest and per-piece methods. Preserve/quarantine stale legacy data explicitly; never secretly compute from a validator/render path. Avoid changing shared Cache behavior for all31parts.

## AI6-D03: Documented makeai6 fresh-book prerequisite is not scheduled

**P1-clean-start-portability; verified actual isolated dependency-scanner result; no make/producer run.**

References: compute.py:69-80, compute.py:143-147, README.md:123-132, tools/make.py:60-95, tools/make.py:126-145, videos/ai/ai1/compute.py:273-280.

Actual AST-only depends_on(ai6) returns{}. Aliased ai1 helper calls have no load literal and are removed from dependency set. First itempages directlyread_texts rawbooks; only laterzipf calls c1.text, which can produce missing corpus. Thus missing rawbooks cause FileNotFoundError before promised first-step provision. Existing completed Part1 books avoid this in the current workspace.

Bounded repair: Add explicit item-level corpus prerequisite in orchestration or a precise fail-fast prerequisite check before any Part6 run. Keep producer execution single-owner; do not use an implicit scene load to download/recompute inputs.

## AI6-D04: Probability clipping caps log loss without disclosure

**P2-score-semantics; verified isolated actual-source functions on one synthetic row; default occurrence untested.**

References: compute.py:406-413, compute.py:569-577, compute.py:591-619, s17_metrics.py:169-187, zh_lines.py:419-422.

reliability logloss clips probabilities to1e-12. With actual sigmoid(z=1000)=1 andy0, reports27.631021nats versus stable logloss1000nats. It is a bounded/clipped score, whereas narration says proper logloss charges every confidence digit. AllOOFprobabilities are stored, but logits only forNB, so stable exact scores are not recoverable for all methods from current payload.

Bounded repair: Retain every methodOOFlogit and compute stable np.logaddexp logloss from logits; use probabilities only forECE/Brier/plots. Alternatively explicitly label clipped-logloss cap and metadata consistently, accepting it is a different reporting convention. Record how many default rows exceed floor when data exists.

## AI6-D05: AUC interpretation omits half-credit for ties

**P2-narration-qualification; verified exact-source tie fixture; default tied-pair count unmeasured.**

References: compute.py:1516-1535, s17_metrics.py:81-92, zh_lines.py:343-344.

roc groups ties and mann_whitney correctlyadds0.5ties. Both language narration interpretsAUC as strict probability Dickensscores higher. One equal-score0/1pair hasAUC0.5 butstrictP(>)0.

Bounded repair: Add plus half the chance of a tie inEN/ZH, keeping actual algorithm and displayed numbers.

## AI6-D06: Contest calls a tied score a win

**P2-outcome-branch; verified actual scene expression on synthetic tie; default outcome unmeasured.**

References: s18_contest.py:54-67, zh_lines.py:358-362.

linear_wins useslr70>=xgb70, but truebranch sayslogistic beats boostedtrees andZHuses胜过. Equal0.8scores produce thatstrict-win wording. Finite outcomes are otherwise compared on the same folds.

Bounded repair: Use explicit greater/equal/less branches (and finiteness validation before rendering), label sampled-CV wins descriptively rather than a statistically significant or universal ranking.

## AI6-D07: Logistic producer refuses valid tied/worse70-feature results

**P2-producer-outcome-censoring; verified actual assertion predicate on legitimate synthetic outcome; no default computation.**

References: compute.py:466-502.

Finalassert acc70>acc2>0.75 rejects legitimate measured outcomes unrelated to solver correctness, before any payload can be returned. Exampleboth.8 withpositiveHessian is rejected. This prevents scene branches from reporting a surprising outcome if source/corpus changes.

Bounded repair: Separate numerical correctness/finiteness checks from outcome claims; cache actual accuracy and adapt narration, retaining successful existing measurements without forcing a preferred winner.

## Preserved correct behavior and limits

- Train/test and fold standardization use training rows only. No global mean/std scaling leak found in reviewed paths. References: compute.py:111-113, compute.py:262-272, compute.py:341-353, compute.py:749-756, compute.py:1076-1085, compute.py:1596-1646.
- Platt calibration uses inner out-of-fold scores on each outer-training cohort; outer validation labels do not fit the calibration map. References: compute.py:593-612.
- Board comparisons share exact ten stratified folds and feature cohorts; no in-board hyperparameter optimization on validation/heldout labels. Different methodsettings/budgets are explicit, so this is a fixed-procedure comparison, not equal computational budget. References: compute.py:1704-1722.
- Chapter text explicitly distinguishes heldout-best diagnostic setting from trainingCV choice; computing an entire heldout diagnostic curve is not itself proof of tuning model parameters on it. References: s10_knn.py:105-119, s13_trees.py:130-139.
- Reported CVshuffle variation is conditional on one finite page corpus, with90% training per fold versus70% in random split experiment. It is not an independent-generalization confidence interval; noCIlabel found. Recommend explicit partition-sensitivity/training-size qualifier. References: compute.py:1567-1591, s17_metrics.py:196-236.
- Board contains12named representative procedures/22feature cases and omits a separate ridge row; wording everymethod is broader than literal inventory. No default ranking/winner or rendering validated. References: compute.py:1683-1697, s18_contest.py:30-69.

## Item inventory

| Item | Dataset/evaluation | Inspected behavior |
|---|---|---|
| pages (78–102) | 5 raw Part1 novels | Vocabulary chosen on full corpus, then author-stratified random page70/30 split; records book IDs but not raw-input hashes. |
| zipf (143–156) | Part1 training-text helper | Separate Part1 text experiment; not page classification; helper may autocompute missing corpus. |
| gaussmarkov (169–202) | synthetic regression | Seeded independent Gaussian/t3 simulation; no page-split evaluation. |
| lsq (206–238) | fixed page train/test | Training-only standardization; three solvers share identical design; test score at0.5. |
| ridge (247–281) | training-page ten-fold CV plus fixed heldout | Fold-local standardization; lambda selected on training CV; all heldout lambda scores also computed for demonstration. |
| lasso (310–402) | training-page ten-fold CV plus fixed heldout | Fold-local standardization; lambda grid scale derives from complete training labels; all heldout path scores computed; sparse/oneSE choice from CV. |
| logistic (466–502) | fixed page train/test | Train-only standardization and fixed penalties; performance assertion requires70-rate accuracy strictly beat2-rate accuracy. |
| irls (506–556) | training objective/convergence plus fixed test | Train-only standardization; optimization/separability branch assumptions need separate math review; no default result measured here. |
| calibration (586–620) | all-page outer ten-fold CV; inner five-fold Platt | Every outer prediction excludes that page; inner out-of-fold scores train calibration only on outer-training labels. Global original test flag intentionally not used. |
| nbvslr (627–662) | training-only subsample draws against fixed heldout | Both models share each selected training subset and test pages; normalization uses that subset. Same test reused descriptively across sample sizes. |
| lda (683–725) | fixed page train/test | Fit centers/covariance/standardization on training pages; evaluate fixed heldout. |
| knn (738–758) | fixed train/test and training-only CV | Train-only/fold-local standardization; chapter explicitly displays heldout bestk and trainingCVk separately. |
| coverhart (765–805) | synthetic Gaussian neighbors | Known-distribution asymptotic comparison; no page-split evaluation. |
| curse (812–838) | synthetic cube plus noisy page features | Noise features generated for all rows, standardization fits training only; heldout descriptive curves over noise dimension. |
| kernel (862–944) | synthetic features plus fixed page train/test | Train-only page standardization; Gram/features checks conditional on training pages; fixed heldout score. |
| svm (1012–1099) | fixed train/test plus training-page CV | Fold-local standardization and paired folds across C/gamma; selected pair evaluated on heldout; many heldout grid diagnostics also generated. |
| trees (1186–1238) | fixed train/test plus training-page depth CV | No learned scaling; test depth diagnostics and CV choice displayed separately; bootstrap variation shares heldout. |
| bagging (1242–1310) | training/bootstraps; fixed heldout and OOB | Test locations used to measure prediction variance and accuracy; OOB uses only trees excluding that row. Partial pieces keyed only byRs,T,m. |
| adaboost (1345–1398) | training rounds, fixed heldout diagnostic trajectory | Weight/stump choices use training only; fixed round budgets; same heldout measured each round. |
| xgb (1455–1512) | training rounds, fixed heldout diagnostic trajectory | Split/leaf choices use training only; fixed depth/lambda/rate; first/second-order comparisons share data. |
| metrics (1538–1592) | all-page OOF scores + resampled prevalence/splits | ROC/AP use calibrationOOF;10070/30 fits versus20 repetitions of90/10 ten-foldCV are different training sizes; variation is partition sensitivity. |
| board (1700–1724) | same all-page ten-fold CV plus fixed70/30 heldout | 12named representative methods;22method/feature cases; same folds/paired predictions; settings fixed in function source, not tuned inside board; partialparams omit source/data identity. |

All31 frozen source/support files remain unchanged at close: True. Full exact hashes and snapshots are retained locally in this runtime report. No full Part6QA completion, default numerical validation, rendered review, continuous playback or audio claim.
