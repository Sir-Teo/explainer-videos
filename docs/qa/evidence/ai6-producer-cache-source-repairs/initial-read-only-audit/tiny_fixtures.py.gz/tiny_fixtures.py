"""Tiny isolated source/counterexample probes. No production-module imports, loaders or experiments."""
from pathlib import Path
import ast,collections,hashlib,json,math,re,types
import numpy as np

REPO=Path('/workspace/explainer-videos')
OUT=Path(__file__).parent
source=OUT/'sources/videos/ai/ai6/compute.py'
tree=ast.parse(source.read_text())
def isolated(names,env):
 nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
 assert len(nodes)==len(names)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),env)
 return env

findings={}
# Preserve the actual clipping and stable-logit implementations; tiny one-page fixture only.
env=isolated(['reliability','logloss','sigmoid','roc','mann_whitney'],{'np':np,'math':math})
z=np.array([1000.]);y=np.array([0.]);p=env['sigmoid'](z)
clipped=env['reliability'](p,y)['logloss'];stable=env['logloss'](z,y)
assert math.isclose(clipped,-math.log(1e-12)) and stable==1000.
findings['clipped_logloss']={'logit':1000,'label':0,'computed_probability':float(p[0]),'actual_reliability_logloss':clipped,'actual_stable_logloss':stable,'scope':'Exact isolated AST functions, one synthetic row; no default-data result'}
scores=np.array([0.,0.]);y=np.array([0,1]);auc=env['roc'](scores,y)[4];mw=env['mann_whitney'](scores,y)
assert auc==mw==.5
findings['auc_tie']={'scores':scores.tolist(),'labels':y.tolist(),'actual_roc_auc':auc,'actual_mann_whitney_half_tie':mw,'strict_higher_probability':0.}

# Vocabulary selection can change while the training text remains exactly fixed.
train=['the']*3+['not']*2
test_a=['and']*4;test_b=['or']*4
vocab=lambda words:[w for w,_ in collections.Counter(words).most_common(2)]
assert vocab(train+test_a)!=vocab(train+test_b)
findings['heldout_vocabulary_influence']={'training_text':train,'heldout_A':test_a,'heldout_B':test_b,'whole_corpus_top2_A':vocab(train+test_a),'whole_corpus_top2_B':vocab(train+test_b),'training_only_top2':vocab(train),'scope':'Minimal illustration of the exact allw.most_common mechanism; not measured default top70 drift'}

# Execute the existing dependency scanner alone; no module import or subprocess launcher.
make=REPO/'tools/make.py';mt=ast.parse(make.read_text());nodes=[]
for n in mt.body:
 if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['_ALIAS','_LOAD_ALIAS','_COMMON_LOAD'] for t in n.targets):nodes.append(n)
 if isinstance(n,ast.FunctionDef) and n.name=='depends_on':nodes.append(n)
env={'re':re,'VIDEOS':REPO/'videos','video_dir':lambda v:REPO/'videos/ai'/v}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(make),'exec'),env)
deps=env['depends_on']('ai6');assert deps=={}
findings['dependency_scan']={'actual_AST_depends_on_ai6':deps,'scanner_sha256':hashlib.sha256(make.read_bytes()).hexdigest(),'rawbook_path':'Part1 BOOK_DIR/<id>.txt, directly read by ai6.book_words before zipf text helper','scope':'Read-only metadata scan; no make command or producer executed'}

# Partial constructor reads supplied bytes only. It has no input/source identity beyond params.
cache=OUT/'sources/explainer/ai/cache.py';ct=ast.parse(cache.read_text());part=next(n for n in ct.body if isinstance(n,ast.ClassDef) and n.name=='Partial')
env={'Path':Path,'json':json};exec(compile(ast.Module(body=[part],type_ignores=[]),str(cache),'exec'),env)
class MemoryPath:
 def __init__(self,raw):self.raw=raw
 def exists(self):return True
 def read_text(self):return self.raw
params={'folds':10,'seed':2025,'v':1}
prior={'params':params,'done':{'lr_70':{'cv':.91,'folds':[.91]*10,'held':.9}}}
piece=env['Partial'](MemoryPath(json.dumps(prior)),params,'isolated fixture')
assert 'lr_70' in piece and piece['lr_70']['cv']==.91
findings['partial_resume_identity']={'actual_params':params,'prior_piece_reused':piece['lr_70'],'changing_source_or_pages_changes_params':False,'scope':'Actual isolated Partial constructor on in-memory JSON only, no production cache access/write'}

scene=ast.parse((OUT/'sources/videos/ai/ai6/s18_contest.py').read_text())
expr=next(n.value for n in ast.walk(scene) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='line_s' for x in n.targets))
branch=eval(compile(ast.Expression(expr),'<isolated-contest-branch>','eval'),{'linear_wins':.8>=.8})
assert 'beats' in branch
findings['contest_tie_branch']={'lr70':.8,'xgb70':.8,'actual_condition':True,'actual_line_s':branch,'scope':'Actual isolated scene expression with synthetic tie, no default measurements'}
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='compute_logistic')
guard=next(n.test for n in ast.walk(fn) if isinstance(n,ast.Assert))
class PositiveEigenvalues:
 def min(self):return 1.
passes=eval(compile(ast.Expression(guard),'<isolated-performance-guard>','eval'),{'acc70':.8,'acc2':.8,'eig':PositiveEigenvalues()})
assert not passes
findings['performance_assertion']={'acc70':.8,'acc2':.8,'positive_hessian_min':1.,'actual_performance_guard_passes':passes,'scope':'Actual isolated source predicate; a legitimate tie is rejected before results are returned'}

findings['execution_scope']={'production_imports':0,'producer_calls':0,'model_calls':0,'default_data_reads':0,'repository_mutations':0,'tiny_synthetic_rows':3}
(OUT/'tiny-fixture-results.json').write_text(json.dumps(findings,indent=2)+'\n')
print(json.dumps(findings,indent=2))
