# Part6 producer/cache contract source handoff

The owned producer/cache batch is frozen with41 focused synthetic tests passing in2.450s. The recorded8 source/support/test files match exactly before and after the run; no Part6 default cache existed before or after. This is source and synthetic validation, not a default numerical or rendered QA sign-off.

The cache contract observes exact source/runtime/raw-input/dependent-payload identities, required JSON/NPZ fields, numeric types, shapes, finite values and explicit page/fold cohorts. Completed legacy bytes are never silently attested. Incompatible checkpoints are independently preserved; exact current checkpoints resume, forced runs do not reuse old pieces, and checkpoint retirement follows successful completed-item publication. Pure current/status and cached-only loads never launch producers or downloads.

Normal registered-producer autoload remains compatible for downstream Parts7/8/11, with precise missing-corpus errors. Explicit CLI input preparation is the only new download route: only missing/empty five public books, validated in temporary files and published atomically. Existing train/valid/corpus bytes and nonempty books are not rewritten. All download tests use mocks.

OOF logits for all four calibration procedures are retained. Probability reliability/Brier use the probabilities; log loss uses stable uncapped logits in nats per page. Extreme wrong-confidence and moderate-score cases, OOF/innerPlatt dataflow via fitting spies, outcome-guard behavior, lineage changes, NPZ absence/tampering, checkpoint interruptions/checksums, force handling and CLI isolation are covered. No fitted/default models or production experiment ran.

All non-pages registered ITEMS continue through the existing _item/_plain normalization. Internal direct bypass of that normalization is outside the supported producer entrypoint; a reviewer initially raised nested-array serialization as a default-run concern, then retracted it after confirming the registered wrapper. No source edit was made in response; the frozen hashes remain unchanged.

Independent code/schema review and root-owned actual22-item computation remain pending, followed by current-cache closure, default metric checks and actual bilingual visual/output QA. No full scientific, continuous playback, listening, production-resolution or upload claim is made.
