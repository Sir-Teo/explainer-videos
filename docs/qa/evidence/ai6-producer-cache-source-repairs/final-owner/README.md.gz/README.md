# Part 6 producer/cache contract source handoff

The owned producer/cache batch is frozen with **42 focused synthetic tests passing in 2.543s**. The eight recorded source/support/test files match exactly before and after the run; no Part 6 default cache existed before or after. This is source and synthetic validation, not default numerical or rendered QA approval.

The contract observes exact source/runtime/raw-input/dependent-payload identities, required JSON/NPZ fields, numeric types, shapes, finite values and explicit page/fold cohorts. Completed legacy bytes are never silently attested. Incompatible checkpoints are independently preserved; exact current checkpoints resume, forced runs do not reuse old pieces, and checkpoint retirement follows successful completed-item publication. Pure current/status and cached-only loads never launch producers or downloads.

Normal registered-producer autoload remains compatible for downstream Parts 7/8/11, with precise missing-corpus errors. Explicit CLI input preparation is the only new download route: only missing/empty five public books, validated in temporary files and published atomically. Existing train/valid/corpus bytes and nonempty books are not rewritten. All download tests use mocks.

OOF logits for all four calibration procedures are retained. ECE/Brier use probabilities; log loss uses stable uncapped logits in nats per page. Tests cover extreme wrong confidence and moderate scores, OOF/inner-Platt data flow via fitting spies, outcome guards, lineage changes, missing/tampered NPZ, interrupted checkpoints/checksums, force handling and CLI isolation. No fitted/default models or production experiment ran.

One independent integration finding was corrected before production: the old bound compute.load alias bypassed a later QA patch of CACHE.load when only --cached-only was supplied without the environment flag. The new dynamic dispatcher preserves calls while honoring the current guarded instance. The tiny before proof and new actual AST test are retained. The original 41-test receipt/source freeze remains in pre-dispatcher; the current 42-test run is separate, not a fictitious combined suite.

All non-pages registered ITEMS continue through the existing _item/_plain normalization. Internal direct bypass of that normalization is outside the supported producer entrypoint; a reviewer initially raised nested-array serialization as a default-run concern, then retracted it after confirming the registered wrapper. No source edit was made in response.

Independent code/schema review and root-owned actual 22-item computation remain pending, followed by current-cache closure, default metric checks and actual bilingual visual/output QA. No full scientific, continuous playback, listening, production-resolution or upload claim is made.
