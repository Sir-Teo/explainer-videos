from pathlib import Path
import ast,copy,datetime,hashlib,json,math,os,sys,tempfile,unittest
from unittest.mock import patch
import numpy as np
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R));O=Path(__file__).parent
from videos.ai.ai6 import contracts as C
from videos.ai.ai6.cache_contract import SchemaCache,CacheValidationError,canonical
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();T=ast.parse((R/'videos/ai/ai6/compute.py').read_text());functions={f.name:f for f in T.body if isinstance(f,ast.FunctionDef)}
namespace={'np':np};exec(compile(ast.Module([functions[n] for n in ('_plain','_item')],type_ignores=[]),'actual-registered-wrapper','exec'),namespace);wrap=namespace['_item']
constants={n.targets[0].id:ast.literal_eval(n.value) for n in T.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ('NB_SIZES','KS','SVM_CS','SVM_GS','AB_SNAPS','XGB_SNAPS')}
files=['videos/ai/ai6/compute.py','videos/ai/ai6/contracts.py','videos/ai/ai6/cache_contract.py','tests/test_ai6_cache_contracts.py','tests/test_ai6_score_contracts.py'];initial={p:H(R/p) for p in files};metrics={}
def pages():
 book=np.tile(C.BOOK_IDS,40);y=np.isin(book,C.BOOK_IDS[2:]).astype(int);n=len(y);test=np.arange(n)%3==0;X=np.zeros((n,70));X[:,0]=np.arange(n)+1;X[:,1]=np.arange(n)%5;i=int(np.flatnonzero(test)[0]);return dict(vocab=['the','not']+[f'w{k}' for k in range(68)],X=X,X2=X[:,:2].copy(),y=y,book=book,test=test,plot=['the','not'],example='the not',example_label=int(y[i]),example_i=i,n_pages=n,n_austen=int((y==0).sum()),n_dickens=int((y==1).sum()),titles={n:str(n) for n in C.BOOK_IDS},protocol=C.benchmark_protocol())
pg=pages();N=pg['n_pages'];NT=int((~pg['test']).sum());NTE=N-NT;cohort=dict(n_pages=N,n_train=NT,n_test=NTE,labels=pg['y'].tolist());grid=120;xs=np.linspace(0,1,grid);ys=xs.copy()
def cal(offset=0):
 z=np.linspace(-2,2,N)+offset;y=pg['y'];p=.5*(1+np.tanh(.5*z));d={k:C.score_summary(z,y,p) for k in ('lr2','lr70','nb','nb_platt')};d['acc']={k:float(((p>.5)==y).mean()) for k in d};d.update(nb_z=z,nb_extreme=0.,nb_median_abs_z=float(np.median(abs(z))),fold_ids=np.arange(N)%10,evaluation=dict(folds=10,seed=1950,inner_platt_folds=5,fold_sha256=C.content_digest((np.arange(N)%10).tolist()),protocol=C.benchmark_protocol()))
 for k in ('lr2','lr70','nb','nb_platt'):d['p_'+k]=p.copy();d['z_'+k]=z.copy()
 return d
foldvals=np.linspace(.6,.9,10)
def board_piece():return dict(cv=float(foldvals.mean()),sd=float(foldvals.std(ddof=1)),lo=float(foldvals.min()),hi=float(foldvals.max()),folds=foldvals.tolist(),held=.75)
def fixture(name):
 d={k:0. for k in C.REQUIRED[name].split()}
 if name=='pages':return copy.deepcopy(pg)
 if name=='zipf':d.update(f=np.ones(1000),r=np.arange(1,1001.),beta=np.array([2.,-1.]),n_words=100000,words=['the']*12,r2=.99)
 elif name=='gaussmarkov':
  d.update(x=np.linspace(1,10,12),beta=[1.,.5],R=40000,w_ols=np.ones(12),w_end=np.ones(12),w_mix=np.ones(12),hist_bins=np.linspace(.08,.92,43),samples=np.zeros((6,12)),theory={k:1. for k in ('ols','end','mix')})
  for k in ('hist_ols','hist_end','hist_ts'):d[k]=np.ones(42)
  for k in ('gauss','t3'):d[k]={s:dict(mean=.5,var=.1,se_mean=.001) for s in ('ols','end','mix','ts')}
 elif name=='lsq':d.update(acc_train=.8,acc_test=.7,ne_dup='singular',same_fit=True)
 elif name=='ridge':
  m=49;d.update(d=np.ones(70),lams=np.logspace(-1,5,m),shows=[1.,30.,1000.],shrink={str(k):np.ones(70)/(1+k) for k in (1.,30.,1000.)},uy=np.ones(70),coef=np.zeros((m,70)),best=0,one_se=1,lam_best=.1,d_ratio=1.)
  for k in ('df','cv_mse','cv_mse_se','cv_acc','cv_acc_sd','test_acc'):d[k]=np.ones(m)*.5
 elif name=='lasso':
  m=61;d.update(lams=np.logspace(0,-3,m),path=np.zeros((m,70)),epath=np.zeros((m,70)),twin_lasso=np.zeros((m,2)),twin_enet=np.zeros((m,2)),best=0,one_se=1,sweeps=[1]*m,words8=[],order=[],selected=[],pair=[],pair_idx=[])
  for k in ('nnz','cv_mse','cv_se','cv_acc','cv_acc_sd','test_acc','enet_nnz'):d[k]=np.zeros(m)
 elif name=='logistic':d.update(w=np.zeros(2),xs=xs,ys=ys,prob=np.ones((grid,grid))*.5,path=np.zeros((16,5)),curve=np.zeros((802,2)),hess_eig=np.ones(3)*.1,acc2=.5,acc70=.5,n_te=NTE)
 elif name=='irls':d.update(gd=np.zeros((90,2)),lines_newton=np.zeros((7,4)).tolist(),lines_gd=np.zeros((7,4)).tolist(),pens=[.1,.01,.001,.0001,.00001,.000001,.0000001],norms=[1.]*7,train_acc=[.8]*7,losses=[.1]*7,newton_gap=[1.,.5,0.],n_newton=2,separable=False)
 elif name=='calibration':return cal()
 elif name=='nbvslr':
  d.update(sizes=constants['NB_SIZES'],nb={},lr={},crossover=None,nb_better_at=[],nb_austen=[],nb_dickens=[])
  for k in ('nb','lr'):d[k]={str(n):dict(mean=.5,lo=.4,hi=.6,se=.01) for n in d['sizes']}
 elif name=='lda':d.update(w=np.ones(2),mA=np.zeros(2),mD=np.ones(2),covA=np.eye(2),covD=np.eye(2),SB=np.zeros((70,70)),SW=np.eye(70),angles=np.linspace(0,math.pi,181),sep=np.ones(181),eigvals=np.r_[1.,np.zeros(4)],top=['the','not'],top_signs=[1,-1],rank_SB=1)
 elif name=='knn':
  d.update(ks=constants['KS'],xs=xs,ys=ys,cv=np.ones(10)*.5,cv_sd=np.zeros(10),k_cv=1)
  for k in d['ks']:d['region'+str(k)]=np.ones((grid,grid))*.5;d['acc'+str(k)]=.5;d['train'+str(k)]=.5
 elif name=='coverhart':
  d.update(ns=[10,30,100,300,1000,3000,10000]);d.update({k:{str(n):dict(mean=.3,lo=.2,hi=.4) for n in d['ns']} for k in ('e1','ek')})
 elif name=='curse':
  d.update(dims=[1,2,3,5,10,20,50,100,200,500,1000],contrast=[1.]*11,nn_frac=[.5]*11,noise=[0,10,30,100,300,1000],edge={str(n):.5 for n in [1,2,3,5,10,20,50,100,200,500,1000]});d.update({k:{str(n):dict(mean=.6,lo=.5,hi=.7) for n in d['noise']} for k in ('knn','lr')})
 elif name=='kernel':d.update(n=NT,ev2=np.ones(NT),ev70=np.ones(NT),ev_sig=np.ones(NT),lift_w=np.ones(3),lift_sv=np.array([0,1]),taylor_err=np.zeros(20),lift_sep=True)
 elif name=='svm':
  d.update(Cs=constants['SVM_CS'],gammas=constants['SVM_GS'],xs=xs,ys=ys,cv=np.ones((5,5))*.5,cv_sd=np.zeros((5,5)),mu=np.zeros(2),sd=np.ones(2),n_train=NT,toy_w=np.ones(2),toy_sv=np.array([0,1]),toy_alpha=np.zeros(28),perc_w=np.ones(3),kkt={})
  for c in d['Cs']:d[f'region_C{c:g}']=np.zeros((grid,grid));d[f'alpha_C{c:g}']=np.zeros(NT);d[f'sv_C{c:g}']=np.array([0,1])
  for g in d['gammas']:d[f'region_g{g:g}']=np.zeros((grid,grid))
 elif name=='trees':
  d.update(depths=list(range(1,7)),cv=np.ones(7)*.5,cv_sd=np.zeros(7),boot_roots=[['the',3,'the','not']]*20,boot_acc=[.5]*20,tree3={'leaf':.5},rects_deep=[],box=[0,1,0,1])
  for k in range(1,7):d[f'rects{k}']=[];d[f'acc{k}']=.5;d[f'train{k}']=.5
  for word in ('the','not'):
   d[f'scan_{word}_t']=np.linspace(0,1,20)
   for k in ('gini','entropy','error'):d[f'scan_{word}_{k}']=np.ones(20)*.1
 elif name=='bagging':
  d.update(forest_acc=[.5]*300,forest_oob=[.5]*300,bag_acc=[.5]*100,Bm=[1,2,3,5,10,20,30,50],Rs=30,T=50,m=150,syn_B=[1,2,3,5,8,12,20,30,50,80,100],syn={})
  for k in ('mf70','mf8','mf2'):d[k]=dict(s2=.1,cov=.02,rho=.2,meas=[.1]*8,acc=[.5]*8)
 elif name in ('adaboost','xgb'):
  d.update(xs=xs,ys=ys,snaps=constants['AB_SNAPS' if name=='adaboost' else 'XGB_SNAPS'])
  if name=='xgb':d.update(T=200,lam=1.,eta=.3,depth=3,check_G=[1.,-1.],check_H=[1.,1.],check_word='the',check_thr=1.)
  else:d.update(first_words=['the'],alpha_check=0.)
  for feat,rounds in [('2',300 if name=='adaboost' else 200),('70',400 if name=='adaboost' else 200)]:
   fields=('eps','alpha','exp_loss','train_err','test_err') if name=='adaboost' else ('train_loss','test_loss','test_acc','train_acc','first_loss','first_acc')
   for field in fields:d[f'{field}_{feat}']=[.5]*rounds
  for k in d['snaps']:
   d[f'region{k}']=np.zeros((grid,grid))
   if name=='adaboost':d[f'w{k}']=np.ones(NT)/NT
 elif name=='metrics':
  d.update(split_acc=np.ones(100)*.5,cv_acc=np.ones(20)*.5,fold_acc=np.ones(200)*.5)
  for k in ('lr2','lr70','nb','rare'):
   d[k]=dict(auc=.5,ap=.5,mw=.5)
   for p in ('roc','pr'):d[f'{p}_{k}']=np.array([[0.,0.],[1.,1.]])
 elif name=='board':d.update(rows=[dict(key=k,name=k,**{str(nf):board_piece() for nf in fs}) for k,fs in C.BOARD_CASES.items()],n=N,folds=10,fold_ids=np.arange(N)%10,evaluation=dict(fold_sha256=canonical((np.arange(N)%10).tolist()),seed=2025,protocol=C.benchmark_protocol(),method_feature_cases=[f'{k}_{nf}' for k,fs in C.BOARD_CASES.items() for nf in fs]))
 return d
class SyntheticWholeContract(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.base=Path(self.tmp.name);self.cache=SchemaCache('ai6');self.cache.dir=self.base/'cache/ai6';books=self.base/'cache/ai1/books';books.mkdir(parents=True)
  for n in C.BOOK_IDS:(books/f'{n}.txt').write_text(f'Project Gutenberg eBook #{n}\n*** START OF THE PROJECT GUTENBERG EBOOK TEST ***\n'+'the not '*5000+'\n*** END OF THE PROJECT GUTENBERG EBOOK TEST ***\n')
  (books.parent/'train.txt').write_text('the not '*5000);self.items={n:wrap(lambda n=n:fixture(n)) for n in C.REQUIRED};self.cache.bind(self.items)
 def publish(self,n):self.cache._produce(n,self.items[n]);self.assertTrue(self.cache.current(n),self.cache.status(n))
 def test_all22_registered_shaped_payloads_roundtrip_as_current(self):
  result={}
  for n in C.REQUIRED:
   raw=fixture(n);self.assertTrue(C.valid_structure(n,raw,None if n in ('pages','zipf','gaussmarkov','coverhart') else cohort),n);out=self.items[n]();self.assertTrue(C.required_arrays(n,out)<={k for k,v in out.items() if isinstance(v,np.ndarray)},n);self.publish(n);result[n]={'top_level_arrays':{k:list(v.shape) for k,v in out.items() if isinstance(v,np.ndarray)},'required_array_count':len(C.required_arrays(n,out)),'status':self.cache.status(n)}
  metrics['22_synthetic_registered_roundtrips']=result
  with patch.object(self.cache,'_produce',side_effect=AssertionError('unexpected producer')):
   for n in C.REQUIRED:self.cache.load(n)
 def test_wrapper_normalizes_actual_nested_ridge_and_calibration_outputs(self):
  self.publish('pages')
  for n,key in [('ridge','shrink'),('calibration','lr2')]:
   raw=fixture(n);self.assertIsInstance(raw[key],dict);self.publish(n);loaded=self.cache.load(n)
   if n=='ridge':np.testing.assert_allclose(loaded['shrink']['30.0'],raw['shrink']['30.0']);self.assertIsInstance(loaded['shrink']['30.0'],list)
   else:np.testing.assert_allclose(loaded['lr2']['count'],raw['lr2']['count']);self.assertIsInstance(loaded['lr2']['count'],list)
 def test_pure_status_and_missing_cachedonly_load_no_write_no_lock(self):
  with patch.object(self.cache,'_produce',side_effect=AssertionError('producer')),patch.dict(os.environ,{'EXPLAINER_CACHED_ONLY':'1'}):
   for n in C.REQUIRED:self.assertEqual(self.cache.status(n)['status'],'missing');self.assertFalse(self.cache.current(n))
   with self.assertRaises(CacheValidationError):self.cache.load('pages')
  self.assertFalse(self.cache.dir.exists())
 def test_calibration_change_invalidates_metrics_without_production(self):
  for n in ('pages','calibration','metrics'):self.publish(n)
  self.cache._produce('calibration',wrap(lambda:cal(.2)));self.assertTrue(self.cache.current('calibration'))
  with patch.object(self.cache,'_produce',side_effect=AssertionError('producer')):self.assertEqual(self.cache.status('metrics')['status'],'stale')
 def test_page_change_invalidates_calibration_then_metrics_transitively(self):
  for n in ('pages','calibration','metrics'):self.publish(n)
  p=pages();p['X'][1,0]+=.5;p['X2'][1,0]+=.5;self.cache._produce('pages',lambda:p)
  with patch.object(self.cache,'_produce',side_effect=AssertionError('producer')):
   self.assertEqual(self.cache.status('calibration')['status'],'stale');self.assertEqual(self.cache.status('metrics')['status'],'stale')
if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SyntheticWholeContract));after={p:H(R/p) for p in files};receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'source_before':initial,'source_after':after,'source_unchanged':initial==after,'metrics':metrics,'scope':'Synthetic producer-shaped payloads and actual registered _item/_plain/cache state machine only; no actual default producer, download, model, production cache or renderer. Fixture values do not represent measured results and contract success does not validate all scientific semantics.'};(O/'core-probe-result.json').write_text(json.dumps(receipt,indent=2)+'\n');sys.exit(not result.wasSuccessful())
