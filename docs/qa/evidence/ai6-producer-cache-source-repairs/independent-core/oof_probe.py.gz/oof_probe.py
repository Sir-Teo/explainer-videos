from pathlib import Path
import ast,datetime,hashlib,json,math,sys
import numpy as np
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R));O=Path(__file__).parent
from videos.ai.ai6 import contracts as C
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();source=R/'videos/ai/ai6/compute.py';before=H(source);T=ast.parse(source.read_text());names={'rng','kfold','standardize','sigmoid','acc_of','reliability','compute_calibration'};nodes=[n for n in T.body if isinstance(n,ast.FunctionDef) and n.name in names];assert len(nodes)==len(names)
N=40;X=np.zeros((N,70));X[:,0]=np.arange(N);X[:,1]=(np.arange(N)%7)**2;y=np.arange(N)%2;X2=X[:,:2].copy();nbfits=[];lrfits=[];plattfits=[]
def fake_lr(a,labels,l2):lrfits.append({'features':a.copy(),'labels':labels.copy(),'l2':l2});return np.zeros(a.shape[1]),0.
def fake_nb(a,labels):
 ids=a[:,0].astype(int);bias=float(np.sum((ids+1)**2)/1000);nbfits.append({'ids':ids.copy(),'labels':labels.copy(),'bias':bias});return np.zeros(a.shape[1]),bias
def fake_platt(z,labels):plattfits.append({'z':z.copy(),'labels':labels.copy()});return .5,-.2
env=dict(np=np,math=math,FOLDS=10,split=lambda:(X,y,np.arange(N)%3==0,X2),newton_logreg=fake_lr,nb_fit=fake_nb,platt=fake_platt,score_summary=C.score_summary,canonical=C.content_digest,benchmark_protocol=C.benchmark_protocol)
exec(compile(ast.Module(nodes,type_ignores=[]),'actual-OOF-orchestration','exec'),env);out=env['compute_calibration']();f=out['fold_ids'];receipts=[]
assert len(nbfits)==60 and len(lrfits)==20 and len(plattfits)==10
for k in range(10):
 tr=np.flatnonzero(f!=k);va=np.flatnonzero(f==k);outer=nbfits[6*k];np.testing.assert_array_equal(outer['ids'],tr);np.testing.assert_array_equal(outer['labels'],y[tr]);assert not set(va)&set(outer['ids'])
 np.testing.assert_array_equal(out['z_nb'][va],np.full(len(va),outer['bias']))
 for j,A in enumerate((X2,X)):
  fit=lrfits[2*k+j];mu=A[tr].mean(0);sd=A[tr].std(0)+1e-9;np.testing.assert_allclose(fit['features'],(A[tr]-mu)/sd);np.testing.assert_array_equal(fit['labels'],y[tr])
 inner=env['kfold'](y[tr],k=5,seed=1999+k);np.testing.assert_array_equal(plattfits[k]['labels'],y[tr]);innerrows=[]
 for j in range(5):
  fit=nbfits[6*k+1+j];want=tr[inner!=j];held=tr[inner==j];np.testing.assert_array_equal(fit['ids'],want);np.testing.assert_array_equal(fit['labels'],y[want]);assert not set(held)&set(fit['ids']);assert not set(va)&set(fit['ids']);np.testing.assert_array_equal(plattfits[k]['z'][inner==j],np.full(len(held),fit['bias']));innerrows.append({'inner_fold':j,'train_ids':want.tolist(),'held_ids':held.tolist(),'predicted_bias':fit['bias']})
 receipts.append({'outer_fold':k,'outer_train_ids':tr.tolist(),'outer_validation_ids':va.tolist(),'inner':innerrows,'platt_logits_sha256':hashlib.sha256(plattfits[k]['z'].tobytes()).hexdigest()})
assert C.valid_structure('calibration',out,dict(n_pages=N,labels=y.tolist()));assert H(source)==before
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':before,'source_unchanged':True,'outer_folds':10,'inner_models':50,'fake_LR_fits':20,'fake_NB_fits':60,'fake_Platt_fits':10,'training_only_standardization_verified':True,'every_outer_prediction_excludes_its_row':True,'each_inner_Platt_input_row_predicted_by_model_excluding_it':True,'outer_validation_rows_excluded_from_every_inner_fit':True,'finite_original_logits_and_probabilities_valid':True,'fold_receipts':receipts,'scope':'Actual AST calibration orchestration with synthetic rows and stub fitters only. No numerical fitting, default producer, production load/cache, download/model or renderer.'};(O/'oof-probe-result.json').write_text(json.dumps(report,indent=2)+'\n');print('OOF isolation verified:10 outer,50 inner;20 fake LR/60 fake NB/10 fake Platt; source',before)
