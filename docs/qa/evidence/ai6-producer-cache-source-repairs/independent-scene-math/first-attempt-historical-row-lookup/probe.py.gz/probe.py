from pathlib import Path
import ast,datetime,hashlib,json,math,sys,unittest
import numpy as np
from manim import VMobject
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R));O=Path(__file__).parent
H=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=['videos/ai/ai6/s09_lda.py','videos/ai/ai6/s12_svm.py','videos/ai/ai6/s16_gboost.py','videos/ai/ai6/s13_trees.py','tests/test_ai6_scene_teaching_repairs.py','videos/ai/ai6/zh_lines.py','videos/ai/ai6/text_zh_add.json','explainer/ai/viz.py','videos/ai/ai6/compute.py']
before={p:H(R/p) for p in paths};(O/'before-source-identities.json').write_text(json.dumps(before,indent=2)+'\n')
def tree(p):return ast.parse((R/p).read_text())
def method(p,name):return next(n for n in ast.walk(tree(p)) if isinstance(n,ast.FunctionDef) and n.name==name)
def execute(nodes,**scope):
 scope=dict(np=np,math=math,**scope);exec(compile(ast.Module(nodes,type_ignores=[]),'actual-AST-independent-probe','exec'),scope);return scope
whiten=execute([method(paths[0],'whitening_geometry')])['whitening_geometry']
metrics={}
class IndependentMath(unittest.TestCase):
 def test_random_SPD_whitening_pooled_factor_and_pullback(self):
  rng=np.random.default_rng(771);errors=[]
  for k in range(50):
   Q,_=np.linalg.qr(rng.normal(size=(2,2)));ev=np.exp(rng.uniform(-2,2,2));cov=Q@np.diag(ev)@Q.T;means=rng.normal(size=(2,2));n=23;Sw=(n-2)*cov;g=whiten(cov,means);delta=means[1]-means[0]
   np.testing.assert_allclose(g['W']@cov@g['W'].T,np.eye(2),atol=2e-14)
   np.testing.assert_allclose(g['normal'],(n-2)*np.linalg.solve(Sw,delta),atol=2e-14)
   np.testing.assert_allclose(g['normal'],g['W'].T@g['delta_z'],atol=2e-14)
   np.testing.assert_allclose(g['after'],g['before']@g['W'].T,atol=2e-14)
   errors.append(float(np.max(np.abs(g['W']@cov@g['W'].T-np.eye(2)))))
  metrics['50_random_SPD_max_whitening_error']=max(errors)
 def test_generalized_positive_eigenpair_vs_zero_stationary_direction(self):
  cov=np.array([[4.,1.],[1.,2.]]);delta=np.array([2.,-1.]);SB=np.outer(delta,delta);w=np.linalg.solve(cov,delta);lam=delta@w
  np.testing.assert_allclose(SB@w,lam*cov@w)
  zero=np.array([1.,2.]);np.testing.assert_allclose(SB@zero,0,atol=1e-14)
  self.assertGreater(lam,0);self.assertAlmostEqual(float((zero@SB@zero)/(zero@cov@zero)),0)
  metrics['positive_lambda']=float(lam)
 def test_positive_max_does_not_make_arbitrary_w_maximizer(self):
  # A concrete counterexample for the still-unqualified displayed implication.
  SW=np.eye(2);SB=np.diag([1.,0.]);w=np.array([0.,1.]);maxJ=1.
  self.assertGreater(maxJ,0);self.assertFalse(np.allclose(SB@w,maxJ*SW@w))
  row=next(n for n in ast.walk(method(paths[0],'eigen')) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='cmath' and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value==r'\max J > 0')
  self.assertEqual(row.lineno,266);metrics['displayed_implication_counterexample']={'SW':SW.tolist(),'SB':SB.tolist(),'w':w.tolist(),'maxJ':maxJ,'left':(SB@w).tolist(),'right':(maxJ*SW@w).tolist(),'line':row.lineno}
 def test_LS_direction_agrees_but_half_threshold_can_differ(self):
  rng=np.random.default_rng(89);A=rng.normal(size=(7,2));D=rng.normal(size=(19,2))@np.array([[1.3,.4],[0.,.8]])+[2.,1.];X=np.r_[A,D];y=np.r_[np.zeros(len(A)),np.ones(len(D))];SW=(A-A.mean(0)).T@(A-A.mean(0))+(D-D.mean(0)).T@(D-D.mean(0));w=np.linalg.solve(SW,D.mean(0)-A.mean(0));b,bx,by=np.linalg.lstsq(np.c_[np.ones(len(X)),X],y,rcond=None)[0];coef=np.array([bx,by]);scale=float(coef@w/(w@w));np.testing.assert_allclose(coef,scale*w,atol=1e-14)
  cut_LDA=.5*(A.mean(0)+D.mean(0))@w;cut_LS=(.5-b)/scale
  self.assertGreater(abs(cut_LDA-cut_LS),.01);metrics['LS_threshold_counterexample']={'nA':len(A),'nD':len(D),'coefficient_scale':scale,'midpoint_cut':float(cut_LDA),'OLS_half_cut_in_same_score_units':float(cut_LS)}
 def test_actual_SVM_smooth_path_stays_below_true_top_boundary(self):
  curve=execute([method('explainer/ai/viz.py','curve')],VMobject=VMobject)['curve'];calls=[]
  class Ax:
   def c2p(self,x,y):return np.array([x,y,0.])
  def capture(ax,x,y,*a,**k):
   q=curve(ax,x,y,*a,**k);calls.append(q);return q
  names={'m','hingec','logc','exp_m','expc'};nodes=[n for n in method(paths[1],'hinge').body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in n.targets)]
  scope=execute(nodes,ax=Ax(),curve=capture,GOLD='gold',C=type('Colors',(),{'TRUE_P':'blue'}));m=scope['m'];exp=scope['exp_m'];self.assertAlmostEqual(exp[0],-math.log(4))
  bounds=[]
  for c in calls:
   pts=np.concatenate([f(np.linspace(0,1,17)) for f in []]) if False else np.array([f(a) for f in c.get_cubic_bezier_tuples() for a in []])
   samples=np.array([cubic[0]*(1-a)**3+3*cubic[1]*a*(1-a)**2+3*cubic[2]*a*a*(1-a)+cubic[3]*a**3 for cubic in c.get_cubic_bezier_tuples() for a in np.linspace(0,1,17)])
   bounds.append([float(samples[:,1].min()),float(samples[:,1].max())]);self.assertGreaterEqual(samples[:,1].min(),-1e-12);self.assertLessEqual(samples[:,1].max(),4+1e-12)
  metrics['actual_cubic_loss_path_y_bounds']=bounds
 def test_regularized_actual_Taylor_LHS_contains_Omega(self):
  first=next(n for n in ast.walk(method(paths[2],'derive')) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='cmath');self.assertIn(r'+ \Omega(f)',first.args[0].value)
  y=np.array([0.,1.,1.]);F=np.array([-.5,.4,1.2]);f=np.array([.01,-.015,.02]);p=1/(1+np.exp(-F));lam=.4;gamma=.3;omega=gamma*3+.5*lam*(f@f);loss=lambda z:float(np.sum(np.logaddexp(0,z)-y*z));lhs=loss(F+f)+omega;rhs=loss(F)+((p-y)*f+.5*p*(1-p)*f*f).sum()+omega
  self.assertLess(abs(lhs-rhs),1e-6);self.assertGreater(abs(loss(F+f)-rhs),.8);metrics['regularized_taylor_abs_error']=abs(lhs-rhs)
 def test_zero_error_gain_differs_from_strictly_concave_gain(self):
  L,R,weight=.2,.4,.5;parent=weight*L+(1-weight)*R;gain=lambda fn:fn(parent)-weight*fn(L)-(1-weight)*fn(R);error=lambda p:min(p,1-p);gini=lambda p:2*p*(1-p);entropy=lambda p:-p*np.log2(p)-(1-p)*np.log2(1-p)
  self.assertAlmostEqual(gain(error),0);self.assertGreater(gain(gini),0);self.assertGreater(gain(entropy),0);metrics['same_side_child_gains']={'parent':parent,'left':L,'right':R,'error':gain(error),'gini':gain(gini),'entropy':gain(entropy)}
 def test_actual_repaired_voiceovers_translate_and_preserve_bookmarks(self):
  from explainer.zh_templates import Translator
  tr=Translator('ai6');import re
  cases=[(paths[0],'fisher',dict(acc=.82,like_lr='.')),(paths[0],'eigen',dict(ld={'cos_eig':1.,'acc70':.9},also='It also agrees with least squares on a zero-one target in coefficient direction. The intercept and classification threshold are separate choices.',names="'the', 'not'")),(paths[1],'hinge',{}),(paths[2],'derive',{}),(paths[3],'impurity',dict(say="On the pages, all three agree on the first question: 'not' at most 9 times per thousand. "))]
  translated=[]
  for path,name,scope in cases:
   calls=[n for n in ast.walk(method(path,name)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover'];arg=calls[-1].args[0];en=eval(compile(ast.Expression(arg),'actual-VO-AST','eval'),scope);zh=tr(en);self.assertIsNotNone(zh);marks=lambda s:re.findall(r"<bookmark mark=['\"]([^'\"]+)['\"]/>",s);self.assertEqual(marks(en),marks(zh));translated.append({'scene':path,'method':name,'bookmarks':marks(en),'english':en,'chinese':zh})
  metrics['actual_repaired_voiceovers']=translated
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(IndependentMath);result=unittest.TextTestRunner(verbosity=2).run(suite);after={p:H(R/p) for p in paths};assert before==after
 receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'source_before_after_identical':True,'source_sha256':before,'metrics':metrics,'scope':'AST-extracted actual consumers, independent tiny NumPy and actual-Manim path interpolation; no producer/load/scene construction/render/default data/model import. The counterexample fixture proves an outstanding source formula defect, not an approved formula.'};(O/'probe-result.json').write_text(json.dumps(receipt,indent=2)+'\n');sys.exit(not result.wasSuccessful())
