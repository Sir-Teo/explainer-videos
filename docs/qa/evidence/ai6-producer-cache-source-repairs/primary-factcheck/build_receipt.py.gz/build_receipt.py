from pathlib import Path
import datetime, hashlib, json, subprocess

ROOT = Path('/workspace/explainer-videos')
OUT = Path('/workspace/runtime/ai6-tabpfn-primary-factcheck')
EXPECTED = {
 'videos/ai/ai6/README.md':'01c771710c4d29d56497a4e79e4ecfa38604e1db4943299e6c8be75511107e61',
 'videos/ai/ai6/s18_contest.py':'8df5ffd458a0c00a1ff06c48e0e2f39e51e8aa36dffd79d147d9dfb3d36ba32c',
 'videos/ai/ai6/zh_lines.py':'692021154cdc330720cb95dc26118b7eb4bc2d7d64521d0fa3faa666d0f70aec',
}
def sha(b): return hashlib.sha256(b).hexdigest()
pins = []
for name, expected in EXPECTED.items():
 b = (ROOT/name).read_bytes()
 observed = sha(b)
 row = dict(path=name, initial_observed_sha256=expected, receipt_observed_sha256=observed, unchanged_since_initial_read=observed == expected, bytes=len(b))
 # Only these exact observed bytes are snapshots; no historical-import claim.
 dest = OUT/'source-observations'/name
 dest.parent.mkdir(parents=True, exist_ok=True)
 dest.write_bytes(b)
 row['snapshot'] = str(dest.relative_to(OUT))
 pins.append(row)

sources = [
 dict(id='nature-v2',title='Accurate predictions on small data with a tabular foundation model',url='https://www.nature.com/articles/s41586-024-08328-6',published='2025-01-08',issue_date='2025-01-09',locators=['Abstract','Detailed evaluation protocol','Comparison with state-of-the-art baselines'],verdict='verified_with_benchmark_qualifiers',facts='Up to10000 samples;2.8s average classification,4.8s regression. Evaluation used8CPU cores and additionally RTX2080Ti for TabPFN. Single-forward-pass in-context mechanism supported. Timing is not a universal hardware/task guarantee.'),
 dict(id='tabpfn-2.5',title='TabPFN-2.5: Advancing the State of the Art in Tabular Foundation Models',url='https://arxiv.org/abs/2511.08667',version_url='https://arxiv.org/html/2511.08667v2',submitted_utc='2025-11-11T18:57:15Z',revised_utc='2026-02-05T00:17:10Z',verdict='verified',facts='Abstract supports50000 points/2000 features. Base model is synthetic-pretrained; distinguish Real-TabPFN-2.5, a separately real-data-finetuned variant.'),
 dict(id='tabpfn-3',title='TabPFN-3: Technical Report',url='https://arxiv.org/abs/2605.13986',version_url='https://arxiv.org/html/2605.13986v2',submitted_utc='2026-05-13T18:01:43Z',revised_utc='2026-05-28T17:22:15Z',verdict='verified_as_authors_report',facts='1M training rows at200features;100K at2000;1K at20000. Authors report leading TabArena results. No independently checked current live leaderboard rank or installed-hardware feasibility is established.'),
 dict(id='beyond-iid',title='Beyond IID: How General Are Tabular Foundation Models, Really?',url='https://arxiv.org/abs/2606.30410',version_url='https://arxiv.org/html/2606.30410v1',submitted_utc='2026-06-29T14:55:52Z',locators=['Author affiliations','Section5 Experimental Design','Abstract','Competing Interests','AppendixD.2'],verdict='citation_verified_scene_scope_incorrect',facts='142datasets/11models. Tested TFMs:TabDPT,TabPFN-2.6,TabICLv2; in-context defaults,no fine-tuning. Purucker/Hutter are TabPFN-2.6 authors;4authors disclose PriorLabs affiliation. Thus author-independent is false; result does not test TabPFN-3. Small/medium IID strengths; harder regimes can favor traditional trees AND neural models. Some>100K TabPFN2.6/TabDPT results are imputed, not successful large-run measurements.'),
 dict(id='trees-2022',title='Why do tree-based models still outperform deep learning on tabular data?',url='https://arxiv.org/abs/2207.08815',submitted_utc='2022-07-18T08:36:08Z',verdict='verified',facts='45datasets, medium-size approximately10Ksamples. Three empirical inductive-bias concerns support the scene explanation; this is not a theorem that every neural architecture always loses.'),
]
findings = [
 dict(id='F1',status='confirmed_incorrect',where=['README.md:133-134','s18_contest.py:174-175,187','zh_lines.py:369'],claim='independent check / independent benchmark / 独立基准测试',primary='beyond-iid',repair='Remove independent; disclose model-author overlap if contrasting with makers-report.'),
 dict(id='F2',status='confirmed_unsupported_transition',where=['s18_contest.py:185-188','zh_lines.py:369'],claim='found them immediately after TabPFN-3 release',primary='beyond-iid',repair='Name evaluated TabPFN-2.6 cohort; do not imply BeyondIID measured TabPFN-3.'),
 dict(id='F3',status='scope_correction',where=['s18_contest.py:174-175,187-189','zh_lines.py:369'],claim='small/medium best; trees lead large/shifting/wide',primary='beyond-iid',repair='Include IID qualification and traditional neural baselines; phrase benchmark outcomes, not a universal ordering.'),
 dict(id='F4',status='scope_correction',where=['s18_contest.py:169-170,184-185','zh_lines.py:369'],claim='2.8s vs4h',primary='nature-v2',repair='Explicit classification-benchmark scope; retain as reported measurement, not universal speed guarantee.'),
 dict(id='F5',status='verified_qualified_capacity',where=['s18_contest.py:171-173','README.md:133'],claim='2.5Nov2025;3May2026;50000/2000;1M',primary=['tabpfn-2.5','tabpfn-3'],repair='Release/date cards can remain.1M capacity is training rows with feature frontier; authors-report rank remains dated/report-specific.'),
 dict(id='F6',status='durability_translation_note',where=['s18_contest.py:183,186','zh_lines.py:369'],claim='this May; 几百万 synthetic tables',primary=['nature-v2','tabpfn-3'],repair='Prefer explicit May2026 and non-narrowing 大量/数以百万计 over 几百万. No new product-capability claim needed.'),
]
report = dict(schema_version=1,checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),task='bounded read-only Part6 primary-source factcheck',git_head_initial='e25e8659c17a8be824c2e2e2a67b6727b49c55bc',git_head_receipt=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),source_observations=pins,sources=sources,findings=findings,coverage=['README contemporary TabPFN paragraph and citations','Contest contemporary section EN and corresponding Chinese paragraph','Nearby Outro bibliography, Hook2025 date label only','Small2022 benchmark prerequisite check'],limits=['No source edits, producers, data loads, model downloads, renders or tests.','No full Part6 source audit, rendered/audio/playback or production approval.','Live leaderboard, API availability, pricing, product licensing and current downloadable model capabilities were not verified.','Dates here are publication/submission dates, not independently established commercial rollout dates.','Source snapshots record filesystem observations, not historical imported-module proof.'],access_notes=['Initial Nature primary search supplied full publisher text; later direct-find redirect failed non-retryably. No redirect bypass attempted. Subsequent publisher search confirmed benchmark details.','One combined web response was truncated and was not treated as inspected evidence.','A suggested unverified HTML anchor was immediately withdrawn; all citations below use verified complete version URLs.'],implementation='Findings sent to parent and qa_integrity; repairs owned by them and not reviewed here.')
(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
md = '''# Part6 contemporary-reference factcheck

Read-only source review, checked 2026-11-01. Exact observed source hashes, citation versions, dates, line references, scope and access limitations are in [report.json](report.json). Source snapshots are observations, not import provenance. No repository edits or render/data work were performed.

The release cards are supported by the [Nature paper](https://www.nature.com/articles/s41586-024-08328-6), [2.5 report](https://arxiv.org/abs/2511.08667), and [3 report](https://arxiv.org/abs/2605.13986). Publication/submission dates are 2025-01-08, 2025-11-11 and 2026-05-13 respectively; they are not independently established commercial rollout dates.

[BeyondIID v1](https://arxiv.org/html/2606.30410v1) (2026-06-29) requires correction: model-author overlap defeats the independent-check description, and its evaluated TabPFN version is2.6, not3. See F1–F3 in the receipt. No implication of invalid research follows from disclosed affiliations.

F4–F6 retain timing/capacity and dated-report qualifications. No current live leaderboard guarantee was established. The nearby [2022 tree benchmark](https://arxiv.org/abs/2207.08815) supports its45-dataset/~10K description.

Parent and qa_integrity own implementation. This receipt does not approve their later edits, bilingual renders, listening, continuous playback or production output.
'''
(OUT/'report.md').write_text(md)
payloads=[]
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.name!='manifest.json':
  b=p.read_bytes();payloads.append(dict(path=str(p.relative_to(OUT)),bytes=len(b),sha256=sha(b)))
(OUT/'manifest.json').write_text(json.dumps(dict(payloads=payloads),indent=2)+'\n')
print(json.dumps(dict(report_sha256=sha((OUT/'report.json').read_bytes()),payloads=len(payloads),all_initial_sources_still_match=all(p['unchanged_since_initial_read'] for p in pins)),indent=2))
