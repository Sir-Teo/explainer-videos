# Part6 contemporary-reference factcheck

Read-only source review, checked 2026-11-01. Exact observed source hashes, citation versions, dates, line references, scope and access limitations are in [report.json](report.json). Source snapshots are observations, not import provenance. No repository edits or render/data work were performed.

The release cards are supported by the [Nature paper](https://www.nature.com/articles/s41586-024-08328-6), [2.5 report](https://arxiv.org/abs/2511.08667), and [3 report](https://arxiv.org/abs/2605.13986). Publication/submission dates are 2025-01-08, 2025-11-11 and 2026-05-13 respectively; they are not independently established commercial rollout dates.

[BeyondIID v1](https://arxiv.org/html/2606.30410v1) (2026-06-29) requires correction: model-author overlap defeats the independent-check description, and its evaluated TabPFN version is2.6, not3. See F1–F3 in the receipt. No implication of invalid research follows from disclosed affiliations.

F4–F6 retain timing/capacity and dated-report qualifications. No current live leaderboard guarantee was established. The nearby [2022 tree benchmark](https://arxiv.org/abs/2207.08815) supports its45-dataset/~10K description.

Parent and qa_integrity own implementation. This receipt does not approve their later edits, bilingual renders, listening, continuous playback or production output.
