from pathlib import Path
import json,hashlib,shutil,subprocess,fcntl,time,os,datetime
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;I=Path('/workspace/runtime/ai6-remaining-qa-serial/final-gate-completed-index.json');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[x for x in json.loads(I.read_text())['rows'] if x['scene']=='Logistic'];assert len(rows)==4
(D/'index-at-freeze.json').write_bytes(I.read_bytes());sources={}
for name in ['videos/ai/ai6/s06_logistic.py','videos/ai/ai6/common.py','videos/ai/ai6/zh_lines.py','videos/ai/ai_text_zh.json','tools/qa_motion.py']:
 p=R/name;q=D/'observed-source'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);sources[name]={'sha256':sha(p),'bytes':p.stat().st_size}
freeze=[]
for row in rows:
 receipt=Path(row['receipt']);assert sha(receipt)==row['receipt_sha256'];case=receipt.parent;out=D/row['lang']/row['mode'];out.mkdir(parents=True,exist_ok=True)
 for name in ['receipt.json','source-before.json','source-after.json','data-before.json','data-after.json','command.json']:
  p=case/name;shutil.copyfile(p,out/name)
 for name in ['result.json','copy-manifest.json','text.jsonl']:
  p=case/'completed'/name;shutil.copyfile(p,out/('raw-'+name))
 observations=[]
 for artifact in json.loads(receipt.read_text())['freeze']['artifacts']:
  p=Path('/workspace/runtime/ai6-remaining-qa-serial')/artifact['destination'];assert p.is_file() and sha(p)==artifact['sha256'];assert p.stat().st_nlink==1
  observations.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'inode':p.stat().st_ino,'nlink':p.stat().st_nlink})
 freeze.append({'index_row':row,'artifacts_verified':observations})
(D/'freeze.json').write_text(json.dumps({'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cases':freeze,'observed_sources':sources,'observations_not_historical_import_proof':True},indent=2)+'\n')
for language in ['en','zh']:
 row=next(x for x in rows if x['lang']==language and x['mode']=='motion');movie=Path(row['movie']['path']);out=D/language/'audit';log=D/language/'audit.log'
 with open('/workspace/runtime/ai4-tail-motion-review/extract.lock','a') as lock:
  print(language,'waiting-shared-extract-lock',flush=True);fcntl.flock(lock,fcntl.LOCK_EX)
  assert shutil.disk_usage('/workspace').free>=768*2**20,'disk guard before extraction'
  assert sha(movie)==row['movie']['sha256']
  command=['/workspace/runtime/venv/bin/python',str(R/'tools/qa_motion.py'),str(movie),'-o',str(out),'--dense','.25','--max-gap','1']
  # The activated interpreter is supplied by the parent process; no guessed environment path.
  command[0]=os.environ['ACTIVE_PYTHON']
  with log.open('w') as f:
   child=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
   while child.poll() is None:
    free=shutil.disk_usage('/workspace').free
    if free<768*2**20:
     child.terminate();child.wait();(D/'resource-stop.json').write_text(json.dumps({'language':language,'free_bytes':free,'threshold':768*2**20,'command':command,'reason':'disk guard during extraction','time':time.time()},indent=2));raise SystemExit(72)
    time.sleep(1)
  assert child.returncode==0,language+' extraction exit '+str(child.returncode)
  assert sha(movie)==row['movie']['sha256'];assert sha(R/'tools/qa_motion.py')==sources['tools/qa_motion.py']['sha256']
  print(language,'audit-complete',flush=True)
(D/'extract-complete.json').write_text(json.dumps({'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'both_movie_sha_unchanged':True,'disk_free_bytes':shutil.disk_usage('/workspace').free},indent=2)+'\n')
