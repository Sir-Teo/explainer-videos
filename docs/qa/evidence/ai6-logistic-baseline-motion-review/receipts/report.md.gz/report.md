# Part6 Logistic bilingual baseline review

Complete sampled-image review of both frozen silent480p15 movies: 1026 selected times, 909 exact-RGB unique images directly viewed on 115 chronological pages. All38 endpoint states were directly viewed on10pages, with23 original854px critical followups. All5155 encoded frames were decoded; omitted images remain unviewed and exact gaps are inreport.json. No continuous/listening/production approval.

Four local convex append-copy morphs produce duplicate overlapping glyphs in both languages; held formulas recover. Native evidence confirms allfour. Only the authorized four stepcalls gainedtransform=False after the entire baselinepair was viewed. All other AST, voiceovers/bookmarks, math, data, positions and requested durations are unchanged; shared ladder uses1.2s for both branches. Twelve existing teaching tests pass. Fresh bilingual endpoint/motion regressions remain pending root.

No additional blocking layout defect found within scope. Linear score/probability,3D surface+lift, loss units, convex proof,GD replay and held-out/fixed-dictionary cohort disclosures were checked. Native replay followups did not establish a detached marker bug. Original four raw runtime cases all passed withzero warnings, but their visual-review pending fields remain untouched. Source/table scope reconciliation does not claim whole-fingerprint equivalence.

All74 existing data files in the driver inventory retain exact hashes/sizes/mtimes. No producer/model/TTS or scene rendering ran. The independent movie copies remain byte-identical and singly linked.
