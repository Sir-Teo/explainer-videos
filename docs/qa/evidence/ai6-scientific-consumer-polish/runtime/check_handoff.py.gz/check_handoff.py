from pathlib import Path
import ast,json,math,re,hashlib,sys
import numpy as np
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R));D=Path(__file__).parent
def module(n):return ast.parse((R/'videos/ai/ai6'/n).read_text())
def method(n,m):return next(x for x in ast.walk(module(n)) if isinstance(x,ast.FunctionDef) and x.name==m)
def voce(fn):return next(x.args[0] for x in ast.walk(fn) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr=='voiceover')
def evaluate(n,env):return eval(compile(ast.Expression(n),'actual-source-template','eval'),env)
def raw(n):return json.loads((R/'.cache/ai6'/f'{n}.json').read_text())
from explainer.zh_templates import Translator
translate=Translator('ai6');svm=raw('svm');ab=raw('adaboost');board=raw('board');te=np.asarray(ab['test_err_70']);tr=np.asarray(ab['train_err_70']);z0=int(np.flatnonzero(tr==0)[0])+1;best=int(np.argmin(te))+1;n=len(te)
scope=dict(np=np,math=math,tr=tr,te=te,z0=z0,te_z=te[z0-1],best=best,n=n)
fn=method('s15_adaboost.py','curves');branch=next(x for x in fn.body if isinstance(x,ast.If) and any(isinstance(y,ast.Name) and y.id=='say' for y in ast.walk(x)));exec(compile(ast.Module([branch],type_ignores=[]),'actual-adaboost-branches','exec'),dict(scope,keeps=True))
say_scope=dict(scope,keeps=True);exec(compile(ast.Module([branch],type_ignores=[]),'actual-adaboost-branches','exec'),say_scope);ada=evaluate(voce(fn),dict(scope,say=say_scope['say']))
cs=[float(c) for c in svm['Cs']];sv=evaluate(voce(method('s12_svm.py','pages')),dict(s=svm,Cs=cs,c0=svm['C0.01'],cb=svm['C100'],cvC=svm['C_cv'],cvg=svm['g_cv'],kk=svm['kkt']))
rows=board['rows'];a2=[r['2']['cv'] for r in rows if '2' in r];b70=max(rows,key=lambda r:r.get('70',{}).get('cv',0));co=evaluate(voce(method('s18_contest.py','board')),dict(lo2=min(a2),hi2=max(a2),best70=b70,tree70=next(r['70']['cv'] for r in rows if r['key']=='tree'),line_s='Logistic regression scores higher than boosted trees in these folds. On this fixed-corpus task, a sum of small word effects is a useful description.'))
utterances=[]
for name,en in [('AdaBoost.actual',ada),('SVM.actual',sv),('Contest.actual',co)]:
 zh=translate(en);assert zh is not None and not re.search(r'\{[^{}]+\}',zh),(name,zh);bm=lambda s:re.findall(r"<bookmark mark=['\"]([^'\"]+)['\"]/>",s);assert bm(en)==bm(zh)
 utterances.append({'case':name,'en':en,'zh':zh,'bookmarks':bm(en)})
for train,test in [(np.array([.1,.0,.0,.0]),np.array([.2,.2,.1,.15])),(np.array([.3,.2,.1]),np.array([.25,.2,.3])),(np.zeros(3),np.array([.1,.2,.2]))]:
 env=dict(np=np,tr=train,te=test,n=len(test));nodes=[x for x in fn.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['z0','te_z','best','keeps'] for t in x.targets)]+[branch];exec(compile(ast.Module(nodes,type_ignores=[]),'actual-branch-fixture','exec'),env);en=env['say'];zh=translate(en);assert zh is not None and not re.search(r'\{[^{}]+\}',zh);utterances.append({'case':'AdaBoost.branch','en':en,'zh':zh})
scinode=next(x for x in module('common.py').body if isinstance(x,ast.FunctionDef) and x.name=='sci_tex');scope={'math':math};exec(compile(ast.Module([scinode],type_ignores=[]),'actual-sci-formatter','exec'),scope);sci=scope['sci_tex']
strings={r'KKT at $C = 1$: \ margin tolerance $10^{-3}$':r'$C = 1$ 时的 KKT：\ 间隔容差 $10^{-3}$',rf"outside/bound violations: \ ${svm['kkt']['outside']+svm['kkt']['bound_out']}$":rf"街道外／上界点未通过检查：\ ${svm['kkt']['outside']+svm['kkt']['bound_out']}$",rf"free-margin residual: \ ${sci(svm['kkt']['free_off'])}$":rf"自由点最大间隔残差：\ ${sci(svm['kkt']['free_off'])}$",rf'final: \ ${100*te[-1]:.1f}\%$, \ round ${n}$':rf'最终：\ ${100*te[-1]:.1f}\%$，\ 第 ${n}$ 轮'}
(D/'caption-add.json').write_text(json.dumps({'strings':strings},ensure_ascii=False,indent=2)+'\n');(D/'actual-narration-checks.json').write_text(json.dumps({'utterances':utterances,'scope':'ActualTranslator/pureAST source evaluation with readonlyactualscalarpayloads and three meaningfulbranchfixtures; no scene imports, producer or render.','passed':True},ensure_ascii=False,indent=2)+'\n')
print('PASS',len(utterances),'actual+branch bilingual templates;4exactcurrentcaptionkeys')
