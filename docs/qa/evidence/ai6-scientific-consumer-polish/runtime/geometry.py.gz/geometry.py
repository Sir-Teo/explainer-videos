import os,sys,json,ast,math
from pathlib import Path
import numpy as np
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;sys.path.insert(0,str(R));review_language=sys.argv[1];os.environ['EXPLAINER_VIDEO']='ai6';os.environ['EXPLAINER_LANG']=review_language
from manim import config
config.media_dir=str(D/'geometry-media'/review_language)
from explainer.ai import *
if review_language=='zh':
 import explainer.zh_text as zt
 zt._TABLE=json.loads((R/'videos/ai/ai_text_zh.json').read_text());zt._TABLE['strings'].update(json.loads((D/'caption-add.json').read_text())['strings']);zt._BY_NUMBERS=None
def method(n,m):return next(x for x in ast.walk(ast.parse((R/'videos/ai/ai6'/n).read_text())) if isinstance(x,ast.FunctionDef) and x.name==m)
def assign(n,k):return isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==k for t in n.targets)
def execnodes(nodes,env):exec(compile(ast.Module(nodes,type_ignores=[]),'actual-caption-geometry','exec'),env)
def bounds(o):return {'left':float(o.get_left()[0]),'right':float(o.get_right()[0]),'bottom':float(o.get_bottom()[1]),'top':float(o.get_top()[1]),'width':float(o.width),'height':float(o.height)}
svm=json.loads((R/'.cache/ai6/svm.json').read_text());ab=json.loads((R/'.cache/ai6/adaboost.json').read_text());te=np.array(ab['test_err_70']);tr=np.array(ab['train_err_70']);z0=int(np.flatnonzero(tr==0)[0])+1;best=int(np.argmin(te))+1;n=len(te)
scinode=next(x for x in ast.parse((R/'videos/ai/ai6/common.py').read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='sci_tex');env=dict(globals(),kk=svm['kkt'],GOOD=C.REWARD,EXPC='#B48EF0',HL='#FAC863',te=te,tr=tr,z0=z0,te_z=te[z0-1],best=best,n=n);execnodes([scinode],env)
kktnode=next(x for x in method('s12_svm.py','pages').body if assign(x,'kkt'));execnodes([kktnode],env);kkt=env['kkt']
body=method('s15_adaboost.py','curves').body;nodes=[]
for x in body:
 if assign(x,'key') or assign(x,'bound') or assign(x,'res'):nodes.append(x)
 elif isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and isinstance(x.value.func,ast.Attribute) and isinstance(x.value.func.value,ast.Call) and isinstance(x.value.func.value.func,ast.Attribute) and isinstance(x.value.func.value.func.value,ast.Name) and x.value.func.value.func.value.id=='key':nodes.append(x)
execnodes(nodes,env);res=env['res'];report={'language':review_language,'scope':'ActualManimTex/mobject geometry only, privateproposedtable overlay; no scene import/render/cacheloader or producer.','kkt':bounds(kkt),'kkt_rows':[bounds(r) for r in kkt],'adaboost_result':bounds(res),'adaboost_rows':[bounds(r) for r in res]};(D/f'geometry-{review_language}.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
