from pathlib import Path
import ast,json,hashlib,datetime,re,subprocess
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=json.loads((D/'before.json').read_text())
allowed={'s12_svm.py':{'pages'},'s15_adaboost.py':{'curves'},'s18_contest.py':{'board'}};sources=[];changes=[]
def methods(tree):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)}
def voces(tree):return [{'line':n.lineno,'source':ast.unparse(n.args[0])} for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover' and n.args]
for name,owned in allowed.items():
 rel='videos/ai/ai6/'+name;b=D/'before'/rel;p=R/rel;old=ast.parse(b.read_text());new=ast.parse(p.read_text());bm,am=methods(old),methods(new);changed=[k for k in bm if bm[k]!=am[k]];assert set(changed)<=owned and set(bm)==set(am)
 oldvo,newvo=voces(old),voces(new);assert len(oldvo)==len(newvo)
 for a,c in zip(oldvo,newvo):
  if a['source']!=c['source']:changes.append({'file':rel,'before':a,'after':c})
 sources.append({'path':rel,'before_sha256':sha(b),'after_sha256':sha(p),'changed_methods':changed})
 for a,c in zip(oldvo,newvo):
  marks=lambda s:re.findall(r"mark=.(\w+).",s)
  assert marks(a['source'])==marks(c['source'])
for rel,expected in before['numerical_core'].items():assert sha(R/rel)==expected
guard=json.loads(Path('/workspace/runtime/ai6-scientific-audit/guarded-load-report.json').read_text());payload_unchanged=True
for rel,expected in guard['payloads_after'].items():
 p=R/rel;assert sha(p)==expected['sha256'] and p.stat().st_size==expected['bytes'] and p.stat().st_mtime_ns==expected['mtime_ns']
for lang in ['en','zh']:
 g=json.loads((D/f'geometry-{lang}.json').read_text());assert g['kkt']['right']<6.95 and g['kkt']['bottom']>-1.3 and g['adaboost_result']['right']<6.95 and g['adaboost_result']['bottom']>-3.6
for rel in ['videos/ai/ai6/zh_lines.py','videos/ai/ai6/README.md','tests/test_ai6_scene_teaching_repairs.py']:
 ast.parse((R/rel).read_text()) if rel.endswith('.py') else None;sources.append({'path':rel,'before_sha256':sha(D/'before'/rel),'after_sha256':sha(R/rel)})
assert 'Ran 12 tests' in (D/'target-tests.log').read_text() and '\nOK\n' in (D/'target-tests.log').read_text()
report={'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'changed_direct_voiceover_expressions':changes,'nested_voiceover_change':'AdaBoostcurves say positiveimprovement branch; main a/b/cbookmark template unchanged. Actual6ENZHcases preserved in actual-narration-checks.json.','caption_add':{'path':str(D/'caption-add.json'),'sha256':sha(D/'caption-add.json'),'count':4,'global_table_edited':False,'scope':'Exactstrings rendered from currentimmutableactualdata; not inventedmeasured prototypes.'},'tests':{'existing_teaching_tests_passed':12,'actual_and_branch_bilingual_templates_passed':6,'source_translation_coverage':'126of126, existingunused-key warnings retained','initial_failed_test_command':'Overbroad55test invocation incorrectly enabledcached-only for intentionaltemporary-generation cachefixtures; rawfailurelog retained. No cachedatafailureclaimed.'},'geometry':{'en':json.loads((D/'geometry-en.json').read_text()),'zh':json.loads((D/'geometry-zh.json').read_text()),'scope':'ActualTex/mobject bounds with privateproposedcaptionoverlay, no scene/render; freshbothlanguageEP/motion gatespending.'},'numerical_core_unchanged':before['numerical_core'],'all_ai6_payload_hash_size_mtime_unchanged':payload_unchanged,'no_s17_edit':'CurrentdisplayedROCcurvesalreadyinclude endpoints. Missingterminalpoints onlyinunusedroc_lr70/roc_nb payloadfields; authoritativeAUC unchanged.','timing_scope':'Changedspokenparagraphs can change preview/narrationdurations; no timing-equivalenceclaim. Allbookmarknames/order andexplicitplay/wait operations retained.','limits':['No actualrenderedvisualapproval or listening/synchronization approval.','Sourceobservationsdo notestablishhistoricalimports.','No producer/core/data/sharedcaption/Hook/s02/s03/s17 edits.']}
(D/'source-freeze-handoff.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'handoff_sha256':sha(D/'source-freeze-handoff.json'),'sources':sources,'caption_sha256':sha(D/'caption-add.json')},indent=2))
