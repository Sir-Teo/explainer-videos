"""Outer-product rank edge cases and the linked EN/ZH educational claim.

Executes the actual example contraction on tiny inputs; never imports scenes,
loads cached data, trains a model, or renders a frame.
"""
import ast
from pathlib import Path
import re
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'videos/ai/ai3/s03_einsum.py'
NARRATION = ROOT / 'videos/ai/ai3/zh_lines.py'


def example_claim():
    tree = ast.parse(SOURCE.read_text())
    method = next(n for n in ast.walk(tree)
                  if isinstance(n, ast.FunctionDef) and n.name == 'examples')
    table_node = next(n for n in method.body if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == 'table' for t in n.targets))
    outer = next(row for row in ast.literal_eval(table_node.value) if 'outer product:' in row[1])
    voiceover = next(n for n in ast.walk(method) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Attribute) and n.func.attr == 'voiceover')
    english = ast.literal_eval(voiceover.args[0])
    zh_tree = ast.parse(NARRATION.read_text())
    zh_node = next(n for n in zh_tree.body if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == 'ZH' for t in n.targets))
    translations = ast.literal_eval(zh_node.value)
    # This unchanged prefix is the production narration lookup key.
    chinese = translations['One function does all of these.']
    return outer, english, chinese


class OuterProductRankTests(unittest.TestCase):
    def test_actual_contraction_has_rank_zero_if_either_input_is_zero(self):
        (expression, _), _, _ = example_claim()
        for left, right in [(np.zeros(3), np.array([2., -3., 4., 5.])),
                            (np.array([1., 2., -1.]), np.zeros(4)),
                            (np.zeros(3), np.zeros(4))]:
            with self.subTest(left=left.tolist(), right=right.tolist()):
                actual = np.einsum(expression, left, right)
                np.testing.assert_array_equal(actual, np.zeros((3, 4)))
                self.assertEqual(np.linalg.matrix_rank(actual), 0)

    def test_actual_contraction_has_rank_one_for_nonzero_inputs(self):
        (expression, _), _, _ = example_claim()
        for left, right in [(np.array([1., -2., 3.]), np.array([4., 5., -6., 7.])),
                            (np.array([0., 2., 0.]), np.array([0., 0., -3., 0.]))]:
            with self.subTest(left=left.tolist(), right=right.tolist()):
                actual = np.einsum(expression, left, right)
                np.testing.assert_array_equal(actual, left[:, None] * right[None, :])
                self.assertEqual(np.linalg.matrix_rank(actual), 1)

    def test_caption_and_both_narrations_preserve_the_zero_input_case(self):
        (_, caption), english, chinese = example_claim()
        self.assertIn('rank at most one', caption)
        self.assertIn('a matrix of rank at most one.', english)
        self.assertIn('秩至多为1的矩阵', chinese)
        bookmarks = lambda s: re.findall(r"<bookmark mark='([^']+)'/>", s)
        self.assertEqual(bookmarks(english), list('abcdef'))
        self.assertEqual(bookmarks(chinese), bookmarks(english))
