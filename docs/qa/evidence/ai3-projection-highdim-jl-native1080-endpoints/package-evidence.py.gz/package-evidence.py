from pathlib import Path
import json,gzip,hashlib,datetime,subprocess
root=Path('/workspace/explainer-videos');base=Path('/workspace/runtime/ai3-projection-highdim-jl-1080-review');out=root/'docs/qa/evidence/ai3-projection-highdim-jl-native1080-endpoints';out.mkdir();payloads=[]
def add(src,name,compress=False):
 src=Path(src);b=src.read_bytes();rawsha=hashlib.sha256(b).hexdigest()
 if compress:b=gzip.compress(b,mtime=0)
 (out/name).write_bytes(b);p={'file':name,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'source':str(src),'source_sha256':rawsha}
 if compress:p['uncompressed_sha256']=rawsha
 payloads.append(p)
add(base/'report.json','report.json.gz',True);add(base/'pre-capture-sources.json','pre-capture-sources.json.gz',True);add(base/'projection-source-before-completion.json','projection-source-before-completion.json.gz',True)
for p in sorted(base.glob('before-*')):add(p,p.name+'.gz',True)
add('/workspace/runtime/record-ai3-theory-1080-review.py','record-review.py.gz',True);add('/workspace/runtime/package-ai3-theory-1080.py','package-evidence.py.gz',True)
add(root/'tools/qa_series.py','qa_series.py.gz',True);add(root/'manim.cfg','manim.cfg.gz',True);add(base/'critical-crops.json','critical-crops.json.gz',True)
for p in sorted(base.glob('*.png')):add(p,p.name)
report=json.loads((base/'report.json').read_text())
for case in report['cases']:
 name=case['case'];lang,scene=name.split('-');folder=root/'renders/qa/production-endpoints-1080/ai3'/lang/scene
 add(base/name/'review.json',name+'-review.json.gz',True);add(base/name/'render-result.json',name+'-capture.json.gz',True);add('/workspace/runtime/ai3-projection-highdim-jl-1080-'+name+'.log',name+'-capture.log.gz',True)
 for f in json.loads((base/name/'review.json').read_text())['frames']:
  p=folder/f['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==f['sha256'];add(p,name+'-'+f['file'])
manifest={'packaged_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':report['scope'],'repository_head_at_packaging':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'payloads':payloads,'cases':report['cases'],'summary':{'actual_native_images_viewed':111,'resolution':[1920,1080],'cases':6,'runtime_status':'All six passed, zero warnings, worker exits0.','critical_crops_actually_viewed':7},'limits':report['limits'],'mutations':report['mutations']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(out,len(payloads),sum(p['bytes'] for p in payloads))
