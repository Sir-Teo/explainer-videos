"""Parent-authorized manual adapter of tools.build: no rendering or producer load."""
from pathlib import Path
import ast,datetime,hashlib,json,os,shutil,sys,time
ROOT=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai3-silent-preview-assembly');sys.path.insert(0,str(ROOT))
language=sys.argv[1];assert language in ('en','zh')
release_path=Path(sys.argv[2]);release=json.loads(release_path.read_text());assert release['parent_go_ahead'] and release['revision']=='continuity-qualified'
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
os.environ.update(EXPLAINER_TTS='silent',EXPLAINER_LANG=language,EXPLAINER_VIDEO='ai3')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();stamp=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
expected={('en','Power'):'8b790fba90fe4694c9fb3ab0b3f88de2851082a0e94db9dd0182379bb5dae73a',('zh','Power'):'15380304cade3740dfab90886aba13bb1daec92a28f7848fe64688f57a7aacf0',('en','Outro'):'f99b2a8263bd613e741d0ed8f61c1ac9601732593445d0fbef874acc48682881',('zh','Outro'):'56124f7e0155fd8cb5f581d6613184de64d30d3cce7392aade37d325ed3b9667'}
authoritative_path=Path(release['authoritative_map']);assert sha(authoritative_path)==release['authoritative_map_sha256'];authoritative=json.loads(authoritative_path.read_text());assert len(authoritative['cases'])==38
for row in authoritative['cases'].values():
 p=ROOT/row['source_file'];assert sha(p)==row['source_sha256']
 expected[(row['lang'],row['scene'])]=row['movie_sha256']
assert sha(ROOT/'videos/ai/ai_text_zh.json')==release['shared_caption_sha256']
for l in ('en','zh'):
 for scene in ('Hook','GaLore','Words','Netflix'):
  digest=release['replacement_movies'][l][scene];assert isinstance(digest,str) and len(digest)==64
  expected[(l,scene)]=digest
manifest=ROOT/'videos/ai/ai3/manifest.py';tree=ast.parse(manifest.read_text());scenes=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SCENES' for t in n.targets)))
base=OUT/'continuity-qualified'/language;assert not (base/'assembly-receipt.json').exists(),'reconcile existing assembly before rerun';base.mkdir(parents=True,exist_ok=True)
receipt={'scope':'SILENT854x48015fps manual preview assembly; estimated narration/subtitles; not narrated or1080p production approval','parent_go_ahead':release['parent_go_ahead'],'source_commit':release['source_commit'],'Power_independent_review_status':release['Power_independent_review_status'],'release_receipt':str(release_path),'release_receipt_sha256':sha(release_path),'started_utc':stamp(),'lang':language,'sources':{},'inputs':[],'commands':[],'expected_final_movies':{s:h for (l,s),h in expected.items() if l==language},'disk_before':dict(zip(('total','used','free'),shutil.disk_usage(ROOT)))}
shutil.copy2(authoritative_path,base/'authoritative-source-case-map.json');shutil.copy2(release_path,base/'release.json');receipt['authoritative_map_sha256']=sha(authoritative_path)
save=lambda:(base/'assembly-progress.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
for rel in ['tools/build.py','explainer/voiceover.py','explainer/lang.py','explainer/tts.py','tools/qa_series.py','videos/ai/ai_text_zh.json']+[str(p.relative_to(ROOT)) for p in sorted((ROOT/'videos/ai/ai3').glob('*.py'))]:
 p=ROOT/rel;q=base/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);receipt['sources'][rel]={'sha256':sha(p),'frozen':str(q)}
paths={}
for index,(module,scene,title) in enumerate(scenes):
 folder=ROOT/'renders/qa/series/ai3'/language/(scene+'_motion');rp=folder/'result.json';record=json.loads(rp.read_text());assert record['status'] in ('passed','needs-review');movie=ROOT/record['movie'];side=movie.with_suffix('.narration.json');meta=json.loads(side.read_text());assert meta['lines']==record['narration'];h=sha(movie)
 assert sha(rp)==authoritative['cases'][f'{language}/{scene}']['record_sha256']
 if (language,scene) in expected:assert h==expected[(language,scene)],f'{language}/{scene} final movie mismatch'
 for rel,sig in record['inputs'].items():
  p=ROOT/rel;st=p.stat() if p.exists() else None;assert ([st.st_size,st.st_mtime_ns] if st else None)==sig,f'{scene}: consumed input signature stale'
 d=base/'chapters'/f'{index:02d}-{scene}';d.mkdir(parents=True,exist_ok=True);target=d/f'{scene}.mp4';shutil.copy2(movie,target);shutil.copy2(side,target.with_suffix('.narration.json'));shutil.copy2(rp,d/'result.json');assert sha(movie)==sha(target)==h
 paths[scene]=target;receipt['inputs'].append({'index':index,'module':module,'scene':scene,'title_en':title,'original_movie':str(movie),'movie_sha256':h,'movie_bytes':target.stat().st_size,'frozen_movie':str(target),'frozen_record':str(d/'result.json'),'record_sha256':sha(rp),'sidecar_sha256':sha(side),'record_status':record['status'],'record_warnings':record['warnings'],'record_fingerprint':record['fingerprint'],'consumed_inputs':record['inputs']});save()
from tools import build
original_run=build.run;original_master=build.master_filter;original_title=build.narration_lang.video_title
def threaded(cmd):
 return [cmd[0],'-threads','1','-filter_threads','1','-filter_complex_threads','1',*cmd[1:]] if cmd[0]=='ffmpeg' else cmd
def tracked_run(cmd,**kw):
 command=threaded(cmd);receipt['commands'].append({'command':command,'started_utc':stamp()});save();result=original_run(command,**kw);receipt['commands'][-1].update(exit_code=result.returncode,completed_utc=stamp());save();return result
def tracked_master(cmd):
 command=threaded(cmd);receipt['commands'].append({'command':command,'started_utc':stamp(),'kind':'master-filter-measurement'});save();out=original_master(command);receipt['commands'][-1].update(exit_code=0,completed_utc=stamp(),selected_filter=out);save();return out
build.ROOT=base/'private-build-root';build.ROOT.mkdir(exist_ok=True);build.run=tracked_run;build.master_filter=tracked_master
build.scene_output=lambda media,module,scene,quality,fps:paths[scene]
build.render_scene=lambda *a,**kw:(_ for _ in ()).throw(RuntimeError('Manual preview forbids rendering'))
build.narration_lang.video_title=lambda video,title,lang=None:original_title(video,title,lang)+' [SILENT QA PREVIEW; estimated narration timing]'
sys.argv=['tools/build.py','ai3','-q','l','--fps','15','--lang',language,'--stitch-only','-j','1'];receipt['build_argv']=sys.argv;receipt['adapter_changes']=['private output root','frozen QA chapter path lookup','forbid render_scene','ffmpeg single-thread options and command receipts','explicit silent-preview container title'];save();start=time.monotonic();build.main()
suffix='_480p'+('' if language=='en' else '_zh');produced=build.ROOT/'renders'/f'ai3{suffix}';dest=base/f'ai3-silent-preview-{language}-480p15'
for ext in ('.mp4','.srt','.chapters.txt'):shutil.copy2(Path(str(produced)+ext),Path(str(dest)+ext))
receipt.update(completed_utc=stamp(),assembly_seconds=round(time.monotonic()-start,3),final=str(dest)+'.mp4',final_sha256=sha(str(dest)+'.mp4'),subtitle=str(dest)+'.srt',subtitle_sha256=sha(str(dest)+'.srt'),chapter_list=str(dest)+'.chapters.txt',disk_after=dict(zip(('total','used','free'),shutil.disk_usage(ROOT))));(base/'assembly-receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n');save();print(json.dumps({'lang':language,'final':receipt['final'],'sha256':receipt['final_sha256'],'seconds':receipt['assembly_seconds']},indent=2))
