# Part 3 final silent preview assembly

Both final English and Chinese reels were assembled once from all 19 frozen existing chapter movies, in manifest order. No scene rerender, model import, data computation or repository source change was performed. The manual adapter uses the existing `tools/build.py --stitch-only` normalization, concatenation, subtitle, chapter and mastering workflow with private output paths, one numeric/FFmpeg thread and an explicit silent-preview title.

Source release: `927fba668656a682b3e29a288de64130ddc680dd`; authoritative map SHA256 `7cca99a8ce8a27f460fdd85ad273ace41ac757f1cd99abbdd04e51ad190d59b6`; caption table SHA256 `8e4ed21282fc336bebc5f6e7d1aea7e3c975d09da486c873913c84c98bf3cb0a`. All 38 source movie/result hashes and 19 direct scene source hashes was checked against that map before assembly. `consumed-data-hashes.json` adds raw cache-byte digests; original consumed input size/mtime signatures still match. Root confirmed all 38 current selected chapter regressions closed before final GO. Historical pending-Power wording in earlier preparation receipts is superseded by this final GO; receipts themselves remain untouched.

|Language|Duration|Decoded video frames|SRT cues|MP4 SHA256|
|---|---:|---:|---:|---|
|en|3281.809979s|49,227|990|`bf14c51ccea011245e9af1e5bcdfc33c4a46abadf390f69e003790638d58a169`|
|zh|3469.088542s|52,036|1,039|`ba44de77ae0934e247c4702ab2f2d2a886d9f088de7fe8fcde293f4c438e1c26`|

Each final movie contains H.264 at 854×480 and 15 fps, AAC at 48 kHz stereo, a correctly tagged soft subtitle track and 19 localized chapter markers. Full final video and audio decode completed without errors. Decoded video PTS strictly increase; packet DTS do not decrease within any stream. Normalized chapter frame counts equal the frozen source counts; final counts equal their sums. Extracted soft subtitle text and millisecond cue timings exactly match the generated SRT; all cues are within the video and do not overlap. The first decoded video timestamp is 0.021029 s in both files (mux/audio priming), and every chapter marker is within one 15 fps frame of the incoming decoded frame; this is recorded, not treated as zero offset.

Actual visual join coverage:18 joins per language,19 selected timestamps per join,684 timestamps total. All 82 chronological sheets were viewed (650 unique PNGs,34 exact byte-identical duplicates mapped to their viewed image); both native 854×480 context frames at -1s/+1s were also viewed for every join (72 native views). Every frame at relative indices -6 through +6 is selected, plus -15/-12/-9/+9/+12/+15. Maximum selected-time gap within each ±1s window is approximately 0.2 s. The per-language `validation/join-review.json` contains timestamp, SHA, page-view and native-view receipts plus all 18 per-join findings. `join-selection.json` is the immutable extraction plan; its original pending flags are superseded only by the separate actual-view ledger.

No assembly defect was observed in these selected join windows: chapter order is correct, outgoing states fade to the shared background, incoming chapter cards/recap fade in, and no unexpected carryover, missing chapter, duplicate opening or hard flash appeared. Existing source chapter warnings remain: EN Einsum/LowRank/GaLore and ZH Projection/LowRank retain raw `needs-review` / `source-changed-during-render` records; this assembly pass does not convert them to runtime passed. Root’s exact-source scoped reviews are associated via the authoritative map.

Final MP4, SRT and chapter lists are in `en/` and `zh/`. The machine-readable result is `final-review.json`; hashes and important artifact paths are in `handoff-manifest.json`. Per-language original chapter movies/narration sidecars/results and source snapshots remain in `chapters/` and `source/`; full PTS/packet ledgers, probes, actual image-view ledgers and full AAC decode receipts remain in `validation/`. All originals and the old English interim reel remain preserved. That interim reel is mechanism evidence only and is not current.

Exact executed assembly commands (serial, see sibling logs):

```bash
source /workspace/runtime/activate.sh
nice -n 10 python /workspace/runtime/assemble_ai3_silent_preview_final.py en /workspace/runtime/ai3-silent-preview-assembly/continuity-qualified-release.json
nice -n 10 python /workspace/runtime/assemble_ai3_silent_preview_final.py zh /workspace/runtime/ai3-silent-preview-assembly/continuity-qualified-release.json
```

The immutable assembly receipts contain actual build arguments and every FFmpeg command/output status. Full validation was run per language with `validate_ai3_silent_preview.py BASE --full`; separate complete AAC decodes are in each audio receipt. Assembly logs are `../en-final-assembly.log` and `../zh-final-assembly.log`.

Limits: these are SILENT 480p15 previews with estimated narration and subtitle timing. Actual narration, pronunciation, speech/animation sync, listening, production loudness and uninterrupted full-reel perceptual playback remain untested. Frames outside the selected join windows were fully decoded but not visually inspected in this assembly pass. This is not full 1080p motion approval. Subtitle extraction does not validate player font overlays, responsive behavior or browser playback. Earlier chapter-specific selected-time/native endpoint reviews remain separate source-specific evidence.
