from pathlib import Path
import os,stat,time,re,json,hashlib,datetime,math,shutil
R=Path('/workspace/explainer-videos');T=R/'.cache/tts';D=Path('/workspace/runtime/capacity-published-tts-silent-wav-sparse-20261101');FLAGS=os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NOATIME
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):
 fd=os.open(p,FLAGS)
 with os.fdopen(fd,'rb') as f:return f.read()
def stamp(p,contents=None):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_nlink==1 and p.resolve()==p,'Not regular independent nonsymlink file'
 h=sha(read(p) if contents is None else contents)
 a=p.stat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns),'Identity drift during inventory'
 return {'bytes':s.st_size,'sha256':h,'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns,'ctime_ns':s.st_ctime_ns,'mode':stat.S_IMODE(s.st_mode),'inode':s.st_ino,'device':s.st_dev,'nlink':s.st_nlink,'allocated_bytes':s.st_blocks*512}
started=time.time_ns();cutoff=started-600*10**9;rows=[]
# Freeze this initial list; do not chase later creates or newly aged entries.
paths=sorted(p for p in T.glob('*.wav') if re.fullmatch('[0-9a-f]{16}',p.stem))
for p in paths:
 m=p.with_suffix('.json');l=m.with_suffix('.json.lock');row={'wav':str(p),'metadata':str(m),'lock':str(l)}
 try:
  for q in [p,m,l]:assert q.exists() and not q.is_symlink() and stat.S_ISREG(q.lstat().st_mode) and q.stat().st_nlink==1 and q.resolve()==q,'Missing/linked/nonregular pair orlock'
  s=p.stat();mstat=m.stat();row['wav_before_allocated_bytes']=s.st_blocks*512
  assert s.st_mtime_ns<cutoff and mstat.st_mtime_ns<cutoff,'Recent published pair (<600s at initial inventory)'
  assert l.stat().st_size==0,'Unknown nonempty lock payload'
  meta_bytes=read(m);meta=json.loads(meta_bytes)
  assert isinstance(meta,dict) and all(k in meta for k in ['text','spoken','duration','tokens']) and isinstance(meta['text'],str) and isinstance(meta['spoken'],str) and isinstance(meta['tokens'],list) and isinstance(meta['duration'],(int,float)) and math.isfinite(meta['duration']) and meta['duration']>=0,'Incomplete metadata schema'
  row.update(eligible=True,wav_signature=stamp(p),metadata_signature=stamp(m,meta_bytes),lock_signature=stamp(l,b''))
 except (AssertionError,FileNotFoundError,PermissionError,json.JSONDecodeError) as e:row.update(eligible=False,skip_reason=type(e).__name__ if not isinstance(e,AssertionError) else str(e))
 rows.append(row)
plan={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initial_inventory_ns':started,'age_cutoff_ns':cutoff,'minimum_pair_age_seconds':600,'scope':'Only initial published16hex.wav +matching.json +sameexisting.json.lock in repo.cache/tts. Metadata content is never recorded; signatures only. No cache/TTS/model calls. No mutation yet.','cache_protocol_sources':{f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in ['explainer/tts.py','explainer/cache_lock.py']},'initial_published_wavs':len(paths),'eligible_count':sum(r['eligible'] for r in rows),'eligible_allocated_bytes':sum(r['wav_signature']['allocated_bytes'] for r in rows if r['eligible']),'eligible_logical_bytes':sum(r['wav_signature']['bytes'] for r in rows if r['eligible']),'skipped_count':sum(not r['eligible'] for r in rows),'free':shutil.disk_usage('/workspace').free,'rows':rows}
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print({k:v for k,v in plan.items() if k!='rows'});print('plan_sha256',hashlib.sha256((D/'plan.json').read_bytes()).hexdigest())
