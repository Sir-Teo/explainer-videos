"""Same-lock, byte-preserving hole punching of old published TTS zero interiors."""
from pathlib import Path
import os,stat,time,json,hashlib,datetime,math,shutil,gzip,fcntl,subprocess,ast,collections
R=Path('/workspace/explainer-videos');T=R/'.cache/tts';D=Path('/workspace/runtime/capacity-published-tts-silent-wav-sparse-20261101');PLAN=D/'plan.json';PIN='5e0e3e0887b9de5cc22318b09a8a4defaeb563869b2927126b7d3b1d45f0a6c8';FLAGS=os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NOATIME
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def noatime_read(p):
 fd=os.open(p,FLAGS)
 with os.fdopen(fd,'rb') as f:return f.read()
def stamp(p,contents=None,empty_lock=False):
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and not p.is_symlink() and s.st_nlink==1 and p.resolve()==p
 if empty_lock:assert s.st_size==0;contents=b''
 if contents is None:contents=noatime_read(p)
 a=p.stat();assert (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns),'Identity drift while reading'
 return dict(bytes=s.st_size,sha256=hashlib.sha256(contents).hexdigest(),mtime_ns=s.st_mtime_ns,atime_ns=s.st_atime_ns,ctime_ns=s.st_ctime_ns,mode=stat.S_IMODE(s.st_mode),inode=s.st_ino,device=s.st_dev,nlink=s.st_nlink,allocated_bytes=s.st_blocks*512)
def savegz(name,obj):
 with (D/name).open('wb') as f:
  with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as z:z.write(json.dumps(obj,indent=2).encode())
def normal_stamp(p):
 s=p.stat();return dict(bytes=s.st_size,sha256=sha(p),mtime_ns=s.st_mtime_ns,mode=stat.S_IMODE(s.st_mode),inode=s.st_ino,device=s.st_dev,allocated_bytes=s.st_blocks*512,ctime_ns=s.st_ctime_ns)
# Reuse only the read-only source inventory function, never execute its original module.
scope=dict(R=R,sha=sha);tree=ast.parse(Path('/workspace/runtime/old-tex-capacity-audit/duplicate-only-execution/execute.py').read_text());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='source_inventory');exec(compile(ast.Module([node],type_ignores=[]),'frozen-source-inventory','exec'),scope);source_inventory=scope['source_inventory']
def activity(targets):
 counts=collections.Counter();matches=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
  counts['pids_seen']+=1
  try:
   fds=list((proc/'fd').iterdir());counts['fd_dirs_readable']+=1
   for fd in fds:
    try:p=os.readlink(fd);counts['fd_links_readable']+=1
    except (PermissionError,FileNotFoundError,ProcessLookupError):counts['fd_links_unreadable_or_raced']+=1;continue
    if p in targets:matches.append(dict(pid=proc.name,path=p,kind='fd'))
  except (PermissionError,FileNotFoundError,ProcessLookupError):counts['fd_dirs_unreadable_or_raced']+=1
  try:
   text=(proc/'maps').read_text();counts['maps_readable']+=1
   for line in text.splitlines():
    f=line.split(maxsplit=5)
    if len(f)==6 and f[5] in targets:matches.append(dict(pid=proc.name,path=f[5],kind='mapped'))
  except (PermissionError,FileNotFoundError,ProcessLookupError):counts['maps_unreadable_or_raced']+=1
 return dict(at=now(),counts=dict(counts),visible_open_or_mapped=matches,caveat='Partial host FD/maps visibility; same existing per-item exclusive flock is the writer guard. Readers would see identical bytes. No global absence claim.')
assert sha(PLAN)==PIN;plan=json.loads(PLAN.read_text());eligible=[r for r in plan['rows'] if r['eligible']];assert len(eligible)==1261
reference=json.loads(Path('/workspace/runtime/capacity-silent-qa-sparse-20261101/receipt.json').read_text())['protected_after'];assert len(reference)==306
protected_before={p:normal_stamp(Path(p)) for p in reference};savegz('protected306-before.json.gz',protected_before)
assert all(s['sha256']==reference[p]['sha256'] and s['bytes']==reference[p]['bytes'] for p,s in protected_before.items())
sources_before=source_inventory();assert len(sources_before)==1524;savegz('source-before.json.gz',sources_before)
for p,h in plan['cache_protocol_sources'].items():assert sha(R/p)==h,'Cache protocol changed'
targets={r[k] for r in eligible for k in ['wav','metadata','lock']};batch_activity=[];act=activity(targets);(D/'activity-before.json').write_text(json.dumps(act,indent=2));opened={r['path'] for r in act['visible_open_or_mapped']}
free_before=shutil.disk_usage('/workspace').free;started=now();rows=[];stopped=None
with (D/'journal.jsonl').open('x') as journal:
 for index,row in enumerate(eligible):
  if index%50==0:
   if sha(PLAN)!=PIN or source_inventory()!=sources_before:stopped='Plan/critical source drift; remaining initial candidates preserved';break
   act=activity(targets);opened={r['path'] for r in act['visible_open_or_mapped']};batch_activity.append({'candidate_index':index,**act})
  w=Path(row['wav']);m=Path(row['metadata']);l=Path(row['lock']);result={'wav':str(w),'metadata':str(m),'lock':str(l)};lockfd=None;held=False
  if any(str(p) in opened for p in [w,m,l]):result['status']='skipped-visible-in-use';rows.append(result);journal.write(json.dumps(result)+'\n');continue
  try:
   assert w.parent==m.parent==l.parent==T and w.stem==m.stem and l.name==m.name+'.lock','Path/lock mismatch'
   assert w.resolve()==w and m.resolve()==m and l.resolve()==l and not any(p.is_symlink() for p in [w,m,l]),'Symlink/path drift'
   lock0=stamp(l,empty_lock=True);assert lock0==row['lock_signature'],'Existing lock identity drift'
   # Existing exact protocol lock, read-only/no-create, exclusive and nonblocking.
   lockfd=os.open(l,FLAGS);fs=os.fstat(lockfd);assert (fs.st_dev,fs.st_ino)==(lock0['device'],lock0['inode']),'Lock replaced during open'
   try:fcntl.flock(lockfd,fcntl.LOCK_EX|fcntl.LOCK_NB);held=True
   except BlockingIOError:result['status']='skipped-busy-lock';rows.append(result);journal.write(json.dumps(result)+'\n');continue
   before=stamp(w);meta_bytes=noatime_read(m);meta0=stamp(m,meta_bytes);lock_before=stamp(l,empty_lock=True)
   assert before==row['wav_signature'] and meta0==row['metadata_signature'] and lock_before==row['lock_signature'],'Published pair or lock drift from initial inventory'
   assert before['mtime_ns']<plan['age_cutoff_ns'] and meta0['mtime_ns']<plan['age_cutoff_ns'],'Not initially older600s'
   assert before['mtime_ns']<time.time_ns()-600*10**9 and meta0['mtime_ns']<time.time_ns()-600*10**9,'Recent pair'
   meta=json.loads(meta_bytes);assert isinstance(meta,dict) and all(k in meta for k in ['text','spoken','duration','tokens']) and isinstance(meta['text'],str) and isinstance(meta['spoken'],str) and isinstance(meta['tokens'],list) and isinstance(meta['duration'],(int,float)) and math.isfinite(meta['duration']) and meta['duration']>=0,'Incomplete metadata'
   result.update(before=before,metadata_before=meta0,lock_before=lock_before)
   start=4096;length=(before['bytes']//4096)*4096-start
   if length<=0:result['status']='skipped-too-short';rows.append(result);journal.write(json.dumps(result)+'\n');continue
   minimum=4096+(4096 if before['bytes']%4096 else 0)
   if before['allocated_bytes']<=minimum:result['status']='skipped-already-minimal-allocation';rows.append(result);journal.write(json.dumps(result)+'\n');continue
   fd=os.open(w,FLAGS)
   with os.fdopen(fd,'rb') as f:
    header=f.read(start);assert header[:4]==b'RIFF' and header[8:12]==b'WAVE','Unknown WAV format'
    remain=length;checked=0;zero=True
    while remain:
     b=f.read(min(1024*1024,remain));assert b,'Truncated WAV';checked+=len(b)
     if b.strip(b'\0'):zero=False;break
     remain-=len(b)
    f.seek(start+length);tail=f.read()
   if not zero:
    result.update(status='skipped-nonzero-interior',zero_check_bytes_before_first_nonzero=checked,metadata_after=stamp(m),lock_after=stamp(l,empty_lock=True))
    assert result['metadata_after']==meta0 and result['lock_after']==lock_before and stamp(w)==before
    rows.append(result);journal.write(json.dumps(result)+'\n');continue
   assert checked==length and stamp(w)==before and stamp(m)==meta0 and stamp(l,empty_lock=True)==lock_before,'Drift during zero proof'
   result.update(zero_bytes_proved=checked,punch_offset=start,punch_length=length,entire_aligned_interior_zero=True,header_bytes=len(header),tail_bytes=len(tail),header_sha256=hashlib.sha256(header).hexdigest(),tail_sha256=hashlib.sha256(tail).hexdigest())
   (D/'operation-intent.json').write_text(json.dumps({'at':now(),**result},indent=2))
   op=subprocess.run(['fallocate','--punch-hole','--keep-size','--offset',str(start),'--length',str(length),str(w)],text=True,capture_output=True)
   if op.returncode:
    result.update(status='unsupported-or-failed',returncode=op.returncode,stderr=op.stderr);rows.append(result);stopped='Physical operation failed/unsupported; no retry or alternate method';journal.write(json.dumps(result)+'\n');break
   os.utime(w,ns=(before['atime_ns'],before['mtime_ns']));after=stamp(w);meta_after=stamp(m);lock_after=stamp(l,empty_lock=True)
   for key in ['sha256','bytes','inode','device','mode','mtime_ns','atime_ns','nlink']:assert after[key]==before[key],(w.name,key)
   assert meta_after==meta0 and lock_after==lock_before,'Metadata or existing lock changed'
   fd=os.open(w,FLAGS)
   with os.fdopen(fd,'rb') as f:head2=f.read(start);f.seek(start+length);tail2=f.read()
   assert head2==header and tail2==tail,'Header/tail changed'
   result.update(status='byte-exact-sparse',after=after,metadata_after=meta_after,lock_after=lock_after,allocated_bytes_recovered=before['allocated_bytes']-after['allocated_bytes'],original_mtime_atime_explicitly_restored=True,ctime_changed=before['ctime_ns']!=after['ctime_ns'],header_tail_unchanged=True)
   rows.append(result);journal.write(json.dumps(result)+'\n');journal.flush()
   if len(rows)%50==0:os.fsync(journal.fileno());print('processed',len(rows),'/',len(eligible),'recovered',sum(r.get('allocated_bytes_recovered',0) for r in rows),flush=True)
  except (AssertionError,FileNotFoundError,PermissionError,json.JSONDecodeError) as e:
   result.update(status='skipped-ineligible-or-drift',reason=str(e) if isinstance(e,AssertionError) else type(e).__name__);rows.append(result);journal.write(json.dumps(result)+'\n')
   if isinstance(e,AssertionError) and 'source' in str(e).lower():stopped='Source/protocol drift';break
  finally:
   if lockfd is not None:
    if held:fcntl.flock(lockfd,fcntl.LOCK_UN)
    os.close(lockfd)
protected_after={p:normal_stamp(Path(p)) for p in reference};sources_after=source_inventory();savegz('protected306-after.json.gz',protected_after);savegz('source-after.json.gz',sources_after);savegz('batch-activity.json.gz',batch_activity)
activity_after=activity(targets);(D/'activity-after.json').write_text(json.dumps(activity_after,indent=2));free_after=shutil.disk_usage('/workspace').free
success=[r for r in rows if r['status']=='byte-exact-sparse'];status_counts=dict(collections.Counter(r['status'] for r in rows));receipt={'started':started,'finished':now(),'scope':'Only fixed initial published16hex.wav/json +sameexisting.json.lock pairs older600s; sameexclusiveNONBLOCKINGflock, no create/retag/delete/reencode/synthesis/network. Metadata content never recorded.','plan_sha256':PIN,'initial_inventory':plan['initial_published_wavs'],'initial_ineligible':plan['skipped_count'],'initial_eligible':len(eligible),'considered':len(rows),'remaining_unprocessed':len(eligible)-len(rows),'status_counts':status_counts,'stopped_reason':stopped,'allocated_bytes_recovered':sum(r['allocated_bytes_recovered'] for r in success),'target_before_allocated_bytes':sum(r['before']['allocated_bytes'] for r in success),'target_after_allocated_bytes':sum(r['after']['allocated_bytes'] for r in success),'free_before':free_before,'free_after':free_after,'observed_free_space_delta':free_after-free_before,'space_caveat':'OtherPart6 QA writes continue; observedwholefilesystemdelta separate from exacttargetallocatedrecovery.','all_success_WAV_bytes_path_size_inode_device_mode_mtime_atime_preserved':all(all(r['before'][k]==r['after'][k] for k in ['sha256','bytes','inode','device','mode','mtime_ns','atime_ns']) for r in success),'all_success_headers_tails_preserved':all(r['header_tail_unchanged'] for r in success),'all_success_metadata_exact_signatures_preserved':all(r['metadata_before']==r['metadata_after'] for r in success),'all_success_existing_lock_exact_signatures_preserved':all(r['lock_before']==r['lock_after'] for r in success),'ctime_changes_explicit':True,'protected306_count':len(protected_before),'protected306_exact_signatures_unchanged':protected_before==protected_after,'critical_source_files':len(sources_before),'critical_source_bytes_unchanged':sources_before==sources_after,'partial_activity_visibility_caveat':activity_after['caveat'],'no_provider_model_or_network_calls':True,'rows':rows};(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='rows'},indent=2),flush=True)
assert receipt['protected306_exact_signatures_unchanged'] and receipt['critical_source_bytes_unchanged'] and receipt['all_success_WAV_bytes_path_size_inode_device_mode_mtime_atime_preserved'] and receipt['all_success_metadata_exact_signatures_preserved'] and receipt['all_success_existing_lock_exact_signatures_preserved']
