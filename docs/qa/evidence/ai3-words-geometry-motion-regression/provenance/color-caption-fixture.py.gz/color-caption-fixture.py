import ast,json,hashlib,sys
from pathlib import Path
import numpy as np
from manim import ValueTracker,ManimColor,interpolate_color,Dot,FadeIn,FadeOut,Succession,smooth
sys.path.insert(0,'/workspace/explainer-videos')
from explainer.ai.viz import LiveBars
from explainer.ai import C
root=Path('/workspace/explainer-videos');source=root/'videos/ai/ai3/s17_geometry.py';tree=ast.parse(source.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='anisotropy');with_=next(n for n in fn.body if isinstance(n,ast.With));start=next(i for i,n in enumerate(with_.body)if isinstance(n,ast.Assign)and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='color_mix');block=ast.Module(body=with_.body[start:],type_ignores=[])
with np.load(root/'.cache/ai3/gpt2.npz',allow_pickle=False)as data:raw=np.asarray(data['hist_raw'],float);cen=np.asarray(data['hist_centred'],float)
raw/=raw.sum();cen/=cen.sum();top=max(raw.max(),cen.max());bars=LiveBars(raw,max_value=top,height=3.4,bar_width=.17,gap=.03,colors=C.TRUE_P);bars.place(-2.)
class Capture:
 def __init__(self):self.mobjects=[]
 def add(self,*objects):self.mobjects.extend(objects)
 def remove(self,*objects):self.mobjects=[m for m in self.mobjects if m not in objects]
 def get_mobject_family_members(self):return [m for obj in self.mobjects for m in obj.get_family()]
 def play(self,*animations,**kwargs):self.animations=animations;self.kwargs=kwargs
scene=Capture();env=dict(ValueTracker=ValueTracker,bars=bars,cen=cen,self=scene,RAWC=C.TRUE_P,CENC=C.BITS,interpolate_color=interpolate_color,ManimColor=ManimColor,FadeIn=FadeIn,FadeOut=FadeOut,Succession=Succession,m1=Dot(),m2=Dot())
exec(compile(ast.fix_missing_locations(block),str(source),'exec'),env);animations=[a.build()if hasattr(a,'build')else a for a in scene.animations];assert scene.kwargs['run_time']==1.6
assert len({id(a.mobject)for a in animations})==len(animations);assert not({id(bars.bar(i))for i in range(bars.n)}&{id(a.mobject)for a in animations})
scene.add(env['m1'])
for a in animations:a._setup_scene(scene);a.begin()
caption_checks=[]
samples=[]
for alpha in np.linspace(0,1,41):
 for a in animations:a.interpolate(float(alpha))
 old_opacity=float(env['m1'].get_fill_opacity()) if env['m1'] in scene.mobjects else 0.;new_opacity=float(env['m2'].get_fill_opacity()) if env['m2'] in scene.mobjects else 0.;assert not(old_opacity>1e-10 and new_opacity>1e-10),(alpha,old_opacity,new_opacity);caption_checks.append([float(alpha),old_opacity,new_opacity])
 bars.update(0);mix=env['color_mix'].get_value();expected=raw+(cen-raw)*smooth(float(alpha));heights=[]
 for i,v in enumerate(expected):
  bar=bars.bar(i);assert np.isclose(bars.trackers[i].get_value(),v,atol=1e-12);assert np.isclose(bar.height,max(3.4*v/top,.002),atol=1e-10);assert np.isclose(bar.get_bottom()[1],-2,atol=1e-10);assert np.isclose(bar.width,.17,atol=1e-10);assert np.allclose(bar.get_fill_color().to_rgb(),interpolate_color(ManimColor(C.TRUE_P),ManimColor(C.BITS),mix).to_rgb(),atol=1e-12);heights.append(float(bar.height))
 samples.append({'alpha':float(alpha),'color_mix':float(mix),'bar_count':bars.n,'total_normalized_probability':float(sum(t.get_value()for t in bars.trackers)),'minimum_height':min(heights),'maximum_height':max(heights)})
for a in animations:a.finish()
bars.update(0);bars.freeze();assert all(not m.updaters for m in bars.get_family());assert np.allclose(bars.bar(30).get_fill_color().to_rgb(),ManimColor(C.BITS).to_rgb())
out=source.parent.parent.parent.parent/'dummy';report={'status':'passed','scope':'Actual Manim LiveBars, actual cached histogram arrays; AST-extracted unchanged production color/height animation block. No render/model/data generation.','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'samples':samples,'caption_opacity_samples':caption_checks,'checks':['41 animation samples across all60 bars: original-height interpolation, fixed baseline/width, continuous common color from raw blue to centered yellow','Unique animation target mobjects; bar objects are not independently animated','End freeze clears group and child updaters and retains centered yellow','Same1.6s play duration; no VO/bookmark edits'],'fresh_render':'pending root-owned actual EN/ZH endpoint and motion regression'};p=Path('/workspace/runtime/ai3-words-geometry-motion-repair/color-fixture-result.json');p.write_text(json.dumps(report,indent=2)+'\n');print('PASS:41samples ×60bars, no competing bar animations; exact data geometry and color targets; freeze remains yellow.');print(p)
