import ast, json, hashlib, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, '/workspace/explainer-videos')
from explainer.ai import *
from videos.ai.ai3.common import MONO

ROOT = Path('/workspace/explainer-videos')
OUT = Path('/workspace/runtime/ai3-words-geometry-motion-repair')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def method(path, name):
    tree = ast.parse(Path(path).read_text())
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef))
    return next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == name)
def execute(nodes, env, filename):
    exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(filename), 'exec'), env)

words = ROOT/'videos/ai/ai3/s13_words.py'
with np.load(ROOT/'.cache/ai3/words.npz', allow_pickle=False) as values:
    xy = np.asarray(values['analogy_xy'])
def analogy_geometry(path):
    nodes = method(path, 'analogy').body
    start = next(i for i,n in enumerate(nodes) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='xy')
    end = next(i for i,n in enumerate(nodes) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='land')
    env = dict(globals(), w={'analogy_xy':xy})
    execute(nodes[start:end+1],env,path)
    return env
before = analogy_geometry(OUT/'before-s13_words.py')
after = analogy_geometry(words)
for name in ('pts','dots','labs','step','again','land'):
    if name=='pts': assert np.array_equal(before[name],after[name])
    else: assert np.array_equal(before[name].get_all_points(),after[name].get_all_points()), name
for lab in after['labs']:
    assert all(m.z_index==20 for m in lab.get_family())
    assert all(m.get_style()['background_stroke_width']==5 for m in lab.family_members_with_points())
    assert all(m.get_style()['background_stroke_opacity']==1 for m in lab.family_members_with_points())
assert after['step'].z_index < min(lab.z_index for lab in after['labs'])
assert after['again'].z_index < min(lab.z_index for lab in after['labs'])
copy = TransformFromCopy(after['step'],after['again'])
copy.begin()
for alpha in np.linspace(0,1,41):
    copy.interpolate(float(alpha))
    assert copy.mobject.z_index < min(lab.z_index for lab in after['labs'])
copy.finish()

source = ROOT/'videos/ai/ai3/s17_geometry.py'
data=json.loads((ROOT/'.cache/ai3/gpt2.json').read_text())
with np.load(ROOT/'.cache/ai3/gpt2.npz',allow_pickle=False) as values:
    data.update({k:np.asarray(values[k]) for k in values.files})
share = np.asarray(data['pc_share'])[:20]
ax=Axes(x_range=[0,21,5],y_range=[0,share[0]*1.15,share[0]/2],x_length=5.4,y_length=3.4,tips=False)
fn=method(source,'directions')
node=next(n for n in fn.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='bars')
env=dict(globals(),share=share,ax=ax,RAWC=C.TRUE_P)
execute([node],env,source); bars=env['bars']
class Capture:
    def play(self,*animations,**kwargs): self.animations=animations;self.kwargs=kwargs
scene=Capture();env['self']=scene
with_node=next(n for n in fn.body if isinstance(n,ast.With))
play=next(n for n in with_node.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and any(isinstance(a,ast.Call) and isinstance(a.func,ast.Name) and a.func.id=='Indicate' for a in n.value.args))
execute([play],env,source);pulse=scene.animations[0]
base=bars[0].get_all_points().copy();basecolor=bars[0].get_fill_color().to_rgb()
pulse.begin();peak_changed=False
for alpha in np.linspace(0,1,41):
    pulse.interpolate(float(alpha))
    assert np.allclose(bars[0].get_all_points(),base,atol=1e-12)
    assert np.isclose(bars[0].get_bottom()[1],ax.c2p(1,0)[1],atol=1e-12)
    if np.isclose(alpha,.5):peak_changed=not np.allclose(bars[0].get_fill_color().to_rgb(),basecolor)
pulse.finish();assert peak_changed
report={'status':'passed','scope':'Actual Manim objects/animations with AST-extracted production blocks; cached immutable arrays only. No production loader/model/render.',
 'sources':{str(p.relative_to(ROOT)):sha(p) for p in (words,source)},
 'checks':['Analogy points/dots/label vector paths/arrow endpoints/dashed error connector exactly unchanged from preserved source.',
 'Each local point-label glyph has opaque5px background stroke and z20; original/copied arrow z remains below at41 animation samples.',
 'Actual AST PC Indicate changes color but all measured rectangle points/height/baseline remain fixed at41 samples.'],
 'fresh_render':'pending root-owned EN/ZH regression; source geometry does not alone prove raster readability.'}
(OUT/'geometry-fixture-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
