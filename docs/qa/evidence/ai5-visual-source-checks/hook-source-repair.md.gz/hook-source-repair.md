# Part 5 Hook score consistency repair

The arrow field now reaches the actual time-zero density, without the old 0.06 floor. A green lower-left label identifies score directions and rescaled lengths. The first two narration blocks distinguish the score component from the full known-form drift and random kicks; this toy score is computed exactly, while a model learns it later. The tag fades with the arrows. The timeline footer now has a 0.35 inset.

All original animation play calls, run_time arguments, bookmarks, score palette and particle-data inputs remain unchanged apart from adding the tag to existing fades. The numerical score_at function is unchanged. Only Hook source and its scoped tests/private overlay were edited; main Chinese/global tables, numerical core and caches were not changed.

Before evidence contains the exact 13 endpoint PNG identities, result, sheet, text capture and source. Current completed shape NPZ is byte-identical to the parent's backup; all 7 array dtypes/shapes/bytes match. No old endpoint image is represented as approval of the new source.

An AST-only probe of the unchanged score_at on the actual 209-point display grid and completed shape data is finite at t=0,.01,.06,.1,2.5,5. The maximum endpoint direction difference between the old .06 floor and true zero is 153.44 degrees. This is a numerical field probe, not a rendered visual result.

Three focused source/Translator tests pass in 0.222 seconds. Four actual-Manim legend/footer object checks pass in English and Chinese with the private overlay. No Scene, model or producer was executed and no video/frame was rendered. Fresh bilingual endpoints/motion and all audio/listening remain pending parent gates.

`proposed-zh-overlay.json` contains exactly two narration updates and one unique caption. It is byte-identical to `tests/fixtures/ai5-hook-score-overlay.json`. Exact source/data/probe/test/before-image identities are recorded in the JSON receipts and manifest.
