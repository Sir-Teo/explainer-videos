from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time
R=Path('/workspace/explainer-videos');B=Path('/workspace/runtime/ai6-hook-split-polish/v2');F=B/'after-frozen';F.mkdir();h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();MIN=768*1024**2
expected='a056c9a3ddbe16b77214173c85d1faada320fc7b7d701644fd935aedbfa2498d';table='da401f2e66a875261f0a135c9cda9326100ea5b9f8a7b70140712224537717b4'
assert os.environ['AI6_HOOK_CAPTIONS_MERGED']=='confirmed' and os.environ['AI6_HOOK_GLOBAL_SHA256']==table and os.environ['EXPLAINER_CACHED_ONLY']=='1'
def guard():
 assert h(R/'videos/ai/ai6/s01_hook.py')==expected
 assert h(R/'videos/ai/ai_text_zh.json')==table
 if shutil.disk_usage(R).free<MIN:raise RuntimeError('STOP: less than768MiB free before/duringcase')
def independent(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);assert h(src)==h(dst) and (src.stat().st_dev,src.stat().st_ino)!=(dst.stat().st_dev,dst.stat().st_ino);return {'source':str(src),'copy':str(dst),'sha256':h(dst),'bytes':dst.stat().st_size}
verified=[]
for lang in ['en','zh']:
 freeze=Path('/workspace/runtime/ai6-hook-baseline')/lang/'freeze.json';d=json.loads(freeze.read_text())
 for row in d['files']:
  p=Path(row['copy']);assert h(p)==row['sha256'] and p.stat().st_size==row['bytes'];verified.append(row)
 for rel,row in d['inputs'].items():assert h(R/rel)==row['sha256']
(B/'baseline-reverified-before-overwrite.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verified':verified},indent=2)+'\n')
progress=[]
for mode in ['endpoints','motion']:
 for lang in ['en','zh']:
  guard();D=F/lang/mode;D.mkdir(parents=True);before=[]
  for rel in ['videos/ai/ai6/s01_hook.py','videos/ai/ai6/common.py','videos/ai/ai6/zh_lines.py','videos/ai/ai6/text_zh_add.json','videos/ai/ai6/narration_zh.json','videos/ai/ai_text_zh.json','tools/qa_series.py','tools/qa_motion.py','explainer/voiceover.py','explainer/ai/__init__.py','explainer/ai/viz.py','explainer/analysis/__init__.py','explainer/zh_text.py']:
   before.append(independent(R/rel,D/'observed-before'/rel))
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();cmd=['nice','-n','10',sys.executable,'tools/qa_series.py','ai6','--only','Hook','--lang',lang,'--cached-only','--timeout','1800']+(['--motion'] if mode=='motion' else [])
  print('START',mode,lang,'free',shutil.disk_usage(R).free,flush=True)
  with (B/f'after-{mode}-{lang}.log').open('w') as out:
   proc=subprocess.Popen(cmd,cwd=R,env=os.environ.copy(),stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
   while proc.poll() is None:
    if shutil.disk_usage(R).free<MIN:
     import signal
     os.killpg(proc.pid,signal.SIGTERM);proc.wait();raise RuntimeError('STOPcase diskguard')
    time.sleep(.5)
  rc=proc.returncode;canonical=R/f'renders/qa/series/ai6/{lang}/'+Path('Hook'+('_motion' if mode=='motion' else '')) if False else R/f'renders/qa/series/ai6/{lang}/'+Path('unused') if False else R/f'renders/qa/series/ai6/{lang}/'+Path('unused') if False else R/f'renders/qa/series/ai6/{lang}'/('Hook_motion' if mode=='motion' else 'Hook')
  raw=canonical/'result.json';assert raw.exists();record=json.loads(raw.read_text());copies=[independent(raw,D/'result.json')]
  for n in ['render.log','sheet.png','text.jsonl']:
   if (canonical/n).exists():copies.append(independent(canonical/n,D/n))
  for frame in record.get('frames',[]):copies.append(independent(canonical/frame['file'],D/frame['file']))
  if mode=='motion':
   movie=R/record['movie'];copies.append(independent(movie,D/'Hook.mp4'))
   for suffix in ['.narration.json','.srt']:
    if movie.with_suffix(suffix).exists():copies.append(independent(movie.with_suffix(suffix),D/('Hook'+suffix)))
  inputs=[]
  for rel,sig in record.get('inputs',{}).items():
   p=R/rel
   if p.exists():inputs.append({**independent(p,D/'input-snapshots'/rel),'recorded_signature':sig,'observed_signature':[p.stat().st_size,p.stat().st_mtime_ns]})
  after=[{'path':q['source'],'before_sha256':q['sha256'],'after_sha256':h(Path(q['source']))} for q in before]
  event={'case':lang+'/Hook','mode':mode,'started_utc':start,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':rc,'raw_status':record.get('status'),'raw_warnings':record.get('warnings'),'raw_fingerprint':record.get('fingerprint'),'copies':copies,'inputs':inputs,'source_observations_before_after':after,'scope':'Source copies arefilesystem observations, not historicalimport attestation. Original rawrecord preserved; runtimecompletion isnotvisualapproval.'};(D/'freeze.json').write_text(json.dumps(event,indent=2)+'\n');progress.append(event);(B/'render-progress.json').write_text(json.dumps(progress,indent=2)+'\n');print('DONE',mode,lang,'exit',rc,'status',record.get('status'),'warnings',record.get('warnings'),'frames',len(record.get('frames',[])),flush=True)
  guard()
print('ALL4CASES_RENDERED_AND_INDEPENDENTLY_FROZEN',flush=True)
