from pathlib import Path
import ast,copy,hashlib,json,re,unittest
import numpy as np
R=Path('/workspace/explainer-videos');B=Path('/workspace/runtime/ai6-hook-split-polish/v2');current=R/'videos/ai/ai6/s01_hook.py';old=B/'s01_hook-before.py';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def parse(p):return ast.parse(p.read_text())
def calls(t,name):return [n for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr==name]
def method(t,name):return next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name==name)
def dump(n):return ast.dump(n,include_attributes=False)
class Dot:
 def __init__(self,page):self.page=page;self.fill_opacity=.85;self.color=['Austen','Dickens'][page%2];self.position=(page*.3,page*.5)
 def set_fill(self,*,opacity):self.fill_opacity=opacity
class Fixtures(unittest.TestCase):
 def test_filtered_page_ids_are_used_instead_of_visible_order(self):
  t=parse(current);loop=next(n for n in method(t,'cloud').body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='dot');dots=[Dot(4),Dot(0),Dot(2)];mask=np.array([False,True,True,False,True]);before=[(d.color,d.position,d.page) for d in dots]
  exec(compile(ast.Module([loop],type_ignores=[]),'actual-opacity-loop','exec'),dict(dots=dots,test=mask))
  self.assertEqual([d.fill_opacity for d in dots],[.45,.85,.45]);self.assertEqual([(d.color,d.position,d.page) for d in dots],before)
 def test_all_train_and_all_heldout_have_honest_extremes(self):
  loop=next(n for n in method(parse(current),'cloud').body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='dot')
  for mask,expected in [(np.zeros(3,bool),.85),(np.ones(3,bool),.45)]:
   dots=[Dot(i) for i in range(3)];exec(compile(ast.Module([loop],type_ignores=[]),'actual-opacity-loop','exec'),dict(dots=dots,test=mask));self.assertEqual([d.fill_opacity for d in dots],[expected]*3)
 def test_all_voiceover_bookmark_wait_and_explicit_timing_asts_exact(self):
  a,b=parse(old),parse(current)
  for name in ['voiceover','wait_until','wait']:
   self.assertEqual([dump(n) for n in calls(a,name)],[dump(n) for n in calls(b,name)])
  for name in ['play']:
   ac,bc=calls(a,name),calls(b,name);self.assertEqual(len(ac),len(bc));self.assertEqual([[dump(k) for k in n.keywords] for n in ac],[[dump(k) for k in n.keywords] for n in bc])
  self.assertEqual([dump(n) for n in ast.walk(a) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='page_dots'],[dump(n) for n in ast.walk(b) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='page_dots'])
 def test_only_existing_books_reveal_adds_the_splitnote(self):
  a,b=parse(old),parse(current);oldplays=calls(a,'play');newplays=calls(b,'play');changed=[]
  for i,(x,y) in enumerate(zip(oldplays,newplays)):
   if dump(x)!=dump(y):changed.append(i);self.assertEqual(len(x.args),1);self.assertEqual(len(y.args),2);self.assertEqual(dump(x.args[0]),dump(y.args[0]));self.assertEqual(dump(y.args[1]),dump(ast.parse('FadeIn(splitnote)',mode='eval').body))
  self.assertEqual(len(changed),1)
 def test_dynamic_counts_and_chinese_proposal_match_actual_caption_fields(self):
  proposal=json.loads((B/'local-caption-proposal.json').read_text());counts=[]
  for n in ast.walk(method(parse(current),'cloud')):
   if isinstance(n,ast.JoinedStr):
    try:s=eval(compile(ast.Expression(n),'actual-caption','eval'),dict(test=np.array([False,True,True,False]),int=int))
    except NameError:continue
    if s.startswith(('training pages:','held-out pages:')):counts.append(s)
  self.assertCountEqual(counts,['training pages: $2$','held-out pages: $2$'])
  for en,zh in [('training pages: $448$','训练页：$448$'),('held-out pages: $191$','留出页：$191$'),('$632$ shown; $7$ outside view','显示$632$页；$7$页在视野外')]:
   matches=[re.sub(p,v,en) for p,v in proposal['patterns'] if re.fullmatch(p,en)];self.assertEqual(matches,[zh])
if __name__=='__main__':unittest.main()
