from pathlib import Path
import datetime,fcntl,hashlib,importlib.util,json,os,shutil,subprocess,sys,time
R=Path('/workspace/explainer-videos');B=Path('/workspace/runtime/ai6-hook-split-polish/v2');lang=sys.argv[1];D=B/'motion-review'/lang;D.mkdir(parents=True);F=B/'after-frozen'/lang/'motion';OLD=Path('/workspace/runtime/ai6-hook-baseline-motion-review')/lang;h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();MIN=768*1024**2
assert (F/'freeze.json').exists();assert not(D/'plan.json').exists();freeze=json.loads((F/'freeze.json').read_text());movie=F/'Hook.mp4';movie_row=next(q for q in freeze['copies'] if q['copy']==str(movie));assert h(movie)==movie_row['sha256']
baseplan=json.loads((OLD/'plan.json').read_text());views=json.loads((OLD/'views.json').read_text());byname={p['file']:p for p in baseplan['pages']};assert len(views['pages'])==len(baseplan['pages'])
for viewed in views['pages']:
 q=byname[viewed['file']];assert q['sha256']==viewed['sha256'] and h(OLD/'unique'/viewed['file'])==q['sha256']
base={}
for i,rep in enumerate(baseplan['reps']):
 p=OLD/'unique'/rep['file'];assert h(p)==rep['sha256'];base[rep['sha256']]={'baseline_representative':i,'time':rep['time'],'source_frame':rep['source_frame'],'path':str(p),'baseline_movie_sha256':baseplan['source_sha256']}
with open('/workspace/runtime/ai4-tail-motion-review/extract.lock','a') as lock:
 print('WAITING_SHARED_EXTRACTION_LOCK',lang,flush=True);fcntl.flock(lock,fcntl.LOCK_EX)
 if shutil.disk_usage(R).free<MIN:raise RuntimeError('STOPbeforeextraction disk<768MiB')
 assert h(R/'tools/qa_motion.py')=='1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e'
 env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
 with (D/'audit.log').open('w') as log:
  proc=subprocess.Popen(['nice','-n','10',sys.executable,str(R/'tools/qa_motion.py'),str(movie),'-o',str(D/'audit'),'--dense','.25','--max-gap','1'],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   if shutil.disk_usage(R).free<MIN:
    import signal
    os.killpg(proc.pid,signal.SIGTERM);proc.wait();raise RuntimeError('STOPduringextraction disk<768MiB')
   time.sleep(.5)
  assert proc.returncode==0,proc.returncode
spec=importlib.util.spec_from_file_location('qa_motion',R/'tools/qa_motion.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);a=json.loads((D/'audit/result.json').read_text());assert a['source_sha256']==h(movie);reps=[];mapping=[];seen={};inherit=[];novel=[]
for selected_index,f in enumerate(a['selected_frames']):
 sha=f['sha256']
 if sha not in seen:
  idx=len(reps);seen[sha]=idx;rep={**f,'file':'../audit/'+f['file'],'all_representative_index':idx}
  p=D/'audit'/f['file'];assert h(p)==sha
  if sha in base:rep['exact_inherited']=base[sha];inherit.append(rep)
  else:rep['changed_index']=len(novel);novel.append(rep)
  reps.append(rep)
 mapping.append({'selected_index':selected_index,'time':f['time'],'source_frame':f['source_frame'],'sha256':sha,'representative_index':seen[sha]})
N=D/'changed';N.mkdir();pages=m.sheets(N,novel);plan={'case':lang+'/Hook','movie_sha256':h(movie),'record_sha256':h(F/'result.json'),'freeze_sha256':h(F/'freeze.json'),'tool_sha256':a['tool_sha256'],'decoded':a['analysis']['decoded_frames'],'selected':len(a['selected_frames']),'unique':len(reps),'exact_inherited_unique':len(inherit),'novel_unique':len(novel),'representatives':reps,'mapping':mapping,'inherited':inherit,'novel':novel,'pages':pages,'gaps':a['unextracted_frame_gaps'],'max_gap':a['largest_selected_time_gap'],'first_time':a['selected_frames'][0]['time'],'last_time':a['selected_frames'][-1]['time'],'duration':a['duration'],'baseline_plan_sha256':h(OLD/'plan.json'),'baseline_views_sha256':h(OLD/'views.json'),'inheritance_scope':'EverybaselineoriginalPNG/page hash reverified and everybaselineuniqueviewed receipt confirmed; onlyexactPNGhashes inherited, never similarity.'};(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(D/'views.json').write_text('{"pages":[],"native":[],"findings":[]}\n');print('READY',lang,json.dumps({k:plan[k] for k in ['decoded','selected','unique','exact_inherited_unique','novel_unique']}),'pages',len(pages),flush=True)
