from pathlib import Path
import numpy as np,json,hashlib,datetime
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-actual-viewport-data-audit');D.mkdir(exist_ok=False)
paths=set();sources=['s04_ridge.py','s05_lasso.py','s10_knn.py','s14_forests.py','s16_gboost.py'];before={};after={};rows=[]
def sig(p):return dict(bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def data(name):
 j=R/'.cache/ai6'/f'{name}.json';a=j.with_suffix('.npz');out={}
 for p in [j,a]:
  if p.exists():before[str(p.relative_to(R))]=sig(p);paths.add(p)
 out.update(json.loads(j.read_text()))
 if a.exists():
  with np.load(a) as z:out.update({k:z[k].copy() for k in z.files})
 return out
def check(name,values,lo,hi,meaning):
 v=np.asarray(values,dtype=float);assert v.size and np.isfinite(v).all();rows.append(dict(series=name,count=v.size,minimum=float(v.min()),maximum=float(v.max()),lower=float(lo),upper=float(hi),changed_values=int(((v<lo)|(v>hi)).sum()),maximum_absolute_change=float(np.max(np.abs(v-np.clip(v,lo,hi)))),meaning=meaning))
r=data('ridge');mm=np.asarray(r['cv_mse']);se=np.asarray(r['cv_mse_se'])
for n,v in [('mean',mm),('low',mm-se),('high',mm+se)]:check('ridge.'+n,v,0,.26,'Displayed mean/error envelope')
l=data('lasso');mm=np.asarray(l['cv_mse']);se=np.asarray(l['cv_se']);top=min(float(mm.max()),.26)*1.05
for n,v in [('mean',mm),('low',mm-se),('high',mm+se)]:check('lasso.'+n,v,0,top,'Displayed mean/error envelope')
b=data('bagging')
for k in ['forest_acc','forest_oob','bag_acc']:check('bagging.'+k,b[k],.8,1,'Forest comparison accuracy')
x=data('xgb');check('xgb.test_acc_2',x['test_acc_2'],.74,.86,'Two-rate miniature accuracy plot')
for k in ['train_loss_70','first_loss_70']:check('xgb.'+k,x[k],10**-2.5,float('inf'),'Log training-loss viewport floor')
for k in ['test_acc_70','first_acc_70']:check('xgb.'+k,x[k],.85,1,'All-rate comparison accuracy')
c=data('coverhart')
for k in ['e1','ek']:check('coverhart.'+k+'.high',[c[k][str(n)]['hi'] for n in c['ns']],-float('inf'),.4,'KNN displayed10th–90th percentile upper envelope')
for name in sources:
 p=R/'videos/ai/ai6'/name;before[str(p.relative_to(R))]=sig(p);paths.add(p)
for p in paths:after[str(p.relative_to(R))]=sig(p)
assert before==after
# JSON-safe unbounded mathematical clamps are represented by null.
for row in rows:
 for k in ['lower','upper']:
  if not np.isfinite(row[k]):row[k]=None
out=dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),rows=rows,all_read_payload_and_source_signatures_unchanged=True,before=before,after=after,scope='Read-only actual frozen default numerical arrays; no producer/model/scene imports, fits, writes or render. Existing clamping is inactive for the checked Ridge/Lasso/forest/boosting arrays. KNN percentile-band distortion is active and separately confirmed in existing rendered endpoints by its review owner. This is not proof about future seeds, unexamined arrays, full movies or visual readability.')
(D/'report.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n');print(json.dumps(dict(checked_series=len(rows),active=[r for r in rows if r['changed_values']],stable_signatures=len(before)),indent=2))
