from pathlib import Path
import json,subprocess,shutil,hashlib,datetime,os
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;T=Path('/workspace/runtime/part1-probability-numeric-dwell-v7-base927');OLD=Path('/workspace/runtime/part1-surprise-v6-preflight-base927');BASE='927fba668656a682b3e29a288de64130ddc680dd';HARD=512*1024**2
assert not T.exists() and not (D/'actual-context-preparation.json').exists(),'Reconcile any uncertain prior context first'
free=shutil.disk_usage('/workspace').free;assert free>HARD+16*1024**2,free
original=json.loads((D/'existing-v6-fixture-input-hash-proof.json').read_text());prep=json.loads(Path('/workspace/runtime/surprise-overlay-v6-final/preparation.json').read_text())
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def state(p):
 s=p.stat();return dict(bytes=s.st_size,sha256=sha(p),mtime_ns=s.st_mtime_ns,inode=s.st_ino,device=s.st_dev,nlink=s.st_nlink,mode=s.st_mode)
# Original fixture Git is observed read-only, never checkout/add/reset/commit there.
def git(args,cwd,mutate=False):
 assert shutil.disk_usage('/workspace').free>HARD
 cmd=['git',*args] if mutate else ['git','--no-optional-locks',*args];p=subprocess.run(cmd,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);commands.append(dict(command=cmd,cwd=str(cwd),returncode=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode()));assert p.returncode==0,commands[-1];return p.stdout
commands=[];gitdir=Path(git(['rev-parse','--absolute-git-dir'],OLD).decode().strip());oldgit={str(p):state(p) for p in sorted(gitdir.rglob('*')) if p.is_file()};oldgit[str(OLD/'.git')]=state(OLD/'.git');(D/'old-fixture-git-before.json').write_text(json.dumps(oldgit,indent=2)+'\n')
references=[]
for row in original['rows']:
 f=Path(row['file']);s=state(f);assert all(s[k]==row[k] for k in ['bytes','sha256','mtime_ns','inode','device','nlink']);references.append(dict(path=row['path'],reference_file=str(f),before=s))
# Local shared-object clone creates its own Git metadata and never mutates old/main Git.
git(['clone','--shared','--no-hardlinks','--no-checkout',str(R),str(T)],D,True)
git(['sparse-checkout','init','--no-cone'],T,True)
p=subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=T,input=''.join('/'+p+'\n' for p in prep['sparse_paths']).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE);commands.append(dict(command=['git','sparse-checkout','set','--no-cone','--stdin'],cwd=str(T),returncode=p.returncode,stdin_paths=len(prep['sparse_paths']),stdout=p.stdout.decode(),stderr=p.stderr.decode()));assert p.returncode==0
git(['checkout','--detach',BASE],T,True);assert git(['rev-parse','HEAD'],T).decode().strip()==BASE
links=[]
for row in references:
 assert row['path'].startswith('.cache/');p=T/row['path'];p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists() and not p.is_symlink();p.symlink_to(row['reference_file']);assert p.is_symlink() and p.is_file();links.append(dict(path=row['path'],link_target=os.readlink(p),symlink_inode=p.lstat().st_ino,reference_sha256=row['before']['sha256']))
status=git(['status','--porcelain=v1','--untracked-files=all'],T).decode();assert status=='',status
for row in references:assert state(Path(row['reference_file']))==row['before']
assert {str(p):state(p) for p in sorted(gitdir.rglob('*')) if p.is_file()}|{str(OLD/'.git'):state(OLD/'.git')}==oldgit
report=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base_commit=BASE,target=str(T),old_readonly_reference=str(OLD),git_object_policy='NewindependentGitmetadata; read-onlyalternates toexistingmainobjects, nooriginalfixtureGitmutation.',commands=commands,source_sparse_paths=prep['sparse_paths'],input_references=references,data_links=links,new_data_copy_bytes=0,reused_file_count=len(links),reused_logical_bytes=sum(x['before']['bytes'] for x in references),original_git_before_sha256=sha(D/'old-fixture-git-before.json'),initial_worktree_status=status,free_before=free,free_after=shutil.disk_usage('/workspace').free,guard_minimum_bytes=HARD,scope='Newcloudsource-onlyfixturewithignored.cache symlinks toexisting156exactoldpayloads. Verificationcodeonlyreadsthem; nofilesystemwrite-protectionclaim. No model/producer/load/render/audio/download/oldfixture mutation.')
assert report['free_after']>HARD;(D/'actual-context-preparation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['target','new_data_copy_bytes','reused_file_count','reused_logical_bytes','free_before','free_after']},indent=2))
