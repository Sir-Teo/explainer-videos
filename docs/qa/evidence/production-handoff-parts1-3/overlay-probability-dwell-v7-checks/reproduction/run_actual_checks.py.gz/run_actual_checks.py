"""Read-only verifier against a NEW source context; old payload/Git targets never mutated."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;T=Path('/workspace/runtime/part1-probability-numeric-dwell-v7-base927');M=R/'docs/qa/evidence/production-handoff-parts1-3';HELPER=M/'verify_handoff.py';ID='part1-probability-numeric-dwell-surprise-roadmap-and-part3-v7';V6='part1-surprise-probability-roadmap-and-part3-v6';BASE='927fba668656a682b3e29a288de64130ddc680dd';HARD=512*1024**2
assert not (D/'actual-checks-receipt.json').exists() and not (D/'actual-checks-in-progress.json').exists(),'Reconcile any uncertain prior operations first'
p=json.loads((D/'actual-context-preparation.json').read_text());m=json.loads((M/'overlays'/f'{ID}.json').read_text());records=[];commands=[]
def guard():
 free=shutil.disk_usage('/workspace').free;assert free>HARD+1024**2,free;return free
def h(raw):return hashlib.sha256(raw).hexdigest()
def sha(path):
 v=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):v.update(b)
 return v.hexdigest()
def state(path):
 s=path.stat();return dict(bytes=s.st_size,sha256=sha(path),mtime_ns=s.st_mtime_ns,inode=s.st_ino,device=s.st_dev,nlink=s.st_nlink,mode=s.st_mode)
def git(*args):
 guard();r=subprocess.run(['git',*args],cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE);commands.append(dict(command=['git',*args],returncode=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode()));assert r.returncode==0,commands[-1];return r.stdout
assert git('rev-parse','HEAD').decode().strip()==BASE and git('status','--porcelain')==b''
for r in p['input_references']:assert state(Path(r['reference_file']))==r['before']
# Full publicmodel hashes are still checked by everystrictverify; no tensor/torch/model import.
external=json.loads((M/'external-validation-dependencies.json').read_text());hub=Path(os.environ['HF_HOME'])/'hub';public_before={str(hub/r['snapshot_relative_path']):state(hub/r['snapshot_relative_path']) for r in external['gpt2']['files']}
def check(name,passed,overlay=None,version_fixture=False):
 free=guard();args=[sys.executable,'-B',str(HELPER),'--repo',str(T),'--strict-external','--optional-audio']
 if overlay:args+=['--overlay',overlay]
 if version_fixture:
  code="import importlib.metadata,runpy,sys; old=importlib.metadata.version; importlib.metadata.version=lambda n:'deliberate-wrong-version-fixture' if n=='numpy' else old(n); sys.argv=sys.argv[1:]; runpy.run_path(sys.argv[0],run_name='__main__')"
  args=[sys.executable,'-B','-c',code,*args[2:]]
 out=subprocess.run(args,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(D/(name+'.json')).write_bytes(out.stdout);(D/(name+'.stderr.txt')).write_bytes(out.stderr);j=json.loads(out.stdout);actual=out.returncode==0 and not j['errors'];row=dict(name=name,expected_pass=passed,actual_pass=actual,returncode=out.returncode,checked_files=j['checked_files'],errors=j['errors'],command=args,stdout_sha256=h(out.stdout),stderr_sha256=h(out.stderr),source_HEAD=git('rev-parse','HEAD').decode().strip(),free_before=free,free_after=guard(),deliberate_version_metadata_fixture=version_fixture);records.append(row);(D/'actual-checks-in-progress.json').write_text(json.dumps(records,indent=2)+'\n');assert actual is passed,row;print(name,'PASS' if actual else 'EXPECTED_REJECT',j['checked_files'],len(j['errors']),flush=True)
check('v7-clean-base-strict',True)
# Exact five regular independent source files only; data symlinks remain ignored.
for row in m['source_replacements']:
 f=T/row['before']['path'];assert f.is_file() and not f.is_symlink() and sha(f)==row['before']['sha256'];raw=(R/row['after']['path']).read_bytes();assert h(raw)==row['after']['sha256'] and len(raw)==row['after']['bytes'];(D/(f.name+'.base927.gz')).write_bytes(__import__('gzip').compress(f.read_bytes(),mtime=0));f.write_bytes(raw);f.chmod(0o644)
check('v7-exact-five-source-worktree',True,ID)
for name,mode in [('v7-default-rejects-new-source',None),('v7-v1-rejects-new-source','svd-reveal-v1'),('v7-v2-rejects-new-source','svd-production-polish-v2'),('v7-v3-rejects-new-source','part3-svd-outro-production-v3'),('v7-v4-rejects-new-source','part1-roadmap-and-part3-v4'),('v7-v5-rejects-new-source','part1-probability-roadmap-and-part3-v5'),('v7-v6-rejects-new-source',V6)]:check(name,False,mode)
f=T/'videos/ai/ai1/s02_probability.py';good=f.read_bytes();old=Path('/workspace/runtime/surprise-overlay-v6-final/s02_probability.py.after').read_bytes();assert h(old)=='50ff2a79121a6429eaf30950094d2157e6118d3b390e4544185f27cc44ecf0ed';f.write_bytes(old)
try:
 check('v7-v6-still-accepts-exact-old-five',True,V6);check('v7-rejects-old-probability',False,ID)
finally:f.write_bytes(good)
f=T/'README.md';good=f.read_bytes();f.write_bytes(good+b'\nDeliberate unrelated source drift fixture.\n')
try:check('v7-rejects-unrelated-worktree-source',False,ID)
finally:f.write_bytes(good)
f=T/'videos/ai/ai3/unreviewed_v7_fixture_producer.py';assert not f.exists();f.write_text('raise RuntimeError("must never be imported")\n')
try:check('v7-rejects-untracked-producer',False,ID)
finally:(D/'untracked-producer.rejected.gz').write_bytes(__import__('gzip').compress(f.read_bytes(),mtime=0));f.unlink()
# NEVER write/rename the reused payload target: perturb only the NEW link/copy.
row=json.loads((M/'cache-inventory.json').read_text())['files'][0];f=T/row['path'];assert f.is_symlink();target=os.readlink(f);assert state(Path(target))==next(r['before'] for r in p['input_references'] if r['path']==row['path']);f.unlink()
try:
 check('v7-rejects-missing-reused-link',False,ID);f.write_bytes(b'deliberately wrong independent tiny input');check('v7-rejects-tampered-independent-input',False,ID)
finally:
 if f.exists() or f.is_symlink():f.unlink()
 f.symlink_to(target)
check('v7-rejects-runtime-version-fixture',False,ID,True)
paths=[r['after']['path'] for r in m['source_replacements']];git('add','--',*paths);git('-c','user.name=Cloud QA fixture','-c','user.email=qa@example.invalid','commit','--quiet','-m','Fixture exact approved five-source numeric dwell overlay');source_commit=git('rev-parse','HEAD').decode().strip();check('v7-exact-five-source-commit',True,ID)
f=T/'README.md';good=f.read_bytes();f.write_bytes(good+b'\nDeliberate unrelated HEAD fixture.\n');git('add','--','README.md');git('-c','user.name=Cloud QA fixture','-c','user.email=qa@example.invalid','commit','--quiet','-m','Fixture forbidden unrelated HEAD');rejected_commit=git('rev-parse','HEAD').decode().strip()
try:check('v7-rejects-unrelated-HEAD',False,ID)
finally:git('checkout','--detach',source_commit)
check('v7-final-source-only-strict',True,ID)
closed=[]
for row in p['input_references']:
 ref=Path(row['reference_file']);new=T/row['path'];assert state(ref)==row['before'];assert new.is_symlink() and os.readlink(new)==str(ref) and state(new)==row['before'];closed.append(dict(path=row['path'],reference_file=str(ref),before=row['before'],after=state(ref),new_context_resolves_identically=True))
oldgit=json.loads((D/'old-fixture-git-before.json').read_text());assert all(state(Path(path))==st for path,st in oldgit.items())
# Reject added/missing private Git files as well as changed existing entries.
oldgitdir=Path(next(c['stdout'].strip() for c in p['commands'] if c['command'][-2:]==['rev-parse','--absolute-git-dir']));oldgitnow={str(f):state(f) for f in sorted(oldgitdir.rglob('*')) if f.is_file()};oldgitnow[str(Path(p['old_readonly_reference'])/'.git')]=state(Path(p['old_readonly_reference'])/'.git');assert oldgitnow==oldgit
assert all(state(Path(path))==st for path,st in public_before.items())
(D/'old-fixture-git-after.json').write_text(json.dumps(oldgitnow,indent=2)+'\n');(D/'actual-data-before-after.json').write_text(json.dumps(closed,indent=2)+'\n')
receipt=dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),overlay_id=ID,base_commit=BASE,helper_sha256=sha(HELPER),overlay_sha256=sha(M/'overlays'/f'{ID}.json'),checks=records,actual_checks=len(records),all_expected_results=True,final_strict_file_checks=records[-1]['checked_files'],source_only_fixture_commit=source_commit,rejected_unrelated_commit=rejected_commit,new_source_context=str(T),original_fixture=str(p['old_readonly_reference']),original_156_payload_hash_size_mtime_inode_nlink_mode_device_exact=True,original_fixture_Git_files_exact=True,public_model_files_hash_size_mtime_inode_nlink_exact=True,public_model_witnesses=public_before,new_data_copy_bytes=0,link_mutation_scope='OnlyoneNEWsymlink temporarilyabsent/replacedbytinyindependentwrongfile; restoredsameoldtarget. Oldpayloadbytes/metadata neverwritten, renamed, chmodded or linkedbyhardlink.',git_commands=commands,final_worktree_status=git('status','--porcelain').decode(),free_after=guard(),remaining='Controlled source permission only. No repaired production render/readability/audio/listening/sync/wholemovie duration acceptance.',scope='Actual268source/cache/runtime/publicmodel/optionalreal-audiofilegates, no scene/producer/model imports or synth/render/decode/download. Originalreferencefiles/Git preserved; onlynewfixtureGit changes.')
assert receipt['final_strict_file_checks']==268 and receipt['final_worktree_status']=='';(D/'actual-checks-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('FINAL',len(records),'expectedoutcomes;156oldpayloads+Git+publicmodelwitnessesexact;free',receipt['free_after'])
