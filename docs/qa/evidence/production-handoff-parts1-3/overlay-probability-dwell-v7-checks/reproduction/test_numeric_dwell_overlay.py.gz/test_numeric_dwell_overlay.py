"""Private portable v7 policy fixtures; actual manifest/source registration pending."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import unittest
from unittest.mock import patch
import test_production_handoff_surprise_overlay as previous

D=Path(__file__).parent
spec=importlib.util.spec_from_file_location('private_numeric_dwell_preflight',D/'verify_handoff.py')
preflight=importlib.util.module_from_spec(spec);spec.loader.exec_module(preflight)
# Reuse fixture builders with this private helper in this isolated test process.
previous.preflight=preflight
previous.previous.preflight=preflight
previous.previous.old.preflight=preflight
sha=lambda raw:hashlib.sha256(raw).hexdigest()

class NumericDwellOverlayPreparationTests(unittest.TestCase):
    setUp=previous.SurpriseOverlayTests.setUp
    cmd=previous.SurpriseOverlayTests.cmd
    commit=previous.SurpriseOverlayTests.commit
    write=previous.SurpriseOverlayTests.write
    json=previous.SurpriseOverlayTests.json
    row=previous.SurpriseOverlayTests.row
    verify=previous.SurpriseOverlayTests.verify
    assertRejected=previous.SurpriseOverlayTests.assertRejected
    repin_fixture_manifest=previous.SurpriseOverlayTests.repin_fixture_manifest
    install_combined_fixture=previous.SurpriseOverlayTests.install_combined_fixture
    repin_combined_fixture=previous.SurpriseOverlayTests.repin_combined_fixture
    install_roadmap_fixture=previous.SurpriseOverlayTests.install_roadmap_fixture
    repin_roadmap_fixture=previous.SurpriseOverlayTests.repin_roadmap_fixture
    install_polish_fixture=previous.SurpriseOverlayTests.install_polish_fixture
    install_probability_fixture=previous.SurpriseOverlayTests.install_probability_fixture
    repin_probability_fixture=previous.SurpriseOverlayTests.repin_probability_fixture
    install_surprise_fixture=previous.SurpriseOverlayTests.install_surprise_fixture
    repin_surprise_fixture=previous.SurpriseOverlayTests.repin_surprise_fixture

    def install_dwell_fixture(self):
        self.install_surprise_fixture()
        self.dwell_after=b'synthetic reviewed numeric result dwell source\n'
        self.dwell=json.loads(json.dumps(self.surprise));self.dwell['overlay_id']=preflight.NUMERIC_DWELL_OVERLAY
        self.dwell['source_replacements'][1]['after']=self.row(preflight.PROBABILITY,self.dwell_after)
        self.dwell['production_acceptance']={'probability_numeric_dwell_output_accepted':False}
        self.repin_dwell_fixture();self.write(preflight.PROBABILITY,self.dwell_after)
        return preflight.NUMERIC_DWELL_OVERLAY

    def repin_dwell_fixture(self):
        rel='overlays/'+preflight.NUMERIC_DWELL_OVERLAY+'.json';self.json(rel,self.dwell)
        self.known[preflight.NUMERIC_DWELL_OVERLAY]=(rel,sha((self.meta/rel).read_bytes()))

    def test_exact_five_sources_and_strict_inputs_accepted(self):
        name=self.install_dwell_fixture();r=preflight.verify(self.repo,overlay_id=name,strict_external=True,optional_audio=True)
        self.assertEqual(r['errors'],[]);self.assertEqual(r['checked_files'],12)

    def test_source_only_equivalent_commit_accepted(self):
        name=self.install_dwell_fixture();self.cmd('add',*[r['after']['path'] for r in self.dwell['source_replacements']]);self.commit('exact synthetic numeric dwell tree')
        self.assertEqual(preflight.verify(self.repo,overlay_id=name)['errors'],[])

    def test_default_and_every_old_mode_reject_new_probability(self):
        self.install_dwell_fixture();v2=self.install_polish_fixture()
        for name in [None,'svd-reveal-v1',v2,preflight.COMBINED,preflight.ROADMAP,preflight.PROBABILITY_OVERLAY,preflight.SURPRISE_OVERLAY]:
            self.assertRejected(preflight.verify(self.repo,overlay_id=name),preflight.PROBABILITY)
        self.write(preflight.PROBABILITY,self.prob_after)
        self.assertEqual(preflight.verify(self.repo,overlay_id=preflight.SURPRISE_OVERLAY)['errors'],[])
        self.assertRejected(preflight.verify(self.repo,overlay_id=preflight.NUMERIC_DWELL_OVERLAY),preflight.PROBABILITY)

    def test_every_exact_source_replacement_remains_required(self):
        name=self.install_dwell_fixture()
        for row in self.dwell['source_replacements']:
            path=row['after']['path'];raw=(self.repo/path).read_bytes();self.write(path,self.cmd('show',self.base+':'+path).encode())
            self.assertRejected(preflight.verify(self.repo,overlay_id=name),path);self.write(path,raw)

    def test_unknown_or_tampered_manifest_and_wrong_base_fail(self):
        name=self.install_dwell_fixture();self.assertRejected(preflight.verify(self.repo,overlay_id='unreviewed-numeric-dwell'),'Unknown reviewed overlay')
        self.dwell['production_acceptance']['probability_numeric_dwell_output_accepted']=True;self.json('overlays/'+name+'.json',self.dwell)
        self.assertRejected(preflight.verify(self.repo,overlay_id=name),'manifest hash mismatch')
        self.dwell['base_commit']='0'*40;self.repin_dwell_fixture();self.assertRejected(preflight.verify(self.repo,overlay_id=name),'identity/base mismatch')

    def test_wrong_source_path_order_and_extra_repository_files_fail(self):
        name=self.install_dwell_fixture();original=json.loads(json.dumps(self.dwell))
        self.dwell['source_replacements'][1]['after']['path']='videos/ai/ai1/unreviewed.py';self.repin_dwell_fixture();self.assertRejected(preflight.verify(self.repo,overlay_id=name),'unreviewed path')
        self.dwell=json.loads(json.dumps(original));self.dwell['source_replacements'].reverse();self.repin_dwell_fixture();self.assertRejected(preflight.verify(self.repo,overlay_id=name),'unreviewed path')
        self.dwell=json.loads(json.dumps(original));self.dwell['optional_evidence_files']=[self.row(self.evidence_path,self.evidence_bytes)];self.repin_dwell_fixture();self.assertRejected(preflight.verify(self.repo,overlay_id=name),'unreviewed path')

    def test_strict_schema_types_do_not_broaden(self):
        name=self.install_dwell_fixture()
        for version in [1,True,'2',3]:
            self.dwell['schema_version']=version;self.repin_dwell_fixture();self.assertRejected(preflight.verify(self.repo,overlay_id=name),'schema_version must be exactly 2')

    def test_unrelated_head_index_and_untracked_producer_rejected_without_execution(self):
        name=self.install_dwell_fixture();self.write('README.md',b'forbidden later-tree\n');self.cmd('add','.');self.commit('forbidden unrelated source')
        self.write('explainer/unchanged.py',b'forbidden index\n');self.cmd('add','explainer/unchanged.py');self.write('explainer/unreviewed_producer.py',b'raise RuntimeError("must never import")\n')
        r=preflight.verify(self.repo,overlay_id=name)
        for text in ['Overlay HEAD contains unrelated','Overlay index contains unrelated','unreviewed_producer.py']:self.assertRejected(r,text)

    def test_missing_tampered_data_runtime_model_audio_still_reject(self):
        name=self.install_dwell_fixture();self.cache.unlink();self.audio.write_bytes(b'wrong audio');(self.snapshot/'model.safetensors').unlink()
        with patch.object(preflight.importlib.metadata,'version',return_value='wrong'):
            r=preflight.verify(self.repo,overlay_id=name,strict_external=True,optional_audio=True)
        for text in ['.cache/result.json','.cache/real.wav','model.safetensors','Package torch:']:self.assertRejected(r,text)

    def test_existing_data_symlink_policy_can_reuse_readonly_frozen_bytes(self):
        name=self.install_dwell_fixture();source=self.root/'frozen-input.json';source.write_bytes(self.cache.read_bytes());before=(sha(source.read_bytes()),source.stat().st_mtime_ns,source.stat().st_ino)
        self.cache.unlink();self.cache.symlink_to(source)
        self.assertEqual(preflight.verify(self.repo,overlay_id=name,strict_external=True,optional_audio=True)['errors'],[])
        self.assertEqual((sha(source.read_bytes()),source.stat().st_mtime_ns,source.stat().st_ino),before)
        source.write_bytes(b'tampered reused input')
        self.assertRejected(preflight.verify(self.repo,overlay_id=name),'.cache/result.json')

    def test_source_symlinks_still_reject(self):
        name=self.install_dwell_fixture();source=self.root/'after.py';source.write_bytes(self.dwell_after)
        p=self.repo/preflight.PROBABILITY;p.unlink();p.symlink_to(source)
        self.assertRejected(preflight.verify(self.repo,overlay_id=name),'type mismatch')

class PublishedPolicyPreservationTests(unittest.TestCase):
    def test_verify_body_and_published_v1_to_v6_files_remain_byte_exact(self):
        prep=json.loads((D/'preparation.json').read_text())
        for row in prep['historical_files']:
            raw=Path(row['path']).read_bytes();self.assertEqual((len(raw),sha(raw)),(row['bytes'],row['sha256']))
        def verify_ast(path):return ast.dump(next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='verify'),include_attributes=False)
        self.assertEqual(verify_ast(D/'verify_handoff.py'),verify_ast(D/'historical-before/verify_handoff.py'))
        self.assertNotIn(preflight.NUMERIC_DWELL_OVERLAY,preflight.KNOWN_OVERLAYS)

if __name__=='__main__':unittest.main()
