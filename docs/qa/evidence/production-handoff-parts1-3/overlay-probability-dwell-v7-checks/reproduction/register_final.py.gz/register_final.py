from pathlib import Path
import hashlib,json,gzip,subprocess,datetime,shutil,ast
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;M=R/'docs/qa/evidence/production-handoff-parts1-3';E=R/'docs/qa/evidence/ai1-probability-numeric-dwell-source-repair';ID='part1-probability-numeric-dwell-surprise-roadmap-and-part3-v7';AFTER='5e856dd92a662a8a7f1bfc370e57e0c937722c5e2f9c35e99960e1cfd80724ea';HARD=512*1024**2
h=lambda b:hashlib.sha256(b).hexdigest();assert shutil.disk_usage('/workspace').free>HARD+2*1024**2
required=['README.md','source.patch.gz','file-manifest.json','applied-receipt.json']
assert all((E/n).is_file() for n in required),'Wait/reconcile source-owner final evidence; do not invent pins'
source=R/'videos/ai/ai1/s02_probability.py';raw=source.read_bytes();assert h(raw)==AFTER and len(raw)==25970
patch=(E/'source.patch.gz').read_bytes();plain=gzip.decompress(patch);assert h(patch)=='109ff13454fa1b851a9fdc0e497b915fe6fc667e1fd9a0fa5614eebc51b00d16' and h(plain)=='35eb669e7aa001d5fad63f44f8422cb99e984209fcfc3d7a614325c5426100bd'
for row in json.loads((M/'historical/probability-numeric-dwell-v7-before/preserved-pins.json').read_text())['files']:
 p=R/row['path'];assert p.stat().st_size==row['bytes'] and h(p.read_bytes())==row['sha256']
v6path=M/'overlays/part1-surprise-probability-roadmap-and-part3-v6.json';v6=json.loads(v6path.read_text());manifest=json.loads(json.dumps(v6));manifest['overlay_id']=ID
manifest['scope']='Exactly original base927 plus Hook7230, Probability5e856d numeric-result dwell, Surprise6456, SVD2c01 and Outroe874. Five exact regular source replacements only; no optionalrepository files or laterbranchHEAD. Source permission is controlled narrated-rerender clearance only. Existing source/cache/runtime/publicmodel/audio guards unchanged.'
after=manifest['source_replacements'][1]['after'];after['bytes']=len(raw);after['sha256']=AFTER;after['git_blob']=subprocess.check_output(['git','hash-object','--stdin'],cwd=R,input=raw).decode().strip()
manifest['numeric_dwell_source_patch_identity']=dict(kind='Exact incremental50ff-to5e856d source patch; independent of the laterjointpublication commit',path=str((E/'source.patch.gz').relative_to(R)),compressed_bytes=len(patch),compressed_sha256=h(patch),raw_patch_sha256=h(plain),incremental_before_source_sha256='50ff2a79121a6429eaf30950094d2157e6118d3b390e4544185f27cc44ecf0ed',incremental_after_source_sha256=AFTER)
manifest['production_acceptance'].update(dict(probability_numeric_dwell_source_status='Exact root/source-owner freeze; controlled narrated-rerender source clearance only',probability_numeric_dwell_output_observed=False,probability_numeric_dwell_output_accepted=False,remaining_probability_dwell_gates=['Actual completed numeric-display readability/pacing at productionresolution','Actual narrated bookmark synchronization and listening','Actual rendered output/frame timing and overall duration']))
manifest['numeric_dwell_source_review']=dict(minimum_finished_numeric_hold_seconds=1.5,speech_master_metadata_blocks=11,bookmark_count=18,scope='Actual source-owner source/metadata/phase checks preserve VO/masterIDs/bookmark names; hold may addnon-speech time. No equality of old/new wholemovie durations or actual repaired output/listening is claimed.')
manifest['numeric_dwell_evidence_receipts']=[dict(path=str((E/n).relative_to(R)),bytes=(E/n).stat().st_size,sha256=h((E/n).read_bytes())) for n in required]
manifest['evidence_references']+= [str((E/'README.md').relative_to(R))]
# Preserve exactly the other four substitutions and all originalbase rows.
assert all(manifest['source_replacements'][i]==v6['source_replacements'][i] for i in [0,2,3,4]);assert manifest['source_replacements'][1]['before']==v6['source_replacements'][1]['before'];assert manifest['optional_evidence_files']==[]
mp=M/'overlays'/f'{ID}.json';assert not mp.exists();serialized=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();mp.write_bytes(serialized);pin=h(serialized)
helper=(D/'verify_handoff.py').read_text().replace('# Private policy preparation only: v7 stays unregistered until exact manifest/source clearance.','# V7 accepts only its exact reviewed source/manifest pin; repaired output remains unapproved.')
helper=helper.replace('KNOWN_OVERLAYS = {','KNOWN_OVERLAYS = {\n    NUMERIC_DWELL_OVERLAY: (\'overlays/'+ID+'.json\',\n                            \''+pin+'\'),',1)
helper=helper.replace('or part1-surprise-probability-roadmap-and-part3-v6.','part1-surprise-probability-roadmap-and-part3-v6, or '+ID+'.')
new=ast.parse(helper);old=ast.parse((M/'verify_handoff.py').read_text());bodies=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,ast.FunctionDef) and n.name not in {'load_overlay','main'}};assert bodies(new)==bodies(old)
(M/'verify_handoff.py').write_text(helper)
report=dict(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),overlay_id=ID,overlay_path=str(mp.relative_to(R)),overlay_sha256=pin,helper_sha256=h(helper.encode()),source_sha256=AFTER,source_bytes=len(raw),new_tests_path='tests/test_production_handoff_probability_dwell_overlay.py',new_tests_sha256=h((R/'tests/test_production_handoff_probability_dwell_overlay.py').read_bytes()),schema_version=2,sourcepaths=[x['after']['path'] for x in manifest['source_replacements']],all_other_guard_function_AST_exact=True,actual_repaired_output_accepted=False,free_bytes=shutil.disk_usage('/workspace').free)
(D/'registration.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
