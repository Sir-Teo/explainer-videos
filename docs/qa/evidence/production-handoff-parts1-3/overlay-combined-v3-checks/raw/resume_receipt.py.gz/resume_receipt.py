"""Cloud-only fixture checks; no scenes/producers/model imports or downloads."""
import datetime, hashlib, json, os, pathlib, subprocess, sys
MAIN=pathlib.Path('/workspace/explainer-videos')
OUT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/workspace/runtime/part3-svd-outro-v3-preflight-base927')
D=MAIN/'docs/qa/evidence/production-handoff-parts1-3'
HELPER=D/'verify_handoff.py'
BASE='927fba668656a682b3e29a288de64130ddc680dd'
COMMIT='5fc8eeab34c2c2fe49a6b38ff38629e1512fa7ed'
ID='part3-svd-outro-production-v3'
manifest=json.loads((D/'overlays'/f'{ID}.json').read_text())
preparation=json.loads((OUT/'preparation.json').read_text())
assert REPO.resolve()!=MAIN and REPO.name=='part3-svd-outro-v3-preflight-base927'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,stderr=subprocess.PIPE)
def main_git(*args):return subprocess.check_output(['git',*args],cwd=MAIN,stderr=subprocess.PIPE)
records=json.loads((OUT/'checks-in-progress.json').read_text())
assert len(records)==14 and all(r['expected_pass']==r['actual_pass'] for r in records)
source_commit=records[-1]['head']; rejected_commit=next(r['head'] for r in records if r['name']=='combined-rejects-unrelated-head')
# Verify all copied inputs and read-only original references after every negative.
verified=[]
for row in preparation['copies']:
    # Preparation records use explicit source/destination; tolerate known row keys.
    src=pathlib.Path(row['reference_file'])
    dst=REPO/row['path']
    expected=row['sha256']
    assert src.is_file() and dst.is_file(),row
    assert sha(src.read_bytes())==sha(dst.read_bytes())==expected,row
    assert (src.stat().st_dev,src.stat().st_ino)!=(dst.stat().st_dev,dst.stat().st_ino),row
    verified.append({'path':str(dst.relative_to(REPO)),'sha256':expected,'bytes':dst.stat().st_size,'reference_unchanged':True,'independent_inode':True})
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':BASE,'overlay_id':ID,'overlay_sha256':sha((D/'overlays'/f'{ID}.json').read_bytes()),'helper_sha256':sha(HELPER.read_bytes()),'fixture_source_only_commit':source_commit,'rejected_unrelated_commit':rejected_commit,'target':str(REPO),'checks':records,'orchestration_note':'All14 expected checks completed in initial run; receipt aggregation then stopped on a preparation-record key mismatch. Original wrapper/log preserved. Corrected reference_file/path mapping resumed only reference/hash aggregation; no checks or fixture operations retried.','input_reference_checks':verified,'all_expected_results':True,'copied_inputs_exact_after_negative_checks':True,'final_worktree_status':git('status','--porcelain').decode(),'source_tree_diff':git('diff','--stat',BASE,source_commit).decode(),'scope':'Isolated cloud fixture only, actual 268 file gates; version-negative is explicitly metadata mock. No production scenes/producers/models/render/audio/listening/new narration candidate approval.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('FINAL',len(records),'expected checks; copied inputs',len(verified),'all exact')
