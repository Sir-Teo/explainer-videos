"""Cloud-only fixture checks; no scenes/producers/model imports or downloads."""
import datetime, hashlib, json, os, pathlib, subprocess, sys
MAIN=pathlib.Path('/workspace/explainer-videos')
OUT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/workspace/runtime/part1-surprise-v6-preflight-base927')
D=MAIN/'docs/qa/evidence/production-handoff-parts1-3'
HELPER=D/'verify_handoff.py'
BASE='927fba668656a682b3e29a288de64130ddc680dd'
COMMIT='5fc8eeab34c2c2fe49a6b38ff38629e1512fa7ed'
ID='part1-surprise-probability-roadmap-and-part3-v6'
manifest=json.loads((D/'overlays'/f'{ID}.json').read_text())
preparation=json.loads((OUT/'preparation.json').read_text())
assert REPO.resolve()!=MAIN and REPO.name=='part1-surprise-v6-preflight-base927'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO,stderr=subprocess.PIPE)
def main_git(*args):return subprocess.check_output(['git',*args],cwd=MAIN,stderr=subprocess.PIPE)
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('status','--porcelain')
records=[]
def check(name,expected,overlay=None,version_fixture=False):
    args=[sys.executable,str(HELPER),'--repo',str(REPO),'--strict-external','--optional-audio']
    if overlay:args+=['--overlay',overlay]
    if version_fixture:
        # Deliberate package-version mismatch in metadata only. No runtime package
        # imports or target package/data changes are performed.
        code="import importlib.metadata,runpy,sys; original=importlib.metadata.version; importlib.metadata.version=lambda n: 'fixture-wrong-version' if n=='numpy' else original(n); sys.argv=sys.argv[1:]; runpy.run_path(sys.argv[0],run_name='__main__')"
        args=[sys.executable,'-c',code,*args[1:]]
    run=subprocess.run(args,cwd=MAIN,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (OUT/f'{name}.json').write_bytes(run.stdout)
    (OUT/f'{name}.stderr.txt').write_bytes(run.stderr)
    result=json.loads(run.stdout)
    actual=run.returncode==0 and not result['errors']
    record={'name':name,'expected_pass':expected,'actual_pass':actual,'returncode':run.returncode,'checked_files':result['checked_files'],'errors':result['errors'],'command':args,'result_sha256':sha(run.stdout),'stderr_sha256':sha(run.stderr),'head':git('rev-parse','HEAD').decode().strip()}
    records.append(record)
    (OUT/'checks-in-progress.json').write_text(json.dumps(records,indent=2)+'\n')
    assert actual is expected, record
    print(name, 'PASS' if actual else 'EXPECTED_REJECT',len(result['errors']),flush=True)
check('clean-base-strict',True)
before={}
for row in manifest['source_replacements']:
    p=REPO/row['before']['path'];before[str(p.relative_to(REPO))]=p.read_bytes()
    assert sha(p.read_bytes())==row['before']['sha256']
    value=(MAIN/row['after']['path']).read_bytes()
    assert len(value)==row['after']['bytes'] and sha(value)==row['after']['sha256']
    (OUT/(p.name+'.before')).write_bytes(p.read_bytes())
    (OUT/(p.name+'.after')).write_bytes(value)
    p.write_bytes(value);p.chmod(0o644)
check('exact-five-source-worktree',True,ID)
check('default-rejects-five-source',False)
check('v1-rejects-five-source',False,'svd-reveal-v1')
check('v2-rejects-outro',False,'svd-production-polish-v2')
check('v3-rejects-new-part1-sources',False,'part3-svd-outro-production-v3')
check('v4-rejects-new-probability',False,'part1-roadmap-and-part3-v4')
check('v5-rejects-new-surprise',False,'part1-probability-roadmap-and-part3-v5')
p=REPO/manifest['source_replacements'][2]['after']['path'];good=p.read_bytes();p.write_bytes(before[str(p.relative_to(REPO))])
try:
    check('v6-rejects-missing-surprise',False,ID)
    check('v5-still-accepts-original-four-only',True,'part1-probability-roadmap-and-part3-v5')
finally:p.write_bytes(good)
p=REPO/'.gitignore';good=p.read_bytes();p.write_bytes(good+b'\n# deliberate unrelated cloud fixture change\n')
try:check('combined-rejects-unrelated-source',False,ID)
finally:p.write_bytes(good)
p=REPO/'videos/ai/ai3/unreviewed_fixture_producer.py';assert not p.exists();p.write_text('raise RuntimeError("must never be imported")\n')
try:check('combined-rejects-untracked-producer',False,ID)
finally:(OUT/'unreviewed_fixture_producer.py.rejected').write_bytes(p.read_bytes());p.unlink()
core=json.loads((D/'cache-inventory.json').read_text())['files'][0]
p=REPO/core['path'];good=p.read_bytes();p.write_bytes(good+b'fixture-tamper')
try:check('combined-rejects-tampered-cache',False,ID)
finally:p.write_bytes(good)
hidden=OUT/'temporarily-absent-cache';assert not hidden.exists();p.rename(hidden)
try:check('combined-rejects-missing-cache',False,ID)
finally:hidden.rename(p)
check('combined-rejects-runtime-version-fixture',False,ID,True)
paths=[r['after']['path'] for r in manifest['source_replacements']]
git('add','--',*paths)
git('-c','user.name=Cloud QA fixture','-c','user.email=cloud-qa-fixture@example.invalid','commit','-m','Cloud fixture: exact reviewed Part1 Hook/Probability/Surprise and Part3 SVD/Outro sources only')
source_commit=git('rev-parse','HEAD').decode().strip()
check('exact-five-source-commit',True,ID)
p=REPO/'.gitignore';good=p.read_bytes();p.write_bytes(good+b'\n# deliberate unrelated HEAD fixture\n');git('add','--','.gitignore');git('-c','user.name=Cloud QA fixture','-c','user.email=cloud-qa-fixture@example.invalid','commit','-m','Cloud negative fixture: unrelated HEAD change')
rejected_commit=git('rev-parse','HEAD').decode().strip()
try:check('combined-rejects-unrelated-head',False,ID)
finally:git('checkout','--detach',source_commit)
check('final-source-only-strict',True,ID)
# Verify all copied inputs and read-only original references after every negative.
verified=[]
for row in preparation['copies']:
    # Preparation records use explicit source/destination; tolerate known row keys.
    src=pathlib.Path(row['reference_file'])
    dst=REPO/row['path']
    expected=row['sha256']
    assert src.is_file() and dst.is_file(),row
    assert sha(src.read_bytes())==sha(dst.read_bytes())==expected,row
    assert (src.stat().st_dev,src.stat().st_ino)!=(dst.stat().st_dev,dst.stat().st_ino),row
    verified.append({'path':str(dst.relative_to(REPO)),'sha256':expected,'bytes':dst.stat().st_size,'reference_unchanged':True,'independent_inode':True})
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':BASE,'overlay_id':ID,'overlay_sha256':sha((D/'overlays'/f'{ID}.json').read_bytes()),'helper_sha256':sha(HELPER.read_bytes()),'fixture_source_only_commit':source_commit,'rejected_unrelated_commit':rejected_commit,'target':str(REPO),'checks':records,'input_reference_checks':verified,'all_expected_results':True,'copied_inputs_exact_after_negative_checks':True,'final_worktree_status':git('status','--porcelain').decode(),'source_tree_diff':git('diff','--stat',BASE,source_commit).decode(),'Surprise_repaired_output_acceptance':False,'scope':'Isolated cloud fixture only, source cleared only for controlled Part1 narrated rerender; actual 268 file gates; version-negative is explicitly metadata mock. No production scenes/producers/models/render/audio/listening/new narration candidate approval.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('FINAL',len(records),'expected checks; copied inputs',len(verified),'all exact')
