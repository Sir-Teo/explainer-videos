from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
R=Path('/workspace/explainer-videos');OLD=Path('/workspace/runtime/part3-combined-overlay-v3-checks/preparation.json');O=Path('/workspace/runtime/probability-overlay-v5-final');T=Path('/workspace/runtime/part1-probability-v5-preflight-base927');BASE='927fba668656a682b3e29a288de64130ddc680dd'
assert not T.exists() and not (O/'preparation.json').exists(),'Reconcile uncertain previous preparation first'
old=json.loads(OLD.read_text());O.mkdir(exist_ok=True);need=sum(x['bytes'] for x in old['copies']);free=shutil.disk_usage('/workspace').free;assert free>need+128*1024**2
commands=[]
def run(args,cwd=R,stdin=None):
 p=subprocess.run(['git',*args],cwd=cwd,input=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE);commands.append({'command':['git',*args],'cwd':str(cwd),'returncode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});assert p.returncode==0,commands[-1]
run(['worktree','add','--detach','--no-checkout',str(T),BASE]);run(['sparse-checkout','init','--no-cone'],T);run(['sparse-checkout','set','--no-cone','--stdin'],T,(''.join('/'+p+'\n' for p in old['sparse_paths'])).encode());run(['checkout','--detach',BASE],T)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
rows=[]
for row in old['copies']:
 src=Path(row['reference_file']);dst=T/row['path'];assert sha(src)==row['sha256'];dst.parent.mkdir(parents=True,exist_ok=True);assert not dst.exists();shutil.copy2(src,dst);assert sha(dst)==row['sha256'];assert (src.stat().st_dev,src.stat().st_ino)!=(dst.stat().st_dev,dst.stat().st_ino);rows.append({**row,'independent_inode':True})
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':BASE,'target':str(T),'readonly_reference':old['readonly_reference'],'git_commands':commands,'sparse_paths':old['sparse_paths'],'copied_file_count':len(rows),'copied_bytes':need,'copies':rows,'free_before':free,'free_after':shutil.disk_usage('/workspace').free,'scope':'Fresh independent cloud fixture/cache copies only. No old fixture mutation, producers/models/loads/render/downloads/uploads.'}
(O/'preparation.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ['target','copied_file_count','copied_bytes','free_after']}))
