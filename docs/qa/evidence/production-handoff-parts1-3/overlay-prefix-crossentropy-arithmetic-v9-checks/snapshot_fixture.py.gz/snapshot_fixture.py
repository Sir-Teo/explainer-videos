"""Read-only signatures; external inputs are hashed, never copied or modified."""
import gzip,hashlib,json,os,shutil,stat,subprocess
from pathlib import Path
F=Path('/workspace/runtime/part1-probability-numeric-dwell-v7-base927');P=Path(__file__).parent
assert shutil.disk_usage('/workspace').free>=536870912

def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def metadata(p,follow=True):
 s=p.stat()if follow else p.lstat()
 return {'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'inode':s.st_ino,'nlink':s.st_nlink}
def snapshot():
 regular=[];links=[];dirs=[]
 for p in sorted(F.rglob('*')):
  rel=str(p.relative_to(F))
  if p.is_symlink():
   target=p.resolve(strict=True);links.append({'path':rel,'link_text':os.readlink(p),'link_metadata':metadata(p,False),'target':str(target),'target_metadata':metadata(target),'target_sha256':sha(target)})
  elif p.is_file():regular.append({'path':rel,**metadata(p),'sha256':sha(p)})
  elif p.is_dir():dirs.append({'path':rel,'mode':stat.S_IMODE(p.stat().st_mode),'mtime_ns':p.stat().st_mtime_ns})
 env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
 state={}
 for key,args in [('HEAD',['rev-parse','HEAD']),('status',['status','--porcelain=v1','--untracked-files=all']),('index',['ls-files','--stage','-z'])]:
  state[key]=subprocess.check_output(['git','-C',str(F),*args],env=env).decode()
 return {'fixture':str(F),'regular':regular,'links':links,'directories':dirs,'git':state,'metadata_scope':'mode/mtime_ns/inode/nlink/bytes and hashes; excludes read-driven atime and non-restorable ctime','root_metadata':metadata(F)}
if __name__=='__main__':
 s=snapshot();assert len(s['regular'])==148 and len(s['links'])==156 and s['git']['status']==''
 out=P/'fixture-before.json.gz';out.write_bytes(gzip.compress(json.dumps(s,sort_keys=True).encode(),mtime=0));os.chmod(out,0o600)
 print(json.dumps({'regular':len(s['regular']),'links':len(s['links']),'linked_bytes':sum(x['target_metadata']['bytes']for x in s['links']),'head':s['git']['HEAD'].strip(),'snapshot_bytes':out.stat().st_size,'free':shutil.disk_usage('/workspace').free}))
