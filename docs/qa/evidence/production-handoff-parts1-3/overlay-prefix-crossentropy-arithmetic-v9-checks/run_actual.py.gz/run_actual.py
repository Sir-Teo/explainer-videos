"""Reversible source-only probe with real alternate Git; protected inputs never written."""
from __future__ import annotations
import gzip,hashlib,importlib.util,json,os,shutil,stat,sys,time
from pathlib import Path
from snapshot_fixture import snapshot
P=Path(__file__).parent;R=Path('/workspace/explainer-videos');F=Path('/workspace/runtime/part1-probability-numeric-dwell-v7-base927');G=P/'real-git'
FLOOR=536870912;CAP=1000000
assert shutil.disk_usage('/workspace').free>=FLOOR
assert os.environ.get('CE_SOURCE_AND_GATE_RELEASE')=='root-confirmed'
spec=importlib.util.spec_from_file_location('actual_v9_preflight',R/'docs/qa/evidence/production-handoff-parts1-3/verify_handoff.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
errors=[];overlay=m.load_overlay(m.CROSS_ENTROPY_OVERLAY,errors);assert not errors
rows=m.source_replacements(overlay);assert len(rows)==10
expected_before=json.loads(gzip.decompress((P/'fixture-before.json.gz').read_bytes()))
assert snapshot()==expected_before
restore={}
for row in rows:
 path=row['after']['path'];f=F/path;live=R/path
 assert f.is_file()and not f.is_symlink()and f.resolve()==f and f.resolve().is_relative_to(F.resolve())
 assert f.stat().st_nlink==1 and (f.stat().st_dev,f.stat().st_ino)!=(live.stat().st_dev,live.stat().st_ino)
 raw=f.read_bytes();s=f.stat()
 restore[path]={'raw_hex':raw.hex(),'mode':stat.S_IMODE(s.st_mode),'mtime_ns':s.st_mtime_ns,'atime_ns':s.st_atime_ns}
 raw=(R/path).read_bytes();assert len(raw)==row['after']['bytes']and hashlib.sha256(raw).hexdigest()==row['after']['sha256']
backup=gzip.compress(json.dumps(restore).encode(),mtime=0)
assert sum(x.stat().st_size for x in P.rglob('*')if x.is_file())+len(backup)+25000<CAP,'Private1MB envelope cannot fit backup and bounded receipts; no source mutation'
os.umask(0o077);(P/'source-restore.json.gz').write_bytes(backup)
saved_env={key:os.environ.get(key)for key in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OPTIONAL_LOCKS')}
os.environ.update(GIT_DIR=str(G),GIT_WORK_TREE=str(F),GIT_INDEX_FILE=str(G/'index'),GIT_OPTIONAL_LOCKS='0')
checks=[]
def verify(name,mode,expected):
 assert shutil.disk_usage('/workspace').free>=FLOOR
 r=m.verify(F,overlay_id=mode,strict_external=True,optional_audio=True)
 ok=not r['errors'];assert ok==expected,(name,r['errors'])
 checks.append({'name':name,'overlay':mode,'expected_accept':expected,'accepted':ok,'checked_files':r['checked_files'],'errors':r['errors']})
 # Bounded checkpoint, source restoration remains the outer finally's job.
 (P/'actual-checks-in-progress.json.gz').write_bytes(gzip.compress(json.dumps(checks).encode(),mtime=0))
try:
 for row in rows:
  f=F/row['after']['path'];f.write_bytes((R/row['after']['path']).read_bytes());os.chmod(f,int(row['after']['git_mode'][-3:],8))
 verify('exact-ten-strict',m.CROSS_ENTROPY_OVERLAY,True)
 for mode in [None,'svd-reveal-v1','svd-production-polish-v2',m.COMBINED,m.ROADMAP,m.PROBABILITY_OVERLAY,m.SURPRISE_OVERLAY,m.NUMERIC_DWELL_OVERLAY,m.ENTROPY_PREFIX_OVERLAY]:
  verify('prior-rejects-ten:'+str(mode),mode,False)
 for row in rows:
  path=row['after']['path'];f=F/path;good=f.read_bytes();base=m.git(F,'show',m.BASE+':'+path);assert len(base)==row['before']['bytes']and hashlib.sha256(base).hexdigest()==row['before']['sha256']
  f.write_bytes(base);verify('requires-exact:'+path,m.CROSS_ENTROPY_OVERLAY,False);f.write_bytes(good)
 ce=F/m.CROSS_ENTROPY;good=ce.read_bytes();ce.write_bytes(good+b'# unreviewed actual probe\n');verify('bad-ce-structured-error',m.CROSS_ENTROPY_OVERLAY,False);ce.write_bytes(good)
 prefix=F/m.PREFIX;goodprefix=prefix.read_bytes();oldprefix=gzip.decompress((P/'prefix-v8-after.py.gz').read_bytes())
 assert hashlib.sha256(oldprefix).hexdigest()=='4592ba3674a83dca35bf52455367b32dc1ee8a53df93e27e5676f50387a7e7e8'
 arith=F/m.ARITHMETIC;zh=F/m.AI1_ZH;goodarith=arith.read_bytes();goodzh=zh.read_bytes()
 ce.write_bytes(m.git(F,'show',m.BASE+':'+m.CROSS_ENTROPY));arith.write_bytes(m.git(F,'show',m.BASE+':'+m.ARITHMETIC));zh.write_bytes(m.git(F,'show',m.BASE+':'+m.AI1_ZH))
 verify('v8-rejects-new-prefix-other-added-sources-original',m.ENTROPY_PREFIX_OVERLAY,False)
 prefix.write_bytes(oldprefix);zh.write_bytes(goodzh);verify('v8-rejects-new-zh-other-changes-original',m.ENTROPY_PREFIX_OVERLAY,False)
 zh.write_bytes(m.git(F,'show',m.BASE+':'+m.AI1_ZH));verify('v8-exact-seven-still-accepted-all-new-changes-reverted',m.ENTROPY_PREFIX_OVERLAY,True)
 ce.write_bytes(good);arith.write_bytes(goodarith);zh.write_bytes(goodzh);verify('v9-rejects-old-v8-prefix',m.CROSS_ENTROPY_OVERLAY,False);prefix.write_bytes(goodprefix)
 verify('final-exact-ten-strict',m.CROSS_ENTROPY_OVERLAY,True)
finally:
 for path,saved in restore.items():
  f=F/path;assert not f.is_symlink();f.write_bytes(bytes.fromhex(saved['raw_hex']));os.chmod(f,saved['mode']);os.utime(f,ns=(saved['atime_ns'],saved['mtime_ns']))
 for key,value in saved_env.items():
  if value is None:os.environ.pop(key,None)
  else:os.environ[key]=value
 actual_after=snapshot();assert actual_after==expected_before,'Fixture/source/Git/external-input restoration mismatch'
 after_sha=hashlib.sha256(json.dumps(actual_after,sort_keys=True).encode()).hexdigest()
 before_sha=hashlib.sha256(gzip.decompress((P/'fixture-before.json.gz').read_bytes())).hexdigest()
 assert after_sha==before_sha
 (P/'fixture-after-equals-before.json').write_text(json.dumps({'before_and_after_canonical_snapshot_sha256':after_sha,'full_after_mapping':'byte-identical canonical JSON to decompressed fixture-before.json.gz; not redundantly copied'},indent=2)+'\n')
 (P/'restoration.json').write_text(json.dumps({'all148regular_metadata_hashes_unchanged':True,'all156external_link_and_target_metadata_hashes_unchanged':True,'original_HEAD_index_and_untracked_state_unchanged':True,'directories_modes_mtimes_unchanged':True,'no_numeric_speech_model_target_written':True,'private_real_git_context':json.loads((P/'real-git-preparation.json').read_text())},indent=2)+'\n')
(P/'actual-checks.json.gz').write_bytes(gzip.compress(json.dumps(checks,indent=2).encode(),mtime=0))
print(json.dumps({'checks':len(checks),'all_expected_outcomes':True,'restored':True,'checked_files':checks[0]['checked_files'],'free':shutil.disk_usage('/workspace').free}))
