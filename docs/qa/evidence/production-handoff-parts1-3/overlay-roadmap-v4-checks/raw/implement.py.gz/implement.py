from pathlib import Path
import hashlib,json,subprocess,shutil
R=Path('/workspace/explainer-videos');D=R/'docs/qa/evidence/production-handoff-parts1-3';H=D/'historical/roadmap-v4-before';H.mkdir(parents=True,exist_ok=False)
for p in [D/'verify_handoff.py',D/'README.md',R/'docs/qa/production-handoff-parts1-3.md',R/'tests/test_production_handoff_overlay.py',D/'manifest-combined-part3-v3.json']:
 b=p.read_bytes();old=subprocess.check_output(['git','show','c83e2f6d2dfeab79c4ff4e6aca9896d4d2198fe9:'+str(p.relative_to(R))],cwd=R);assert b==old;(H/p.name).write_bytes(b)
def sha(b):return hashlib.sha256(b).hexdigest()
v3=json.loads((D/'overlays/part3-svd-outro-production-v3.json').read_text());path='videos/ai/ai1/s01_hook.py'
before=subprocess.check_output(['git','show',v3['base_commit']+':'+path],cwd=R);after=(R/path).read_bytes();assert sha(after)=='7230ac4c55882c65ba880133512bbb328a4239f919a1f993544a52e7d272dcf8'
def row(b):return {'path':path,'bytes':len(b),'sha256':sha(b),'git_mode':'100644','git_blob':subprocess.check_output(['git','hash-object','--stdin'],cwd=R,input=b).decode().strip()}
manifest={'schema_version':2,'overlay_id':'part1-roadmap-and-part3-v4','base_commit':v3['base_commit'],'reviewed_patch_commits':{'part1_hook':'03e3ab6eeeac77396e0ffff081f64af945f6c636',**v3['reviewed_patch_commits']},'scope':'Exactly base927 plus Part1 Hook7230 and the same two Part3 visual replacements as immutable v3. Part1 change is a controlled narrated-rerender candidate only, not accepted production output. No other source/evidence/tree changes or new narration candidates allowed; all original cache/runtime/model/audio gates remain strict. Full later commit trees are provenance only and not accepted.','source_replacements':[{'before':row(before),'after':row(after)},*v3['source_replacements']],'optional_evidence_files':[],'production_acceptance':{'part1_hook_source_status':'cleared only for controlled narrated 4K rerender','repaired_part1_output_observed':False,'repaired_part1_output_accepted':False,'remaining_part1_gates':['Actual repaired 4K narrated bookmark/reveal timing and native readability','Playback/listening/synchronization acceptance'],'part3_scope':'Existing SVD/Outro visual source evidence only; no new narrated output approval.'},'unchanged_inputs':'Part1 VO/bookmark/audio/TTS keys and scientific inputs are unchanged; only nonfinal roadmap reveal runtime is capped to next measured bookmark minus one frame. Existing Part3 visual repair source/data/VO identities remain unchanged.','evidence_references':['docs/qa/evidence/ai1-opening-roadmap-narrated-timing-repair/README.md',*v3['evidence_references']],'evidence_receipts':[],'external_supplement_note':{'novels_base_library_file_id':'libfile_f134e147968881918fc96c1c227cdc88','version':0,'scope':'Separately authorized private supplement; not included/duplicated in this source metadata overlay.'}}
for p in [R/'docs/qa/evidence/ai1-opening-roadmap-narrated-timing-repair'/n for n in ['README.md','manifest.json','repair-receipt.json']]:
 b=p.read_bytes();manifest['evidence_receipts'].append({'path':str(p.relative_to(R)),'bytes':len(b),'sha256':sha(b)})
manifest['evidence_receipts']+=v3['evidence_receipts']
p=D/'overlays/part1-roadmap-and-part3-v4.json';p.write_text(json.dumps(manifest,indent=2)+'\n');pin=sha(p.read_bytes())
p=D/'verify_handoff.py';s=p.read_text();s=s.replace("OUTRO = 'videos/ai/ai3/s19_outro.py'","OUTRO = 'videos/ai/ai3/s19_outro.py'\nHOOK = 'videos/ai/ai1/s01_hook.py'\nROADMAP = 'part1-roadmap-and-part3-v4'")
s=s.replace('KNOWN_OVERLAYS = {',f"KNOWN_OVERLAYS = {{\n    ROADMAP: ('overlays/part1-roadmap-and-part3-v4.json',\n              '{pin}'),")
s=s.replace('version = 2 if name == COMBINED else 1','version = 2 if name in (COMBINED, ROADMAP) else 1')
s=s.replace('expected_paths = [SVD, OUTRO] if name == COMBINED else [SVD]',"expected_paths = ([HOOK, SVD, OUTRO] if name == ROADMAP\n                          else [SVD, OUTRO] if name == COMBINED else [SVD])")
s=s.replace('if name == COMBINED:', 'if name in (COMBINED, ROADMAP):')
s=s.replace("label = 'SVD' if after['path'] == SVD else 'Outro'","label = {SVD: 'SVD', OUTRO: 'Outro', HOOK: 'Part1 Hook'}[after['path']]")
s=s.replace('or part3-svd-outro-production-v3.','part3-svd-outro-production-v3, or part1-roadmap-and-part3-v4.')
p.write_text(s)
print(json.dumps({'overlay_sha256':pin,'hook_before':row(before),'hook_after':row(after)},indent=2))
