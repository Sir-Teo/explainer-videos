from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess
R=Path('/workspace/explainer-videos');D=Path(__file__).parent
OLD=Path('/workspace/runtime/part1-probability-numeric-dwell-v7-base927')
T=Path('/workspace/runtime/part1-entropy-prefix-v8-base927');BASE='927fba668656a682b3e29a288de64130ddc680dd';HARD=512*1024**2
assert not T.exists() and not(D/'actual-preparation.json').exists()
assert shutil.disk_usage('/workspace').free>HARD+8*1024**2
def guard():assert shutil.disk_usage('/workspace').free>HARD
def digest(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def state(p):
 s=p.stat();return dict(bytes=s.st_size,sha256=digest(p),mtime_ns=s.st_mtime_ns,inode=s.st_ino,nlink=s.st_nlink,device=s.st_dev,mode=s.st_mode)
commands=[]
def git(where,*args,mutate=False):
 guard();cmd=['git',*args]if mutate else['git','--no-optional-locks',*args]
 p=subprocess.run(cmd,cwd=where,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 commands.append(dict(command=cmd,cwd=str(where),returncode=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode()))
 assert p.returncode==0,commands[-1];return p.stdout
oldgit={str(p):state(p)for p in sorted((OLD/'.git').rglob('*'))if p.is_file()}
links=[]
for p in sorted(OLD.rglob('*')):
 if p.is_symlink():
  assert str(p.relative_to(OLD)).startswith('.cache/')
  links.append({'path':str(p.relative_to(OLD)),'link_target':str(p.readlink()),'original_symlink_inode':p.lstat().st_ino,
                'reference_file':str(p.resolve()),'before':state(p.resolve())})
assert len(links)==156
(D/'old-v7-git-before.json').write_text(json.dumps(oldgit,indent=2)+'\n')
git(R,'clone','--shared','--no-hardlinks','--no-checkout',str(R),str(T),mutate=True)
git(T,'sparse-checkout','init','--no-cone',mutate=True)
sparse=(OLD/'.git/info/sparse-checkout').read_bytes()
p=subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=T,input=sparse,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
assert p.returncode==0,p.stderr.decode();commands.append(dict(command=['git','sparse-checkout','set','--no-cone','--stdin'],returncode=p.returncode))
git(T,'checkout','--detach',BASE,mutate=True)
for row in links:
 guard();target=T/row['path'];target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists()and not target.is_symlink()
 target.symlink_to(row['reference_file']);assert state(target)==row['before']
assert git(T,'status','--porcelain')==b''
assert{str(p):state(p)for p in sorted((OLD/'.git').rglob('*'))if p.is_file()}==oldgit
assert all(state(Path(x['reference_file']))==x['before']for x in links)
guard()
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':BASE,'target':str(T),
 'original_fixture':str(OLD),'old_git_files':oldgit,'links':links,'reused_input_count':156,
 'reused_input_logical_bytes':sum(x['before']['bytes']for x in links),'new_data_copy_bytes':0,
 'git_policy':'New independent Git metadata with read-only alternates; old fixture Git untouched.',
 'commands':commands,'free_after_bytes':shutil.disk_usage('/workspace').free,'hardstop_bytes':HARD}
(D/'actual-preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k]for k in ['target','reused_input_count','reused_input_logical_bytes','new_data_copy_bytes','free_after_bytes']},indent=2))
