from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;M=R/'docs/qa/evidence/production-handoff-parts1-3'
assert shutil.disk_usage(R).free>=512*1024**2
old=(D/'historical-before/0-verify_handoff.py').read_text()
assert hashlib.sha256(old.encode()).hexdigest()=='6362af754a9b42dd06a3c1b7f2665929f94ae35fc64f6ea19ca175affd0bcb25'
new=old.replace("NUMERIC_DWELL_OVERLAY =", "ENTROPY = 'videos/ai/ai1/s04_entropy.py'\nPREFIX = 'videos/ai/ai1/s05_prefix.py'\nENTROPY_PREFIX_OVERLAY = 'part1-entropy-prefix-timing-and-part3-v8'\n# v8 policy remains private/unregistered until the exact source/evidence freeze.\nNUMERIC_DWELL_OVERLAY =",1)
new=new.replace('(COMBINED, ROADMAP, PROBABILITY_OVERLAY, SURPRISE_OVERLAY, NUMERIC_DWELL_OVERLAY)',
                '(COMBINED, ROADMAP, PROBABILITY_OVERLAY, SURPRISE_OVERLAY, NUMERIC_DWELL_OVERLAY, ENTROPY_PREFIX_OVERLAY)')
new=new.replace("expected_paths = ([HOOK, PROBABILITY, SURPRISE, SVD, OUTRO]", "expected_paths = ([HOOK, PROBABILITY, SURPRISE, ENTROPY, PREFIX, SVD, OUTRO] if name == ENTROPY_PREFIX_OVERLAY\n                          else [HOOK, PROBABILITY, SURPRISE, SVD, OUTRO]")
new=new.replace("PROBABILITY: 'Part1 Probability', SURPRISE: 'Part1 Surprise'}[after['path']]",
                "PROBABILITY: 'Part1 Probability', SURPRISE: 'Part1 Surprise',\n                     ENTROPY: 'Part1 Entropy', PREFIX: 'Part1 Prefix'}[after['path']]")
new=new.replace("or part1-probability-numeric-dwell-surprise-roadmap-and-part3-v7.'", "part1-probability-numeric-dwell-surprise-roadmap-and-part3-v7, or part1-entropy-prefix-timing-and-part3-v8.'")
ast.parse(new)
(D/'verify_handoff.py').write_text(new)
(D/'policy-only.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before-v8/verify_handoff.py',tofile='private-v8/verify_handoff.py')))
ot={x.name:ast.dump(x,include_attributes=False)for x in ast.parse(old).body if isinstance(x,ast.FunctionDef)}
nt={x.name:x for x in ast.parse(new).body if isinstance(x,ast.FunctionDef)}
target=nt['overlay_tree_checks'];labels=[n for n in ast.walk(target)if isinstance(n,ast.Assign)and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)and n.targets[0].id=='label']
assert len(labels)==1 and isinstance(labels[0].value,ast.Subscript)and isinstance(labels[0].value.value,ast.Dict)
mapping=labels[0].value.value;extras=[(k,v)for k,v in zip(mapping.keys,mapping.values)if isinstance(k,ast.Name)and k.id in ('ENTROPY','PREFIX')]
assert [(k.id,v.value)for k,v in extras]==[('ENTROPY','Part1 Entropy'),('PREFIX','Part1 Prefix')]
keep=[(k,v)for k,v in zip(mapping.keys,mapping.values)if not(isinstance(k,ast.Name)and k.id in ('ENTROPY','PREFIX'))]
mapping.keys=[x[0]for x in keep];mapping.values=[x[1]for x in keep]
for name,node in nt.items():
 if name not in ('load_overlay','main'):assert ast.dump(node,include_attributes=False)==ot[name],name
(D/'private-policy-check.json').write_text(json.dumps({'registered':False,'new_manifest_created':False,
 'old_helper_sha256':hashlib.sha256(old.encode()).hexdigest(),'private_helper_sha256':hashlib.sha256(new.encode()).hexdigest(),
 'unchanged_full_verify_and_guard_AST_except_exact_diagnostic_dispatch':True,
 'diagnostic_only_additions':{'ENTROPY':'Part1 Entropy','PREFIX':'Part1 Prefix'},'source_files_edited':False},indent=2)+'\n')
print('private unregistered policy ready; guard AST exact after strict two-entry normalization')
