"""Actual strict hash gates on a new source-only fixture; no data/model loads."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys
D=Path(__file__).parent;R=Path('/workspace/explainer-videos');M=R/'docs/qa/evidence/production-handoff-parts1-3'
T=Path('/workspace/runtime/part1-entropy-prefix-v8-base927');ID='part1-entropy-prefix-timing-and-part3-v8'
V7='part1-probability-numeric-dwell-surprise-roadmap-and-part3-v7';BASE='927fba668656a682b3e29a288de64130ddc680dd';HARD=512*1024**2
assert not(D/'actual-checks-receipt.json').exists()and not(D/'actual-checks-progress.json').exists()
prep=json.loads((D/'actual-preparation.json').read_text());overlay=json.loads((M/'overlays'/f'{ID}.json').read_text());checks=[];commands=[]
def guard():
 free=shutil.disk_usage('/workspace').free;assert free>HARD+1024**2,free;return free
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def state(p):
 s=p.stat();return dict(bytes=s.st_size,sha256=sha(p),mtime_ns=s.st_mtime_ns,inode=s.st_ino,nlink=s.st_nlink,device=s.st_dev,mode=s.st_mode)
def git(*args):
 guard();p=subprocess.run(['git',*args],cwd=T,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 commands.append(dict(command=['git',*args],returncode=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode()));assert p.returncode==0,commands[-1];return p.stdout
assert git('rev-parse','HEAD').decode().strip()==BASE and git('status','--porcelain')==b''
external=json.loads((M/'external-validation-dependencies.json').read_text())
hub=Path(os.environ.get('HF_HUB_CACHE',str(Path(os.environ['HF_HOME'])/'hub')))
public_before={str(hub/x['snapshot_relative_path']):state(hub/x['snapshot_relative_path'])for x in external['gpt2']['files']}
for row in prep['links']:assert state(Path(row['reference_file']))==row['before']
def check(name,expected,mode=None,*,wrong_version=False,empty_hub=False):
 free=guard();args=[sys.executable,'-B',str(M/'verify_handoff.py'),'--repo',str(T),'--strict-external','--optional-audio']
 if mode:args+=['--overlay',mode]
 if wrong_version:
  code="import importlib.metadata,runpy,sys;old=importlib.metadata.version;importlib.metadata.version=lambda n:'wrong-runtime-fixture'if n=='numpy'else old(n);sys.argv=sys.argv[1:];runpy.run_path(sys.argv[0],run_name='__main__')"
  args=[sys.executable,'-B','-c',code,*args[2:]]
 env=os.environ.copy()
 if empty_hub:env['HF_HUB_CACHE']=str(D/'deliberately-absent-model-context')
 proc=subprocess.run(args,cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (D/(name+'.json')).write_bytes(proc.stdout);(D/(name+'.stderr.txt')).write_bytes(proc.stderr)
 result=json.loads(proc.stdout);passed=proc.returncode==0 and not result['errors']
 row=dict(name=name,expected_pass=expected,actual_pass=passed,returncode=proc.returncode,
          checked_files=result['checked_files'],errors=result['errors'],command=args,
          stdout_sha256=hashlib.sha256(proc.stdout).hexdigest(),stderr_sha256=hashlib.sha256(proc.stderr).hexdigest(),
          deliberate_runtime_fixture=wrong_version,deliberately_absent_model_context=empty_hub,
          free_before=free,free_after=guard())
 checks.append(row);(D/'actual-checks-progress.json').write_text(json.dumps(checks,indent=2)+'\n')
 assert passed is expected,row;print(name,'PASS'if passed else'EXPECTED_REJECT',result['checked_files'],flush=True)
check('v8-clean-base-strict',True)
for row in overlay['source_replacements']:
 p=T/row['before']['path'];assert p.is_file()and not p.is_symlink()and sha(p)==row['before']['sha256']
 raw=(R/row['after']['path']).read_bytes();assert(len(raw),hashlib.sha256(raw).hexdigest())==(row['after']['bytes'],row['after']['sha256'])
 p.write_bytes(raw);p.chmod(0o644)
check('v8-exact-seven-worktree',True,ID)
for label,mode in [('default',None),('v1','svd-reveal-v1'),('v2','svd-production-polish-v2'),
 ('v3','part3-svd-outro-production-v3'),('v4','part1-roadmap-and-part3-v4'),
 ('v5','part1-probability-roadmap-and-part3-v5'),('v6','part1-surprise-probability-roadmap-and-part3-v6'),('v7',V7)]:
 check('v8-'+label+'-rejects-new-two',False,mode)
newpaths=['videos/ai/ai1/s04_entropy.py','videos/ai/ai1/s05_prefix.py'];after={p:(T/p).read_bytes()for p in newpaths}
for path in newpaths:
 p=T/path;p.write_bytes(git('show',BASE+':'+path))
 check('v8-rejects-old-'+p.stem,False,ID);p.write_bytes(after[path])
for path in newpaths:(T/path).write_bytes(git('show',BASE+':'+path))
check('v8-v7-retains-exact-five-scope',True,V7);check('v8-rejects-both-old-new-paths',False,ID)
for path in newpaths:(T/path).write_bytes(after[path])
for path in newpaths:
 p=T/path;target=D/(p.stem+'-independent-link-target.py');target.write_bytes(after[path]);p.unlink();p.symlink_to(target)
 try:check('v8-rejects-source-symlink-'+p.stem,False,ID)
 finally:p.unlink();p.write_bytes(after[path])
p=T/'videos/ai/ai1/s06_huffman.py';original=p.read_bytes();p.write_bytes(original+b'\n# unrelatedHuffmanfixture\n')
try:check('v8-rejects-Huffman',False,ID)
finally:p.write_bytes(original)
p=T/'videos/ai/ai7/unreviewed_v8_producer.py';assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text('raise RuntimeError("must never import")\n')
try:check('v8-rejects-untracked-producer',False,ID)
finally:p.unlink()
p=T/'README.md';original=p.read_bytes();p.write_bytes(original+b'\nUnrelatedfixture\n')
try:check('v8-rejects-unrelated-worktree',False,ID)
finally:p.write_bytes(original)
# Only new symlinks are changed; old frozen payload targets remain untouched.
first=json.loads((M/'cache-inventory.json').read_text())['files'][0]['path'];p=T/first;assert p.is_symlink();target=os.readlink(p);p.unlink()
try:
 check('v8-rejects-missing-data-link',False,ID);p.write_bytes(b'independent wrong tiny input');check('v8-rejects-independent-tampered-input',False,ID)
finally:
 if p.exists()or p.is_symlink():p.unlink()
 p.symlink_to(target)
audio=json.loads((M/'real-information-audio.json').read_text())['blocks'][0]['files'][0]['path'];p=T/audio;assert p.is_symlink();target=os.readlink(p);p.unlink()
try:check('v8-rejects-missing-optional-audio',False,ID)
finally:p.symlink_to(target)
check('v8-rejects-runtime-version',False,ID,wrong_version=True)
check('v8-rejects-absent-public-model-context',False,ID,empty_hub=True)
paths=[x['after']['path']for x in overlay['source_replacements']]
git('add','--',*paths);git('-c','user.name=Cloud QA fixture','-c','user.email=qa@example.invalid','commit','--quiet','-m','Fixture exact approved seven-source entropy-prefix timing overlay')
source_commit=git('rev-parse','HEAD').decode().strip();check('v8-exact-seven-source-commit',True,ID)
p=T/'README.md';original=p.read_bytes();p.write_bytes(original+b'\nUnrelatedindexfixture\n');git('add','--','README.md')
try:check('v8-rejects-unrelated-index',False,ID)
finally:git('restore','--staged','README.md');p.write_bytes(original)
p.write_bytes(original+b'\nUnrelatedHEADfixture\n');git('add','--','README.md');git('-c','user.name=Cloud QA fixture','-c','user.email=qa@example.invalid','commit','--quiet','-m','Fixture unreviewed unrelated HEAD')
rejected_commit=git('rev-parse','HEAD').decode().strip()
try:check('v8-rejects-unrelated-HEAD',False,ID)
finally:git('checkout','--detach',source_commit)
check('v8-final-strict-seven-source',True,ID)
assert all(state(Path(x['reference_file']))==x['before']and(T/x['path']).is_symlink()and str((T/x['path']).readlink())==x['reference_file']for x in prep['links'])
OLD=Path(prep['original_fixture']);oldgit={str(p):state(p)for p in sorted((OLD/'.git').rglob('*'))if p.is_file()};assert oldgit==prep['old_git_files']
assert all(state(Path(p))==st for p,st in public_before.items())
record={'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'overlay_id':ID,
 'helper_sha256':sha(M/'verify_handoff.py'),'overlay_sha256':sha(M/'overlays'/f'{ID}.json'),
 'actual_checks':len(checks),'all_expected_results':True,'checks':checks,
 'final_strict_file_checks':checks[-1]['checked_files'],'source_only_fixture_commit':source_commit,
 'rejected_unrelated_commit':rejected_commit,'original_156_payloads_and_link_targets_exact':True,
 'original_v7_fixture_Git_files_exact':True,'public_model_files_exact':True,'public_model_witnesses':public_before,
 'old_git_after':oldgit,'new_data_copy_bytes':0,'new_source_context':str(T),'git_commands':commands,
 'guard_minimum_bytes':HARD,'free_after_bytes':guard(),'final_worktree_status':git('status','--porcelain').decode(),
 'scope':'Actual read-only source/cache/runtime/model-file/audio-file preflight on a new fixture. No model/producer imports, normal data loads, render, synth, decode or download. Source clearance only; repaired production output/readability/listening unapproved.'}
assert record['final_strict_file_checks']==268 and record['final_worktree_status']==''
(D/'actual-checks-receipt.json').write_text(json.dumps(record,indent=2)+'\n');print('FINAL',len(checks),'expected outcomes;268files;156oldinputs+oldGit+modelwitnesses exact',flush=True)
