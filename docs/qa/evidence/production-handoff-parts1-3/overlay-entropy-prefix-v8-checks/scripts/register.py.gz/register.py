from pathlib import Path
import ast,copy,datetime,hashlib,json,shutil,subprocess
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;M=R/'docs/qa/evidence/production-handoff-parts1-3'
ID='part1-entropy-prefix-timing-and-part3-v8';BASE='927fba668656a682b3e29a288de64130ddc680dd'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert shutil.disk_usage(R).free>=512*1024**2
assert not(M/'overlays'/f'{ID}.json').exists()
prior=json.loads((D/'preserved-pins.json').read_text());history=M/'historical/entropy-prefix-v8-before';assert not history.exists();history.mkdir(parents=True)
preserved=[]
for row in prior['files']:
 raw=(D/row['private_copy']).read_bytes();assert(len(raw),sha(raw))==(row['bytes'],row['sha256'])
 assert(R/row['path']).read_bytes()==raw
 target=history/Path(row['path']).name
 if '/overlays/'in row['path']:target=history/'overlays'/Path(row['path']).name
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
 preserved.append({**{k:v for k,v in row.items()if k!='private_copy'},'historical_path':str(target.relative_to(R))})
(history/'preserved-pins.json').write_text(json.dumps({'source_gate_commit':prior['source_gate_commit'],'files':preserved},indent=2)+'\n')
v7=json.loads((M/'overlays/part1-probability-numeric-dwell-surprise-roadmap-and-part3-v7.json').read_text())
v8=copy.deepcopy(v7);v8['overlay_id']=ID
v8['scope']='Exactly base927 plus SEVEN exact regular source replacements: Hook7230,Probability5e,Surprise6456,Entropy338c,Prefix4592,SVD2c01,Outroe874. Controlled narrated-rerender source clearance only. No Huffman,wholeP7HEAD,extra files,data/audio/runtime exemptions or output approval.'
receipt_dir=R/'docs/qa/evidence/ai1-entropy-prefix-narrated-timing-repair'
repair=json.loads((receipt_dir/'repair-receipt.json').read_text())
expected={'Entropy':('338c43429a0087d9cbba25e945bba2dfbad09fd40afeb2eef9f7ce68c62dcc49',30806),
          'Prefix':('4592ba3674a83dca35bf52455367b32dc1ee8a53df93e27e5676f50387a7e7e8',24707)}
add=[]
for source in repair['source_changes']:
 name=source['path'];after=(R/name).read_bytes();before=subprocess.check_output(['git','show',BASE+':'+name],cwd=R)
 assert(sha(after),len(after))==expected[source['scene']]
 assert(sha(before),len(before))==(source['before_sha256'],source['before_bytes'])
 row=lambda raw:{'path':name,'bytes':len(raw),'sha256':sha(raw),'git_mode':'100644',
                 'git_blob':subprocess.check_output(['git','hash-object','--stdin'],cwd=R,input=raw).decode().strip()}
 add.append({'before':row(before),'after':row(after)})
v8['source_replacements'][3:3]=add
v8['optional_evidence_files']=[]
v8['production_acceptance'].update(entropy_repaired_output_observed=False,entropy_repaired_output_accepted=False,
    prefix_repaired_output_observed=False,prefix_repaired_output_accepted=False,
    entropy_prefix_source_status='Exact source-owner/root-reviewed timing repair; controlled narrated rerender only',
    remaining_entropy_prefix_gates=repair['remaining_gates'])
v8['entropy_prefix_source_review']={k:repair[k]for k in ['focused_tests','observed_original_late_seconds','phase_proof','short_motion_stages','adapter_contract','invariants','scope']}
evidence=['README.md','repair-receipt.json','file-manifest.json','entropy-source.patch.gz','prefix-source.patch.gz']
v8['entropy_prefix_evidence_receipts']=[{'path':str((receipt_dir/name).relative_to(R)),
    'bytes':(receipt_dir/name).stat().st_size,'sha256':sha((receipt_dir/name).read_bytes())}for name in evidence]
v8['entropy_prefix_evidence_receipts'].append(repair['new_test'])
v8['evidence_references'].append(str((receipt_dir/'README.md').relative_to(R)))
v8['registration_history']='Original v1-v7 overlay manifests/inventories and prior test files remain unchanged except the explicitly versioned v7 AST-comparison test normalization. Original v7 test/helper/docs bytes preserved before-v8. Exactly two diagnostic labeldict entries added; fullverify and acceptance guards unchanged.'
raw=(json.dumps(v8,indent=2)+'\n').encode();(M/'overlays'/f'{ID}.json').write_bytes(raw)
candidate=(D/'verify_handoff.py').read_text()
candidate=candidate.replace('# v8 policy remains private/unregistered until the exact source/evidence freeze.',
                          '# V8 authorizes only its exact seven-source controlled-rerender manifest; no output approval.')
candidate=candidate.replace('KNOWN_OVERLAYS = {',"KNOWN_OVERLAYS = {\n    ENTROPY_PREFIX_OVERLAY: ('overlays/"+ID+".json',\n                             '"+sha(raw)+"'),",1)
ast.parse(candidate);(M/'verify_handoff.py').write_text(candidate)
test=R/'tests/test_production_handoff_entropy_prefix_overlay.py';assert not test.exists();test.write_bytes((D/'test_entropy_prefix_overlay.py').read_bytes())
oldtest=R/'tests/test_production_handoff_probability_dwell_overlay.py';old=oldtest.read_text();tree=ast.parse(old)
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='NumericDwellReviewedManifestTests')
method=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name=='test_full_verify_and_other_guard_bodies_unchanged')
newmethod='''    def test_full_verify_and_other_guard_bodies_unchanged(self):
        old=D/'historical/probability-numeric-dwell-v7-before/verify_handoff.py'
        def bodies(path):
            nodes={n.name:n for n in ast.parse(path.read_text()).body
                   if isinstance(n,ast.FunctionDef) and n.name not in {'load_overlay','main'}}
            if path==D/'verify_handoff.py':
                # V8 adds diagnostic labels only. Require exactly these pairs
                # at the existing label lookup, then compare every guard AST.
                fn=nodes['overlay_tree_checks']
                labels=[n for n in ast.walk(fn) if isinstance(n,ast.Assign)
                        and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)
                        and n.targets[0].id=='label']
                self.assertEqual(len(labels),1)
                value=labels[0].value
                self.assertIsInstance(value,ast.Subscript)
                self.assertIsInstance(value.value,ast.Dict)
                self.assertEqual(ast.dump(value.slice,include_attributes=False),
                                 ast.dump(ast.parse("after['path']",mode='eval').body,include_attributes=False))
                mapping=value.value
                additions=[(k,v) for k,v in zip(mapping.keys,mapping.values)
                           if isinstance(k,ast.Name) and k.id in {'ENTROPY','PREFIX'}]
                self.assertEqual([(k.id,ast.dump(v,include_attributes=False)) for k,v in additions],
                                 [('ENTROPY',ast.dump(ast.Constant(value='Part1 Entropy'),include_attributes=False)),
                                  ('PREFIX',ast.dump(ast.Constant(value='Part1 Prefix'),include_attributes=False))])
                self.assertEqual(len(mapping.keys),7)
                keep=[(k,v) for k,v in zip(mapping.keys,mapping.values)
                      if not(isinstance(k,ast.Name) and k.id in {'ENTROPY','PREFIX'})]
                mapping.keys=[k for k,v in keep];mapping.values=[v for k,v in keep]
            return {name:ast.dump(n,include_attributes=False) for name,n in nodes.items()}
        self.assertEqual(bodies(old),bodies(D/'verify_handoff.py'))
'''
lines=old.splitlines(True);lines[method.lineno-1:method.end_lineno]=[newmethod];updated=''.join(lines);ast.parse(updated);oldtest.write_text(updated)
reason='''\n\n### Explicit v8 controlled-rerender gate\n\n`--overlay part1-entropy-prefix-timing-and-part3-v8` permits exactly base927 plus seven pinned regular source files: Hook7230, Probability5e, Surprise6456, Entropy338c, Prefix4592, SVD2c01, Outroe874. No Huffman, Part7 HEAD, extra repository paths or data/runtime/model/audio exemptions are authorized. Existing default/no-overlay behavior and v1–v7 manifests retain their scopes; v7 remains the unchanged five-source option.\n\nEntropy/Prefix source clearance follows actual supplied word clocks and frame-phase tests plus constructor checks; it authorizes controlled rerender only. Short Entropy motions request approximately0.179/0.306/0.221seconds, with retained settled proof state at least2.1507seconds in the clock probe. No repaired encoded output, actual readability/listening/sync or production acceptance is claimed.\n\nThe verifier adds only two diagnostic labels for the new source paths beyond explicit v8 manifest dispatch. Its fullverify and all acceptance guards are unchanged. The existing v7 AST-comparison test is deliberately revised to require those exact two dictionary pairs at the exact existing label assignment, remove only those pairs, and compare every remaining guard AST. Its original bytes and prior helper/docs/manifests/tests are preserved under `historical/entropy-prefix-v8-before/`; current v7 test bytes are therefore explicitly not called unchanged. Other old tests/manifests/inventories remain byte-exact.\n'''
for p in [M/'README.md',R/'docs/qa/production-handoff-parts1-3.md']:
 with p.open('a')as f:f.write(reason)
registration={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'overlay_id':ID,'overlay_sha256':sha(raw),
 'helper_sha256':sha((M/'verify_handoff.py').read_bytes()),'new_test_sha256':sha(test.read_bytes()),
 'v7_test_before_sha256':sha(old.encode()),'v7_test_after_sha256':sha(updated.encode()),
 'source_only':True,'prior_manifests_unchanged':True,'actual_checks':'pending source-only fixture; no render'}
(D/'registration.json').write_text(json.dumps(registration,indent=2)+'\n');print(json.dumps(registration,indent=2))
