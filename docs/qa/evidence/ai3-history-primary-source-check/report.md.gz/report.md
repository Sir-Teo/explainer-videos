# Part 3 bounded primary-source history review

Bounded primary-source attribution/date/quote check of twenty central Part3 claims in nine source/doc files. No scene/data/model/render mutations. Source-defined captions and README were inspected; no new rendered playback review in this task.

One concrete overstatement required correction: the GaLore scene described completed 7B pretraining on one 24 GB GPU. The original paper reports the completed 150K-step run on 64 A100 GPUs and separately establishes approximately 22 GB memory feasibility for a small per-device token batch. This was reported to the parent before editing; the subsequently authorized bounded repair is recorded separately. The source snapshot here remains the pre-repair record.

Publication years were distinguished from online migration dates, conference years and preprint dates. Exact Firth wording is confirmed in the original scan. This is a sampled historical check, not certification of every reference or priority claim.

| Claim | Assessment | Repository reference | Primary evidence |
|---|---|---|---|
| harris1954 | supported | s13_words.py:38–40,50–51; README.md:63,139 | [harris](https://www.tandfonline.com/doi/abs/10.1080/00437956.1954.11659520) |
| firth1957 | supported | s13_words.py:41–42,51; s01_hook.py:179,196–197; README.md:18,63,139 | [firth](https://languagelog.ldc.upenn.edu/myl/Firth1957.pdf) |
| lsa1990 | supported | s13_words.py:43–45,52–54; s09_lowrank.py:260–262; README.md:18,63,139–140 | [lsa](https://www.microsoft.com/en-us/research/publication/indexing-by-latent-semantic-analysis/) |
| power1929 | partially verified | s07_power.py:182–183,196; README.md:41–42,129–130 | [power1929](https://onlinelibrary.wiley.com/doi/10.1002/zamm.19290090105) |
| pagerank1998 | supported | s07_power.py:184–186,196–197; README.md:42 | [pagerank](https://snap.stanford.edu/class/cs224w-readings/Brin98Anatomy.pdf) |
| spectral2018 | supported | s07_power.py:187–189,197–198; README.md:42,135 | [spectral](https://arxiv.org/abs/1802.05957) |
| beltrami1873 | supported | s08_svd.py:97–99,119–120; README.md:17,125 | [beltrami](https://www-users.cse.umn.edu/~boley/publications/papers/Beltrami.pdf) |
| jordan1874 | metadata verified | s08_svd.py:97–99,119–120; README.md:17,125 | [jordan](https://www.numdam.org/item/JMPA_1874_2_19__35_0/) |
| hook_svd_anchor | qualification | s01_hook.py:176; s08_svd.py:97–99; README.md:17 | [beltrami](https://www-users.cse.umn.edu/~boley/publications/papers/Beltrami.pdf), [jordan](https://www.numdam.org/item/JMPA_1874_2_19__35_0/) |
| schmidt1907 | metadata verified | s08_svd.py:98; s09_lowrank.py:85; README.md:125 | [schmidt](https://link.springer.com/article/10.1007/BF01449770) |
| golubkahan1965 | supported | s08_svd.py:98–99,119–120; README.md:130 | [golubkahan](https://epubs.siam.org/doi/abs/10.1137/0702016) |
| eckartyoung1936 | supported | s09_lowrank.py:60,69,83–85; s01_hook.py:178; README.md:18,46,130 | [eckartyoung](https://www.cambridge.org/core/journals/psychometrika/article/abs/approximation-of-one-matrix-by-another-of-lower-rank/B29672E1EDD0FA1B7611D4DFAFC321B3) |
| mp1967 | supported | s11_spectra.py:36–41,63; README.md:55,132 | [mp](https://www.mathnet.ru/eng/msb4101) |
| jl1984 | metadata verified | s16_jl.py:116–121,127; s01_hook.py:180; README.md:18,145 | [jl1984](https://www.ams.org/conm/026/), [dg](https://cseweb.ucsd.edu/~dasgupta/papers/jl.pdf) |
| dg2003 | supported with qualification | s16_jl.py:116–127; README.md:145–146 | [dg](https://cseweb.ucsd.edu/~dasgupta/papers/jl.pdf) |
| ln2017 | supported with qualification | s16_jl.py:277–279,285–286; README.md:80–81,146–147 | [ln](https://arxiv.org/abs/1609.02094) |
| lora2021 | supported | s09_lowrank.py:263–265,274–275; s01_hook.py:184; s12_galore.py:274; README.md:19,135 | [lora](https://arxiv.org/abs/2106.09685) |
| galore2024 | supported | s12_galore.py:139,163; s01_hook.py:185; README.md:19,60,135–136 | [galore](https://proceedings.mlr.press/v235/zhao24s.html) |
| galore_memory | supported | s12_galore.py:140,168 | [galore](https://proceedings.mlr.press/v235/zhao24s.html) |
| galore_24gb | contradiction overstatement | s12_galore.py:140–142,168–169 | [galore](https://proceedings.mlr.press/v235/zhao24s.html) |

## Precise assessments

### harris1954

Harris (1954): words in similar contexts tend to have similar meanings.

The original meaning/distribution correlation and synonym examples support this cautious paraphrase.

### firth1957

Firth (1957): “You shall know a word by the company it keeps.”

The exact ten-word quotation appears on printed page 11. The caption omits the original exclamation mark; the words are unchanged.

### lsa1990

Deerwester, Dumais and colleagues (1990): term/document SVD for semantic retrieval.

The coauthor page and manuscript support the year, attribution, SVD and retrieval beyond literal shared query terms.

Limits: Car/automobile is an illustrative synonym example; the scene does not claim that this exact pair came from the paper.

### power1929

The power method is from 1929, by von Mises and Pollaczek-Geiringer.

Original publisher records support the joint two-part 1929 work. A publication date does not establish first invention.

Limits: Exclusive-origin wording remains unverified. An earlier Müntz (1913) lead was discovered through secondary sources, but the original Gallica scan was inaccessible. No primary-backed contradiction is asserted.

### pagerank1998

Brin and Page (1998): PageRank is a principal eigenvector, found iteratively.

The original paper, section 2.1.1, explicitly connects iterative computation with the principal eigenvector.

Limits: The matrix is normalized and damped, rather than raw adjacency. The scene uses high-level link-matrix shorthand; the paper formula was checked.

### spectral2018

Miyato and colleagues (2018): spectral normalization uses one power round per training step.

The ICLR 2018 paper explains recycling vectors across weight updates and using one round in its experiments.

Limits: This is a practical approximation with recycled state, rather than a universal exact one-step spectral-norm guarantee.

### beltrami1873

Beltrami (1873): bilinear canonical reduction underlying the SVD.

The translator-hosted primary work reproduces the 1873 volume title and distinct orthogonal substitutions reducing a bilinear form to paired canonical terms.

Limits: The English 1990 translation was inspected. The original Italian scan and every modern rectangular formulation were not checked.

### jordan1874

Jordan (1874): bilinear-form SVD attribution.

The official journal archive identifies the 1874 memoir, pages 35–54.

Limits: The linked original body could not be fetched. Independent discovery and priority are not certified by this bounded check.

### hook_svd_anchor

The Hook uses one 1873 timeline anchor for Beltrami and Jordan; the detailed scene and README say 1873–1874.

The detailed dates agree with the inspected records. The single anchor compresses a two-year span.

Limits: An optional 1873–1874 display clarification would improve consistency. This is not promoted as a false chronology: Jordan also has earlier bilinear-form notes outside this inspected sample.

### schmidt1907

Schmidt (1907): the corresponding integral-operator result.

The original publisher identifies the 1907 integral-equation paper and its exact volume and pages.

Limits: The subscription preview does not verify the full infinite-dimensional proof or priority. Those bodies remain unchecked.

### golubkahan1965

Golub and Kahan (1965): a stable SVD algorithm.

The original abstract describes unitary factors through bidiagonalization and diagonalization; the 1965 publication year matches.

Limits: The broad “computers still use” wording concerns algorithmic lineage. It is not a verified statement about every modern library or SVD driver.

### eckartyoung1936

Eckart and Young (1936): best lower-rank least-squares approximation.

The original publisher record and abstract match the authors, 1936 date and lower-rank least-squares problem.

Limits: The complete proof body was not accessible. Existing scene mathematical checks were not recounted as new external verification.

### mp1967

Marchenko and Pastur (1967): a limiting random-matrix density.

The original paper and explicit density example confirm the date, authors and limiting-law lineage.

Limits: The original parameterization differs. This is not a new audit of all moment assumptions or finite-sample measurements.

### jl1984

Johnson and Lindenstrauss (1984).

The AMS indexed original proceedings record and the primary Dasgupta–Gupta reference agree on 1984, volume 26, pages 189–206.

Limits: Direct AMS body access returned 403. The original 1984 proof was not read. The 1982 conference and 1984 publication are distinct dates.

### dg2003

The JL dimension constant and existence argument are attributed to Dasgupta and Gupta (2003).

Theorem 2.1 and its proof give the displayed dimension constant and 1/n existence probability. The 2003 issue year is correct despite online publication in November 2002.

Limits: The paper proves a random orthogonal-subspace version and discusses Gaussian alternatives. The scene uses a Gaussian adaptation: constants and lineage agree, but the samplers are not identical.

### ln2017

Larsen and Nelson (2017): worst-case optimality of log(n)/epsilon².

The official FOCS 2017 record and original manuscript support the date, authors and worst-case order.

Limits: The paper specifies (min{n,d})^−0.4999 < epsilon < 1. The compact scene card omits this regime; it must not be read as an unrestricted bound for every n,d,epsilon. This is a scope qualification, not a new numerical-method repair.

### lora2021

Hu and colleagues (2021): LoRA, with a stated 10,000-fold GPT-3 trainable-parameter reduction.

The original 2021 preprint abstract gives that comparison against full GPT-3 175B Adam fine-tuning.

Limits: This is a reported result under the paper configuration, rather than a universal saving for every model. The preprint year is valid even though conference publication came later.

### galore2024

Zhao, Tian, Anandkumar and colleagues: GaLore, ICML 2024.

The official proceedings confirm 2024 and the full six-author list.

### galore_memory

GaLore reports up to 65.5 percent less optimizer memory.

The official abstract and section 5.5 report that optimizer-state figure.

Limits: The percentage does not mean total training memory; the scene correctly specifies optimizer memory.

### galore_24gb

A 7B model was pretrained on one 24 GB GPU.

Section 5.3 reports the completed 150K-step, 19.7B-token 7B run on 64 A100 GPUs. Section 5.5 establishes an approximately 22 GB single-device memory footprint and 24 GB feasibility under a small token batch, 8-bit states and per-layer updates. It does not report a completed one-card 24 GB pretraining run.

Limits: Repair coordinated with parent before editing: say pretraining can fit within 24 GB under the stated conditions. Preserve the distinction between memory feasibility and the actual large training run.

## Primary-source access limits

- The original 1984 JL proof and direct AMS page returned 403. The official indexed publisher metadata and the primary Dasgupta–Gupta bibliography support the date and attribution.
- The 1929 power-method part II body returned 403. Publisher records verify its date and coauthors, not first invention. The earlier Müntz original could not be accessed through Gallica; the secondary discovery lead is not counted as confirmation.
- The original Jordan body failed through the journal archive’s Gallica redirect. Schmidt supplied subscription metadata only. Those dates and authors are verified, while the complete proof and priority claims remain open.
- The first Stanford HTML PageRank URL timed out; the original published Stanford PDF succeeded. The PMLR PDF content type was unsupported, so the original arXiv PDF and official PMLR record were read.

The JSON ledger preserves exact URLs, inspected sections/pages, verdict scope and SHA-256 hashes of all nine snapshotted repository files. Source snapshots preserve the precise reviewed captions. No complete copyrighted paper text was copied into this report. Secondary results were discovery leads only. No production computation, model training, data download or new render was performed for this historical review.

The published PMLR PDF was also fetched through its normal public URL by the parent, then its extracted text was inspected independently here. The PDF SHA-256 is `53b0a2155d1844cbf1e14630f01e11836ad02e04908a9c664a1ec6d6e7246c50` (749,048 bytes); it remains private runtime evidence and must not be redistributed in the repository. It confirms the same actual-run versus memory-feasibility distinction. The coordinated caption/VO repair is frozen in the separate handoff; fresh appearance checks remain pending.
