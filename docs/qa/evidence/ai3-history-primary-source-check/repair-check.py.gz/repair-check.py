from pathlib import Path
import ast, copy, hashlib, json, re, shutil
from explainer.ai import *
from explainer import zh_text, lang
from explainer.analysis import WIDE_TEX
import explainer.analysis as analysis

repo = Path('/workspace/explainer-videos')
out = Path(__file__).parent
part = repo / 'videos/ai/ai3'
source = part / 's12_galore.py'
tree = ast.parse(source.read_text())
before = ast.parse((out / 's12_galore.py.before').read_text())
method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'method')
history = next(n for n in method.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'hist' for t in n.targets))
new_key = next(n.value for n in ast.walk(history) if isinstance(n, ast.Constant) and isinstance(n.value, str) and '65.5' in n.value)
old_key = next(n.value for n in ast.walk(before) if isinstance(n, ast.Constant) and isinstance(n.value, str) and '65.5' in n.value)
new_zh = r'预训练时优化器内存最多减少$65.5\%$；\ 配合8位状态和逐层更新，\ 70亿参数模型的预训练可容纳在24GB内存中'
(out / 'captions-handoff.json').write_text(json.dumps({'strings': {new_key: new_zh}, 'old_key': old_key}, ensure_ascii=False, indent=2) + '\n')
zh_text.install(WIDE_TEX)
# This fixture switches language within one process; production sets it before
# importing analysis. Ensure its whole-string wrapping hook follows that switch.
analysis._zh = zh_text.translate
table = json.loads((repo / 'videos/ai/ai_text_zh.json').read_text())
table['strings'][new_key] = new_zh
zh_text._TABLE = table
geometry = []
for language in ['en', 'zh']:
    lang.LANG = language
    env = dict(globals(), HIST=C.HUMAN)
    exec(compile(ast.Module([history], type_ignores=[]), 'actual-GaLore-history-card', 'exec'), env)
    obj = env['hist']
    bounds = [float(obj.get_left()[0]), float(obj.get_right()[0]), float(obj.get_bottom()[1]), float(obj.get_top()[1])]
    assert bounds[0] > -config.frame_width / 2
    assert bounds[1] < config.frame_width / 2
    assert bounds[2] > -3.75 and bounds[3] < 3.75
    tex_strings = [str(getattr(m, 'tex_string', '')) for m in obj.get_family() if getattr(m, 'tex_string', '')]
    if language == 'zh':
        assert any('70亿' in s for s in tex_strings), tex_strings
    geometry.append({'lang': language, 'bounds': bounds, 'bottom_inset_world': bounds[2] + 4, 'width': float(obj.width), 'height': float(obj.height), 'actual_tex_strings': tex_strings})

calls = lambda tr: [n for n in ast.walk(tr) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'voiceover']
changes = []
for old, new in zip(calls(before), calls(tree)):
    if ast.dump(old) != ast.dump(new):
        old_text, new_text = ast.unparse(old.args[0]), ast.unparse(new.args[0])
        marks = re.findall(r'<bookmark[^>]+/>', old_text)
        assert marks == re.findall(r'<bookmark[^>]+/>', new_text)
        assert len(marks) == 3
        changes.append({'before': old_text, 'after': new_text, 'bookmarks': marks})
assert len(changes) == 1
# A strict structural scope comparison permits only the one caption constant and
# the one narration expression. All data/algorithm/timing nodes remain identical.
normalized = copy.deepcopy(tree)
changed_call = next(n for n in calls(normalized) if 'That is GaLore' in ast.unparse(n))
old_call = next(n for n in calls(before) if 'That is GaLore' in ast.unparse(n))
changed_call.args[0] = copy.deepcopy(old_call.args[0])
caption_node = next(n for n in ast.walk(normalized) if isinstance(n, ast.Constant) and n.value == new_key)
caption_node.value = old_key
assert ast.dump(normalized, include_attributes=False) == ast.dump(before, include_attributes=False)
old_zh_tree = ast.parse((out / 'zh_lines.py.before').read_text())
new_zh_tree = ast.parse((part / 'zh_lines.py').read_text())
changed_constants = []
for a, b in zip(ast.walk(old_zh_tree), ast.walk(new_zh_tree)):
    if isinstance(a, ast.Constant) and isinstance(b, ast.Constant) and a.value != b.value:
        changed_constants.append({'before': a.value, 'after': b.value})
assert len(changed_constants) == 1
assert re.findall(r'<bookmark[^>]+/>', changed_constants[0]['before']) == re.findall(r'<bookmark[^>]+/>', changed_constants[0]['after'])
for name in ['s12_galore.py', 'zh_lines.py']:
    shutil.copy2(part / name, out / (name + '.after'))
result = {'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'zh_lines_sha256': hashlib.sha256((part / 'zh_lines.py').read_bytes()).hexdigest(), 'geometry': geometry, 'voiceover_changes': changes, 'zh_voiceover_changes': changed_constants, 'scope_ast_check': 'Only one history caption and one VO expression differ; timing/data/algorithm nodes identical.', 'limits': 'Actual Manim text geometry only. Fresh EN/ZH endpoints, selected motion,1080 and actual narrated listening remain pending; silent timing can change with narration length.'}
(out / 'checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))
