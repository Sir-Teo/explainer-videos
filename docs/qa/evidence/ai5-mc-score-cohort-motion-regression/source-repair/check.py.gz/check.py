import ast,copy,json,hashlib,math,os,sys,unittest
from pathlib import Path
R=Path('/workspace/explainer-videos');O=Path(__file__).parent;sys.path.insert(0,str(R))
os.environ.update(EXPLAINER_VIDEO='ai5',EXPLAINER_LANG='zh')
import numpy as np
from manim import *
from explainer.ai import *
from explainer import lang,zh_text
from videos.ai.ai5.plotting import clipped_curve
from tests.test_ai5_dart_prefix import DartPrefixTests
T=json.loads((R/'videos/ai/ai_text_zh.json').read_text());T['strings'].update(json.loads((O/'proposed-zh-overlay.json').read_text())['strings']);zh_text._TABLE=T;zh_text._BY_NUMBERS=None
fn=next(n for n in ast.walk(ast.parse((R/'videos/ai/ai5/s13_montecarlo.py').read_text())) if isinstance(n,ast.FunctionDef) and n.name=='darts')
helper=next(n for n in ast.parse((R/'videos/ai/ai5/s13_montecarlo.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='set_dart_prefix')
def run(n,e):exec(compile(ast.fix_missing_locations(ast.Module([copy.deepcopy(n)],type_ignores=[])),'actual-scene-AST','exec'),e)
def assign(name):return next(n for n in fn.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for target in n.targets for t in ast.walk(target)))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bounds(o):return [float(o.get_left()[0]),float(o.get_right()[0]),float(o.get_bottom()[1]),float(o.get_top()[1])]
D=json.loads((R/'.cache/ai5/montecarlo.json').read_text())
with np.load(R/'.cache/ai5/montecarlo.npz',allow_pickle=False) as z:D.update({k:z[k].copy() for k in z.files})
GEOM=[]
class Geometry(unittest.TestCase):
 def test_actual_bilingual_geometry_and_all_cached_prefixes(self):
  for language in ['en','zh']:
   lang.LANG=language;env=dict(globals(),DATA=C.TRUE_P,N=int(D['N']),pts=D['pts'],inside=np.asarray(D['inside'],bool),est=D['est']);run(helper,env)
   for name in ['c','sq','circ','dots','ax','xl','xn','yl','zoom_note','pi_l','pi_t','ns','t']:run(assign(name),env)
   for n in fn.body:
    if isinstance(n,ast.Expr) and ast.unparse(n).startswith(('set_dart_prefix(dots','dots.add_updater(')):run(n,env)
   for name in ['path','offscale']:run(next(n for n in fn.body if isinstance(n,ast.FunctionDef) and n.name==name),env)
   for name in ['ev','colors','f']:run(assign(name),env)
   run(next(n for n in fn.body if isinstance(n,ast.Expr) and ast.unparse(n).startswith('VGroup(f, ev).arrange')),env)
   for name in ['why','shown','shown_tex','cohort_note','count_value','count_label']:run(assign(name),env)
   for n in fn.body:
    if isinstance(n,ast.Expr) and ast.unparse(n).startswith(('count_value.add_updater(','count_label.arrange(')):run(n,env)
   dots=env['dots'];centers=np.array([d.get_center() for d in dots]);colors=[str(d.get_color()) for d in dots]
   # Every integer count plus rewind and fractional transition from the actual cached data.
   for count in [0,24,1,*range(1,len(dots)+1),1501,3999.9,4000]:
    env['t'].set_value(count);dots.update(0);env['count_value'].update(0)
    shown=min(int(count),len(dots))
    visible=[i for i,d in enumerate(dots) if d.get_fill_opacity()>0]
    self.assertEqual(visible,list(range(shown)))
    if 0<count<=len(dots):self.assertAlmostEqual(4*float(np.count_nonzero(env['inside'][:shown]))/int(count),float(D['est'][int(count)-1]))
   np.testing.assert_array_equal(centers,np.array([d.get_center() for d in dots]));self.assertEqual(colors,[str(d.get_color()) for d in dots])
   b={k:bounds(env[k]) for k in ['sq','why','cohort_note','xn','count_label','zoom_note','f','ev']}
   self.assertGreater(b['cohort_note'][2],-config.frame_height/2+.15)
   self.assertLess(b['cohort_note'][3],b['why'][2]-.05)
   self.assertGreater(b['cohort_note'][0],-config.frame_width/2+.15)
   self.assertLess(b['cohort_note'][1],config.frame_width/2-.15)
   self.assertLess(b['count_label'][3],b['xn'][2]-.05)
   self.assertGreater(b['count_label'][2],-config.frame_height/2+.15)
   self.assertLess(b['count_label'][1],config.frame_width/2-.2)
   GEOM.append({'language':language,'objects':b,'counter_final':env['count_value'].get_value(),'tested_counts':1506,'cohort_note_font':env['cohort_note'].font_size,'scope':'Actual consumer AST and Manim geometry; no scene/data-producer imports or renders.'})
 def test_vo_bookmarks_and_total_plays_unmodified(self):
  for file,allowed in [('s13_montecarlo.py','darts'),('s14_scorefn.py','derive')]:
   old=ast.parse((O/'before'/file).read_text());new=ast.parse((R/'videos/ai/ai5'/file).read_text())
   vos=lambda t:[ast.dump(n.args[0]) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover']
   self.assertEqual(vos(old),vos(new))
   times=lambda t:[(n.func.attr,[(k.arg,ast.dump(k.value)) for k in n.keywords]) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ['play','wait','wait_until']]
   self.assertEqual(times(old),times(new))
   oldc=next(n for n in old.body if isinstance(n,ast.ClassDef));newc=next(n for n in new.body if isinstance(n,ast.ClassDef))
   for a,b in zip(oldc.body,newc.body):
    if isinstance(a,ast.FunctionDef) and a.name!=allowed:self.assertEqual(ast.dump(a),ast.dump(b))
  derive=next(n for n in ast.walk(new) if isinstance(n,ast.FunctionDef) and n.name=='derive')
  steps=[n for n in ast.walk(derive) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='step']
  self.assertEqual([ast.literal_eval(n.args[0]) for n in steps],[0,1,2,3]);self.assertEqual([[(k.arg,ast.literal_eval(k.value)) for k in n.keywords] for n in steps],[[],[('transform',False)],[('transform',False)],[('transform',False)]])
 def test_numeric_caption_preserves_all_roles(self):
  lang.LANG='zh'
  for en,zh in json.loads((O/'proposed-zh-overlay.json').read_text())['strings'].items():
   self.assertEqual(zh_text._NUM.findall(en),zh_text._NUM.findall(zh));self.assertEqual(zh_text.translate(en),zh)
 def test_producer_inputs_still_match_baseline(self):
  baseline=Path('/workspace/runtime/ai5-mc-score-mcmc-brownian-motion-review')
  for case in [baseline/l/s for l in ['en','zh'] for s in ['MonteCarlo','ScoreFn']]:
   d=json.loads((case/'freeze.json').read_text())
   for inp in d['inputs']:self.assertEqual(sha(R/inp['path']),inp['sha256'])

if __name__=='__main__':
 with tempconfig({'media_dir':str(O/'geometry-media'),'tex_dir':str(O/'geometry-media/Tex'),'verbosity':'ERROR','pixel_width':854,'pixel_height':480}):
  suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(DartPrefixTests),unittest.defaultTestLoader.loadTestsFromTestCase(Geometry)])
  result=unittest.TextTestRunner(verbosity=2).run(suite)
  (O/'geometry-results.json').write_text(json.dumps(GEOM,indent=2)+'\n')
  raise SystemExit(not result.wasSuccessful())
