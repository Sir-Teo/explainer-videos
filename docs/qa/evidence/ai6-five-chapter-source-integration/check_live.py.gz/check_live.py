from pathlib import Path
import json,ast,hashlib,os,sys,datetime
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;sys.path.insert(0,str(R))
from explainer import lang,tts,zh_text
from explainer.zh_templates import Translator
from explainer.voiceover import _strip_bookmarks
assert lang.LANG=='zh' and tts.BACKEND=='silent'
def forbidden(*a,**k):raise AssertionError('Provider/synthesis forbidden in live text check')
tts.synthesize=forbidden
tr=Translator('ai6');A=json.loads(Path('/workspace/runtime/ai6-adaboost-source-candidate/proposal.json').read_text());C=json.loads(Path('/workspace/runtime/ai6-contest-tie-cap-candidate/source-translation-fixtures.json').read_text());O=json.loads(Path('/workspace/runtime/ai6-outro-recap-cue-candidate/zh-proposal.json').read_text());checks=[]
def check(name,value):assert value,name;checks.append(dict(name=name,passed=True))
check('actual merged Ada English paragraph translates to corrected Chinese',tr(A['complete_candidate_derive_English_VO'])==A['complete_candidate_derive_Chinese_VO'])
actual=tr(C['actual_english']);check('actual merged Contest nested joint-best paragraph',actual==C['actual_zh'] and '2种流程并列取得最高平均准确率' in actual and '最高的是逻辑回归' not in actual)
t=ast.parse((R/'videos/ai/ai6/s19_outro.py').read_text());recap=next(n for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name=='recap');call=next(n for n in ast.walk(recap) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover');en=ast.literal_eval(call.args[0]);zh=tr(' '.join(en.split()));check('actual merged Outro marked translation',zh==next(iter(O['ZH_updates'].values())))
clean,marks=_strip_bookmarks(zh);check('actual merged Outro clean Chinese exact original',clean==O['cleaned_chinese_before']);check('actual merged Outro nine ordered named cue groups',list(marks)==['linear','penalties','logistic_newton','bayes','neighbours','kernels','averaging','boosting','evaluation'])
from explainer.voiceover import _BOOKMARK
clean_en=lang.clean(_BOOKMARK.sub('',en));check('actual marked English clean original',clean_en==O['cleaned_english_before'])
caption_delta=json.loads((D/'caption-add.json').read_text())['strings'];check('two exact live global captions',all(zh_text.translate(k)==v for k,v in caption_delta.items()))
report=dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=checks,count=len(checks),source_scope='Actual current merged modules/localZH/globaltable and real Translator/bookmark parser, no private table patch. No camera, renderer, decoder, model, synthesis, producer or data load.',local_ZH_sha256=hashlib.sha256((R/'videos/ai/ai6/zh_lines.py').read_bytes()).hexdigest(),global_caption_sha256=hashlib.sha256((R/'videos/ai/ai_text_zh.json').read_bytes()).hexdigest(),actual_Contest_Chinese=actual,actual_Outro_bookmarks=marks)
(D/'live-text-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(count=len(checks),passed=True),indent=2))
