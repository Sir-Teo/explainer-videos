from pathlib import Path
import ast,json,hashlib,copy,os,shutil,datetime
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;p=R/'videos/ai/ai6/zh_lines.py';base=(D/'before/zh_lines.py').read_bytes();h=lambda b:hashlib.sha256(b).hexdigest();assert h(base)=='0c4d021bafe1042615e3247ea5905534c2fa3cb3bf38dd9fafa23b9318ec73c2';bad=p.read_bytes();assert h(bad)=='7b4bc6cc2124a1fef5fddde505600ddc312414ee91092fada0ceb96911842e05'
updates=json.loads((D/'local-ZH-delta.json').read_text());tree=ast.parse(base.decode())
def blocks(t):
 out=[]
 for n in t.body:
  if isinstance(n,ast.Assign) and any(isinstance(v,ast.Name) and v.id=='ZH' for v in n.targets):assert isinstance(n.value,ast.Dict);out.append(n.value)
  elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='ZH' and n.value.func.attr=='update':assert len(n.value.args)==1 and isinstance(n.value.args[0],ast.Dict);out.append(n.value.args[0])
 return out
def effective(t):
 d={}
 for q in blocks(t):d.update(ast.literal_eval(q))
 return d
old=effective(tree);ds=blocks(tree);last={}
for q in ds:
 for k,v in zip(q.keys,q.values):last[ast.literal_eval(k)]=v
lines=base.splitlines(keepends=True);offset=[0]
for line in lines:offset.append(offset[-1]+len(line))
span=lambda n:(offset[n.lineno-1]+n.col_offset,offset[n.end_lineno-1]+n.end_col_offset)
edits=[];new=[]
for k,v in updates.items():
 if k in last:a,b=span(last[k]);edits.append((a,b,json.dumps(v,ensure_ascii=False).encode()))
 else:new.append(k)
end=span(ds[-1])[1]-1
last_value_end=span(ds[-1].values[-1])[1]
assert base[last_value_end:end].strip() in [b'',b',']
if not base[last_value_end:end].strip():edits.append((last_value_end,last_value_end,b','))
addition='\n    # Reviewed measured-score and recap-cue variants.\n'+''.join('    '+json.dumps(k,ensure_ascii=False)+':\n        '+json.dumps(updates[k],ensure_ascii=False)+',\n' for k in new);edits.append((end,end,addition.encode()));after=base
for a,b,s in sorted(edits,reverse=True):after=after[:a]+s+after[b:]
nt=ast.parse(after.decode());assert effective(nt)=={**old,**updates}
a=copy.deepcopy(tree);b=copy.deepcopy(nt)
for t in [a,b]:
 for q in blocks(t):q.keys=[];q.values=[]
assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
hist=D/'initial-merge-attempt';hist.mkdir();(hist/'zh_lines.py').write_bytes(bad);shutil.copy2(D/'report.json',hist/'report.json');tmp=p.with_name(p.name+'.qa-integration.tmp');tmp.write_bytes(after);os.replace(tmp,p);shutil.copy2(p,D/'after/zh_lines.py')
r=json.loads((D/'report.json').read_text());r.update(corrected_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),local_ZH_after=h(after),local_ZH_existing_values_changed=[k for k in updates if k in old and old[k]!=updates[k]],local_ZH_new_keys=new,effective_ZH_update_blocks=len(ds),effective_final_runtime_dictionary_exact_expected=True,merge_regression='Initial merge edited only the first ZH dictionary; an existing later ZH.update overrode Contest. Actual whole-module Translator caught this before publication. Corrected from original0c4 at last effective entries; failed attempt retained.',all_non_ZH_dictionary_code_exact=True)
(D/'report.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(local_ZH_after=h(after),existing_values_changed=r['local_ZH_existing_values_changed'],new_keys=len(new),effective_blocks=len(ds)),ensure_ascii=False,indent=2))
