from pathlib import Path
import json,ast,hashlib,copy,shutil,os,subprocess,datetime
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-five-chapter-source-integration');D.mkdir(exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
A=Path('/workspace/runtime/ai6-adaboost-source-candidate');C=Path('/workspace/runtime/ai6-contest-tie-cap-candidate');O=Path('/workspace/runtime/ai6-outro-recap-cue-candidate')
props=[json.loads((A/'proposal.json').read_text()),json.loads((C/'translation-overlay.json').read_text()),json.loads((O/'zh-proposal.json').read_text())]
source_specs=[('s15_adaboost.py',A/'s15_adaboost.proposed.py','be2d6221ca9c57a69285e7d980a3191e9ec5be33b7d8b6c310393edacb17de12','9dace46b8fa80a1fcf5d8fa51af867875275dda791916647d8e16c1f243cbbd7'),('s18_contest.py',C/'s18_contest.py','7c1e56626b1ceceefc5b5c5ce173a57d8cd28f84883939a1e9268bd679eaf5a2','104c27ae8743b7383b0768235e4a40b0e5b2524fb8edfd2312c88d99b27399b7'),('s19_outro.py',O/'candidate.py','98cc20f6a5a0b03e2b99bde15aa8d5a6a762e7e3d61ed3acb99e1cf44778f62e','0f613477aa043c40f1622d482caef005511f01ed0613ada91cc3a01ab626ea8e')]
zh=R/'videos/ai/ai6/zh_lines.py';gl=R/'videos/ai/ai_text_zh.json';before_zh=zh.read_bytes();before_global=gl.read_bytes();assert h(before_zh)=='0c4d021bafe1042615e3247ea5905534c2fa3cb3bf38dd9fafa23b9318ec73c2';assert h(before_global)=='0884ed469261b1b911c233f875d03430ed6099b6ce79c499972cce6ff0e9d0ad'
protected={}
for p in sorted((R/'.cache/ai6').rglob('*')):
 if p.is_file() and not p.name.endswith('.lock'):protected[str(p.relative_to(R))]=dict(sha256=h(p.read_bytes()),bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns)
(D/'numeric-before.json').write_text(json.dumps(protected,indent=2)+'\n');(D/'before').mkdir();(D/'after').mkdir()
updates={props[0]['local_narration_key']:props[0]['local_narration_proposal']}
for q in props[1:]:
 for k,v in q['ZH_updates'].items():assert k not in updates;updates[k]=v
captions={}
for q in props[:2]:
 for k,v in q.get('captions',q.get('strings',{})).items():assert k not in captions;captions[k]=v
assert len(updates)==6 and len(captions)==2,(len(updates),len(captions))
# Replace only selected literal dictionary values and add only genuinely new prefix entries.
tree=ast.parse(before_zh.decode());node=next(n for n in ast.walk(tree) if isinstance(n,ast.Dict) and any(isinstance(k,ast.Constant) and k.value==props[0]['local_narration_key'] for k in n.keys));old=ast.literal_eval(node);rawlines=before_zh.splitlines(keepends=True);offset=[0]
for line in rawlines:offset.append(offset[-1]+len(line))
span=lambda n:(offset[n.lineno-1]+n.col_offset,offset[n.end_lineno-1]+n.end_col_offset)
edits=[];newkeys=[]
for k,v in updates.items():
 if k in old:
  i=next(i for i,key in enumerate(node.keys) if ast.literal_eval(key)==k);a,b=span(node.values[i]);edits.append((a,b,json.dumps(v,ensure_ascii=False).encode()))
 else:newkeys.append(k)
insert=span(node)[1]-1;addition='\n    # Reviewed measured-score and recap-cue variants.\n'+''.join('    '+json.dumps(k,ensure_ascii=False)+':\n        '+json.dumps(updates[k],ensure_ascii=False)+',\n' for k in newkeys);edits.append((insert,insert,addition.encode()))
after_zh=before_zh
for a,b,v in sorted(edits,reverse=True):after_zh=after_zh[:a]+v+after_zh[b:]
newtree=ast.parse(after_zh.decode());newnode=next(n for n in ast.walk(newtree) if isinstance(n,ast.Dict) and any(isinstance(k,ast.Constant) and k.value==props[0]['local_narration_key'] for k in n.keys));actual=ast.literal_eval(newnode);expected={**old,**updates};assert actual==expected
normalize=lambda t,n:ast.dump(t,include_attributes=False)
a=copy.deepcopy(tree);b=copy.deepcopy(newtree)
for t in [a,b]:
 q=next(n for n in ast.walk(t) if isinstance(n,ast.Dict) and any(isinstance(k,ast.Constant) and k.value==props[0]['local_narration_key'] for k in n.keys));q.keys=[];q.values=[]
assert normalize(a,None)==normalize(b,None),'Other localZH code changed'
# Back up every actual input before the first mutation.
for p in [R/'videos/ai/ai6'/x[0] for x in source_specs]+[zh,gl]:shutil.copy2(p,D/'before'/p.name)
for name,candidate,before_sha,after_sha in source_specs:
 p=R/'videos/ai/ai6'/name;b=candidate.read_bytes();assert h(p.read_bytes())==before_sha and h(b)==after_sha;compile(b,str(p),'exec')
for p,b in [(R/'videos/ai/ai6'/name,candidate.read_bytes()) for name,candidate,_,_ in source_specs]+[(zh,after_zh)]:
 tmp=p.with_name(p.name+'.qa-integration.tmp');tmp.write_bytes(b);os.replace(tmp,p)
(D/'caption-add.json').write_text(json.dumps(dict(strings=captions),ensure_ascii=False,indent=2)+'\n')
with (D/'caption-helper.log').open('w') as log:subprocess.run(['/workspace/explainer-videos/.venv/bin/python','tools/text_zh_add.py','ai',str(D/'caption-add.json')],cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
after_global=gl.read_bytes();o=json.loads(before_global);n=json.loads(after_global);assert n['patterns']==o['patterns'] and all(n['strings'][k]==v for k,v in o['strings'].items()) and len(n['strings'])==len(o['strings'])+2
for p in [R/'videos/ai/ai6'/x[0] for x in source_specs]+[zh,gl]:compile(p.read_bytes(),str(p),'exec') if p.suffix=='.py' else None;shutil.copy2(p,D/'after'/p.name)
after={}
for p in sorted((R/'.cache/ai6').rglob('*')):
 if p.is_file() and not p.name.endswith('.lock'):after[str(p.relative_to(R))]=dict(sha256=h(p.read_bytes()),bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns)
assert protected==after;(D/'numeric-after.json').write_text(json.dumps(after,indent=2)+'\n')
report=dict(applied_utc=now(),source_files=[dict(path='videos/ai/ai6/'+name,before_sha256=before_sha,after_sha256=after_sha) for name,_,before_sha,after_sha in source_specs],local_ZH_before=h(before_zh),local_ZH_after=h(after_zh),local_ZH_existing_values_changed=[k for k in updates if k in old and old[k]!=updates[k]],local_ZH_new_keys=newkeys,all_other_local_ZH_code_and_values_exact=True,global_before=h(before_global),global_after=h(after_global),global_added_exact_strings=2,global_old_entries_and_patterns_preserved=True,protected_numeric_files=len(protected),protected_numeric_signatures_unchanged=True,render_decode_provider_producer_executed=False,after_visual_and_timing_review='PENDING separate authorized execution capacity; no acceptance from compilation or forecasts')
(D/'local-ZH-delta.json').write_text(json.dumps(updates,ensure_ascii=False,indent=2)+'\n');(D/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
