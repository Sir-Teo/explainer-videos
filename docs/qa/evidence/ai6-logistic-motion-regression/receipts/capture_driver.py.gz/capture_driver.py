#!/usr/bin/env python3
"""One serial cloud-only cached QA queue; runtime completion is not visual acceptance."""
import argparse,ast,datetime,fcntl,gzip,hashlib,json,os,re,shutil,signal,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/explainer-videos');HOME=Path(__file__).resolve().parent
TABLE=ROOT/'videos/ai/ai_text_zh.json';MIN_FREE=768*1024**2
SKIP={'Hook','LeastSquares','GaussMarkov','SVM','AdaBoost','Contest'}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def disk(need=0):
 free=shutil.disk_usage(ROOT).free
 if free<MIN_FREE+need:raise RuntimeError(f'disk guard: free={free}, minimum={MIN_FREE}, pending independent copy={need}')
 return free
def event(kind,**kw):
 row={'utc':now(),'kind':kind,**kw};print(json.dumps(row,ensure_ascii=False),flush=True)
 with (HOME/'events.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
def inventory(released=()):
 tree=ast.parse((ROOT/'videos/ai/ai6/manifest.py').read_text());scenes=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SCENES' for t in n.targets)))
 return [{'position':i,'module':m,'scene':s,'title':t} for i,(m,s,t) in enumerate(scenes,1) if i>=4 and (s not in SKIP or s in released)]
def source_files():
 series=ROOT/'videos/ai';files=sorted((ROOT/'explainer').rglob('*.py'));files+=sorted(p for p in series.iterdir() if p.suffix in ('.py','.json'));pending=['ai6'];seen=set()
 while pending:
  part=pending.pop()
  if part in seen:continue
  seen.add(part);part_files=sorted(p for p in (series/part).rglob('*') if p.suffix in ('.py','.json'));files+=part_files
  for p in part_files:
   if p.suffix=='.py':
    for match in re.findall(r'videos\.ai\.(ai\d+)\b|Cache\([\"\x27](ai\d+)[\"\x27]\)',p.read_text()):pending.extend(n for n in match if n)
 return files+[ROOT/'tools/qa_series.py',ROOT/'tools/dead_air.py',ROOT/'manim.cfg']
def source_snapshot():
 h=hashlib.sha256();rows=[];blobs=HOME/'source-blobs'
 for p in source_files():
  raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest();h.update(str(p.relative_to(ROOT)).encode());h.update(raw);blob=blobs/(digest+'.gz')
  if not blob.exists():blob.parent.mkdir(parents=True,exist_ok=True);blob.write_bytes(gzip.compress(raw,mtime=0))
  rows.append({'path':str(p.relative_to(ROOT)),'bytes':len(raw),'sha256':digest,'blob':str(blob.relative_to(HOME))})
 return {'utc':now(),'git_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'qa_fingerprint':h.hexdigest(),'table_sha256':sha(TABLE),'files':rows,'note':'Actual observed source bytes; HEAD is context and does not attest uncommitted changes.'}
def data_snapshot():
 files=sorted(p for p in (ROOT/'.cache/ai6').rglob('*') if p.is_file() and not p.name.endswith('.lock'))
 files+=sorted((ROOT/'.cache/ai1/books').glob('*.txt'))
 return [{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'sha256':sha(p)} for p in files]
def result_folder(scene,lang,mode):return ROOT/'renders/qa/series/ai6'/lang/(scene+('_motion' if mode=='motion' else ''))
def preserve(folder,dst):
 """Independent copies, before/after hashes; no hardlinks or broad media caches."""
 if not (folder/'result.json').exists():return {'present':False}
 with (folder/'.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
  record_raw=(folder/'result.json').read_bytes();r=json.loads(record_raw);paths={folder/'result.json'}
  for n in ['text.jsonl','sheet.png','motion_sheet.png','dead_air.log','render.log']:
   if (folder/n).is_file():paths.add(folder/n)
  for row in r.get('frames',[]):
   p=(folder/row['file']).resolve();assert p.is_relative_to(folder.resolve());paths.add(p)
  if r.get('movie'):
   movie=(ROOT/r['movie']).resolve();assert movie.is_relative_to(folder.resolve())
   paths.add(movie)
   for suffix in ['.narration.json','.srt','.wav']:
    if movie.with_suffix(suffix).is_file():paths.add(movie.with_suffix(suffix))
  paths=sorted(p for p in paths if p.is_file());disk(sum(p.stat().st_size for p in paths));items=[]
  for p in paths:
   sig=sha(p);q=dst/p.relative_to(folder);q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();shutil.copy2(p,q)
   assert sha(p)==sha(q)==sig and not os.path.samefile(p,q)
   items.append({'source':str(p.relative_to(ROOT)),'destination':str(q.relative_to(HOME)),'bytes':q.stat().st_size,'sha256':sig,'independent_copy2':True})
  assert (folder/'result.json').read_bytes()==record_raw
  value={'present':True,'record_sha256':hashlib.sha256(record_raw).hexdigest(),'runtime_status':r.get('status'),'raw_warnings':r.get('warnings',[]),'artifacts':items};write(dst/'copy-manifest.json',value);return value

def run_one(item,lang,mode,run,approved,timeout):
 scene=item['scene'];case=run/f"{item['position']:02d}-{scene}"/lang/mode;case.mkdir(parents=True,exist_ok=False);disk()
 before=source_snapshot();write(case/'source-before.json',before)
 if before['table_sha256']!=approved:raise RuntimeError('Approved caption table differs before case; no render started')
 data_before=data_snapshot();write(case/'data-before.json',data_before)
 folder=result_folder(scene,lang,mode);prior=preserve(folder,case/'prior') if folder.exists() else {'present':False};write(case/'prior-output.json',prior)
 env=os.environ.copy();env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',EXPLAINER_CACHED_ONLY='1',EXPLAINER_TTS='silent')
 cmd=['nice','-n','10',sys.executable,str(ROOT/'tools/qa_series.py'),'ai6','--worker',scene,'--lang',lang,'--cached-only']
 if mode=='motion':cmd.append('--motion')
 write(case/'command.json',{'argv':cmd,'cwd':str(ROOT),'env_overrides':{k:env[k] for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','EXPLAINER_CACHED_ONLY','EXPLAINER_TTS']},'timeout_seconds':timeout,'heartbeat_seconds':30,'minimum_free_bytes':MIN_FREE,'approved_table_sha256':approved,'driver_sha256':sha(Path(__file__))})
 start=time.monotonic();abort=None;event('start',scene=scene,lang=lang,mode=mode,free_bytes=disk(),fingerprint=before['qa_fingerprint'])
 with (case/'process.log').open('w') as log:
  proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while True:
   try:rc=proc.wait(timeout=min(30,max(0.1,timeout-(time.monotonic()-start))));break
   except subprocess.TimeoutExpired:
    elapsed=time.monotonic()-start;free=shutil.disk_usage(ROOT).free;event('heartbeat',scene=scene,lang=lang,mode=mode,pid=proc.pid,elapsed_seconds=round(elapsed,1),free_bytes=free)
    if elapsed>=timeout or free<MIN_FREE:
     abort='timeout' if elapsed>=timeout else 'disk-guard';os.killpg(proc.pid,signal.SIGTERM)
     try:rc=proc.wait(timeout=5)
     except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);rc=proc.wait()
     break
 after=source_snapshot();data_after=data_snapshot();write(case/'source-after.json',after);write(case/'data-after.json',data_after)
 frozen=preserve(folder,case/'completed');r=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
 source_changed=before['qa_fingerprint']!=after['qa_fingerprint'] or after['table_sha256']!=approved;data_changed=data_before!=data_after
 signatures_current=True
 for rel,expected in r.get('inputs',{}).items():
  p=ROOT/rel;actual=[p.stat().st_size,p.stat().st_mtime_ns] if p.exists() else None
  if actual!=expected:signatures_current=False
 raw_warnings=r.get('warnings',[]);runtime_complete=r.get('status') in ['passed','needs-review']
 reconcile=source_changed or data_changed or not signatures_current or r.get('fingerprint')!=before['qa_fingerprint'] or abort is not None
 receipt={'utc':now(),'scene':scene,'lang':lang,'mode':mode,'process_returncode':rc,'elapsed_seconds':round(time.monotonic()-start,3),'aborted':abort,'runtime_record_status':r.get('status','no-result'),'runtime_completed':runtime_complete,'raw_warnings':raw_warnings,'source_changed':source_changed,'data_changed':data_changed,'record_input_signatures_current':signatures_current,'needs_reconcile':reconcile,'outcome':'needs-reconcile' if reconcile else 'runtime-complete-with-warnings' if runtime_complete and raw_warnings else 'runtime-complete' if runtime_complete else 'runtime-failed','visual_review':'pending','continuous_playback':'unverified','audio_listening':'unverified','production_resolution':'unverified','freeze':frozen}
 write(case/'receipt.json',receipt);event('completed',scene=scene,lang=lang,mode=mode,outcome=receipt['outcome'],raw_status=receipt['runtime_record_status'],warnings=len(raw_warnings),elapsed_seconds=receipt['elapsed_seconds'],free_bytes=shutil.disk_usage(ROOT).free)
 if reconcile:raise RuntimeError('Case requires reconciliation; frozen raw result retained; queue stopped before next case')
 return receipt

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--run',action='store_true');ap.add_argument('--approved-table-sha');ap.add_argument('--approved-source-fingerprint');ap.add_argument('--start-at',help='Explicit Scene:lang:mode resume point; no automatic restart');ap.add_argument('--release-scene',action='append',default=[],choices=['SVM','AdaBoost','Contest']);ap.add_argument('--prior-receipt',action='append',default=[],help='Exact PATH=SHA256 binding for retained prior pass, required for resume');ap.add_argument('--timeout-seconds',type=int,default=1200);args=ap.parse_args();items=inventory(args.release_scene);passes=[(i,l,m) for i in items for l in ['en','zh'] for m in ['endpoints','motion']];
 if args.start_at:
  labels=[i['scene']+':'+l+':'+m for i,l,m in passes]
  if args.start_at not in labels:ap.error('start-at not in the approved selected manifest')
  passes=passes[labels.index(args.start_at):]
 plan={'utc':now(),'chapters':items,'excluded':sorted(SKIP-set(args.release_scene)),'released_by_explicit_argument':args.release_scene,'resume_start_at':args.start_at,'selected_subprocess_passes':len(passes),'scene_count':len(items),'bilingual_cases':len(items)*2,'subprocess_passes':len(items)*4,'one_serial_worker':True,'quality':'qa_series low_quality actual480p15 silent motion plus endpoint images','minimum_free_bytes':MIN_FREE,'timeout_seconds_per_pass':args.timeout_seconds,'numeric_threads':1,'actual_visual_review':'not started; render/runtime capture only','table_current_sha256':sha(TABLE),'driver_sha256':sha(Path(__file__))};write(HOME/'plan.json',plan)
 if not args.run:print(json.dumps(plan,indent=2));return 0
 if not args.approved_table_sha or not re.fullmatch('[0-9a-f]{64}',args.approved_table_sha):ap.error('--run requires root-approved exact --approved-table-sha')
 if sha(TABLE)!=args.approved_table_sha:raise RuntimeError('Current global table differs from approval; no run')
 if not args.approved_source_fingerprint or source_snapshot()['qa_fingerprint']!=args.approved_source_fingerprint:raise RuntimeError('Exact approved source fingerprint required before run')
 if any((HOME/'runs').glob('*/**/receipt.json')) and not args.start_at:raise RuntimeError('Prior run exists; explicit bounded resume required, no batch restart')
 prior_pins=[]
 for entry in args.prior_receipt:
  path,digest=entry.rsplit('=',1);q=Path(path);assert re.fullmatch('[0-9a-f]{64}',digest) and sha(q)==digest
  prior_pins.append({'path':str(q),'sha256':digest,'raw_record_unchanged':True,'note':'Explicit prior witness binding; no raw warning/status promotion.'})
 if args.start_at and not prior_pins:raise RuntimeError('Resume requires exact prior receipt pins')
 if not 60<=args.timeout_seconds<=3600:ap.error('timeout must be60..3600 seconds')
 lock=(HOME/'driver.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);disk();run=HOME/'runs'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S');run.mkdir(parents=True,exist_ok=False);receipts=[];write(run/'start-gate.json',{'utc':now(),'approved_source_fingerprint':args.approved_source_fingerprint,'approved_table_sha256':args.approved_table_sha,'start_at':args.start_at,'prior_receipts':prior_pins,'released_scenes':args.release_scene,'prior_warnings_remain_raw':True})
 try:
  for item,lang,mode in passes:
   if source_snapshot()['qa_fingerprint']!=args.approved_source_fingerprint:raise RuntimeError('Approved source fingerprint differs before next pass; stopped')
   receipts.append(run_one(item,lang,mode,run,args.approved_table_sha,args.timeout_seconds));write(run/'progress.json',receipts)
 except Exception as exc:
  event('stopped',error=f'{type(exc).__name__}: {exc}',completed_passes=len(receipts));write(run/'stop.json',{'utc':now(),'error':f'{type(exc).__name__}: {exc}','completed_passes':len(receipts),'not_visual_approval':True});raise
 write(run/'summary.json',{'utc':now(),'receipts':receipts,'actual_visual_review':'pending','all_runtime_completed':all(r['runtime_completed'] for r in receipts),'raw_warning_passes':sum(bool(r['raw_warnings']) for r in receipts)});return 0 if all(r['runtime_completed'] and not r['raw_warnings'] for r in receipts) else 1
if __name__=='__main__':raise SystemExit(main())
