from pathlib import Path
import json,sys,hashlib,datetime
D=Path(__file__).parent;language,kind,ids,note=sys.argv[1:];Q=D/'review'/language;p=Q/'views.json';v=json.loads(p.read_text());plan=json.loads((Q/'plan.json').read_text())
for number in map(int,ids.split(',')):
 item=next(x for x in plan['pages'] if x['number']==number) if kind=='page' else plan['frames'][number];path=Path(item['path']);assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'];v.append({'language':language,'kind':kind,'number':number,'path':str(path),'sha256':item['sha256'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scale':'640px wide tiles from854x480 original' if kind=='page' else 'original854x480','note':note})
p.write_text(json.dumps(v,indent=2)+'\n')
