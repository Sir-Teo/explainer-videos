from pathlib import Path
import ast,datetime,fcntl,hashlib,importlib.util,json,math,os,shutil,signal,subprocess,sys,time
from PIL import Image,ImageDraw
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;OLD=Path('/workspace/runtime/ai6-logistic-selected-review');language=sys.argv[1];F=D/'current/06-Logistic'/language;Q=D/'review'/language;Q.mkdir(parents=True,exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();MIN=768*2**20
assert not (Q/'plan.json').exists();receipt=json.loads((F/'motion/receipt.json').read_text());assert receipt['runtime_completed'] and not receipt['needs_reconcile'];completed=F/'motion/completed';movie=completed/'media/videos/480p15/Logistic.mp4';movie_sha=sha(movie);assert movie.stat().st_nlink==1
baseline_root=Path('/workspace/runtime/ai6-remaining-qa-serial/runs/20261101T055536/06-Logistic')/language;oldmovie=baseline_root/'motion/completed/media/videos/480p15/Logistic.mp4';oldplan=json.loads((OLD/language/'motion-views/plan.json').read_text());oldviews=json.loads((OLD/language/'motion-views/views.json').read_text());assert set(v['number'] for v in oldviews if v['kind']=='page')==set(p['number'] for p in oldplan['pages'])
for p in oldplan['pages']:assert sha(Path(p['path']))==p['sha256']
base_png={};base_rgb={}
for f in oldplan['frames']:
 assert sha(Path(f['path']))==f['sha256'];base_png.setdefault(f['sha256'],f);base_rgb.setdefault(f['pixel_sha256'],f)
with open('/workspace/runtime/ai4-tail-motion-review/extract.lock','a') as lock:
 print(language,'WAITING_SHARED_LOCK',flush=True);fcntl.flock(lock,fcntl.LOCK_EX)
 assert shutil.disk_usage(R).free>=MIN,'disk guard before extraction'
 tool=R/'tools/qa_motion.py';tool_sha=sha(tool)
 with (Q/'audit.log').open('w') as log:
  proc=subprocess.Popen(['nice','-n','10',sys.executable,str(tool),str(movie),'-o',str(Q/'audit'),'--dense','.25','--max-gap','1'],cwd=R,env={**os.environ,'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   if shutil.disk_usage(R).free<MIN:os.killpg(proc.pid,signal.SIGTERM);proc.wait();raise RuntimeError('disk guard during extraction')
   time.sleep(.5)
  assert proc.returncode==0,proc.returncode
 assert sha(movie)==movie_sha and sha(tool)==tool_sha
 spec=importlib.util.spec_from_file_location('qa_motion',tool);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 audit=json.loads((Q/'audit/result.json').read_text());assert audit['source_sha256']==movie_sha
 stream,times=m.probe(movie);oldstream,oldtimes=m.probe(oldmovie);assert times==oldtimes
 pts_proof={'before_sha256':hashlib.sha256(json.dumps(oldtimes).encode()).hexdigest(),'after_sha256':hashlib.sha256(json.dumps(times).encode()).hexdigest(),'all_timestamp_values_equal':True,'frame_count':len(times),'before_stream':oldstream,'after_stream':stream}
 windows=([(64.8,67.3),(69.4,72.0),(76.1,78.7),(82.9,85.5)] if language=='en' else [(73.3,76.2),(78.5,81.2),(85.0,87.7),(91.6,94.4)])
 existing={f['source_frame']:dict(f,path=str(Q/'audit'/f['file']),cohorts=['adaptive-selected']) for f in audit['selected_frames']};extra=[]
 for i,t in enumerate(times):
  if any(a<=t<=b for a,b in windows):
   if i in existing:existing[i]['cohorts'].append('all-encoded-repair-window')
   else:extra.append({'source_frame':i,'time':t,'reasons':['all-encoded-repair-window']})
 assert shutil.disk_usage(R).free>=MIN
 if extra:m.extract(movie,Q/'repair-frames',extra)
 for f in extra:existing[f['source_frame']]=dict(f,path=str(Q/'repair-frames'/Path(f['file']).name),cohorts=['all-encoded-repair-window'])
 assert shutil.disk_usage(R).free>=MIN
 frames=[];unique=[];seen={};novel=[];inherited=[]
 for i,f in enumerate(sorted(existing.values(),key=lambda f:f['source_frame'])):
  p=Path(f['path']);assert p.is_file();png=sha(p);im=Image.open(p).convert('RGB');rgb=hashlib.sha256(str(im.size).encode()+im.tobytes()).hexdigest();f.update(ordinal=i,sha256=png,pixel_sha256=rgb,size=list(im.size));key=png
  if key not in seen:
   f['representative_index']=len(unique);seen[key]=len(unique)
   if png in base_png:f['inheritance']={'type':'exact-PNG-SHA256','baseline':base_png[png]};inherited.append(f)
   elif rgb in base_rgb:f['inheritance']={'type':'exact-full-native-RGB-bytes','baseline':base_rgb[rgb],'PNG_metadata_or_encoding_differs':True};inherited.append(f)
   else:f['changed_index']=len(novel);novel.append(f)
   unique.append(f)
  f['representative_index']=seen[key];frames.append(f)
 pages=[];tile_w=640;tile_h=360;N=8
 for no,offset in enumerate(range(0,len(novel),N),1):
  chunk=novel[offset:offset+N];page=Image.new('RGB',(1280,math.ceil(len(chunk)/2)*(tile_h+28)),'#171e28');draw=ImageDraw.Draw(page)
  for j,f in enumerate(chunk):
   x=j%2*640;y=j//2*388;draw.text((x+6,y+5),f"{language} #{f['ordinal']}  {f['time']:.6f}s  frame{f['source_frame']}",fill='white');page.paste(Image.open(f['path']).convert('RGB').resize((640,360)),(x,y+28))
  p=Q/f'changed-{no:03d}.png';page.save(p);pages.append({'number':no,'path':str(p),'sha256':sha(p),'ordinals':[f['ordinal'] for f in chunk]})
 # Current endpoints: compare immutable originals; only exactPNG/fullnativeRGB may inherit actualbaseline views.
 endpoint_rows=[];epbase=json.loads((OLD/language/'endpoints-views/plan.json').read_text());byname={f['file']:f for f in epbase['frames']};ep=json.loads((F/'endpoints/completed/result.json').read_text())
 for f in ep['frames']:
  p=F/'endpoints/completed'/f['file'];old=byname[f['file']];im=Image.open(p).convert('RGB');rgb=hashlib.sha256(str(im.size).encode()+im.tobytes()).hexdigest();endpoint_rows.append({'file':f['file'],'path':str(p),'sha256':sha(p),'baseline_sha256':old['sha256'],'pixel_sha256':rgb,'baseline_pixel_sha256':old['pixel_sha256'],'exact_png_equal':sha(p)==old['sha256'],'exact_native_rgb_equal':rgb==old['pixel_sha256'],'baseline_view_plan':str(OLD/language/'endpoints-views/plan.json')})
 timing={}
 for suffix in ['.narration.json','.srt','.wav']:
  old=oldmovie.with_suffix(suffix);new=movie.with_suffix(suffix);assert old.is_file() and new.is_file();timing[suffix]={'before_sha256':sha(old),'after_sha256':sha(new),'byte_equal':old.read_bytes()==new.read_bytes()}
 before_rec=json.loads((baseline_root/'motion/completed/result.json').read_text());after_rec=json.loads((completed/'result.json').read_text());timing['complete_pts_comparison']=pts_proof;timing['raw_narration_objects_equal']=before_rec['narration']==after_rec['narration'];timing['record_duration_equal']=before_rec['duration']==after_rec['duration'];timing['before_duration']=before_rec['duration'];timing['after_duration']=after_rec['duration'];assert all(timing[k]['byte_equal'] for k in ['.narration.json','.srt','.wav']) and timing['raw_narration_objects_equal'] and timing['record_duration_equal']
 plan={'language':language,'source_movie':str(movie),'source_movie_sha256':movie_sha,'baseline_movie_sha256':sha(oldmovie),'tool_sha256':tool_sha,'source_record_sha256':sha(completed/'result.json'),'motion_receipt_sha256':sha(F/'motion/receipt.json'),'endpoint_receipt_sha256':sha(F/'endpoints/receipt.json'),'raw_warnings':receipt['raw_warnings'],'automated_selected':len(audit['selected_frames']),'all_encoded_repair_windows':windows,'all_encoded_window_frames':sum('all-encoded-repair-window' in f['cohorts'] for f in frames),'union_frames':len(frames),'unique_pngs':len(unique),'inherited_unique':len(inherited),'novel_unique':len(novel),'frames':frames,'representatives':unique,'pages':pages,'endpoints':endpoint_rows,'timing_sidecars':timing,'decoded':audit['analysis']['decoded_frames'],'gaps':audit['unextracted_frame_gaps'],'maximum_selected_gap':audit['largest_selected_time_gap'],'baseline_plan_sha256':sha(OLD/language/'motion-views/plan.json'),'baseline_views_sha256':sha(OLD/language/'motion-views/views.json'),'inheritance_scope':'Verified actual baseline pageviews, exactoriginalPNG or fullnativeRGB byteequality only; no detector thumbnails/perceptual/JPEG matching. No unviewed oldmovie inheritance.'}
 (Q/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(Q/'views.json').write_text('[]\n');print('READY',language,json.dumps({k:plan[k] for k in ['automated_selected','all_encoded_window_frames','union_frames','unique_pngs','inherited_unique','novel_unique','decoded']}),'pages',len(pages),flush=True)
