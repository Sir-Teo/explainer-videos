from pathlib import Path
import json,hashlib,subprocess,shutil,datetime
from PIL import Image
D=Path(__file__).parent;F=D/'current/06-Logistic/zh';OLD=Path('/workspace/runtime/ai6-remaining-qa-serial/runs/20261101T055536/06-Logistic/zh');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();movie=F/'motion/completed/media/videos/480p15/Logistic.mp4';before=OLD/'motion/completed/media/videos/480p15/Logistic.mp4';out={}
for suffix in ['.narration.json','.srt','.wav']:
 a=before.with_suffix(suffix);b=movie.with_suffix(suffix);out[suffix]={'before_sha256':sha(a),'after_sha256':sha(b),'exact_bytes_equal':a.read_bytes()==b.read_bytes()};assert out[suffix]['exact_bytes_equal']
def pts(p):
 x=subprocess.run(['ffprobe','-v','error','-threads','1','-select_streams','v:0','-show_streams','-show_frames','-show_entries','stream=width,height,avg_frame_rate,duration:frame=best_effort_timestamp_time','-of','json',str(p)],capture_output=True,text=True,check=True);return json.loads(x.stdout)
a=pts(before);b=pts(movie);assert a==b;out['pts']={'arrays_and_stream_fields_exact_equal':True,'frame_count':len(a['frames']),'before_json_sha256':hashlib.sha256(json.dumps(a).encode()).hexdigest(),'after_json_sha256':hashlib.sha256(json.dumps(b).encode()).hexdigest()}
oldplan=json.loads(Path('/workspace/runtime/ai6-logistic-selected-review/zh/endpoints-views/plan.json').read_text());new=json.loads((F/'endpoints/completed/result.json').read_text());rows=[]
for f,old in zip(new['frames'],oldplan['frames']):
 p=F/'endpoints/completed'/f['file'];assert f['file']==old['file'];rgb=Image.open(p).convert('RGB');rh=hashlib.sha256(str(rgb.size).encode()+rgb.tobytes()).hexdigest();assert sha(p)==old['sha256'] and rh==old['pixel_sha256'];rows.append({'path':str(p),'sha256':sha(p),'pixel_sha256':rh,'matches_actually_viewed_baseline_png':True})
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only metadata and endpoint exact-image identity; fresh changed-motion visual review pending.','source_movie_sha256':sha(movie),'baseline_movie_sha256':sha(before),'sidecars':out,'endpoint_states':rows,'raw_receipts':{mode:json.loads((F/mode/'receipt.json').read_text()) for mode in ['endpoints','motion']},'fresh_motion_new_images_reviewed':False}
(D/'zh-metadata-checkpoint.json').write_text(json.dumps(report,indent=2)+'\n');free=shutil.disk_usage('/workspace').free
(D/'zh-extraction-resource-hold.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'action':'Fresh Chinese Logistic qa_motion .25/maxgap1 plus all-encoded four reveal windows','target':str(movie),'outcome':'pending before launch; estimated output cannot fit above unchanged768MiB guard','free_bytes':free,'minimum_free_bytes':768*2**20,'actual_EN_equivalent_output_bytes':65294687,'completed':'Allfour freshcapturepasses; completeENaftervisual review; ZH exactmetadata/19EPidentitycheck','no_bitmap_audio_or_cache_deletion':True},indent=2)+'\n')
print(json.dumps({'ZH_movie_sha256':sha(movie),'sidecars_exact':True,'PTS_frames':len(a['frames']),'EP_exact':len(rows),'diskfree':free},indent=2))
