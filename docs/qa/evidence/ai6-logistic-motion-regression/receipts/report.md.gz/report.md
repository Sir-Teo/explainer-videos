# Logistic bilingual repair regression

Accepted within sampled-image and all-encoded reveal-window scope. All four fresh endpoint/motion passes completed withzero warnings and stable source/data. The four copyghosts are gone in bothlanguages; no new defect found.

Current coverage:1,015 adaptive selected times plus210additional encoded-window times =1,225union times. All321 encoded frame times in the eight stated windows are covered.1,092unique currentPNGs comprise847 exactbaselinePNG matches and245 new images actuallyviewed on32pages, plus10original854px currentfollowups. All38 endpoint states exactly match the previouslyactuallyviewed baselinePNGs. All5,155 encodedframes decoded;3,930 frames remain visuallyunselected, with exact gap ledgers preserved.

Narration JSON, SRT and WAV sidecars are byte-identical; completePTS arrays/streamfields and raw narrationobjects/durations are identical before/after. All74 cache/source-text data inventory files retain exactSHA/size/mtime. Baseline witnesses remain unchanged and allafter artifacts are independent singly-linkedcopy2files.

No continuous/listening/narrated-synchronization/native1080/4K approval is claimed. Raw pending visual-review fields remain untouched; this scoped manualdecision is separate. Root’s604-suite is a separatelyreported sourcecheckpoint, not tests run in this assignment.
