from pathlib import Path
from huggingface_hub import scan_cache_dir
import hashlib,json,os,datetime
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/capacity-inactive-forced-aligner-20261101');D.mkdir(exist_ok=True);cache=Path('/workspace/runtime/huggingface/hub');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def protected():
 paths=[p for n in ['ai1','ai2','ai3','ai4','ai5','novels'] for p in (R/'.cache'/n).rglob('*') if p.is_file() and p.suffix in ['.json','.npz','.pt','.npy','.txt']]
 return [{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted(paths)]
info=scan_cache_dir(cache);repo=next(x for x in info.repos if x.repo_id=='Qwen/Qwen3-ForcedAligner-0.6B');revision=next(iter(repo.revisions));assert revision.commit_hash=='c7cbfc2048c462b0d63a45797104fc9db3ad62b7';blobs={str(f.blob_path) for f in revision.files};active=[]
for proc in Path('/proc').glob('[0-9]*'):
 try:
  maps=(proc/'maps').read_text(errors='replace')
  for path in blobs:
   if path in maps:active.append({'pid':proc.name,'mapped_file':path})
  for fd in (proc/'fd').iterdir():
   try:
    target=os.readlink(fd)
    if target in blobs:active.append({'pid':proc.name,'open_file':target})
   except OSError:pass
 except (OSError,PermissionError):pass
assert not active,active
before=protected();(D/'protected-before.json').write_text(json.dumps(before,indent=2)+'\n');files=[{'name':f.file_name,'file_path':str(f.file_path),'blob_path':str(f.blob_path),'bytes':f.size_on_disk,'sha256':sha(f.blob_path)} for f in revision.files];strategy=info.delete_revisions(revision.commit_hash);expected=strategy.expected_freed_size;assert expected>1_000_000_000;strategy.execute();after=protected();assert before==after;(D/'protected-after.json').write_text(json.dumps(after,indent=2)+'\n');receipt={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repo':'Qwen/Qwen3-ForcedAligner-0.6B','public_revision':revision.commit_hash,'files':files,'manager_expected_freed_bytes':expected,'known_open_or_mapped_files':active,'protected_payloads':len(before),'all_protected_signatures_unchanged':True,'scope':'Normal HuggingFace cache-manager removal of inactive public pretrained forced-aligner download only. This QA worker currently has no active narration/alignment job; separate cloud production has its own environment. No generated TTS speech, GPT2, numerical cache, trained novels model or unique QA evidence removed. Future reuse requires normal public redownload of exact revision.'};(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='files'},indent=2))
