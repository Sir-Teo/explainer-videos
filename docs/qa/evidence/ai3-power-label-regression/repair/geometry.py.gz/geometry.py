import ast
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path('/workspace/explainer-videos')
sys.path.insert(0, str(ROOT))
from explainer.ai import *
import numpy as np
import math
from manim import tempconfig

lang = os.environ['EXPLAINER_LANG']
source = ROOT / 'videos/ai/ai3/s07_power.py'
tree = ast.parse(source.read_text())
method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'measured')
prefix = []
for node in method.body:
    if isinstance(node, ast.With):
        break
    prefix.append(node)
common = ast.parse((ROOT / 'videos/ai/ai3/common.py').read_text())
dots = next(n for n in common.body if isinstance(n, ast.FunctionDef) and n.name == 'dots_on')
env = globals().copy()
env.update(GPTC=C.TRUE_P, LETC=C.MODEL_Q, load=lambda name: json.loads((ROOT / '.cache/ai3/power.json').read_text()))
exec(compile(ast.fix_missing_locations(ast.Module(body=[dots], type_ignores=[])), '<actual-dots>', 'exec'), env)

def build(before):
    body = [n for n in prefix if not (before and isinstance(n, ast.Expr) and 'g.ylabel.shift' in ast.unparse(n))]
    fn = ast.FunctionDef(name='fixture', args=ast.arguments(posonlyargs=[], args=[ast.arg(arg='self')], kwonlyargs=[], kw_defaults=[], defaults=[]), body=body + [ast.Return(value=ast.Call(func=ast.Name(id='locals', ctx=ast.Load()), args=[], keywords=[]))], decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[fn], type_ignores=[])), '<actual-measured-prefix>', 'exec'), env)
    return env['fixture'](None)

def bbox(m):
    return [float(m.get_left()[0]), float(m.get_right()[0]), float(m.get_bottom()[1]), float(m.get_top()[1])]

with tempconfig({'pixel_width':1920,'pixel_height':1080,'tex_dir':ROOT / f'renders/qa/production-endpoints-1080/ai3/{lang}/Power/Tex'}):
    old, new = build(True), build(False)
    assert np.allclose(old['ax'].get_all_points(), new['ax'].get_all_points())
    for a,b in zip(old['series'],new['series']):
        for i in (0,1):
            assert np.allclose(a[i].get_all_points(), b[i].get_all_points())
    assert np.allclose(old['key'].get_all_points(),new['key'].get_all_points())
    assert np.allclose(old['leg'].get_all_points(),new['leg'].get_all_points())
    bottom = new['g'].ylabel.get_bottom()[1]
    predicted_high = max(s[1].get_top()[1] for s in new['series'])
    gap = float(bottom-predicted_high)
    assert gap > .1, gap
    assert new['g'].ylabel.get_top()[1] < config.frame_height/2-.2
    # Horizontal ranges separate the top-right legend from the left y-caption.
    caption = bbox(new['g'].ylabel); key = bbox(new['key'])
    assert caption[1] < key[0] or caption[3] < key[2] or key[3] < caption[2]
    for a,b in zip(old['series'],new['series']):
        # Peak Indicate(scale_factor=1.0) leaves all prediction points fixed.
        anim=Indicate(b[1],color=WHITE,scale_factor=1.0);anim.begin();anim.interpolate(.5)
        assert np.allclose(a[1].get_all_points(),b[1].get_all_points())
    receipt={'lang':lang,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'cache_sha256':hashlib.sha256((ROOT/'.cache/ai3/power.json').read_bytes()).hexdigest(),'old_caption_bounds':bbox(old['g'].ylabel),'new_caption_bounds':caption,'key_bounds':key,'predicted_highest_y':float(predicted_high),'caption_to_prediction_gap_scene_units':gap,'checks':['actual AST measured-prefix geometry','both actual prediction series','axes/curve/legend/provenance points unchanged','caption above both authentic predictions','caption frame-safe and key-disjoint','Indicate scale1 midpoint preserves predictions'],'limits':'Pure geometry fixture; fresh actual renders still required.'}
    out=Path('/workspace/runtime/ai3-power-label-repair')/f'geometry-{lang}.json';out.write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
