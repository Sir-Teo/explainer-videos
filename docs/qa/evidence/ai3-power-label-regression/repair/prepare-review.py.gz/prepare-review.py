import json,hashlib,math,sys
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path('/workspace/explainer-videos');BASE=Path('/workspace/runtime/ai3-power-label-repair');lang=sys.argv[1]
out=BASE/'after'/lang;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def pages_for(frames,stem,columns=2,perpage=8):
 pages=[]
 for no,start in enumerate(range(0,len(frames),perpage),1):
  chunk=frames[start:start+perpage];tiles=[]
  for f in chunk:
   p=Path(f['file']);assert sha(p)==f['sha256']
   with Image.open(p) as im:
    tile=Image.new('RGB',(im.width,im.height+30),'#202732');tile.paste(im,(0,30));ImageDraw.Draw(tile).text((8,7),f"{f.get('time',0):.3f}s | {f['sha256'][:16]}",fill='white');tiles.append(tile)
  w,h=tiles[0].size;sheet=Image.new('RGB',(columns*w,math.ceil(len(tiles)/columns)*h),'#202732')
  for i,t in enumerate(tiles):sheet.paste(t,((i%columns)*w,(i//columns)*h))
  path=out/f'{stem}-{no:03d}.png';sheet.save(path);pages.append({'file':str(path),'sha256':sha(path),'frames':chunk,'actually_viewed':False})
 return pages
baseline_name='ai3-power-svd-repair-motion-review.json' if lang=='en' else 'ai3-power-svd-lowrank-motion-review.json'
baseline=BASE/'before'/baseline_name;oldcase=json.loads(baseline.read_text())['cases'][lang+'/Power']
known={f['sha256']:f for f in oldcase['frame_coverage'] if f['coverage']!='not_yet_reviewed'}
audit=ROOT/f'renders/qa/temporal/ai3-{lang}-Power-label-final/result.json';a=json.loads(audit.read_text());seen={};frames=[];unique=[]
for f in a['selected_frames']:
 f=dict(f,file=str(audit.parent/f['file']))
 if f['sha256'] in known:f.update(coverage='exact_png_from_complete_prior_selected_review',baseline_frame=known[f['sha256']],baseline_receipt=str(baseline),baseline_receipt_sha256=sha(baseline))
 elif f['sha256'] in seen:f.update(coverage='exact_png_duplicate_of_new_representative',representative_sha256=f['sha256'])
 else:f.update(coverage='pending_actual_view');unique.append(f);seen[f['sha256']]=f
 frames.append(f)
motion={'audit':str(audit),'audit_sha256':sha(audit),'source_movie_sha256':a['source_sha256'],'tool_sha256':a['tool_sha256'],'analysis':a['analysis'],'settings':a['settings'],'provenance':a['provenance'],'coverage_limits':a['coverage_limits'],'unextracted_frame_gaps':a['unextracted_frame_gaps'],'largest_selected_time_gap':a['largest_selected_time_gap'],'frames':frames,'pages':pages_for(unique,'motion-new')}
endpoints={}
for mode in ['endpoint','native1080']:
 d=json.loads((out/mode/'result.json').read_text());old={}
 if mode=='native1080':
  oldreceipt=Path('/workspace/runtime/ai3-head-production-1080')/f'{lang}-Power/actual-review.json';old={f['sha256']:f for f in json.loads(oldreceipt.read_text())['frames']}
 fs=[];new=[]
 for i,f in enumerate(d['frames']):
  p=out/mode/f['file'];x={'index':i,'time':f['time'],'file':str(p),'sha256':sha(p),'coverage':'exact_native1080_baseline_png' if sha(p) in old else 'pending_actual_view'}
  if x['coverage']=='pending_actual_view':new.append(x)
  fs.append(x)
 endpoints[mode]={'record_sha256':sha(out/mode/'result.json'),'status':d['status'],'warnings':d['warnings'],'frames':fs,'pages':pages_for(new,mode+'-new',perpage=4 if mode=='native1080' else 8)}
review={'lang':lang,'motion':motion,'endpoints':endpoints,'status':'pending actual new-image review','limits':'Selected-frame480motion and1080endpoint regression only; no continuous playback/listening or1080motion signoff.'}
(out/'review.json').write_text(json.dumps(review,indent=2));print(lang,'motion',len(frames),'new',len(unique),'pages',len(motion['pages']),'endpoints',[(k,len(v['frames']),len(v['pages'])) for k,v in endpoints.items()])
