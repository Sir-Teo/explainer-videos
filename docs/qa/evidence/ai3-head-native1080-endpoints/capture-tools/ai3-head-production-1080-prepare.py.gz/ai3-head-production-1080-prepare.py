import json,hashlib,sys
from pathlib import Path
from PIL import Image,ImageDraw
BASE=Path('/workspace/runtime/ai3-head-production-1080')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for key in sys.argv[1:]:
 case=BASE/key;capture=case/'capture.json';d=json.loads(capture.read_text());assert d['status']in ('passed','needs-review')
 if (case/'review-plan.json').exists():print(str(case/'review-plan.json'));continue
 seen={};todo=[];frames=[]
 for f in d['all_frames']:
  assert sha(f['file'])==f['sha256'];assert Image.open(f['file']).size==(1920,1080);f=dict(f)
  if f['sha256']in seen:f.update(coverage='pending-exact-SHA-duplicate',representative_index=seen[f['sha256']])
  else:f.update(coverage='pending-actual-native-page-view');seen[f['sha256']]=f['index'];todo.append(f)
  frames.append(f)
 pages=[]
 for start in range(0,len(todo),4):
  chunk=todo[start:start+4];im=Image.new('RGB',(3840,1120*((len(chunk)+1)//2)),'#222832');draw=ImageDraw.Draw(im)
  for i,f in enumerate(chunk):
   x=i%2*1920;y=i//2*1120;draw.text((x+10,y+10),f"Native1920x1080 {key} endpoint#{f['index']} {f['time']:.3f}s {f['reason']}",fill='white');im.paste(Image.open(f['file']).convert('RGB'),(x,y+40))
  p=case/f'native-page-{len(pages)+1:03}.png';im.save(p);pages.append({'file':str(p),'sha256':sha(p),'indices':[f['index']for f in chunk],'times':[f['time']for f in chunk],'actually_viewed':False})
 report={'scope':'All native1920x1080 endpoint PNG contents, laid out without resizing; exact within-case PNG SHA duplicates only. Not full1080 motion/audio.','capture':str(capture),'capture_sha256':sha(capture),'all_recorded_frames':frames,'frame_count':len(frames),'actual_unique_count':len(todo),'exact_duplicate_count':len(frames)-len(todo),'pages':pages}
 (case/'review-plan.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'key':key,'frames':len(frames),'unique':len(todo),'pages':len(pages),'plan':str(case/'review-plan.json')}))
