import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai3-head-production-1080');OUT.mkdir(exist_ok=True)
SCENES={'Hook':'s01_hook.py','Vectors':'s02_vectors.py','Einsum':'s03_einsum.py','Matrices':'s04_matrices.py','Eigen':'s06_eigen.py','Power':'s07_power.py','SVD':'s08_svd.py'}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT));from tools.qa_series import fingerprint,inputs_current
for lang in ['en','zh']:
 for scene,module in SCENES.items():
  key=lang+'-'+scene;case=OUT/key;case.mkdir(exist_ok=True);canonical=ROOT/'renders/qa/production-endpoints-1080/ai3'/lang/scene
  if (case/'capture.json').exists():
   existing=json.loads((case/'capture.json').read_text());assert sha(canonical/'result.json')==existing['record_sha256'];print(key+' exact completed capture retained',flush=True);continue
  if (canonical/'result.json').exists():
   # Previous execution completed rendering, then failed only while hashing
   # an expected-absent optional cache. Preserve/reconcile it, never rerender.
   assert (case/'worker-start.json').exists() and (case/'render-record.json').exists()
   assert sha(canonical/'result.json')==sha(case/'render-record.json')
   raw=json.loads((case/'render-record.json').read_text());assert raw['status']=='passed' and raw['manual_capture_configuration']['pixel_width']==1920
   before=json.loads((case/'worker-start.json').read_text());result=None
   images=[]
   for i,f in enumerate(raw['frames']):
    dest=case/'frames'/f['file'];assert sha(dest)==sha(canonical/f['file']);images.append(dict(f,index=i,file=str(dest),sha256=sha(dest)))
   receipt={'finished_utc':datetime.now(timezone.utc).isoformat(),'returncode':None,'reconciliation':'Original renderer completed/passed native configuration; receipt write failed on expected-absent optional NPZ. Original subprocess exit code was not persisted. No renderer rerun.', 'record':str(case/'render-record.json'),'record_sha256':sha(case/'render-record.json'),'status':raw['status'],'warnings':raw['warnings'],'worker_start':str(case/'worker-start.json'),'worker_start_sha256':sha(case/'worker-start.json'),'source_stability':{rel:sha(ROOT/rel)==value['sha256']for rel,value in before['source_files'].items()},'consumed_inputs':{rel:{'sha256':sha(ROOT/rel)if(ROOT/rel).is_file()else None,'signature':signature}for rel,signature in raw['inputs'].items()},'inputs_current_at_freeze':inputs_current(raw),'aggregate_fingerprint_current_at_freeze':raw['fingerprint']==fingerprint('ai3'),'all_frames':images,'coverage':'not visually reviewed yet'}
   (case/'capture.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(key+' completed original render reconciled; no rerender',flush=True);continue
  before={'started_utc':datetime.now(timezone.utc).isoformat(),'case':key,'scene_module':module,'source_files':{},'canonical_record_preexisting':False,'wrapper_sha256':sha('/workspace/runtime/qa_production_endpoint.py')}
  for src in list((ROOT/'videos/ai/ai3').glob('*.py'))+list((ROOT/'videos/ai/ai3').glob('*.json'))+[ROOT/'videos/ai/ai_text_zh.json',ROOT/'tools/qa_series.py',ROOT/'tools/qa_scene.py',ROOT/'explainer/ai/viz.py']:
   dst=case/'source-start'/src.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);before['source_files'][str(src.relative_to(ROOT))]={'sha256':sha(dst),'copy':str(dst)}
  (case/'worker-start.json').write_text(json.dumps(before,indent=2)+'\n')
  with (case/'wrapper.log').open('w')as log:
   result=subprocess.run([sys.executable,'/workspace/runtime/qa_production_endpoint.py','ai3',lang,scene],cwd=ROOT,env=os.environ,stdout=log,stderr=subprocess.STDOUT)
  p=canonical/'result.json'
  if not p.exists():
   (case/'capture-error.json').write_text(json.dumps({'returncode':result.returncode,'status':'no result; no retry','log':str(case/'wrapper.log')}));print(key+' failed without record',flush=True);continue
  raw=json.loads(p.read_text());shutil.copy2(p,case/'render-record.json')
  for name in ['render.log','text.jsonl','sheet.png']:
   if (canonical/name).exists():shutil.copy2(canonical/name,case/name)
  images=[];(case/'frames').mkdir(exist_ok=True)
  for i,f in enumerate(raw['frames']):
   src=canonical/f['file'];dest=case/'frames'/f['file'];shutil.copy2(src,dest);images.append(dict(f,index=i,file=str(dest),sha256=sha(dest)))
  receipt={'finished_utc':datetime.now(timezone.utc).isoformat(),'returncode':result.returncode,'record':str(case/'render-record.json'),'record_sha256':sha(case/'render-record.json'),'status':raw['status'],'warnings':raw['warnings'],'worker_start':str(case/'worker-start.json'),'worker_start_sha256':sha(case/'worker-start.json'),'source_stability':{rel:sha(ROOT/rel)==value['sha256']for rel,value in before['source_files'].items()},'consumed_inputs':{rel:{'sha256':sha(ROOT/rel)if(ROOT/rel).is_file()else None,'signature':signature}for rel,signature in raw['inputs'].items()},'inputs_current_at_freeze':inputs_current(raw),'aggregate_fingerprint_current_at_freeze':raw['fingerprint']==fingerprint('ai3'),'all_frames':images,'coverage':'not visually reviewed yet'}
  (case/'capture.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'case':key,'status':raw['status'],'warnings':raw['warnings'],'frames':len(images),'returncode':result.returncode}),flush=True)
