# Newton zh: selected-time visual QA

456 selected times: 379 native unique images directly viewed on 48 chronological sheets, 77 exact duplicate reuse. Every file frame was automatically decoded (2335 frames); this is not continuous perceptual playback/listening. Largest selected gap 1.000000s.

Movie SHA `e359d181eef3f45ed8567d9aa69226340dba9893a541aed9b99697bfab5e4b0e`; tool SHA `1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e`. Source/input/record/frame/page provenance and gaps remain in JSON.

Page 1: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 2: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 3: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 4: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 5: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 6: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 7: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 8: Actual unscaled Chinese views: chapter/header legible, first formula/why clean. Derive first and second retained-copy appends visibly double glyphs and cross retained rows (M01); final math and translations settle correctly, no frame clipping.

Page 9: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 10: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 11: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 12: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 13: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 14: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 15: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 16: Actual unscaled chronological Chinese views: third derive append also doubleprints retained row (M01); all settled formulas, why notes and 1972 history fit. Fade and two-rate panels/title/step0→1/readouts clear, no additional finding.

Page 17: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 18: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 19: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 20: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 21: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 22: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 23: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 24: Actual unscaled views: two-rate iteration1-6 lines/readouts coherent and inside axes; full fade into all70 log-gap chart. Chinese objective caption also omits penalty (C01). Plot labels and axes remain clear; no new geometry defect.

Page 25: Actual native-scale chronological views: convergence curve reveals/readout fadeins/holds clean; C01 missing objective definition persists. Fade into digits chart/first formula is legible without clipping; no additional finding.

Page 26: Actual native-scale chronological views: convergence curve reveals/readout fadeins/holds clean; C01 missing objective definition persists. Fade into digits chart/first formula is legible without clipping; no additional finding.

Page 27: Actual native-scale chronological views: convergence curve reveals/readout fadeins/holds clean; C01 missing objective definition persists. Fade into digits chart/first formula is legible without clipping; no additional finding.

Page 28: Actual native-scale chronological views: convergence curve reveals/readout fadeins/holds clean; C01 missing objective definition persists. Fade into digits chart/first formula is legible without clipping; no additional finding.

Page 29: Actual native-scale chronological views: convergence curve reveals/readout fadeins/holds clean; C01 missing objective definition persists. Fade into digits chart/first formula is legible without clipping; no additional finding.

Page 30: Actual native-scale chronological views: convergence curve reveals/readout fadeins/holds clean; C01 missing objective definition persists. Fade into digits chart/first formula is legible without clipping; no additional finding.

Page 31: Actual native-scale chronological views: convergence curve reveals/readout fadeins/holds clean; C01 missing objective definition persists. Fade into digits chart/first formula is legible without clipping; no additional finding.

Page 32: Actual Chinese native-scale views: digits append reproduces M02 doubled quadratic-error row/copy crossing, settles correct. All seven data bars, labels, formula note/underlines fit with right margin. No additional clipping/emphasis error; conditional late doubling matches measured gaps.

Page 33: Actual Chinese native-scale views: digits append reproduces M02 doubled quadratic-error row/copy crossing, settles correct. All seven data bars, labels, formula note/underlines fit with right margin. No additional clipping/emphasis error; conditional late doubling matches measured gaps.

Page 34: Actual Chinese native-scale views: digits append reproduces M02 doubled quadratic-error row/copy crossing, settles correct. All seven data bars, labels, formula note/underlines fit with right margin. No additional clipping/emphasis error; conditional late doubling matches measured gaps.

Page 35: Actual Chinese native-scale views: digits append reproduces M02 doubled quadratic-error row/copy crossing, settles correct. All seven data bars, labels, formula note/underlines fit with right margin. No additional clipping/emphasis error; conditional late doubling matches measured gaps.

Page 36: Actual Chinese native-scale views: digits append reproduces M02 doubled quadratic-error row/copy crossing, settles correct. All seven data bars, labels, formula note/underlines fit with right margin. No additional clipping/emphasis error; conditional late doubling matches measured gaps.

Page 37: Actual Chinese native-scale views: digits append reproduces M02 doubled quadratic-error row/copy crossing, settles correct. All seven data bars, labels, formula note/underlines fit with right margin. No additional clipping/emphasis error; conditional late doubling matches measured gaps.

Page 38: Actual Chinese native-scale views: digits append reproduces M02 doubled quadratic-error row/copy crossing, settles correct. All seven data bars, labels, formula note/underlines fit with right margin. No additional clipping/emphasis error; conditional late doubling matches measured gaps.

Page 39: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 40: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 41: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 42: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 43: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 44: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 45: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 46: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 47: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.

Page 48: Actual unscaled Chinese views: complete digits fade, penalty graph introduction, strong-to-weak data-point/curve reveal, loss readout and Soudry footer clear. Final holds/fade/endframe reviewed. No additional defect beyond C01/M01/M02; point samples intentionally appear separately from trail reveal.
