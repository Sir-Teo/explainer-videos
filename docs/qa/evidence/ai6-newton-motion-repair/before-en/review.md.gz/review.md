# Newton en: selected-time visual QA

440 selected times: 377 native unique images directly viewed on 48 chronological sheets, 63 exact duplicate reuse. Every file frame was automatically decoded (2171 frames); this is not continuous perceptual playback/listening. Largest selected gap 1.000000s.

Movie SHA `69bc24931e6d41f2f9d5603bc61e8ced99560364ff5cb94131a8388cd14b26c8`; tool SHA `1d0cee16ad098360ceb70f9cbc513bbce334ea107e90982ace3a7fd3df73595e`. Source/input/record/frame/page provenance and gaps remain in JSON.

Page 1: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 2: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 3: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 4: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 5: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 6: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 7: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 8: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 9: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 10: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 11: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 12: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 13: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 14: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 15: Actual native-scale chronological views: header/title clean; all three derive retained-copy appends visibly double glyphs (M01, individually inspected frames223/347/403); settled derivation correct. History card clear. Full fade then two-rate cloud introduction clear. No continuous playback or listening.

Page 16: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 17: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 18: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 19: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 20: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 21: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 22: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 23: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 24: Actual native-scale views: two-rate panels and data points stay in bounds, synchronized rounded step labels and lines; Newton/GD steps1-6/readouts clear, then fade and convergence-axis introduction. No additional concrete defect; objective disclosure C01 retained.

Page 25: Actual unscaled chronological views: 70-rate convergence curves reveal and hold without clipping, annotations clear, C01 objective disclosure missing. Fade into digits chart and first quadratic-error formula clean; pending append inspection.

Page 26: Actual unscaled chronological views: 70-rate convergence curves reveal and hold without clipping, annotations clear, C01 objective disclosure missing. Fade into digits chart and first quadratic-error formula clean; pending append inspection.

Page 27: Actual unscaled chronological views: 70-rate convergence curves reveal and hold without clipping, annotations clear, C01 objective disclosure missing. Fade into digits chart and first quadratic-error formula clean; pending append inspection.

Page 28: Actual unscaled chronological views: 70-rate convergence curves reveal and hold without clipping, annotations clear, C01 objective disclosure missing. Fade into digits chart and first quadratic-error formula clean; pending append inspection.

Page 29: Actual unscaled chronological views: 70-rate convergence curves reveal and hold without clipping, annotations clear, C01 objective disclosure missing. Fade into digits chart and first quadratic-error formula clean; pending append inspection.

Page 30: Actual unscaled chronological views: 70-rate convergence curves reveal and hold without clipping, annotations clear, C01 objective disclosure missing. Fade into digits chart and first quadratic-error formula clean; pending append inspection.

Page 31: Actual unscaled chronological views: 70-rate convergence curves reveal and hold without clipping, annotations clear, C01 objective disclosure missing. Fade into digits chart and first quadratic-error formula clean; pending append inspection.

Page 32: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 33: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 34: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 35: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 36: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 37: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 38: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 39: Actual unscaled views: digits append double glyphs/copy crossing established M02 at native1392 individually viewed; final formulas clean. All seven measured bars grow from baseline and final labels clear/inbounds; no later emphasis distortion. Fade into penalty-weight graph clear.

Page 40: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 41: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 42: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 43: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 44: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 45: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 46: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 47: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.

Page 48: Actual unscaled views: penalty sequence reveals strong-to-weak correctly; all seven plotted norms and final unpenalized loss readout coherent. Point reveals are measured samples, not moving front markers. Citation fits right edge with narrow but visible margin, final fade/end frame inspected. No extra defect beyond C01/M01/M02.
