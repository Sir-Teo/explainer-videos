"""Execute only after parent reconciles completed immutable renders; argv=lang movie_sha."""
import datetime,gzip,hashlib,json,shutil,subprocess,sys
from pathlib import Path
from PIL import Image,ImageDraw
ROOT=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai3-outro-trail-final-review');lang,expected=sys.argv[1:];assert lang in ('en','zh');dest=OUT/lang;dest.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
module=ROOT/'videos/ai/ai3/s19_outro.py';assert sha(module)=='e874a8da48693ea2c9ec75584e044d090a6bd9a39c8f0c193c1d245101a8ca24'
oldmap_path=ROOT/f'docs/qa/evidence/ai3-outro-selected-review/{lang}-selected-frame-review-map.json.gz';oldmap=json.loads(gzip.decompress(oldmap_path.read_bytes()));oldroot=Path(oldmap['audit']).parent
oldrecord_path=Path('/workspace/runtime/ai3-outro-path-front-probe')/lang/'render-record.json';oldrecord=json.loads(oldrecord_path.read_text());record_path=ROOT/f'renders/qa/series/ai3/{lang}/Outro_motion/result.json';record=json.loads(record_path.read_text());movie=ROOT/record['movie'];assert sha(movie)==expected;assert abs(oldrecord['duration']-record['duration'])<1e-8;assert oldrecord['narration']==record['narration'];assert oldrecord['inputs']==record['inputs'];shutil.copyfile(movie,dest/'Outro.mp4');shutil.copyfile(record_path,dest/'render-record.json');shutil.copyfile(module,dest/'s19_outro.py');shutil.copyfile(oldmap_path,dest/'prior-reviewed-cohort.json.gz')
a,b=(1697,1745) if lang=='en' else (1870,1918);oldby={x['source_frame']:x for x in oldmap['complete_mapping']};indices=sorted(set(oldby)|set(range(a,b+1)));frames=dest/'frames';frames.mkdir();groups=[]
for n in indices:
 if groups and n==groups[-1][-1]+1:groups[-1].append(n)
 else:groups.append([n])
terms=[f'eq(n\\,{g[0]})' if len(g)==1 else f'between(n\\,{g[0]}\\,{g[-1]})' for g in groups]
def balanced(terms):
 if len(terms)==1:return terms[0]
 mid=len(terms)//2
 return '('+balanced(terms[:mid])+'+'+balanced(terms[mid:])+')'
expr=balanced(terms);cmd=['ffmpeg','-hide_banner','-loglevel','error','-threads','1','-filter_threads','1','-filter_complex_threads','1','-i',str(dest/'Outro.mp4'),'-vf','select='+expr,'-vsync','0','-threads','1',str(frames/'%04d.png')];r=subprocess.run(cmd,capture_output=True,text=True);(dest/'ffmpeg-stderr.log').write_text(r.stderr);assert r.returncode==0,r.stderr;files=sorted(frames.glob('*.png'));assert len(files)==len(indices)
rows=[];direct=[]
for n,p in zip(indices,files):
 x={'source_frame':n,'time_seconds':n/15,'file':str(p),'sha256':sha(p),'in_every_encoded_frame_window':a<=n<=b,'in_prior_reviewed_selected_cohort':n in oldby}
 if n in oldby:
  old=oldby[n];oldp=oldroot/old['file'];assert sha(oldp)==old['sha256'];x.update(before_png=str(oldp),before_png_sha256=old['sha256'],matches_same_time_prior_PNG=x['sha256']==old['sha256'])
 if a<=n<=b or not x.get('matches_same_time_prior_PNG',False):x['review']='pending-actual-view';direct.append(x)
 else:x['review']='exact-PNG-inheritance-from-previously-actually-reviewed-same-time-cohort'
 rows.append(x)
pages=[]
for k in range(0,len(direct),8):
 chunk=direct[k:k+8];im=Image.new('RGB',(1708,2080),(11,15,22));draw=ImageDraw.Draw(im)
 for j,x in enumerate(chunk):
  xx=(j%2)*854;yy=(j//2)*520;draw.text((xx+8,yy+12),f"{lang} source{x['source_frame']} | {x['time_seconds']:.6f}s | {'full-window' if x['in_every_encoded_frame_window'] else 'changed-old-cohort'}",fill='white');im.paste(Image.open(x['file']).convert('RGB'),(xx,yy+40))
 p=dest/f'review-{k//8+1:03d}.png';im.save(p);pages.append({'file':str(p),'sha256':sha(p),'source_frames':[x['source_frame'] for x in chunk],'times':[x['time_seconds'] for x in chunk],'actually_viewed':False})
plan={'prepared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lang':lang,'source_sha256':sha(module),'source_snapshot':str(dest/'s19_outro.py'),'movie':str(dest/'Outro.mp4'),'movie_sha256':expected,'record':str(dest/'render-record.json'),'record_sha256':sha(record_path),'runtime_status':record['status'],'warnings':record['warnings'],'render_fingerprint':record['fingerprint'],'old_movie_sha256':oldmap['movie_sha256'],'old_cohort_map':str(oldmap_path),'old_cohort_map_sha256':sha(oldmap_path),'narration_exact_equal':True,'utterance_word_timing_exact_equal':True,'input_path_size_mtime_signatures_exact_equal':True,'full_movie_duration_equal':True,'duration':record['duration'],'cohort_times':len(rows),'prior_selected_cohort_times':len(oldby),'every_frame_window':[a,b],'every_frame_window_times':49,'direct_images':len(direct),'exact_same_time_PNG_inheritances':len(rows)-len(direct),'pages':pages,'mapping':rows,'ffmpeg_command':cmd,'automatic_full_file_decode':'ffmpeg select filter processed the complete movie to EOF; only indexed cohort/window frames were retained','continuous_perceptual_playback':'unverified','listening_and_audio_sync':'unverified','after_visual_review':'pending'};assert sha(movie)==expected;(dest/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({k:plan[k] for k in ('lang','cohort_times','prior_selected_cohort_times','direct_images','exact_same_time_PNG_inheritances')},indent=2));print('pages',len(pages))
