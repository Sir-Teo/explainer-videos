from pathlib import Path
import sys,json,hashlib,os,importlib.util
from PIL import Image
R=Path('/workspace/explainer-videos');B=Path(__file__).parent;OLD=Path('/workspace/runtime/ai4-gradient-motion-review')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def pixel(p):
 with Image.open(p)as im:return hashlib.sha256(im.convert('RGB').tobytes()).hexdigest()
lang=sys.argv[1];b=B/lang;old=OLD/lang;oldmap=json.loads((old/'unique-review/map.json').read_text());seenpages={p['page']:p for p in oldmap['viewed_pages']};pixelrefs={}
for page in oldmap['pages']:
 assert page['file']in seenpages and page['sha256']==seenpages[page['file']]['sha256']==sha(old/'unique-review'/page['file'])
for i,p in enumerate(oldmap['representatives']):
 f=old/'audit'/p['file'];assert sha(f)==p['sha256'];key=pixel(f);page=oldmap['pages'][i//8];pixelrefs.setdefault(key,{'source_file':str(f),'source_png_sha256':p['sha256'],'source_RGB_sha256':key,'baseline_representative_index':i,'baseline_selected_time':p['time'],'actually_viewed_page':page['file'],'actually_viewed_page_sha256':page['sha256'],'source_mapping_sha256':sha(old/'unique-review/map.json')})
audit=json.loads((b/'audit/result.json').read_text());out=b/'novel-review';out.mkdir(exist_ok=False);(out/'frames').mkdir();reps=[];maprows=[];novel={}
for i,row in enumerate(audit['selected_frames']):
 f=b/'audit'/row['file'];png=sha(f);rgb=pixel(f);mapped=dict(row,selected_index=i,sha256=png,RGB_sha256=rgb)
 if rgb in pixelrefs:mapped.update(method='exact RGB inheritance from actually viewed baseline selected PNG',baseline=pixelrefs[rgb])
 else:
  if rgb not in novel:
   novel[rgb]=len(reps);reps.append(dict(row,sha256=png,RGB_sha256=rgb));os.link(f,out/row['file'])
  mapped.update(method='novel representative requires actual view',novel_representative_index=novel[rgb])
 maprows.append(mapped)
spec=importlib.util.spec_from_file_location('qa_motion',R/'tools/qa_motion.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);pages=mod.sheets(out,reps)if reps else[]
result={'language':lang,'fresh_audit_sha256':sha(b/'audit/result.json'),'fresh_record_sha256':sha(b/'render-result.json'),'fresh_movie_sha256':sha(b/'movie.mp4'),'baseline_movie_sha256':sha(old/'movie-frozen.mp4'),'baseline_full_actual_review_sha256':sha(OLD/'review.json'),'baseline_selected_map_sha256':sha(old/'unique-review/map.json'),'selected_count':len(maprows),'inherited_exact_RGB_times':sum('baseline'in x for x in maprows),'novel_unique_RGB_groups':len(reps),'novel_duplicate_times':sum('baseline'not in x for x in maprows)-len(reps),'representatives':reps,'pages':pages,'viewed_pages':[],'complete_selected_map':maprows,'limits':'Exact byte/RGB identity only; no perceptual similarity. Raw audit points to frozen private movie; explicit render-record binding is separate. This is selected-image review, not continuous playback/audio.'};(out/'map.json').write_text(json.dumps(result,indent=2)+'\n');print(lang,{k:result[k]for k in ['selected_count','inherited_exact_RGB_times','novel_unique_RGB_groups','novel_duplicate_times']},'pages',len(pages))
