"""Private Metrics preview worker: cached data and existing speech only."""
from pathlib import Path
import sys,os,hashlib,json,runpy
R=Path('/workspace/explainer-videos');out=Path(sys.argv[1]);language=sys.argv[2];mode=sys.argv[3]
os.environ.update(EXPLAINER_CACHED_ONLY='1',EXPLAINER_TTS='silent',EXPLAINER_LANG=language,EXPLAINER_VIDEO='ai6',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
sys.path.insert(0,str(R))
from explainer import tts
from videos.ai.ai6 import compute
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reads=[];denied=[]
def deny(*a,**k):
 denied.append('producer/save/preparation/synthesis');raise RuntimeError('Metrics regression forbids producer/speech writes')
compute.CACHE._produce=deny;compute.CACHE.save=deny;compute.CACHE.prepare_inputs=deny
original=tts.synthesize
for n in ['_synth_silent','_synth_server','_synth_kokoro','_write_wav']:setattr(tts,n,deny)
def existing(text):
 _,_,key=tts.cache_key(text);paths=[tts.CACHE_DIR/(key+s) for s in ['.wav','.json']]
 if not all(p.is_file() for p in paths):raise FileNotFoundError('Existing silent speech missing; no synthesis allowed: '+key)
 before=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in paths];u=original(text);after=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in paths];assert before==after;reads.append({'key':key,'payloads':before});return u
tts.synthesize=existing
sys.argv=[str(R/'tools/qa_series.py'),'ai6','--worker','Metrics','--lang',language,'--cached-only']+(['--motion'] if mode=='motion' else [])
try:runpy.run_path(str(R/'tools/qa_series.py'),run_name='__main__')
finally:(out/'guarded-reads.json').write_text(json.dumps({'existing_speech_reads':reads,'denied_calls':denied,'worker_sha256':sha(Path(__file__))},indent=2)+'\n')
