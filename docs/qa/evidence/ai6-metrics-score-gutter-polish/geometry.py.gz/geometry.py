from pathlib import Path
import ast,json,hashlib,os,sys
R=Path('/workspace/explainer-videos');D=Path(__file__).parent;sys.path.insert(0,str(R))
from explainer.ai import *
from manim import tempconfig
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def fn(p,name):return next(n for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.FunctionDef) and n.name==name)
def execute(nodes,scope):exec(compile(ast.fix_missing_locations(ast.Module(nodes,type_ignores=[])),str(D/'geometry.py'),'exec'),scope)
def assigned(n):return isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['specs','accs','loss_top','lls','ta','tl','gA','gL'] for t in n.targets)
data=json.loads((R/'.cache/ai6/calibration.json').read_text());allresults={}
with tempconfig({'media_dir':str(D/'manim-geometry-cache'),'verbosity':'ERROR'}):
 for phase in ['before','candidate']:
  scope=dict(globals(),c=data);execute([fn(R/'videos/ai/ai6/common.py','hbars')],scope)
  for n in fn(D/(phase+'.py'),'scores').body:
   if assigned(n) or (isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='r_') or (isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n).startswith('tl.next_to(')):execute([n],scope)
  rows=[]
  for nm,bar,value in scope['accs']:
   rows.append({'name_bounds':[float(nm.get_left()[0]),float(nm.get_right()[0])],'bar_bounds':[float(bar.get_left()[0]),float(bar.get_right()[0])],'bar_width':float(bar.width),'value_bounds':[float(value.get_left()[0]),float(value.get_right()[0])],'y':float(bar.get_y())})
  a=scope['gA'];l=scope['gL'];allresults[phase]={'rows':rows,'accuracy_group_bounds':[float(a.get_left()[0]),float(a.get_right()[0]),float(a.get_bottom()[1]),float(a.get_top()[1])],'loss_group_bounds':[float(l.get_left()[0]),float(l.get_right()[0]),float(l.get_bottom()[1]),float(l.get_top()[1])],'accuracy_heading_bounds':[float(scope['ta'].get_left()[0]),float(scope['ta'].get_right()[0])]}
 old,new=allresults['before'],allresults['candidate'];assert old['loss_group_bounds']==new['loss_group_bounds']
 for a,b in zip(old['rows'],new['rows']):
  assert abs(a['bar_width']-b['bar_width'])<1e-12;assert abs(a['y']-b['y'])<1e-12
  for key in ['name_bounds','bar_bounds','value_bounds']:
   assert all(abs(v-u-.2)<1e-12 for u,v in zip(a[key],b[key]))
 assert max(x['bar_bounds'][0] for x in new['rows'])-min(x['bar_bounds'][0] for x in new['rows'])<1e-12
 fw=config.frame_width;leftpx=(new['accuracy_group_bounds'][0]+fw/2)/fw*854;assert leftpx>15;assert new['accuracy_group_bounds'][1]<new['loss_group_bounds'][0]
 result={'lang':os.environ['EXPLAINER_LANG'],'scope':'Private actual Manim geometry, no scene import/render/producer; physical source edit remains on hold.','source':{str(p.relative_to(R)):sha(p) for p in [R/'videos/ai/ai6/s17_metrics.py',R/'videos/ai/ai6/common.py',R/'videos/ai/ai_text_zh.json']},'data':sha(R/'.cache/ai6/calibration.json'),'results':allresults,'candidate_left_gutter_pixels_854':leftpx,'all_checks_passed':True}
 (D/('geometry-'+os.environ['EXPLAINER_LANG']+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(os.environ['EXPLAINER_LANG'],'candidate leftgutter854',leftpx)
