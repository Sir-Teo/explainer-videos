"""Four serial cases, released only after root's exact caption-table gate."""
from pathlib import Path
import argparse,sys,hashlib,json,shutil,subprocess,os,datetime,time,signal
R=Path('/workspace/explainer-videos');D=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--global-caption-sha256',required=True);p.add_argument('--release',choices=['root-confirmed'],required=True);a=p.parse_args()
assert sha(R/'videos/ai/ai_text_zh.json')==a.global_caption_sha256;assert sha(R/'videos/ai/ai6/s17_metrics.py')=='2f2885828585ad6464f5308e6ee97c10f188bbf668362444ebcaf7804a60ec86'
O=D/'after-frozen';assert not O.exists(),'Do not overwrite a completed/partial operation; reconcile first';O.mkdir()
critical=['videos/ai/ai6/'+n for n in ['s17_metrics.py','common.py','zh_lines.py','compute.py','cache_contract.py','contracts.py']]+['videos/ai/ai_text_zh.json','tools/qa_series.py','explainer/ai/__init__.py','explainer/ai/viz.py','explainer/voiceover.py','explainer/tts.py','explainer/lang.py','explainer/zh_text.py','explainer/zh_templates.py']
pins={rel:sha(R/rel) for rel in critical};(O/'release.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'caption_sha':a.global_caption_sha256,'source_pins':pins,'driver_sha':sha(Path(__file__)),'producer_or_synthesis_allowed':False},indent=2)+'\n');rows=[]
for mode in ['endpoints','motion']:
 for lang in ['en','zh']:
  assert all(sha(R/rel)==h for rel,h in pins.items()),'Source gate drift; pause before nextcase'
  if shutil.disk_usage(R).free<768*1024**2:raise RuntimeError('Free space below768MiB; no case started')
  case=O/lang/mode;case.mkdir(parents=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat();start_ns=time.time_ns()
  for rel in critical:
   q=case/'source-before'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,q)
  cmd=['nice','-n','10',str(R/'.venv/bin/python'),str(D/'read_only_worker.py'),str(case),lang,mode];(case/'command.json').write_text(json.dumps(cmd,indent=2)+'\n');print('START',mode,lang,flush=True)
  with (case/'process.log').open('w') as log:
   child=subprocess.Popen(cmd,cwd=R,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:
    deadline=time.monotonic()+1200
    while child.poll() is None:
     if shutil.disk_usage(R).free<768*1024**2:raise RuntimeError('Free space below768MiB during case')
     remaining=deadline-time.monotonic()
     if remaining<=0:raise subprocess.TimeoutExpired(cmd,1200)
     try:child.wait(timeout=min(2,remaining))
     except subprocess.TimeoutExpired:pass
    rc=child.returncode
   except (subprocess.TimeoutExpired,RuntimeError):
    os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    rc=-1
  src=R/'renders/qa/series/ai6'/lang/('Metrics_motion' if mode=='motion' else 'Metrics');assert (src/'result.json').stat().st_mtime_ns>=start_ns,'No fresh result; preserve process log and stop';j=json.loads((src/'result.json').read_text());names=['result.json','sheet.png','text.jsonl']+[x['file'] for x in j['frames']]
  if mode=='motion':names.extend([str(x.relative_to(src)) for x in src.rglob('*.mp4')]);names.extend([str(x.relative_to(src)) for x in src.rglob('*.narration.json')])
  copies=[]
  for n in names:
   s=src/n
   if s.exists():
    q=case/'completed'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(s,q);assert sha(s)==sha(q);assert s.stat().st_ino!=q.stat().st_ino;copies.append({'source':str(s),'copy':str(q),'sha256':sha(q),'bytes':q.stat().st_size})
  inputs=[]
  for rel,signature in j['inputs'].items():
   q=R/rel;st=q.stat();assert list(signature)==[st.st_size,st.st_mtime_ns];inputs.append({'path':rel,'sha256':sha(q),'size_mtime_ns':signature})
  drift=[rel for rel,h in pins.items() if sha(R/rel)!=h];row={'lang':lang,'mode':mode,'start':start,'completed':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':rc,'status':j['status'],'raw_warnings':j['warnings'],'fingerprint':j['fingerprint'],'copies':copies,'critical_source_drift_after':drift,'inputs_observed':inputs,'fresh_result_verified':True,'visual_approval':False};(case/'receipt.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);(O/'progress.json').write_text(json.dumps(rows,indent=2)+'\n');print('DONE',mode,lang,rc,j['status'],len(j['frames']),flush=True)
  if drift or rc not in [0,1] or j['status'] not in ['passed','needs-review']:raise RuntimeError('Preserved case; reconcile failure/source drift before nextcase')
print('CAPTURE COMPLETE; actual visual review remains pending',flush=True)
