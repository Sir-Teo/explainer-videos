# Chinese history-qualified assembly: delta join review

**PASS for reviewed joins.** Both affected joins were freshly inspected; all 16 other joins have exact-PNG inheritance from the viewed baseline. No join regression observed. Independent Gradient selected-image acceptance is recorded separately. Source publication/commit closure remains parent-owned.

Movie SHA256: `322c81224ea983f72c3e01ce6daa9a16e173e036713bcc1bfbc901158a9c6dd0`  
Duration: 3478.819813s; silent 854×480 at 15fps. Compared baseline: 3479.019813s; delta -0.200s.

All five delta sheets (37 unique PNGs) actually viewed, covering all 38 affected selected times with one exact duplicate mapped to a fresh actual view. Both affected native ±1s pairs (four images) also actually viewed and logged. Fresh viewing was required even for images matching the baseline. The other 304 times and 16 native pairs inherit only verified exact PNG hashes tied to actual baseline receipts. All 342 selected times and 18 native pairs are accounted for.

| Join | Transition | First incoming PTS | Reviewed range | Result |
|---:|---|---:|---|---|
| 2 | Derivative → Gradient | 302.354362s | 301.354362–303.354362s | Clear |
| 3 | Gradient → Jacobian | 475.420378s | 474.420378–476.420378s | Clear |

Join2 preserves the outgoing derivative/chain-rule diagram and incoming Gradient title. Join3 preserves the outgoing Cauchy card, gradient step and illustrative route, then the incoming Jacobian title. Native margins and chapter order are clear. Expected fade-down/dark-center/fade-up remains intact, with no unexpected blank gap, title clipping, collision, stale-content flash or jump observed.

Each window is ±1s around the first incoming frame PTS: every encoded frame within ±0.4s plus ±0.6, ±0.8 and ±1.0s. Full selected frame paths, SHA proofs, times, per-join boundaries and inherited native pairs are in JSON.

Exact replacement identities verified: new ZH Gradient `b4d34a09298ae83b6c21b0b254c373b32cf267c690742b7c994a5811d6a333b6`; scene source `10bac01890e68e3f86915521de9cf3b6729fe9e7934750d629360464263ceb33`; local Chinese mapping `ec04b2f4c18551b990707465209d3f4472d3b098ccf16e61a1d2d558bb089e08`. Both new Gradient movie hashes match authorization. All other 36 bilingual movie, record, sidecar, source and duration identities exactly match the baseline. All 46 raw-input/absence identities match. All 38 frozen movie/result/sidecar hashes checked.

The independent Gradient gate is **accepted within selected-image chapter review limits**, receipt SHA `528b4d7500e2fd2d73ee4b36a09277b3c836f777b581a1278ab7bd6bd7610807`, report SHA `74a19131ec0755391c105c11152bb78c82762af81e020b9870a681ae454e7333`. It resolves historical pending image-gate fields without rewriting old release/freeze receipts. This reviewer performed the bounded join review and consumed that separate chapter acceptance.

Existing exact-movie validation reports full decode of 52,182 video frames, increasing PTS/monotonic packet DTS, 19 chapters, 959 soft-subtitle cues with exact text/millisecond roundtrip and chapter bounds, and zero nonzero decoded PCM bytes. These reports are hash-bound; this reviewer did not rerun decoders or listen.

No continuous playback, full-movie every-frame visual, listening, narrated-sync, subtitle-player-display, production or 1080 motion approval. There are 51,840 full-movie frame indices outside selected join samples. Source publication/commit closure remains parent-owned. Baseline files preserved; no source/data/render/assembly/Library operations. No blockers for selected-window review.

Evidence: [actual delta receipts](/workspace/runtime/ai4-silent-preview-assembly/history-qualified/zh/validation/join-review.json), [full review](/workspace/runtime/ai4-silent-preview-assembly/history-qualified/zh-join-review.json), [Gradient acceptance](/workspace/runtime/ai4-silent-preview-assembly/history-qualified/Gradient-acceptance.json), [technical validation](/workspace/runtime/ai4-silent-preview-assembly/history-qualified/zh/validation/validation.json).
