# Fresh Chinese Brownian transition regression

PASS bounded selected-image visual regression. All repaired retained-row-copy reveals verified; no new visual defect found.

Movie `951680c1f79757e55b173201fb0cc64bd575fbab8f981b13515043d07fedef77`; direct source `780521544fd9ad5e9ab698bfeba6c8da2aa82b24b17433a93623dca69c444e9f`. Independent movie copy, raw files, source snapshots and actual inputs verified. Raw status **passed**, warnings `[]` remain unchanged.

Coverage: 453 fresh primary times plus the complete 459-time original cohort and all 44 encoded frames in 2 repaired windows. The union has 479 times: 440 exact-PNG inherited, 39 changed; all 39 changed representatives on 5 sheets and 15 fresh native checks were actually viewed. 1775 decoded frames remain outside visual approval; all gaps are listed in review.json.

The repaired rows Write separately and the prior copied-row doubles are absent. Partial new glyphs in flight are expected. Native before/mid/settled evidence and exact hashes/times are recorded. No new visual defect found.

One extra changed cloud-onset dot sample at123.467s was inspected.
Fresh native fan extrema/reference bands, raw QV path minimum,400-path mean ± across-path standard-deviation table, QV shorthand, diffusion sqrt(t) footer/heat equation/history caption remain clear.
Prior baseline optional time-axis-label crowding at the fan endpoint remains unchanged, readable, and separate from this transition repair; no new fix was made.

The old Brownian movie witness remains independently hash-verified.

Raw narration is exactly equal across old/fresh records (5 segments, canonical SHA `7b1866d97659b8c71fd0e103c02a24f8d7594eb20952c0843a85c732a27a748b`), duration exactly 150.26666666666532s in both records, and raw input signatures identical with current hashes/metadata verified. ASTs are identical after removing only the 2 authorized transform=False keywords. Frozen direct-source snapshots do not prove historical imported modules; broad raw warnings/fingerprints are preserved.

Selected still-image regression only; decoding for detection is not visual inspection. No continuous perceptual playback, narration listening/synchronization, audio-content, native1080 or unselected-frame approval. No source/global/cache/producer/model/render/commit/Library changes or new repository package by reviewer.
