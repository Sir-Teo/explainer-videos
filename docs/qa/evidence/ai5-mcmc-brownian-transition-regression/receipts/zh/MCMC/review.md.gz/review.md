# Fresh Chinese MCMC transition regression

PASS bounded selected-image visual regression. All repaired retained-row-copy reveals verified; no new visual defect found.

Movie `a2f46275a50f705295ac3b3088556e405e244c95d90f9debf42a4e766ab5a04c`; direct source `95c38c1d058a07556f26dd86fd042dbdba8e137ff4083ea9350cbd0f919655af`. Independent movie copy, raw files, source snapshots and actual inputs verified. Raw status **needs-review**, warnings `[{"kind": "source-changed-during-render"}]` remain unchanged.

Coverage: 701 fresh primary times plus the complete 705-time original cohort and all 81 encoded frames in 3 repaired windows. The union has 761 times: 683 exact-PNG inherited, 78 changed; all 78 changed representatives on 10 sheets and 16 fresh native checks were actually viewed. 2819 decoded frames remain outside visual approval; all gaps are listed in review.json.

The repaired rows Write separately and the prior copied-row doubles are absent. Partial new glyphs in flight are expected. Native before/mid/settled evidence and exact hashes/times are recorded. No new visual defect found.

Seven extra changed Langevin surface-onset representatives around148.198–149.731s were inspected; native148.198 confirms formula, t/L1 readout,1500-particle density vs600 display-points legend and grid margins remain clear.
MCMC third reveal retains the ordinary preceding ladder scroll/top-row fade; that transient scroll is separate from removed copied-row reveal.
Fresh native chain acceptance diagram and mixing traces/table/footer are readable.

Known baseline limitation: old MCMC movie witness now hashes0a8c1a39… versus recorded07ebd3ec…. Parent/root previously accepted this old-hardlink overwrite limitation; the baseline package already discloses it. No further search or witness mutation occurred. All image inheritance binds the original audit.source_sha256 and actually viewed preserved PNG/page receipts/raw records/source blobs, which verify. No historical continuous-movie approval is implied.

Raw narration is exactly equal across old/fresh records (6 segments, canonical SHA `d5c317f5da5985ab0a8966305ad33787b1bae9508bfb4f3ce7cd616b7c87a5f4`), duration exactly 238.66666666666345s in both records, and raw input signatures identical with current hashes/metadata verified. ASTs are identical after removing only the 3 authorized transform=False keywords. Frozen direct-source snapshots do not prove historical imported modules; broad raw warnings/fingerprints are preserved.

Selected still-image regression only; decoding for detection is not visual inspection. No continuous perceptual playback, narration listening/synchronization, audio-content, native1080 or unselected-frame approval. No source/global/cache/producer/model/render/commit/Library changes or new repository package by reviewer.
