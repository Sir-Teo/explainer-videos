"""Manual QA fixture: execute actual scene scheduling AST, no render/compute/model import."""
import ast
import hashlib
import json
import re
import runpy
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path('/workspace/explainer-videos')
sys.path.insert(0, str(ROOT))
from explainer import lang
from explainer.zh_templates import Translator

OUT = Path('/workspace/runtime/ai3-sgns-review')
BEFORE = OUT / 'repair-before'
AFTER = ROOT / 'videos/ai/ai3'
sg = json.loads((ROOT / '.cache/ai3/sgns.json').read_text())
steps = [int(x) for x in sg['snap_steps']]
mid = min(4, len(steps) - 1)
snaps = sg['snap_neighbours']
proper = lambda w: w.capitalize() if w in 'monday tuesday wednesday thursday friday saturday sunday'.split() else w
values = dict(steps=steps, mid=mid, snaps=snaps, proper=proper)
BOOKMARK = re.compile(r"<bookmark\s+mark=['\"]([^'\"]+)['\"]\s*/>")

def replay_tree(path):
    tree = ast.parse(path.read_text())
    return next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'replay')

def spoken(path):
    tree = replay_tree(path)
    node = next(n for n in ast.walk(tree) if isinstance(n, ast.With))
    return eval(compile(ast.Expression(node.items[0].context_expr.args[0]), str(path), 'eval'), {}, values)

def zh_before():
    # Use the actual translator on frozen original files, including its removal
    # of English thousands separators in Chinese numerical placeholders.
    with patch('explainer.zh_templates.video_dir', return_value=BEFORE):
        return Translator('ai3')(spoken(BEFORE / 's14_sgns.py'))

class Shape:
    def next_to(self, *a, **kw):
        return self

class Tracker:
    @property
    def animate(self):
        return self
    def set_value(self, value):
        return ('target', value)

def trace(path, mark_times, start):
    events = []
    class Scene:
        now = start + 1  # actual initial FadeIn has default one-second run time
        def play(self, *animations, run_time):
            value = next(a[1] for a in animations if isinstance(a, tuple) and a[0] == 'target')
            events.append(dict(start=self.now, end=self.now + run_time, step=value))
            self.now += run_time
    scene = Scene()
    class Voice:
        def wait_until(self, mark):
            scene.now = max(scene.now, mark_times[mark])
    node = next(n for n in ast.walk(replay_tree(path)) if isinstance(n, ast.For)
                and any(isinstance(c, ast.Attribute) and c.attr == 'set_value' for c in ast.walk(n)))
    marks_node = next(n for n in ast.walk(replay_tree(path)) if isinstance(n, ast.Assign)
                      and any(isinstance(t, ast.Name) and t.id == 'marks' for t in n.targets))
    env = dict(values, self=scene, vo=Voice(), cols=Shape(), heads=[Shape() for _ in range(4)],
               words=['monday', 'three', 'father', 'eyes'], column=lambda *a: Shape(),
               VGroup=lambda *a: Shape(), FadeIn=lambda *a, **kw: Shape(),
               FadeOut=lambda *a, **kw: Shape(), squish_rate_func=lambda *a: None,
               smooth=None, DOWN=None, t=Tracker())
    exec(compile(ast.Module([marks_node, node], type_ignores=[]), str(path), 'exec'), env)
    return events

before_en = spoken(BEFORE / 's14_sgns.py')
after_en = spoken(AFTER / 's14_sgns.py')
before_zh = zh_before()
after_zh = Translator('ai3')(after_en)
assert after_zh and '混杂' in after_zh and '功能词' in after_zh
assert BOOKMARK.findall(before_en) == BOOKMARK.findall(after_en) == BOOKMARK.findall(after_zh) == ['a', 'b', 'c', 'd']
assert not re.search(r'\{[^{}]+\}', after_zh)
result = dict(scope='actual scene loop AST on captured original silent bookmark times; not a fresh render or TTS timing certificate',
              measured_steps=steps, languages={}, source_sha256=hashlib.sha256((AFTER/'s14_sgns.py').read_bytes()).hexdigest())
for language, original, revised in [('en', before_en, after_en), ('zh', before_zh, after_zh)]:
    case = Path(json.loads((OUT/f'{language}-motion-current.json').read_text())['directory'])
    record = json.loads((case/'render-result.json').read_text())
    line = record['narration'][2]
    clean = lang.clean(BOOKMARK.sub('', original), language)
    assert clean == line['text'], (language, clean, line['text'])
    marks = {m.group(1): len(lang.tokens(lang.clean(BOOKMARK.sub('', original[:m.start()]), language), language))
             for m in BOOKMARK.finditer(original)}
    times = {m: line['words'][index][1] for m, index in marks.items()}
    old = trace(BEFORE/'s14_sgns.py', times, line['start'])
    new = trace(AFTER/'s14_sgns.py', times, line['start'])
    assert [e['step'] for e in old] == steps[1:]
    assert [e['step'] for e in new] == [steps[1], steps[mid], steps[-1]]
    assert all(abs(e['start'] - times[mark]) < 1e-9 for e, mark in zip(new, 'bcd'))
    holds = [dict(step=new[i]['step'], start=new[i]['end'], end=new[i+1]['start']) for i in (0, 1)]
    assert all(h['end'] > h['start'] for h in holds)
    assert any(e['start'] < times['c'] and e['step'] not in [0, steps[1]] for e in old)
    assert any(e['start'] < times['d'] and e['step'] not in [0, steps[1], steps[mid]] for e in old)
    result['languages'][language] = dict(original_movie_sha256=hashlib.sha256((case/'SGNS.mp4').read_bytes()).hexdigest(),
        actual_old_bookmark_times=times, original_events=old, repaired_events_on_old_schedule=new, repaired_holds=holds,
        original_narration=original, repaired_narration=revised,
        original_tokens=len(lang.tokens(lang.clean(BOOKMARK.sub('', original), language), language)),
        repaired_tokens=len(lang.tokens(lang.clean(BOOKMARK.sub('', revised), language), language)),
        bookmark_order=BOOKMARK.findall(revised), fresh_render_required=True)
(OUT/'replay-repair-fixture.json').write_text(json.dumps(result, indent=2, ensure_ascii=False)+'\n')
print(json.dumps({k:{n:v for n,v in row.items() if n not in ('original_narration','repaired_narration')} for k,row in result['languages'].items()}, indent=2))
print('PASS: actual old loop loses narrated states; revised loop holds both until actual next bookmark; actual EN/ZH values and bookmarks resolve.')
