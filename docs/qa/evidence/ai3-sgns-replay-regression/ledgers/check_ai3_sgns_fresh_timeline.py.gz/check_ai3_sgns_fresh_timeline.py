import ast,hashlib,json,re,sys,datetime
from pathlib import Path
ROOT=Path('/workspace/explainer-videos');sys.path.insert(0,str(ROOT))
from explainer import lang
from explainer.zh_templates import Translator
OUT=Path('/workspace/runtime/ai3-sgns-regression');OLD=Path('/workspace/runtime/ai3-sgns-review');AFTER=ROOT/'videos/ai/ai3'
sg=json.loads((ROOT/'.cache/ai3/sgns.json').read_text());steps=[int(x) for x in sg['snap_steps']];mid=min(4,len(steps)-1);snaps=sg['snap_neighbours']
proper=lambda w:w.capitalize() if w in 'monday tuesday wednesday thursday friday saturday sunday'.split() else w
values=dict(steps=steps,mid=mid,snaps=snaps,proper=proper)
fixture=ast.parse(Path('/workspace/runtime/check_ai3_sgns_replay.py').read_text())
for name in ['replay_tree','spoken','Shape','Tracker','trace']:
 node=next(n for n in fixture.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
 exec(compile(ast.Module([node],type_ignores=[]),'actual-scene-AST-fixture','exec'),globals())
v=ast.parse((ROOT/'explainer/voiceover.py').read_text());fn=next(n for n in v.body if isinstance(n,ast.FunctionDef) and n.name=='_strip_bookmarks')
_BOOKMARK=re.compile(r"<bookmark\s+mark\s*=\s*['\"]([^'\"]+)['\"]\s*/>")
exec(compile(ast.Module([fn],type_ignores=[]),'actual-production-bookmark-helper','exec'),globals())
english=spoken(AFTER/'s14_sgns.py');chinese=Translator('ai3')(english)
result=dict(scope='Actual fresh silent render narration records and production token/bookmark helper; not speech/listening evidence',reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases={})
for language in ('en','zh'):
 lang.LANG=language
 for mode in ('endpoints','motion'):
  base=Path(json.loads((OUT/f'{language}-{mode}-current.json').read_text())['directory']);old=Path(json.loads((OLD/f'{language}-{mode}-current.json').read_text())['directory'])
  record=json.loads((base/'render-result.json').read_text());prior=json.loads((old/'render-result.json').read_text());assert len(record['narration'])==len(prior['narration'])==7
  revised=english if language=='en' else chinese;clean,marks=_strip_bookmarks(revised);line=record['narration'][2];assert line['raw']==english and line['text']==clean;assert list(marks)==list('abcd')
  for i,(a,b) in enumerate(zip(record['narration'],prior['narration'])):
   if i!=2:assert a['raw']==b['raw'] and a['text']==b['text'] and abs(a['duration']-b['duration'])<1e-6
   words=a['words'];assert all(x[1]<=x[2] for x in words);assert all(x[2]<=y[1]+1e-6 for x,y in zip(words,words[1:]));assert not words or (words[0][1]>=a['start'] and words[-1][2]<=a['start']+a['duration']+1e-6)
  times={m:line['words'][idx][1] for m,idx in marks.items()};events=trace(AFTER/'s14_sgns.py',times,line['start']);assert [e['step'] for e in events]==[36,1089,10890]
  assert all(abs(e['start']-times[m])<1e-9 for e,m in zip(events,'bcd'))
  holds=[dict(step=events[i]['step'],start=events[i]['end'],end=events[i+1]['start'],duration=events[i+1]['start']-events[i]['end']) for i in (0,1)];assert all(h['duration']>0 for h in holds)
  result['cases'][f'{language}-{mode}']=dict(record_sha256=hashlib.sha256((base/'render-result.json').read_bytes()).hexdigest(),raw=english,translated=revised,clean=clean,bookmark_token_indices=marks,bookmark_times=times,repaired_events=events,holds=holds,narration_duration=line['duration'],prior_duration=prior['narration'][2]['duration'],duration_change=line['duration']-prior['narration'][2]['duration'],other_six_blocks_unchanged=True,word_times_monotonic_in_range=True,actual_record_status=record['status'],actual_record_warnings=record['warnings'])
(OUT/'narration-timing-review.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:{'holds':v['holds'],'duration_change':v['duration_change'],'bookmarks':v['bookmark_times']} for k,v in result['cases'].items()},indent=2));print('PASS all4 actual fresh records; revised EN/ZH content, abcd bookmarks, six other blocks unchanged, monotonic words and held described states.')
