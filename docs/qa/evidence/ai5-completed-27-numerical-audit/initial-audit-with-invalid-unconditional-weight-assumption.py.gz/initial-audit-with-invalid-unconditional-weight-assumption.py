"""Read-only completed-item audit. Never inspect active decoding or call producers."""
from pathlib import Path
import datetime
import hashlib
import json
import math
from fractions import Fraction
from unittest.mock import Mock, patch
import numpy as np
from scipy.special import ndtr
from scipy.stats import binom, norm
from videos.ai.ai5 import compute

ROOT = Path('/workspace/explainer-videos')
OUT = Path('/workspace/runtime/ai5-completed-27-numerical-audit')
RUN = Path('/workspace/runtime/ai5-production-compute/run-20261101T014158.404427Z')
FREEZE = Path('/workspace/runtime/ai5-production-compute/source-freeze-after-draws-fix.json')

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def signature(p):
    p = Path(p)
    if not p.exists(): return None
    st = p.stat()
    return dict(sha256=sha(p),bytes=st.st_size,mtime_ns=st.st_mtime_ns)

def serial(v):
    if isinstance(v,np.ndarray): return v.tolist()
    if isinstance(v,np.generic): return v.item()
    raise TypeError(type(v).__name__)

start = datetime.datetime.now(datetime.timezone.utc).isoformat()
names = [n for n in compute.ITEMS if n != 'decoding']
assert len(names)==27
payload_paths = [p for n in names for p in (compute.CACHE.path(n),compute.CACHE.path(n).with_suffix('.npz'))]
freeze = json.loads(FREEZE.read_text())
source_paths = [Path(p) for p in freeze['files'] if p.endswith('.py')]
before_payload = {str(p):signature(p) for p in payload_paths}
before_source = {str(p):signature(p) for p in source_paths}
for p, row in before_source.items(): assert row['sha256']==freeze['files'][p]['sha256'],p
children = {}
for n in names:
    matches = list(RUN.glob(f'[0-9][0-9]-{n}-child.json'))
    assert len(matches)==1,n
    child = json.loads(matches[0].read_text())
    assert child['status']=='passed' and child['cache_current'] is True
    for p, expected in child['outputs'].items():
        observed=before_payload[p]
        assert observed['bytes']==expected['bytes'] and observed['sha256']==expected['sha256'],p
    children[n]=dict(record_path=str(matches[0]),record_sha256=sha(matches[0]),started_utc=child['started_utc'],ended_utc=child['ended_utc'],wall_seconds=(datetime.datetime.fromisoformat(child['ended_utc'])-datetime.datetime.fromisoformat(child['started_utc'])).total_seconds())

fail=Mock(side_effect=AssertionError('producer must never run'))
data={}
current=[]
with patch.object(compute.CACHE,'_produce',fail), patch.object(compute.CACHE,'items',{n:fail for n in compute.ITEMS}):
    for n in names:
        assert compute.cache_current(n) is True,n
        data[n]=compute.CACHE.load(n)
        current.append(n)
    fail.assert_not_called()

checks=[]
def check(label, condition, **evidence):
    good=bool(condition)
    checks.append(dict(check=label,passed=good,**evidence))
    if not good:
        (OUT/'failure.json').write_text(json.dumps(checks[-1],indent=2,default=serial))
        raise AssertionError(label)

# Exact lattice tail: read stored enumeration; independently evaluate the modest
# cached domain, never re-enter the Monte Carlo/default producer.
t=data['tails']; tails=np.asarray(t['exact_tail_by_n']); cutoff=int(t['certified_cutoff'])
threshold=Fraction(1,2)+Fraction(str(t['e0']))
independent=np.array([binom.sf((n*threshold.numerator+threshold.denominator-1)//threshold.denominator-1,n,.5) for n in range(1,cutoff+1)])
minimum=1+int(np.flatnonzero(tails<=t['d0'])[0]); eventual=2+int(np.flatnonzero(tails>t['d0'])[-1])
check('tails exact inclusive lattice enumeration and certified suffix',len(tails)==cutoff and np.allclose(tails,independent,rtol=0,atol=1e-15) and minimum==t['need']['exact']==262 and eventual==t['need']['exact_eventual']==281 and math.exp(-2*cutoff*t['e0']**2)<=t['d0'],minimum=minimum,eventual=eventual,cutoff=cutoff,need=t['need'],last_failed_n=eventual-1,last_failed_tail=float(tails[eventual-2]),first_qualifying_tail=float(tails[minimum-1]),eventual_first_tail=float(tails[eventual-1]),maximum_formula_difference=float(np.max(abs(tails-independent))),scope=t['sample_size_scope'])

s=data['scorefn']; x,y=-1.2,1.4; sig=s['sig']
expected=np.array([-2*(1-x)-20*x*(y-x*x)+60*x*sig*sig,10*(y-x*x)-10*sig*sig])
check('ES analytic Gaussian-smoothed gradient reference',np.allclose(s['gradient_reference'],expected,rtol=0,atol=1e-12),observed=s['gradient_reference'],expected=expected,scope=s['gradient_reference_scope'])
es={}
for method in ['plain','base']:
    steps=np.asarray(s['actual_steps_'+method]); calls=np.asarray(s['evaluations_'+method]); finals=np.asarray(s['final_'+method]); paths=np.asarray(s['paths_'+method])
    failed=finals==-1
    check('ES '+method+' actual evaluation budget and declared failure rows',steps.shape==(8,) and calls.shape==(8,) and steps.dtype.kind in 'iu' and np.all((steps>=0)&(steps<=s['steps'])) and np.array_equal(calls,steps*s['pop']) and int(failed.sum())==s['div_'+method] and np.all(np.isfinite(finals)) and not np.isinf(paths).any() and all(np.isfinite(row).all() or failed[i] for i,row in enumerate(paths)),actual_steps=steps,evaluations=calls,cap_steps=s['steps'],population=s['pop'],failed_count=int(failed.sum()),final_values_or_minus1=finals,display_path_shape=paths.shape,nan_display_values=int(np.isnan(paths).sum()))
    es[method]=dict(actual_steps=steps,evaluations=calls,failed_count=int(failed.sum()),final_values_or_minus1=finals)

f=data['fisher']; reports=f['fit_reports']
check('Cauchy multistart report is stationarity evidence, no global certificate',f['global_optimum_certified'] is False and len(reports)==len(f['ns']) and all(r['global_optimum_certified'] is False and r['R']==f['R'] and r['n']==n and 0<=r['stationary_count']<=r['R'] and np.isfinite(r['max_score_residual']) for r,n in zip(reports,f['ns'])),R=f['R'],ns=f['ns'],reports=reports,scope=f['fit_scope'],variance_se_scope=f['variance_se_scope'],score_mean=f['score_mean'],score_variance=f['score_var'],mle_nvar=f['mle_nvar'],median_nvar=f['med_nvar'])

mc=data['montecarlo']; z=np.asarray(mc['plain_z']); idx=np.asarray(mc['plain_plot_indices']); w=np.asarray(mc['is_w_full']); wplot=np.asarray(mc['is_w']); hits=np.flatnonzero(z>4)
check('Monte Carlo genuine full rare-event cohort and plot index selection',z.shape==(mc['n'],) and np.isfinite(z).all() and mc['plain_hits']==len(hits) and mc['plain_est']==len(hits)/mc['n'] and idx.dtype.kind in 'iu' and np.array_equal(idx,np.union1d(np.arange(min(400,mc['n'])),hits)) and len(w)==mc['n'] and np.isfinite(w).all() and np.all(w>=0) and np.array_equal(wplot,w[:len(wplot)]) and np.isclose(mc['is_est'],w.mean(),rtol=1e-14,atol=1e-20),n=mc['n'],plain_hits=len(hits),hit_indices=hits,hit_coordinates=z[hits],plain_estimate=mc['plain_est'],importance_estimate=mc['is_est'],truth=mc['true'],plot_count=len(idx),full_weight_count=len(w),first400_weight_count=len(wplot),positive_full_weights=int((w>0).sum()))
e=data['ess']; proxy=float(w.sum()**2/(w*w).sum())
check('Importance-weight ESS proxy uses all actual rare-event weights',e['n_rare']==len(w) and np.isclose(e['ess_rare'],proxy,rtol=1e-14) and 1<=proxy<=len(w) and np.all((e['ess']>=1)&(e['ess']<=e['n']*(1+1e-12))),ess_rare=e['ess_rare'],independent_proxy=proxy,n_rare=e['n_rare'],n_multidimensional=e['n'],dimension_cohort_shape=np.asarray(e['ess']).shape,dims=e['dims'],median_ess=np.median(e['ess'],axis=0),scope='Weight-concentration diagnostic; no independent Monte Carlo error or theorem-certified effective sample count.')

# Normalize the mixture by actual integrated component masses, then use
# standard Gaussian truncated moments; independent of production helper call.
amp=np.array([1.,.7]); variance=np.array([.35,.25]); mu=np.array([-1.6,1.5]); masses=amp*variance; masses/=masses.sum(); sd=np.sqrt(variance); a=-mu/sd
prob=norm.cdf(a); phi=norm.pdf(a); mass=float(masses@prob); first=float(masses@(mu*prob-sd*phi)); second=float(masses@((mu*mu+variance)*prob-sd*mu*phi)); varleft=second/mass-(first/mass)**2
m=data['mcmc']; l=data['langevin']
check('Sampler references distinguish halfspace from component membership',np.isclose(m['true_left_halfspace'],mass,rtol=0,atol=1e-14) and np.isclose(l['true_left_halfspace'],mass,rtol=0,atol=1e-14) and np.isclose(l['true_spread_left_halfspace'],varleft,rtol=0,atol=1e-14),actual_halfspace_mass=mass,actual_conditional_x_variance=varleft,legacy_component_weight=m['true_left'],observed_mcmc_halfspace_fraction=m['left'],mcmc_acceptance=m['accept'],observed_flow_left=l['flow_left'],scope='Spread is coordinate variance, not standard deviation. Mixture components overlap across x=0.')

# Histograms are bin averages conditioned on the display window, not nearby
# point densities; independent ndtr integration on the actual saved bin edges.
d=data['diffusion']; edges=np.asarray(d['hist_edges']); weights=np.array([.45,.55]); original_mu=np.array([-1.5,1.2]); original_sd=np.array([.35,.5]); exact_bins=[]; point_errors=[]
for k,tau in enumerate(d['fp_ts']):
    alpha=math.exp(-tau); means=math.sqrt(alpha)*original_mu; vars_=alpha*original_sd**2+1-alpha
    cdf=ndtr((edges[:,None]-means)/np.sqrt(vars_))@weights
    bins=np.diff(cdf)/((cdf[-1]-cdf[0])*np.diff(edges)); exact_bins.append(bins)
    xs=np.asarray(d['xs']); exact=(weights[:,None]*np.exp(-.5*(xs[None]-means[:,None])**2/vars_[:,None])/np.sqrt(2*math.pi*vars_[:,None])).sum(0)
    point_errors.append(float(np.abs(d['fp'][k]-exact).max()))
exact_bins=np.asarray(exact_bins); hist_errors=np.max(np.abs(d['fp_hist']-exact_bins),axis=1)
check('Diffusion histogram metric compares exact conditional bin averages',edges.shape==(81,) and exact_bins.shape==(5,80) and np.allclose(d['exact_hist_density'],exact_bins,rtol=1e-13,atol=1e-14) and np.allclose(d['hist_err'],hist_errors,rtol=1e-13,atol=1e-14) and np.allclose(d['fp_err'],point_errors,rtol=1e-12,atol=1e-14),histogram_shape=np.asarray(d['fp_hist']).shape,exact_histogram_shape=exact_bins.shape,bin_widths=np.unique(np.round(np.diff(edges),12)),hist_errors=hist_errors,fp_pointwise_errors=point_errors,exact_histogram_integrals=(exact_bins*np.diff(edges)).sum(1),observed_histogram_integrals=(d['fp_hist']*np.diff(edges)).sum(1),scope=d['hist_metric_scope'])

# Small exact algebra checks directly from already produced arrays.
g=data['gauss']; check('Gaussian factorization and conditional covariance',np.allclose(g['L']@g['L'].T,g['S'],atol=1e-12) and np.all(np.linalg.eigvalsh(g['C4'])>=-1e-12),factorization_max_error=float(np.max(abs(g['L']@g['L'].T-g['S']))),conditional_cov_eigenvalues=np.linalg.eigvalsh(g['C4']),slice_count=g['n_slice'],four_dimensional_cohort=g['n4'])
gb=data['galton']; ml=data['mle']; check('Galton MLE moments refer to full actual bins',len(gb['bins'])==gb['n']==ml['n'] and np.isclose(ml['mu_hat'],np.mean(gb['bins']),rtol=0,atol=1e-14) and np.isclose(ml['sigma_hat'],np.std(gb['bins']),rtol=0,atol=1e-14),n=ml['n'],mean=ml['mu_hat'],standard_deviation=ml['sigma_hat'],likelihood_unit='nats per ball; density log-likelihood')
dr=data['draws']; check('Rejection-sampling rectangle uses density-coordinate heights',np.max(dr['up'])<=dr['M'] and dr['M']>0 and np.asarray(dr['acc']).dtype.kind=='b',envelope_M=dr['M'],maximum_display_height=float(np.max(dr['up'])),ordinates_above_one=int((dr['up']>1).sum()),stored_display_proposals=len(dr['xp']),acceptance_rate_full_cohort=dr['rate'])

nonfinite=[]
for name, dct in data.items():
    for key,v in dct.items():
        if isinstance(v,np.ndarray) and v.dtype.kind in 'iuf' and not np.isfinite(v).all():
            nonfinite.append(dict(item=name,field=key,shape=v.shape,nan=int(np.isnan(v).sum()),posinf=int(np.isposinf(v).sum()),neginf=int(np.isneginf(v).sum())))
allowed=all(row['item']=='scorefn' and row['field'] in ('paths_plain','paths_base') and row['posinf']==row['neginf']==0 for row in nonfinite)
check('Nonfinite arrays limited to explicitly failed trajectory gaps',allowed,arrays=nonfinite)

# Summaries are observations, not a claim that every scalar is a theorem.
summary={}
for n,dct in data.items():
    summary[n]={'scalars':{k:v for k,v in dct.items() if isinstance(v,(str,int,float,bool)) or v is None},'arrays':{k:dict(shape=list(v.shape),dtype=str(v.dtype)) for k,v in dct.items() if isinstance(v,np.ndarray)}}

after_payload={str(p):signature(p) for p in payload_paths}; after_source={str(p):signature(p) for p in source_paths}
check('All completed payload bytes and mtimes preserved',before_payload==after_payload,count=len(before_payload),present_count=sum(v is not None for v in before_payload.values()))
check('All frozen Python source bytes and mtimes preserved',before_source==after_source,count=len(before_source))
report=dict(started_utc=start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Read-only27 completed non-decoding items. Active decoding,currentness,partialfiles and modelstate explicitly excluded.',items=current,producer_calls=0,actual_load_count=len(data),checks=checks,payload_signatures_before=before_payload,payload_signatures_after=after_payload,source_signatures_before=before_source,source_signatures_after=after_source,producer_child_records=children,driver_freeze=dict(path=str(FREEZE),sha256=sha(FREEZE)),item_summaries=summary,limits=['Cache currentness proves the declared recipe/dependency/payload/CRC contracts, not scientific truth of every claim.','No producer, training, model inference, font/scene render, active decoding currentness, or decoder partial/model-state read.','Statistics from saved stochastic cohorts are observations, not guarantees about future seeds or estimator error.','Sampler stored trace subsets do not reconstruct every full-cohort reported statistic.','Cauchy multistart stationary candidates are not certified global maximum likelihood estimates.','ES equal caps allow unequal actual probe counts on early-stopped runs; display paths are clipped/downsampled and failedsentinel-1 is not a successful objective.','This audit independently evaluates small analytic identities and saved arrays, without re-entering default numerical experiments.'])
(OUT/'report.json').write_text(json.dumps(report,indent=2,default=serial,allow_nan=False))
print(json.dumps(dict(items=len(data),checks=len(checks),passed=all(c['passed'] for c in checks),producer_calls=fail.call_count,report_sha256=sha(OUT/'report.json'),nonfinite=nonfinite),indent=2,default=serial))
