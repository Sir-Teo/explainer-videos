from pathlib import Path
import json,hashlib,subprocess,os,sys,time,datetime,shutil,signal
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/entropy-prefix-v8-scoped-checks');D.mkdir(exist_ok=False)
H=R/'docs/qa/evidence/production-handoff-parts1-3'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def inventory():
 files=set((R/'explainer').rglob('*.py'))
 files.update((R/'tests').glob('test_ai1_*timing.py'));files.update((R/'tests').glob('test_production_handoff*.py'))
 for name in ['s01_hook','s02_probability','s03_surprise','s04_entropy','s05_prefix']:files.add(R/'videos/ai/ai1'/f'{name}.py')
 for name in ['s08_svd','s19_outro']:files.add(R/'videos/ai/ai3'/f'{name}.py')
 files.update(p for p in H.glob('*') if p.suffix in ['.py','.json']);files.update((H/'overlays').glob('*.json'))
 for name in ['pyproject.toml','uv.lock','requirements.txt','manim.cfg']:
  if (R/name).is_file():files.add(R/name)
 return [{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(files) if p.is_file() and '__pycache__'not in p.parts]
assert shutil.disk_usage(R).free>536870912+4*1024**2
before=inventory();(D/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
names=sorted({p.stem for p in (R/'tests').glob('test_ai1_*timing.py')}|{p.stem for p in (R/'tests').glob('test_production_handoff*.py')})
env=os.environ.copy();env.pop('EXPLAINER_CACHED_ONLY',None);env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=str(R/'tests')+os.pathsep+str(R))
started=now();t=time.monotonic();observations=[]
with(D/'unittest.log').open('w')as log:
 process=subprocess.Popen([sys.executable,'-m','unittest','-v',*names],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while process.poll()is None:
  free=shutil.disk_usage(R).free;observations.append({'at':now(),'free_bytes':free})
  if free<536870912 or time.monotonic()-t>300:
   os.killpg(process.pid,signal.SIGTERM);process.wait(timeout=10);raise RuntimeError('Owned scoped checks stopped at resource/time guard')
  time.sleep(.5)
after=inventory();(D/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'started_utc':started,'ended_utc':now(),'elapsed_seconds':time.monotonic()-t,'returncode':process.returncode,'test_modules':names,'inventoried_repository_files':len(before),'source_unchanged':before==after,'minimum_observed_free_bytes':min(r['free_bytes']for r in observations),'disk_hardstop_bytes':536870912,'scope':'Part1 timing and strict production-gate tests only; Part7 edits not included or approved. Relevant selected repository source/test/gate/config bytes inventoried, not a whole-import-closure or whole-repository test claim.'}
(D/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');(D/'storage-observations.json').write_text(json.dumps(observations,indent=2)+'\n');print(json.dumps(receipt,indent=2));assert process.returncode==0 and before==after
