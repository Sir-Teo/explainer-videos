from pathlib import Path
import json,hashlib,datetime,subprocess,sys,os,time
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-hook-caption-integration');D.mkdir(exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest();p=R/'videos/ai/ai_text_zh.json';before=p.read_bytes();assert h(before)=='bd0a9a0ff4671f8211857804ff71cd380360ba7a9d318a210f563ca75b3f8caa'
proposal=Path('/workspace/runtime/ai6-hook-split-polish/v2/local-caption-proposal.json').read_bytes();assert h(proposal)=='98204b73f56f4eef8fd344928d403e5d9267ab15dda3a6749cc2104caf46fc47'
delta=json.loads(proposal);delta={k:delta[k] for k in ['strings','patterns']};assert len(delta['strings'])==2 and len(delta['patterns'])==3
(D/'before-ai_text_zh.json').write_bytes(before);(D/'caption-add.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2)+'\n')
prior=Path('/workspace/runtime/ai6-caption-integration');oldreport=json.loads((prior/'report.json').read_text());assert oldreport['current_table_sha256']==h(before)
for rel,sha in oldreport['lookup_code_sha256'].items():assert h((R/rel).read_bytes())==sha,rel
for item in oldreport['collected_files']:
 b=(R/item['path']).read_bytes();assert h(b)==item['sha256'] and len(b)==item['bytes'],item['path']
subprocess.run([sys.executable,'tools/text_zh_add.py','ai',str(D/'caption-add.json')],cwd=R,check=True)
after=p.read_bytes();a=json.loads(after);b=json.loads(before)
assert a['patterns']==b['patterns']+delta['patterns'];assert all(a['strings'][k]==v for k,v in b['strings'].items());assert len(a['strings'])==len(b['strings'])+2
for k in set(b)-{'patterns','strings'}:assert a[k]==b[k]
(D/'after-ai_text_zh.json').write_bytes(after)
os.environ['EXPLAINER_VIDEO']='ai6';sys.path.insert(0,str(R));from explainer import lang,zh_text;lang.LANG='zh';zh_text._TABLE=a;zh_text._BY_NUMBERS=None
used=json.loads((prior/'used-caption-results.json').read_text());t=time.monotonic();results=[];diff=[]
for row in used:
 actual=zh_text.translate(row['english']);out=dict(english=row['english'],before=row['after'],after=actual,occurrences=row['occurrences'],contexts=row['contexts']);results.append(out)
 if row['after']!=actual:diff.append(out)
checks={s:zh_text.translate(s) for s in delta['strings']}
assert checks==delta['strings'],checks
for s,expected in [('training pages: $448$','训练页：$448$'),('held-out pages: $191$','留出页：$191$'),('$632$ shown; $7$ outside view','显示$632$页；$7$页在视野外')]:
 checks[s]=zh_text.translate(s);assert checks[s]==expected,(s,checks[s])
assert p.read_bytes()==after
report=dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_table_sha256=h(before),current_table_sha256=h(after),added_strings=2,added_patterns=3,changed_existing_entries=0,collected_files=oldreport['collected_files'],collected_rows=oldreport['collected_rows'],unique_strings=len(used),changed_outputs=len(diff),differences=diff,new_caption_checks=checks,lookup_code_sha256=oldreport['lookup_code_sha256'],prior_comparison_report_sha256=h((prior/'report.json').read_bytes()),prior_used_outputs_sha256=h((prior/'used-caption-results.json').read_bytes()),elapsed_s=time.monotonic()-t,scope='Actual retained Part1–5 caption strings only. Baseline outputs inherit exact earlier bd0 table/lookups/capture bytes, each new output is independently evaluated. No render/audio/perception/invisible branches approval; no compute imports or producers.')
(D/'used-caption-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');(D/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['collected_files','differences','lookup_code_sha256']},ensure_ascii=False,indent=2));assert not diff
