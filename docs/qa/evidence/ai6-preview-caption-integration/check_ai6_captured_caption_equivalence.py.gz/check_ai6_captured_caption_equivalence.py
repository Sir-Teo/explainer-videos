from pathlib import Path
import json,hashlib,os,sys,datetime,time
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-current-caption-case-equivalence');D.mkdir(exist_ok=False);h=lambda b:hashlib.sha256(b).hexdigest()
roots=[Path('/workspace/runtime/ai6-hook-split-polish/v2/after-frozen'),Path('/workspace/runtime/ai6-lsq-gauss-review'),Path('/workspace/runtime/ai6-remaining-qa-serial/runs/20261101T053852/04-Ridge/en')];files=[];contexts={}
for root in roots:
 for p in sorted(root.rglob('text.jsonl')):
  raw=p.read_bytes();rows=[json.loads(x) for x in raw.decode().splitlines() if x.strip()];files.append(dict(path=str(p),bytes=len(raw),sha256=h(raw),rows=len(rows)))
  for i,row in enumerate(rows,1):contexts.setdefault(row['s'],[]).append(dict(path=str(p),line=i))
assert len(files)>=8 and len(contexts)>70
sources={'bd0':Path('/workspace/runtime/ai6-hook-caption-integration/before-ai_text_zh.json'),'da401':Path('/workspace/runtime/ai6-consumer-caption-integration/before-ai_text_zh.json'),'current':R/'videos/ai/ai_text_zh.json'};tables={k:p.read_bytes() for k,p in sources.items()};assert h(tables['current'])=='0e4bad42c0f78534fd66d1ad52caaff9d975ba1ae0940fe9f86ab9d610e3d47a'
os.environ['EXPLAINER_VIDEO']='ai6';sys.path.insert(0,str(R));from explainer import lang,zh_text;lang.LANG='zh';outputs={};t=time.monotonic()
for name,raw in tables.items():
 zh_text._TABLE=json.loads(raw);zh_text._BY_NUMBERS=None;outputs[name]={s:zh_text.translate(s) for s in contexts}
differences={name:[dict(english=s,before=outputs[name][s],current=outputs['current'][s],contexts=contexts[s]) for s in contexts if outputs[name][s]!=outputs['current'][s]] for name in ['bd0','da401']}
report=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_files=files,table_identities={name:dict(path=str(sources[name]),sha256=h(raw),bytes=len(raw)) for name,raw in tables.items()},unique_captured_strings=len(contexts),rows=sum(x['rows'] for x in files),changed_outputs={name:len(rows) for name,rows in differences.items()},differences=differences,elapsed_s=time.monotonic()-t,scope='Raw translator outputs only on actual frozen Hook/LeastSquares/Ridge captions. Two observed prior table candidates compared independently; no claim of exact historical imported-table timing. Does not relabel raw source-change warnings or grant audio/visual/geometry approval.')
(D/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(D/'actual-results.json').write_text(json.dumps(dict(outputs=outputs,contexts=contexts),ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['source_files','differences']},ensure_ascii=False,indent=2));assert not any(differences.values())
