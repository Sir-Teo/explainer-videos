from pathlib import Path
import json,hashlib,datetime,subprocess,sys,os,time
R=Path('/workspace/explainer-videos');D=Path('/workspace/runtime/ai6-consumer-caption-integration');D.mkdir(exist_ok=False)
h=lambda b:hashlib.sha256(b).hexdigest();p=R/'videos/ai/ai_text_zh.json';before=p.read_bytes();assert h(before)=='da401f2e66a875261f0a135c9cda9326100ea5b9f8a7b70140712224537717b4'
proposal=Path('/workspace/runtime/ai6-scientific-consumer-polish/caption-add.json').read_bytes();assert h(proposal)=='3c396bb9221c7e8a140921f7b8f440e1af8a3c029d51cb9cc925358742289a02';delta=json.loads(proposal);assert set(delta)=={'strings'} and len(delta['strings'])==4
(D/'before-ai_text_zh.json').write_bytes(before);(D/'caption-add.json').write_bytes(proposal)
prior=Path('/workspace/runtime/ai6-hook-caption-integration');oldreport=json.loads((prior/'report.json').read_text());assert oldreport['current_table_sha256']==h(before)
for rel,sha in oldreport['lookup_code_sha256'].items():assert h((R/rel).read_bytes())==sha,rel
for item in oldreport['collected_files']:
 b=(R/item['path']).read_bytes();assert h(b)==item['sha256'] and len(b)==item['bytes'],item['path']
subprocess.run([sys.executable,'tools/text_zh_add.py','ai',str(D/'caption-add.json')],cwd=R,check=True)
after=p.read_bytes();a=json.loads(after);b=json.loads(before);assert a['patterns']==b['patterns'];assert all(a['strings'][k]==v for k,v in b['strings'].items());assert len(a['strings'])==len(b['strings'])+4
for k in set(b)-{'patterns','strings'}:assert a[k]==b[k]
(D/'after-ai_text_zh.json').write_bytes(after)
os.environ['EXPLAINER_VIDEO']='ai6';sys.path.insert(0,str(R));from explainer import lang,zh_text;lang.LANG='zh';zh_text._TABLE=a;zh_text._BY_NUMBERS=None
used=json.loads((prior/'used-caption-results.json').read_text());t=time.monotonic();results=[];diff=[]
for row in used:
 actual=zh_text.translate(row['english']);out=dict(english=row['english'],before=row['after'],after=actual,occurrences=row['occurrences'],contexts=row['contexts']);results.append(out)
 if row['after']!=actual:diff.append(out)
checks={s:zh_text.translate(s) for s in delta['strings']};assert checks==delta['strings'],checks
assert p.read_bytes()==after
report=dict(completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),baseline_table_sha256=h(before),current_table_sha256=h(after),added_strings=4,added_patterns=0,changed_existing_entries=0,collected_files=oldreport['collected_files'],collected_rows=oldreport['collected_rows'],unique_strings=len(used),changed_outputs=len(diff),differences=diff,new_caption_checks=checks,lookup_code_sha256=oldreport['lookup_code_sha256'],prior_comparison_report_sha256=h((prior/'report.json').read_bytes()),prior_used_outputs_sha256=h((prior/'used-caption-results.json').read_bytes()),elapsed_s=time.monotonic()-t,scope='Actual retained Part1–5 caption strings only. Baseline outputs inherit exact earlier da401 table/lookups/capture bytes, each new output independently evaluated. No render/audio/perception/unseen-branches approval; no compute imports or producers.')
(D/'used-caption-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');(D/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['collected_files','differences','lookup_code_sha256']},ensure_ascii=False,indent=2));assert not diff
