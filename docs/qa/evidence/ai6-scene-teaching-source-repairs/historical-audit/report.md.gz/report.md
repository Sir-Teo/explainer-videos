# Part6 scene-source audit (read only)

Source HEAD observed: `91266d222f3c2799159dd66df2b42a94c028f458`. Exact Part6 file hashes are in `source-inventory.json` (SHA256 `873f381673e36f05e9c7f05ae89950f63d8c016afa3c3292448e58ef0e7c5494`). No production imports, data/model jobs, tests, renders or source edits were performed.

The review confirms the following source/analytical issues. They do not assert that current default data or rendered output failed. Root owns implementation after the Part5 gate; the other reviewer owns train/test/CV/metric/producer fairness.

## F01 — Whitening picture labels the full inverse as the whitening transform

References: {"s09_lda.py": [96, 121, 143, 154], "text_zh_add.json": [502]}.

With S=diag(4,1), applying S^-1 to the cloud gives covariance S^-1 S S^-T=diag(1/4,1), not identity. The correct whitening map W=S^-1/2 gives WSW^T=I. In whitened coordinates z=Wx the mean difference is delta_z=W delta; pull its separating normal back via w=W^T delta_z=S^-1 delta. Final Fisher formula is correct; the intermediate visual explanation conflates these two stages.

Suggested correction: Label/animate whitening by S_W^-1/2; show mean direction in whitened coordinates and a distinct pullback normal to original coordinates. Preserve w proportional S_W^-1 delta; do not merely replace that final formula by inverse square root.

EN/ZH coordination: zh_lines.py:184 (whitening narration); text_zh_add.json strings key make pooled within-author scatter round... . Suggested: 用S_W的逆平方根把散布白化；在白化坐标里连接两类中心，再把这个法向量映回原坐标，得到S_W的逆乘以均值之差。

## F02 — Fisher stationary derivation omits the zero-eigenvalue stationary branch

References: {"s09_lda.py": [218, 220, 221, 268, 269]}.

S_W=I2, delta=(1,0), w=(0,1): J(w)=0 and gradient J=0, so the shown generalized eigencondition holds, yet w is not proportional to S_W^-1 delta. The quotient has minimizing stationary vectors as well as its maximizing direction.

Suggested correction: State S_W positive definite and delta nonzero, choose the largest positive eigenvalue/maximizer before deriving the inverse-mean direction. Keep arbitrary stationary eigencondition distinct from maximizer.

EN/ZH coordination: zh_lines.py:192 repeats the stationary-to-answer inference. Suggested qualifier: 取最大的正特征值对应的方向；零特征值的驻点并不是最大分离方向。

## F03 — Cosine agreement of LDA and least squares does not establish the same classifier line

References: {"s09_lda.py": [262, 263, 271], "compute.py": [714, 716, 717, 718]}.

Eight 1D training rows: class0 x=(-1,1) repeated3times; class1 x=(1,3). Means0 and2, class proportions3/4 and1/4. Least-squares slope3/14, intercept1/7, so 0.5threshold is x=5/3. LDA midpoint cut is x=1. Their normals point the same way (cosine1), but boundaries differ. The actual code only checks slope cosine, while narration says same line.

Suggested correction: Say same coefficient direction up to scale, with threshold/intercept chosen separately. Do not claim equal decision boundaries from cos_ls alone.

EN/ZH coordination: zh_lines.py:195 says 两者是同一条直线; replace with 权重方向相同，但截距与分类阈值仍需另行确定。

## F04 — Ridge coordinate weights need not shrink monotonically or avoid exact zeros

References: {"s04_ridge.py": [145, 148, 155, 159], "text_zh_add.json": [477]}.

Take Z^T Z=[[2,1],[1,2]],Z^T y=(1,3). Then w1(lambda)=(lambda-1)/((lambda+2)^2-1), so w1(3)=1/12,w1(1)=0,w1(0)=-1/3. Coordinates can cross zero and be nonmonotone even though singular-direction shrink factors are monotone. Source zeros counts abs(coef)<1e-12 across sampled path cells, not mathematical exact zeros and not distinct weights.

Suggested correction: Use coordinate paths vary smoothly, while singular components shrink monotonically. Label zero statistic as sampled coefficients below numerical tolerance and distinguish cells from distinct words; do not infer universal nonzero coordinates.

EN/ZH coordination: zh_lines.py:405–407 repeats every-weight monotone growth/exact-zero wording; local caption 每个权重都平滑地收缩 should distinguish 原坐标系权重路径平滑变化 from 奇异方向上的收缩因子。

## F05 — Hinge loss is called smooth alongside logistic loss

References: {"s12_svm.py": [120, 121, 122]}.

h(m)=max(0,1-m) has left derivative -1 and right derivative0 at m=1; it is convex but nonsmooth. Counting0/1 loss can be optimized by non-gradient/combinatorial methods; cannot be optimized is too absolute.

Suggested correction: Say convex surrogates; logistic is smooth and hinge uses subgradients. Say0/1 loss is difficult for gradient-based optimization.

EN/ZH coordination: zh_lines.py:246 repeats 两者都是凸的...平滑替身 and 后者没法优化. Suggested: 两者都是凸替代损失；逻辑损失光滑，铰链损失在间隔1处有折角。

## F06 — Arbitrary movement of a non-support point can change the SVM

References: {"s12_svm.py": [78]}.

1D hard-margin points: negative -1,positive1,positive2. The point at2 is not a support vector; moving it to0.5 changes the maximum-margin interval and boundary. Invariance only holds while moved point stays safely outside the same margin and other problem conditions remain fixed.

Suggested correction: Qualify move non-support points without entering the margin; preserve support constraints.

EN/ZH coordination: zh_lines.py:243 says 移动其他任何一个点，什么都不会改变; add 只要它仍留在原间隔外侧。

## F07 — Boosting Taylor equation adds regularization only on the right

References: {"s16_gboost.py": [27, 28, 30]}.

The first row puts sum_i loss(y_i,F_i+f_i) on the left, but Taylor sum plus gamma*T+(lambda/2)sumw_j^2 on the right. At f=0 with T=1,gamma>0, Taylor loss equals original loss exactly yet RHS differs by gamma. This is an objective definition mismatch, not approximation error.

Suggested correction: Add Omega(f)=gammaT+lambda||w||^2/2 to the left objective, or introduce it as a separate objective after expanding only the loss.

EN/ZH coordination: zh_lines.py:317 narrates plus a price on leaves and their weights; keep that explanation but make the visual LHS regularized. Formula itself is language independent.

## F08 — A split cannot purify both children while giving zero error-rate gain

References: {"s13_trees.py": [179, 181, 212, 213, 214]}.

Gain=i(parent)-a*i(left)-(1-a)*i(right),0<a<1. If both child impurities are strictly below parent, their weighted average is strictly below parent, hence gain>0. A valid zero-error-gain example is parent p=.2,left p=.1,right p=.3,equal sizes: .2-(.1+.3)/2=0. Children differ, one purer and one less pure.

Suggested correction: Say different child proportions can give zero classification-error gain if both remain on the same side of1/2. Preserve measured tree/threshold values; no default data failure asserted.

EN/ZH coordination: zh_lines.py:264 repeats 两个子节点都更纯. Suggested: 即使两个子节点的类别比例不同，只要都在二分之一的同一侧，错误率的增益仍可为零。

## F09 — Recap drops the asymptotic qualifier from the nearest-neighbor bound

References: {"s19_outro.py": [131, 132]}.

The complete chapter states a large-sample limit. Finite-sample1NN can exceed2R*: deterministic class labels give R*=0, but a finite training sample drawn entirely from one class yields positive error on the other class. Thus no unconditional finite-sample zero-error guarantee follows.

Suggested correction: In the recap say in the large-sample limit, single-neighbor error is at most twice Bayes error, under the chapter assumptions.

EN/ZH coordination: zh_lines.py:373 repeats 单个邻居的错误率，至多是最好规则的两倍; prepend 在大样本极限下。

## F10 — Gaussian Taylor error plot omits its1D bounded-grid measurement scope

References: {"s11_kernels.py": [151, 152, 163, 172, 174], "compute.py": [887, 888, 890, 896, 898]}.

The displayed equation is multidimensional. The producer error fixture actually uses one-dimensional x,z on61gridpoints in[-1.5,1.5],gamma=1,with powers0..D-1. Its20features/error are this bounded1D fixture, not a dimension-independent or global Gaussian approximation guarantee.

Suggested correction: Keep expansion, but label the numerical panel 1D gamma1,grid61x61 in[-1.5,1.5],first20powers. Do not extrapolate the measured max error to all coordinates/inputs.

EN/ZH coordination: zh_lines.py:229 says only keep len(errs) features; qualify 一维、gamma等于1、指定区间网格上的截断验证。

## F11 — AdaBoost no-zero-training-error branch narrates roundNone

References: {"s15_adaboost.py": [150, 158, 169, 170, 171]}.

When train_err_70 has no zero, z0=None. The condition keeps is false, and the fallback sentence still says training error hits zero at round{z0}, producing roundNone. The displayed status already handles no-zero correctly; narration does not.

Suggested correction: Separate z0 is None from zero-reached-but-no-test-improvement, use measured final training/test errors without claiming a zero hit.

EN/ZH coordination: zh_lines.py:307–308 repeats the interpolated zero-hit branch; add a separate never-zero template. This is an adverse-path source proof, not a claim that the default run failed.

## F12 — SVM loss panel forces actual hinge/logistic values onto a false top plateau

References: s12_svm.py:100,104–105.

The panel evaluates margins from-2.5to2.5. At margin-2.5 hinge loss is3.5, but np.minimum(...,3.2) draws it at3.2. Every margin below-2.2 is flattened to the top border, although the hinge formula is a straight line there. Logistic loss is likewise numerically capped at3.2. This transform activates on the literal plotted domain, independent of production data.

Suggested correction: Crop the true curves to the viewport (hinge enters at margin-2.2,loss3.2) or enlarge y-range; do not clamp data ordinates. Keep formula and visible segment truthful.

## Conditional visual leads

These require actual Part6 numerical/render evidence before any default defect conclusion.

- G01 Curve coordinate clipping can fabricate floor/ceiling plateaus: SVM literal-domain clipping is confirmed separately as F12; other actual default arrays remain untested because no Part6 cache/load/production was allowed. Color-scale clipping in region_image/heatmaps is separate and intentional. Proposed followup: Compare actual arrays after root production. Crop visible linear subpaths at viewport boundaries or expand ranges; explicitly disclose numerical/log floors. Hinge at margin -2.5 is analytically3.5 and is forced to3.2 by s12:104, so that particular plotted loss cap is active independent of cache.

- G02 KNN selection uses standardized metric but ring uses a screen-space circle: Source geometry mismatch unless metric happens to be isotropic in displayed pixels; actual default standard deviations untested. Points are additionally jittered for display but links/ring use unjittered positions. Proposed followup: Use actual standardized radius and map its circle through x=mu_x+sd_x*r*cos(t),y=mu_y+sd_y*r*sin(t), or disclose ring as a loose visual highlight; align neighbor links to actual displayed dots.

- G03 Retained ladder rows still use default copy-morph appends: Complete AST call inventory in source-inventory.json. Source pattern matches previous Parts copy-overlap mechanism, but no actual Part6 motion inspected and no defect/playback approval inferred. Proposed followup: Inspect actual dense motion; for retained proof-row appends use local returned-step transform=False when justified, preserve factory and intentional replacements.

- G04 Kernel lift silently replaces invalid/small intersection radius: sqrt(max(r2,.01)) fabricates radius.1when r2<=.01; actual default lift geometry untested. Proposed followup: Validate actual w2/r2 and plot true finite intersection or explicit no-intersection case; do not synthesize a minimum physical radius.

## Coverage and limits

{
  "all19scene_ASTs_parsed": true,
  "detailed_source_sections": [
    "LeastSquares squares/likelihood/projection/Zipf source",
    "GaussMarkov theorem and solving-unit narration excerpts",
    "Ridge allmethods",
    "Lasso shapes/soft/CV/twins; path control AST excerpts",
    "Logistic score/sheet/convex; result/descent controls from AST/excerpts",
    "Newton derive/race/digits/runaway",
    "NaiveBayes derive/learned and race/calibration caption extracts",
    "LDA allmethods",
    "KNN vote/regions/CoverHart; curse AST inventory",
    "Kernels allmethods",
    "SVM street/hinge/dual and pages/grid controls",
    "Trees split/impurity and depth/fragility excerpts",
    "Forests allmethods",
    "AdaBoost plane/derive/curves/faces source extracts",
    "GradientBoosting allmethods",
    "Metrics AST/control inventory only (methodology owned separately)",
    "Contest tables/frontier source and other controls",
    "Outro tiles/recap/payoffs/problems/references source extracts and README exercises"
  ],
  "metrics_train_test_fairness_owner": "motion_foundations; no duplicate full statistical/producer audit",
  "translation": "Read corresponding ZH templates/caption keys for each finding;501local strings/50patterns checked for bare-backslash-before-Unicode leads;0found. Not actual TeX/narration translation execution.",
  "actual_rendered_frames_viewed": 0,
  "actual_motion_viewed": 0,
  "production_modules_imported": 0,
  "producers_executed": 0,
  "tests_executed": 0,
  "source_edits": 0,
  "limits": [
    "No actual numerical-result validation or default-outcome conclusions.",
    "No rendered layout, timing, continuous perception, audio, native1080 or production gate.",
    "Historical/current product claims (e.g TabPFN2026) not independently web-verified in this source-only pass; route primary-source review separately.",
    "Detailed selected sections reviewed, not a claim of line-by-line/full scientific approval of all4,784scene source lines."
  ]
}

The LDA correction must preserve the final full-inverse mean normal: whitening the observations by the inverse square root and pulling the normal back are distinct stages. A direct label-only replacement of the final Fisher formula would introduce a new error.
