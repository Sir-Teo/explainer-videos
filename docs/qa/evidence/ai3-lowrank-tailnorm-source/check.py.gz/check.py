from pathlib import Path
import ast,json,hashlib,re,math
from manim import tempconfig,DOWN
from explainer.analysis import label,WIDE_TEX
from explainer import zh_text,lang
root=Path('/workspace/explainer-videos');part=root/'videos/ai/ai3';before=Path('/workspace/runtime/ai3-lowrank-tail-norm-repair/before18');out=before.parent;source=part/'s09_lowrank.py';tree=ast.parse(source.read_text());old=ast.parse((before/'s09_lowrank.py').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Construct only the actual pure caption expression, with pinned scalar sample values.
a=next(n.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='chk' for t in n.targets));en=eval(compile(ast.Expression(a.func.value.args[0]),str(source),'eval'),{},dict(ranks=[1,2,4,8],err=[0,0,0,7.8646],tail=[0,0,0,7.8646]));zh=en.replace('rank $8$:', '秩$8$：').replace(';', '；')
(out/'captions-handoff.json').write_text(json.dumps({'strings':{en:zh}},ensure_ascii=False,indent=2)+'\n')
metrics=[]
with tempconfig({'media_dir':str(out/'geometry'),'verbosity':'ERROR'}):
 for lang,text in [('en',en),('zh',zh)]:
  if lang=='zh':
   zh_text.install(WIDE_TEX)
   from explainer import lang as language
   language.LANG='zh'
  with zh_text.verbatim():m=label(text,font_size=26).to_edge(DOWN,buff=.55)
  bounds=[float(m.get_left()[0]),float(m.get_right()[0]),float(m.get_bottom()[1]),float(m.get_top()[1])];assert bounds[0]>-6.9 and bounds[1]<6.9 and bounds[2]>=-3.45-1e-8;metrics.append(dict(lang=lang,text=text,bounds=bounds,width=float(m.width),height=float(m.height)))
oldcalls=[n for n in ast.walk(old) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover'];newcalls=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover'];assert len(oldcalls)==len(newcalls)
changes=[]
for a,b in zip(oldcalls,newcalls):
 oldsrc=ast.get_source_segment((before/'s09_lowrank.py').read_text(),a.args[0]);newsrc=ast.get_source_segment(source.read_text(),b.args[0]);assert re.findall(r"<bookmark[^>]+/>",oldsrc)==re.findall(r"<bookmark[^>]+/>",newsrc)
 if ast.dump(a)!=ast.dump(b):changes.append(dict(old_expression=oldsrc,new_expression=newsrc,bookmarks=re.findall(r"<bookmark[^>]+/>",newsrc)))
assert len(changes)==2
r=dict(scene_source_sha256=sha(source),zh_lines_sha256=sha(part/'zh_lines.py'),changes=changes,caption_geometry=metrics,math_fixture={'omitted_values':[3,4],'frobenius_error':math.sqrt(3**2+4**2),'sum':7},coverage='Pure caption AST/Manim layout construction only; no production scene import/load/model/compute/video render. New narrated duration and actual appearance pending root render.',baseline18_inventory_sha256=sha(before/'inventory.json'))
(out/'checks.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps(metrics,ensure_ascii=False));print('source',r['scene_source_sha256'],'zh',r['zh_lines_sha256'])
