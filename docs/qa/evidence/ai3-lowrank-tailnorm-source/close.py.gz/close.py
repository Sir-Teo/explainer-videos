from pathlib import Path
import ast,json,hashlib,re,subprocess
from copy import deepcopy
root=Path('/workspace/explainer-videos');out=Path('/workspace/runtime/ai3-lowrank-tail-norm-repair');before=out/'before18';source=root/'videos/ai/ai3/s09_lowrank.py';zh=root/'videos/ai/ai3/zh_lines.py';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=json.loads((out/'checks.json').read_text());old=ast.parse((before/'s09_lowrank.py').read_text());new=ast.parse(source.read_text())
class NormalizeAllowed(ast.NodeTransformer):
 def visit_Call(self,n):
  self.generic_visit(n)
  if isinstance(n.func,ast.Attribute) and n.func.attr=='voiceover':n.args=[ast.Constant(value='AUTHORIZED_NARRATION')]
  return n
 def visit_Assign(self,n):
  self.generic_visit(n)
  if any(isinstance(t,ast.Name) and t.id=='chk' for t in n.targets):n.value=ast.Constant(value='AUTHORIZED_CAPTION')
  return n
assert ast.dump(NormalizeAllowed().visit(old))==ast.dump(NormalizeAllowed().visit(new))
getzh=lambda p:ast.literal_eval(next(n.value for n in ast.parse(p.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ZH' for t in n.targets)))
a,b=getzh(before/'zh_lines.py'),getzh(zh);keys=[k for k in a if a[k]!=b[k]];assert len(keys)==2 and all(k in ['f"A picture is a matrix too','f"Part 1\'s table of letter pairs'] for k in keys)
for k in keys:assert re.findall(r'<bookmark[^>]+/>',a[k])==re.findall(r'<bookmark[^>]+/>',b[k])
report=json.load(open('/workspace/runtime/ai3-power-svd-lowrank-motion-review.json'))
for lang in ['en','zh']:assert sha(before/'s09_lowrank.py')==report['cases'][lang+'/LowRank']['scene_source_sha256']
after=out/'after';after.mkdir(exist_ok=True);shutil=None
import shutil
for p in [source,zh]:shutil.copy2(p,after/p.name)
(out/'source.patch').write_text(subprocess.check_output(['git','diff','--','videos/ai/ai3/s09_lowrank.py'],cwd=root,text=True))
checks.update(dict(status='source_frozen;actual_bilingual_regression_pending',source_sha256=sha(source),zh_lines_sha256=sha(zh),baseline_inventory_sha256=sha(before/'inventory.json'),baseline_scope='Only LowRank EN/ZH pairs verified exact against completed owner review. Einsum raw concurrent snapshots uncertain; not promoted. Other raw copies require existing owner provenance.',only_authorized_source_differences=True,changed_zh_keys=keys,all_bookmarks_preserved=True,data_geometry_animations_unchanged_except_caption_text=True,tests=dict(narration='10PASS11.009s; existingtest_ai3_narration_review',compile='passed',diff_check='passed'),timing='Both changed EN and ZH VO paragraphs are longer; silent/narrated duration not yet measured. Root will rerender affected EN/ZH; bookmarks/order and animation durations preserved.',scope='No production scene import/loader/compute/model/download/video render. Existingroot-ownedcaptionsonly handoff; no globaltable/STATUS/commit changes.'))
(out/'report.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False)+'\n');(out/'report.md').write_text('# LowRank tail-norm wording repair\n\nFrobenius error is now explicitly the Euclidean norm of omitted singular values in both EN and ZH narration. The image caption displays both measured Frobenius error and sqrt(sumσ²), preserving values and layout anchor.\n\nOnly s09_lowrank.py and its two local ZH entries changed. All bookmarks, data, animations and other geometry preserved by AST check. Existing10 narration integration tests pass; compile/diff checks pass. Standalone[3,4] example distinguishes norm5 from sum7.\n\nActual EN caption width6.0521 and ZH5.9667world, both bottom−3.45/top−2.9643 within frame; actual Tex construction only, not scene render. The new VO is longer and its timing/appearance regression is pending root rendering.\n\nLowRank before EN/ZH movies/source/captures exactly match completed owner reviews. Other18-case raw snapshots are concurrent copies; Einsum had active writers and is explicitly uncertain, not a validated baseline. Raw hashes preserved without recopy.\n\nCaption strings-only handoff: captions-handoff.json. Exact source hashes/full EN expressions/bookmarks, geometry and baseline scopes: report.json.\n');print('source',sha(source),'zh',sha(zh),'report',sha(out/'report.json'));print('beforeZH',sha(before/'zh_lines.py'))
