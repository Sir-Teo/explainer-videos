import ast,math,json,hashlib
from pathlib import Path
import numpy as np
from manim import Axes,ValueTracker,Line,Dot,VGroup,GREY_A
ROOT=Path('/workspace/explainer-videos');p=ROOT/'videos/ai/ai4/s02_derivative.py';tree=ast.parse(p.read_text());method=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Derivative');method=next(n for n in method.body if isinstance(n,ast.FunctionDef) and n.name=='tangent')
ns={'math':math,'ValueTracker':ValueTracker,'Line':Line,'Dot':Dot,'VGroup':VGroup,'GREY_A':GREY_A,'GRAD':'#F5A65B','C':type('Colors',(),{'SURPRISE':'#EF709D'})}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('s','ds')],type_ignores=[]),str(p),'exec'),ns)
ax=Axes(x_range=[0,1,.25],y_range=[0,6,1],x_length=6,y_length=4.6,tips=False).move_to([-3.4,-.3,0]);ns['ax']=ax
names={'p0','h','k','crossings','x0','x1','tangent'}
nodes=[n for n in method.body if (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names or isinstance(t,ast.Tuple) and any(isinstance(x,ast.Name) and x.id in names for x in t.elts) for t in n.targets)) or isinstance(n,ast.FunctionDef) and n.name=='samples']
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)
checks=[];errors=[]
for h in (.30,.15,.075,.02,.004,.002):
 ns['h'].set_value(h);connector,actual,predicted=ns['samples']();a=ax.p2c(actual.get_center());b=ax.p2c(predicted.get_center());expected=np.array([.25+h,ns['s'](.25)+ns['ds'](.25)*h]);assert np.allclose(b,expected);assert np.allclose(a,[.25+h,ns['s'](.25+h)]);assert a[1]>b[1]>0;assert np.allclose(connector.get_start(),predicted.get_center());assert np.allclose(connector.get_end(),actual.get_center());errors.append(a[1]-b[1]);checks.append({'h':h,'curve_value':a[1],'tangent_prediction':b[1],'error':errors[-1]})
start,end=(ax.p2c(ns['tangent'].get_start()),ax.p2c(ns['tangent'].get_end()));assert 0<=start[1]<=6 and -1e-12<=end[1]<=6;assert math.isclose((end[1]-start[1])/(end[0]-start[0]),ns['ds'](.25));assert 3.9<errors[-2]/errors[-1]<4.1
out={'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Actual AST-extracted production s,ds,tangent setup,samples executed with actual Manim axes/Line/Dot/VGroup; no production scene import/load/render/VO.','samples':checks,'tangent_data_endpoints':[start.tolist(),end.tolist()],'slope':ns['ds'](.25),'small_step_error_ratio':errors[-2]/errors[-1],'status':'passed'};Path('/workspace/runtime/ai4-derivative-tangent-repair/geometry-check.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
