import ast,math,json,os,sys,hashlib
from pathlib import Path
import numpy as np
from explainer.ai import *
OUT=Path('/workspace/runtime/ai4-derivative-tangent-repair');ROOT=Path('/workspace/explainer-videos');p=ROOT/'videos/ai/ai4/s02_derivative.py';tree=ast.parse(p.read_text());config.media_dir=str(OUT/'geometry-media');config.verbosity='ERROR'
if os.environ.get('EXPLAINER_LANG')=='zh':
 import explainer.zh_text as z
 z._TABLE=z._table();z._TABLE.setdefault('strings',{}).update(json.loads((OUT/'bilingual-handoff.json').read_text())['strings']);z._BY_NUMBERS=None
ns=dict(globals(),GRAD='#FF9F45',VALUE='#58A6FF');exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('s','ds')],type_ignores=[]),str(p),'exec'),ns)
ax=Axes(x_range=[0,1,.25],y_range=[0,6,1],x_length=6,y_length=4.6,tips=False).move_to([-3.4,-.3,0]);ns['ax']=ax
method=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='tangent');nodes=[]
for n in method.body:
 if isinstance(n,ast.With):break
 if isinstance(n,ast.Assign) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='self':continue
 nodes.append(n)
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ns)
def bounds(m):return {'left':float(m.get_left()[0]),'right':float(m.get_right()[0]),'bottom':float(m.get_bottom()[1]),'top':float(m.get_top()[1])}
items={name:bounds(ns[name]) for name in ['f','what','legend','hl']}
for name,b in items.items():assert b['left']>=-6.95 and b['right']<=6.95 and b['bottom']>=-3.85 and b['top']<=3.85,(name,b)
assert items['legend']['top']<items['what']['bottom'];assert items['legend']['bottom']>items['hl']['top'];assert not any(k.startswith('videos.ai.ai4') for k in sys.modules)
report={'lang':os.environ.get('EXPLAINER_LANG','en'),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Actual pre-voiceover AST objects with Manim/Tex and in-memory Chinese translation handoff; no scene import/data load/render.','bounds':items,'status':'passed'};(OUT/('layout-'+report['lang']+'.json')).write_text(json.dumps(report,indent=2));print(json.dumps(report))
