from pathlib import Path
import datetime,hashlib,json,sys
from PIL import Image,ImageDraw
B=Path('/workspace/runtime/ai3-silent-preview-assembly');D=B/'current-four-replacements';lang=sys.argv[1];base=D/lang/'validation';new=json.loads((base/'join-selection.json').read_text());oldp=B/'continuity-qualified'/lang/'validation/join-review.json';old=json.loads(oldp.read_text());assert old['status']=='reviewed-no-assembly-defect-observed' and old['accounted_for_selected_times']==342;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prior={(x['join'],x['relative_frame']):x for x in old['selected_frames']};rows=[];native=[];direct=[]
for join in new['joins']:
 for x in join['frames']:
  p=prior[(join['index'],x['relative_frame'])];assert sha(p['path'])==p['sha256'];assert p['coverage'] not in ('pending-actual-view','pending-exact-duplicate');assert sha(x['path'])==x['sha256'];r=dict(x,join=join['index'],outgoing_scene=join['outgoing_scene'],incoming_scene=join['incoming_scene'],prior_path=p['path'],prior_sha256=p['sha256'],prior_time=p['time'],same_relative_frame=x['relative_frame']==p['relative_frame'],timestamp_delta=x['time']-p['time'])
  if x['sha256']==p['sha256']:r.update(coverage='exact-PNG-inheritance-from-actually-reviewed-historical-join-image',prior_actual_review=p)
  else:r['coverage']='pending-actual-view';direct.append(r)
  rows.append(r)
 for name,delta in [('before',-15),('after',15)]:
  x=next(x for x in join['frames'] if x['relative_frame']==delta);p=old['native_pairs'][str(join['index'])][name];assert p['actual_view']=='actual-native854x480-view';assert sha(p['path'])==p['sha256'];native.append({'join':join['index'],'role':name,'source_frame':x['source_frame'],'path':x['path'],'sha256':x['sha256'],'prior_native_view':p,'coverage':'exact-PNG-inheritance-of-actual-native-context-view' if x['sha256']==p['sha256'] else 'pending-actual-native-view'})
pages=[]
for k in range(0,len(direct),8):
 chunk=direct[k:k+8];im=Image.new('RGB',(1708,2080),(11,15,22));draw=ImageDraw.Draw(im)
 for j,x in enumerate(chunk):
  xx=(j%2)*854;yy=(j//2)*520;draw.text((xx+8,yy+10),f"{lang} join{x['join']:02d} frame{x['source_frame']} {x['time']:.6f}s",fill='white');im.paste(Image.open(x['path']).convert('RGB'),(xx,yy+40))
 p=base/f'novel-join-review-{k//8+1:03d}.png';im.save(p);pages.append({'file':str(p),'sha256':sha(p),'source_frames':[x['source_frame'] for x in chunk],'actually_viewed':False})
r={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'lang':lang,'scope':'All18joins,19timestamps per join and36native context appearances; exactPNGinheritance from actual historical proof only. Not continuous reel playback/listening.','prior_actual_review':str(oldp),'prior_actual_review_sha256':sha(oldp),'new_selection':str(base/'join-selection.json'),'new_selection_sha256':sha(base/'join-selection.json'),'join_count':len(new['joins']),'selected_times':len(rows),'inherited_times':len(rows)-len(direct),'novel_actual_review_pending':len(direct),'mapping':rows,'native_context':native,'native_exact_inheritances':sum(x['coverage'].startswith('exact-') for x in native),'novel_pages':pages,'findings':[],'status':'closed-by-exact-image-inheritance' if not direct and all(x['coverage'].startswith('exact-') for x in native) else 'pending-new-image-review'};(base/'join-regression.json').write_text(json.dumps(r,indent=2)+'\n');print(lang,'join images',len(rows),'exact',r['inherited_times'],'novel',len(direct),'native exact',r['native_exact_inheritances'])
