from pathlib import Path
import json, hashlib, shutil, subprocess, importlib.util, datetime, fcntl, os
from PIL import Image,ImageDraw
R=Path('/workspace/explainer-videos'); root=Path('/workspace/runtime/ai6-metrics-shared-bars-review'); source=Path('/workspace/runtime/ai6-remaining-qa-serial/runs/20261101T064932/17-Metrics')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('qm',R/'tools/qa_motion.py');qm=importlib.util.module_from_spec(spec);spec.loader.exec_module(qm)
def pages(out,rows,kind):
 result=[];(out/kind).mkdir(exist_ok=True)
 for k in range(0,len(rows),4):
  canvas=Image.new('RGB',(1708,1004),'#10141c');draw=ImageDraw.Draw(canvas)
  for j,x in enumerate(rows[k:k+4]):
   im=Image.open(out/x['file']).convert('RGB');assert im.size==(854,480);xx=(j%2)*854;yy=(j//2)*502;canvas.paste(im,(xx,yy+22));draw.text((xx+6,yy+4),f"{x.get('index',k+j)} / {x['time']:.3f}s",fill='white')
  p=out/kind/f'page-{k//4+1:03d}.png';canvas.save(p);result.append({'page':k//4+1,'file':str(p.relative_to(out)),'sha256':sha(p),'representatives':list(range(k,min(k+4,len(rows)))),'tile_size':[854,480]})
 return result
root.mkdir(exist_ok=True)
with Path('/workspace/runtime/ai4-tail-motion-review/extract.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for lang in ['en','zh']:
  out=root/lang
  if (out/'plan.json').exists():continue
  if shutil.disk_usage(R).free<768*1024**2:raise RuntimeError('free space below768MiB')
  out.mkdir(exist_ok=True); ep=source/lang/'endpoints/completed';mo=source/lang/'motion/completed'; record=json.loads((mo/'result.json').read_text()); er=json.loads((ep/'result.json').read_text());movie=mo/'media/videos/480p15/Metrics.mp4';mh=sha(movie)
  assert record['status']=='passed' and not record['warnings'];assert er['status']=='passed' and not er['warnings']
  for mode,src in [('endpoints',ep),('motion',mo)]:
   d=out/mode;d.mkdir(exist_ok=True)
   for n in ['result.json','copy-manifest.json']:
    shutil.copy2(src/n,d/n)
   for n in ['source-before.json','source-after.json','receipt.json','data-before.json','data-after.json','command.json']:
    shutil.copy2(src.parent/n,d/('factory-'+n))
  frames=[]
  for i,f in enumerate(er['frames']):
   q=ep/f['file']; dest=out/'endpoints'/q.name;shutil.copy2(q,dest);frames.append({'index':i,'time':f['time'],'file':str(dest.relative_to(out)),'sha256':sha(dest)})
  epages=pages(out,frames,'endpoint-pages')
  (out/'source').mkdir(exist_ok=True); sources=[]
  for rel in ['videos/ai/ai6/s17_metrics.py','videos/ai/ai6/common.py','videos/ai/ai6/zh_lines.py','videos/ai/ai_text_zh.json','tools/qa_motion.py']:
   p=R/rel;q=out/'source'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);sources.append({'path':rel,'sha256':sha(p),'bytes':p.stat().st_size,'scope':'source observed at review; factory snapshots remain separate'})
  inputs=[]
  for rel,sm in record['inputs'].items():
   p=R/rel;s=p.stat();assert list(sm)==[s.st_size,s.st_mtime_ns];inputs.append({'path':rel,'sha256':sha(p),'size_mtime_ns':sm})
  stream,times=qm.probe(movie); start=record['narration'][3]['start']-.5;end=record['narration'][4]['start']+.2;chosen=[(i,t) for i,t in enumerate(times) if start<=t<=end]
  w,h=stream['width'],stream['height'];assert (w,h)==(854,480);(out/'motion-unique').mkdir(exist_ok=True)
  command=['ffmpeg','-v','error','-xerror','-err_detect','explode','-threads','1','-i',str(movie),'-map','0:v:0','-an','-sn','-filter_threads','1','-vf',f'select=between(n\\,{chosen[0][0]}\\,{chosen[-1][0]})','-vsync','0','-f','rawvideo','-pix_fmt','rgb24','pipe:1']
  (out/'decode-command.json').write_text(json.dumps(command,indent=2)+'\n')
  seen={};unique=[];mapping=[]
  with (out/'decode.log').open('wb') as log:
   proc=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=log)
   while True:
    raw=qm.read_frame(proc.stdout,w*h*3)
    if not raw:break
    n=len(mapping);assert n<len(chosen);i,t=chosen[n];pixel=hashlib.sha256(raw).hexdigest()
    if pixel not in seen:
     u=len(unique);seen[pixel]=u;p=out/'motion-unique'/f'{u:04d}-{i:06d}-{t:.3f}s.png';Image.frombytes('RGB',(w,h),raw).save(p);unique.append({'index':u,'source_frame':i,'time':t,'rgb_sha256':pixel,'file':str(p.relative_to(out)),'sha256':sha(p)})
    mapping.append({'source_frame':i,'time':t,'rgb_sha256':pixel,'representative':seen[pixel]})
   assert proc.wait()==0
  assert len(mapping)==len(chosen);assert sha(movie)==mh
  mpages=pages(out,unique,'motion-pages')
  plan={'case':lang+'/Metrics','scope':'Early shared hbars regression; all endpoint states, only scores-block movie window. No whole-chapter motion acceptance.','movie':{'path':str(movie),'sha256':mh,'bytes':movie.stat().st_size},'raw_status':record['status'],'raw_warnings':record['warnings'],'raw_fingerprint':record['fingerprint'],'inputs':inputs,'source_observations':sources,'requested_window':[start,end],'actual_window':[chosen[0][1],chosen[-1][1]],'movie_timestamp_count':len(times),'target_encoded_frames_decoded':len(mapping),'target_selected_frames':len(mapping),'unique_rgb_frames':len(unique),'max_target_time_gap':max(b['time']-a['time'] for a,b in zip(mapping,mapping[1:])),'unselected_frames_within_target':0,'outside_target':'Not pixel-decoded or visually reviewed by this bounded audit; timestamp probe only.','mapping':mapping,'unique':unique,'endpoint_frames':frames,'endpoint_pages':epages,'motion_pages':mpages,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  (out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(out/'views.json').write_text('{"endpoint_pages":[],"motion_pages":[],"native":[],"findings":[]}\n');print(lang,len(frames),'endpoints',len(mapping),'windowframes',len(unique),'unique',len(mpages),'pages',flush=True)
