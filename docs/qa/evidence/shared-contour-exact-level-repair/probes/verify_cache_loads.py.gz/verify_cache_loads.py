"""Read existing completed artifacts only; producer hooks fail on every invocation."""
from pathlib import Path
from unittest.mock import Mock,patch
import gc,hashlib,json,sys,time
R=Path('/workspace/explainer-videos');sys.path.insert(0,str(R));B=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((B/'payloads-before.json').read_text())
sources={p:sha(R/p) for p in ['explainer/ai/viz.py','videos/ai/ai3/compute.py','videos/ai/ai3/cache_integrity.py','videos/ai/ai4/compute.py','videos/ai/ai4/cache_contract.py','videos/ai/ai4/contracts.py','explainer/ai/autodiff.py','videos/ai/ai4/s15_quadratic.py']}
from videos.ai.ai3 import compute as c3
from videos.ai.ai4 import compute as c4
results=[]
for part,c,expected in [('ai3',c3,17),('ai4',c4,23)]:
 assert len(c.ITEMS)==expected
 producers={name:Mock(side_effect=AssertionError(f'Forbidden producer {part}/{name}')) for name in c.ITEMS}
 with patch.object(c.CACHE,'_produce',side_effect=AssertionError(f'Forbidden _produce {part}')) as production,patch.dict(c.CACHE.items,producers):
  for name in c.ITEMS:
   start=time.monotonic();current=c.cache_current(name);assert current is True,(part,name,'stale/missing')
   value=c.CACHE.load(name);assert isinstance(value,dict) and len(value)>0
   results.append({'part':part,'item':name,'current':current,'actual_CACHE_load_succeeded':True,'loaded_keys':sorted(value),'seconds':time.monotonic()-start})
   del value;gc.collect()
  production.assert_not_called();assert all(p.call_count==0 for p in producers.values())
for row in before:
 p=R/row['path'];s=p.stat();assert row==dict(path=row['path'],bytes=s.st_size,mtime_ns=s.st_mtime_ns,sha256=sha(p)),row['path']
for p,h in sources.items():assert sha(R/p)==h,p
out={'scope':'All current Part3/4 completed-cache validators and actual CACHE.load calls with producer hooks replaced by immediate failures; schema/integrity and loadability only, not a new scientific calculation.','sources_guarded':sources,'cases':results,'parts':{'ai3':17,'ai4':23},'producer_calls':0,'all_payload_hash_size_mtime_signatures_unchanged':True,'payload_signatures_before':before,'validated_payload_files':len(before),'limitations':['No numerical producers, model loads/training, data/network downloads, cache upgrades/metadata rewrites or renders.','Existing eight Part3 postproduction-attestation origins retain their original disclosed provenance limits.','This is cache integrity/loadability verification, not visual/continuous/audio or independent scientific validation.']}
(B/'cache-load-verification.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'loads':len(results),'producer_calls':0,'payload_files_unchanged':len(before),'sha256':sha(B/'cache-load-verification.json')}))
