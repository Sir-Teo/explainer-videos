import ast,json,hashlib,collections
from pathlib import Path
import numpy as np
from explainer.ai.viz import contour_segments as proposed
import runpy
R=Path('/workspace/explainer-videos');OUT=Path(__file__).parent
assert hashlib.sha256((R/'videos/ai/ai4/s15_quadratic.py').read_bytes()).hexdigest() == '8b387c3a6f707b35b275bfb56a2daba1219707bd6e8c573bbf8ca2456390d68e'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
extracts=[]
def extract(rel,name,*,parent=None,rename=None):
 tree=ast.parse((R/rel).read_text());scope=tree
 if parent:scope=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==parent)
 node=next(n for n in ast.walk(scope) if isinstance(n,ast.FunctionDef) and n.name==name);text=ast.unparse(node);extracts.append({'source':rel,'line':node.lineno,'sha256':sha(R/rel),'function':name,'parent':parent})
 if rename:node.name=rename
 code=ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[]));return code
ns={'np':np};legacy=runpy.run_path(str(R/'tests/fixtures/contour_segments_legacy.py'))['contour_segments']
production_before=sha(R/'explainer/ai/viz.py')
for name in ['bowl','lag_f']:exec(compile(extract('videos/ai/ai4/compute.py',name),'pure-producer-function','exec'),ns)
ns.update(LAG_A=np.array([.6,1.4]),LAG_C=np.array([1.6,.9]))
exec(compile(extract('videos/ai/ai4/s15_quadratic.py','saddle_f'),'pure-scene-function','exec'),ns)
exec(compile(extract('videos/ai/ai4/s13_newton.py','trajectory_bounds'),'pure-bounds-helper','exec'),ns)
cache_receipts=[]
def read(name):
 b=R/'.cache/ai4';p=b/(name+'.json');d=json.loads(p.read_text())
 for p in [p,b/(name+'.npz')]:cache_receipts.append({'file':str(p.relative_to(R)),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns,'sha256':sha(p)})
 with np.load(b/(name+'.npz'),allow_pickle=False) as z:d.update({k:z[k].copy() for k in z.files})
 return d
nw=read('newton');v=read('valley');lag=read('lagrange');assert np.array_equal(lag['A'],ns['LAG_A']);assert np.array_equal(lag['C'],ns['LAG_C'])
ns.update(X=nw['X'],y=nw['y'],lam=nw['lam'],H=v['H'])
exec(compile(extract('videos/ai/ai4/s13_newton.py','f',parent='race',rename='newton_f'),'actual-newton-loss','exec'),ns)
exec(compile(extract('videos/ai/ai4/s15_quadratic.py','f',parent='valley',rename='valley_f'),'actual-valley-loss','exec'),ns)
xr,yr=ns['trajectory_bounds'](nw['gd'],nw['newton'],nw['w_star'])
cases=[('Gradient.contours + cauchy',ns['bowl'],(-4,4),(-3,3),(160,120),np.linspace(.4,3.6,13)),('Newton.race',ns['newton_f'],xr,yr,(90,70),[nw['f_star']+2e-4*2.5**k for k in range(8)]),('Quadratic.valley',ns['valley_f'],(-5,5),(-1.2,1.2),(200,80),[.25*2**k for k in range(8)]),('Quadratic.saddle',ns['saddle_f'],(-1.8,1.8),(-1.5,1.5),(120,100),np.linspace(-.24,1.4,14)),('Lagrange.picture',ns['lag_f'],(-1.6,2.6),(-1.5,1.9),(140,110),[.05*2**k for k in range(8)])]
def topology(segs,xr,yr):
 # Rounding solely joins mathematically shared edge intersections for diagnostics;
 # output geometry is never rounded or changed.
 d=collections.Counter(tuple(round(float(v),11) for v in p) for s in segs for p in s)
 ends=[p for p,k in d.items() if k==1];interior=[p for p in ends if min(abs(p[0]-xr[0]),abs(p[0]-xr[1]),abs(p[1]-yr[0]),abs(p[1]-yr[1]))>1e-9]
 return {'degree1_endpoints':len(ends),'interior_degree1_endpoints':len(interior),'interior_coordinates':interior}
results=[]
for name,f,xr,yr,n,levels in cases:
 xs=np.linspace(*xr,n[0]+1);ys=np.linspace(*yr,n[1]+1);Z=np.array([[f(x,y) for x in xs] for y in ys]);lev=[]
 for level in levels:
  old=legacy(xs,ys,Z,level);new=proposed(xs,ys,Z,level);hits=np.argwhere(Z==level)
  lev.append({'level':float(level),'exact_grid_vertices':len(hits),'exact_vertex_coordinates':[(float(xs[j]),float(ys[i])) for i,j in hits],'legacy_segment_count':len(old),'proposed_segment_count':len(new),'outputs_exactly_equal_including_order':old==new,'legacy_topology':topology(old,xr,yr),'proposed_topology':topology(new,xr,yr)})
 results.append({'case':name,'x_range':list(xr),'y_range':list(yr),'grid_cells':n,'grid_sha256':hashlib.sha256(Z.tobytes()).hexdigest(),'levels':lev,'any_output_change':any(not x['outputs_exactly_equal_including_order'] for x in lev)})
 print(name,[(x['level'],x['exact_grid_vertices'],x['legacy_segment_count'],x['proposed_segment_count'],x['legacy_topology']['interior_degree1_endpoints'],x['proposed_topology']['interior_degree1_endpoints']) for x in lev if not x['outputs_exactly_equal_including_order']],flush=True)
callers=[]
for part in range(1,5):
 for p in sorted((R/f'videos/ai/ai{part}').rglob('*.py')):
  tree=ast.parse(p.read_text())
  for n in ast.walk(tree):
   if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ['contour_segments','contour_lines']:
    callers.append({'part':part,'file':str(p.relative_to(R)),'line':n.lineno,'helper':n.func.id,'expression':ast.unparse(n),'source_sha256':sha(p)})
for p in cache_receipts:
 q=R/p['file'];assert p['sha256']==sha(q) and p['mtime_ns']==q.stat().st_mtime_ns
report={'scope':'Source AST only for helper/function extraction and callsite inventory; existing completed numerical JSON/NPZ read directly. No scene/producer imports, numerical producers, render or downloads.','actual_helper_source_sha256':sha(R/'explainer/ai/viz.py'),'baseline_helper_source_sha256':sha(OUT/'viz-before.py'),'production_helper_source_sha256':production_before,'approved_candidate_sha256':'2736d10023347cf142bd9d9ff44f269290adb99b4261ab120ccef1221eea7f88','ast_extractions':extracts,'actual_parts1_4_callsites':callers,'no_calls_found_in_parts':[x for x in range(1,5) if not any(c['part']==x for c in callers)],'cache_read_receipts':cache_receipts,'cache_payloads_and_mtimes_unchanged_after_probe':True,'topology_quantization_scope':'Only diagnostic graph vertices rounded to11decimal places (1e-9boundary tolerance); actual legacy/proposed output equality uses unrounded values/order.','case_results':results}
(OUT/'actual-caller-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
assert sha(R/'explainer/ai/viz.py')==production_before
for extraction in extracts:assert sha(R/extraction['source'])==extraction['sha256']
(OUT/'actual-helper-function.py').write_text(ast.unparse(next(n for n in ast.parse((R/'explainer/ai/viz.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='contour_segments'))+'\n')
print('report',sha(OUT/'actual-caller-comparison.json'))
