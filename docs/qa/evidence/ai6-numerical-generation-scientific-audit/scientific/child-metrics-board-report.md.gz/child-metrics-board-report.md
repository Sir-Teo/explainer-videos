# Part6 metrics, board and calibration actual-default audit

PASS actual-default numerical checks (154/154 checks).

Raw JSON/NPZ data were read directly; no project cache loader/producer was imported, no model was fitted or trained, and no render/download/source edit occurred. Necessary raw pages labels/test membership supplied the639-page target cohort. Every instrumented read has SHA256/size/mtime before and after plus an unchanged closing identity.

| Predictor | Stable OOF log loss | Accuracy | Beyond old floor | Wrong-label losses above old cap |
|---|---:|---:|---:|---:|
| lr2 | 0.378110884853 | 83.2551% | 0 | 0 |
| lr70 | 0.033826453609 | 99.5305% | 0 | 0 |
| nb | 0.478453904804 | 95.6182% | 494 | 0 |
| nb_platt | 0.087990973642 | 95.6182% | 0 | 0 |

Log loss, Brier score, reliability counts/means and ECE reproduce from stored logits/probabilities and labels. The actual NB payload has494 rows beyond the old1e-12 probability floor, but zero wrong-label losses exceed the old27.631-nat cap: an extreme-logit clipping counterexample is not an observed default cap failure. Stable-logit scores preserve finite extreme predictions without a cap.

AUC independently agrees across strict pair wins + half ties, average ranks and full threshold-ROC integration. LR2 AUC0.909460074391 rounds0.9095. All200 rare-class score resamples reproduce the stored mean/10th/90th summaries and final curves. Repeated-CV pooled accuracy agrees with integer fold outcomes, while board summaries correctly use unweighted fold means and sample SD.

All22 board method-feature cases have finite bounded ten-fold scores, exact mean/sample-SD/min/max summaries and integer fold/heldout outcomes on the declared cohort. The shared2025 fold vector reproduces exactly; calibration independently uses its declared1950 vector. Logistic and Gaussian-kernel SVM tie at99.5337% mean CV. The paired logistic-minus-boosting fold differences are descriptive, not a significance claim.

README and scenes reproduce the actual reported rounded values. One scientific wording caveat: contest line71 says “two numbers simply don’t hold more.” The tested procedure range76–83% does not establish a fundamental information ceiling; qualify it as the tested procedures on these folds. No source edit was made.

Plot-array caveat: downsampling can omit the terminalROC point; full-score AUC is the authoritative metric. Details and actual endpoints/areas are recorded in JSON. Per-page board predictions and all fold fit records are absent, so raw-data verification cannot independently re-prove training provenance or refit accuracy. The benchmark explicitly uses a full-corpus transductive lexicon and same-five-novel page evaluation.

Full checks, actual per-case results, source pins, paired differences, rounding comparisons, clipping diagnostics, gaps and the exact read ledger are in child-metrics-board-report.json and child-metrics-board-reads.jsonl.
