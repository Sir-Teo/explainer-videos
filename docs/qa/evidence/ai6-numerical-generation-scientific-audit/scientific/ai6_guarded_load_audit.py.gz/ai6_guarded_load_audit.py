from pathlib import Path
import os, sys, json, hashlib, datetime, traceback, time
ROOT=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai6-scientific-audit');OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT))
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:assert os.environ.get(k)=='1'
assert os.environ.get('EXPLAINER_CACHED_ONLY')=='1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
 return {str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted((ROOT/'.cache/ai6').rglob('*')) if p.is_file() and p.suffix in ['.json','.npz']}
sources=['videos/ai/ai6/compute.py','videos/ai/ai6/contracts.py','videos/ai/ai6/cache_contract.py','videos/ai/ai1/compute.py','explainer/ai/cache.py','explainer/cache_lock.py']
before=inventory();source_before={n:sha(ROOT/n) for n in sources};attempts=[];records=[];errors=[];start=time.monotonic()
def blocked(label):
 def fail(*args,**kwargs):attempts.append(label);raise AssertionError('Forbidden production/write call: '+label)
 return fail
try:
 import numpy as np
 from videos.ai.ai6 import compute as c
 from videos.ai.ai6.cache_contract import SchemaCache
 from explainer.ai.cache import Cache
 originals=dict(c.ITEMS)
 for name in originals:
  c.ITEMS[name]=blocked('ITEMS/'+name);setattr(c,'compute_'+name,blocked('compute_'+name))
 c.CACHE.items=dict(c.ITEMS)
 for cls in [Cache,SchemaCache]:
  for name in ['save','partial','_produce','_preserve','prepare_inputs']:
   if hasattr(cls,name):setattr(cls,name,blocked(cls.__name__+'.'+name))
 for name in ['save','savez','savez_compressed']:setattr(np,name,blocked('numpy.'+name))
 for name in originals:
  t=time.monotonic();s=c.cache_status(name);assert s['status']=='current',s
  data=c.load(name)
  assert c.cache_current(name)
  arrays={k:{'shape':list(v.shape),'dtype':str(v.dtype),'all_finite':bool(np.isfinite(v).all()) if v.dtype.kind in 'fci' else None} for k,v in data.items() if isinstance(v,np.ndarray)}
  scalars={k:v for k,v in data.items() if k!='_cache' and not isinstance(v,(dict,list,np.ndarray))}
  records.append({'item':name,'status':'current','loaded':True,'seconds':time.monotonic()-t,'keys':sorted(data),'arrays':arrays,'scalars':scalars})
  print(name,'current/loaded',round(time.monotonic()-t,3),flush=True)
except Exception as e:
 errors.append({'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
finally:
 after=inventory();source_after={n:sha(ROOT/n) for n in sources}
 report={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','EXPLAINER_CACHED_ONLY']},'records':records,'forbidden_attempts':attempts,'errors':errors,'payloads_before':before,'payloads_after':after,'payload_hash_size_mtime_unchanged':before==after,'source_before':source_before,'source_after':source_after,'source_unchanged':source_before==source_after,'wall_seconds':time.monotonic()-start,'scope':'Actual22cached-onlyloads/current checks with registered producers, module producers, cache writes/partials/preservation/inputprep and numpy writes patched fail-on-call. No scene imports/refits/default producers.'}
 (OUT/'guarded-load-report.json').write_text(json.dumps(report,indent=2)+'\n')
 assert not errors and not attempts and before==after and source_before==source_after
 assert len(records)==22
 print('PASS22 loads, zero forbidden attempts, unchanged payloads/source',flush=True)
