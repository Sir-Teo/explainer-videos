from pathlib import Path
import os,json,hashlib,math,datetime,traceback,collections
import numpy as np
R=Path('/workspace/explainer-videos');OUT=Path('/workspace/runtime/ai6-scientific-audit');OUT.mkdir(exist_ok=True)
assert all(os.environ.get(k)=='1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','EXPLAINER_CACHED_ONLY'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():return {str(p.relative_to(R)):{'sha256':sha(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in sorted((R/'.cache/ai6').rglob('*')) if p.is_file() and p.suffix in ['.json','.npz']}
before=inventory();source_names=['videos/ai/ai6/compute.py','videos/ai/ai6/contracts.py','videos/ai/ai6/cache_contract.py'];sources={n:sha(R/n) for n in source_names};data={};checks=[];errors=[];notes={}
def ck(item,name,condition,**evidence):
 checks.append(dict(item=item,check=name,passed=bool(condition),**evidence))
 if not condition:print('FAILED',item,name,evidence,flush=True)
def eq(item,name,actual,expected,tol=1e-9):
 a,b=np.asarray(actual),np.asarray(expected)
 if a.shape!=b.shape:ck(item,name,False,actual_shape=list(a.shape),expected_shape=list(b.shape));return
 e=float(np.max(np.abs(a-b))) if a.size else 0.;ck(item,name,e<=tol,max_abs_error=e,tolerance=tol)
def raw(n):
 p=R/'.cache/ai6'/f'{n}.json';d=json.loads(p.read_text());p=p.with_suffix('.npz')
 if p.exists():
  with np.load(p,allow_pickle=False) as z:d.update({k:z[k] for k in z.files})
 data[n]=d;return d
def acc(s,y):return float(np.mean((np.asarray(s)>.5)==y))
try:
 for name in ['pages','zipf','gaussmarkov','lsq','ridge','lasso','logistic','irls','nbvslr','lda','knn','coverhart','curse','kernel','svm','trees','bagging','adaboost','xgb']:raw(name)
 p=data['pages'];X=np.asarray(p['X']);y=np.asarray(p['y']);te=np.asarray(p['test'],bool);tr=~te;X2=np.asarray(p['X2']);yt=y[tr];yv=y[te];mu=X[tr].mean(0);sd=X[tr].std(0)+1e-9;Z=(X[tr]-mu)/sd;Zv=(X[te]-mu)/sd;yc=yt-yt.mean();n=len(yt)
 ck('pages','actual639/448/191and70columns',X.shape==(639,70) and n==448 and te.sum()==191,n_pages=len(y),training=n,test=int(te.sum()),class_counts=np.bincount(y).tolist(),training_classes=np.bincount(yt).tolist(),test_classes=np.bincount(yv).tolist())
 eq('pages','X2equalsdeclaredthe/notfeatures',X2,X[:,[p['vocab'].index(w) for w in ['the','not']]],0)
 ck('pages','integer1000wordrates',np.isfinite(X).all() and (X>=0).all() and np.array_equal(X,np.round(X)))
 ck('pages','fivebooksandtestexample',set(np.asarray(p['book']).tolist())=={1342,158,98,1400,46} and te[p['example_i']] and y[p['example_i']]==p['example_label'])
 expected=dict(vocabulary_fit='all five novels, including evaluation pages',transductive_vocabulary=True,split_unit='nonoverlapping 1000-word page',evaluation_scope='unseen pages within these same five novels; not unseen novels',standardization='respective training split or fold only')
 ck('pages','protocolexplicit',all(p['protocol'].get(k)==v for k,v in expected.items()),protocol=p['protocol'])
 g=np.random.Generator(np.random.PCG64(1964));expected_test=np.zeros(len(y),bool)
 for lab in (0,1):
  idx=np.flatnonzero(y==lab);expected_test[g.choice(idx,size=int(round(.3*len(idx))),replace=False)]=True
 eq('pages','exactseededstratifiedsplitnoexperiment',te.astype(int),expected_test.astype(int),0)
 d=data['zipf'];A=np.column_stack([np.ones(len(d['r'])),np.log10(d['r'])]);res=np.log10(d['f'])-A@d['beta'];eq('zipf','cachedbetanormalequationresidual',A.T@res,np.zeros(2),1e-8);eq('zipf','cachedR2',d['r2'],1-res@res/np.sum((np.log10(d['f'])-np.log10(d['f']).mean())**2),1e-13);notes['zipf']={k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in d.items() if k in ['beta','r2','n_words']}
 d=data['gaussmarkov'];x=np.asarray(d['x']);w=np.asarray(d['w_ols']);w0=(x-x.mean())/np.sum((x-x.mean())**2)
 eq('gaussmarkov','OLSslopeweightdesignidentity',w,w0,1e-14)
 for key in ['ols','end','mix']:
  v=np.asarray(d['w_'+key]);eq('gaussmarkov',key+'unbiaseddesignmoments',[v.sum(),v@x],[0,1],1e-13);eq('gaussmarkov',key+'varianceidentity',d['theory'][key],v@v,1e-14)
 eq('gaussmarkov','orthogonalextraweightvariance',d['theory']['mix']-d['theory']['ols'],np.sum((np.asarray(d['w_mix'])-w)**2),1e-14)
 notes['gaussmarkov']={k:d[k] for k in ['theory','gauss','t3','R']}
 A=np.column_stack([np.ones(n),Z]);U,s,Vt=np.linalg.svd(A,full_matrices=False);P=U@U.T
 eq('lsq','projectionissymmetric',P,P.T,1e-14);eq('lsq','projectionidempotence',P@P,P,1e-13);eq('lsq','projectionfixesdesign',P@A,A,1e-12)
 d=data['lsq'];eq('lsq','cachedconditionfromactualdesign',d['kappa_A'],s[0]/s[-1],1e-11);eq('lsq','conditionAtAsquares',d['kappa_AtA'],d['kappa_A']**2,1e-10)
 j=p['vocab'].index('not');Adup=np.column_stack([A,A[:,1+j]]);ck('lsq','actualduplicatecolumnrank',np.linalg.matrix_rank(Adup)==d['rank_dup']==71 and Adup.shape[1]==d['cols_dup']==72)
 eq('lsq','duplicatecoefficientssplitequally',[d['w_not_a'],d['w_not_b']],[d['w_not']/2]*2,1e-14);notes['lsq']={'limitation':'No cached complete OLS coefficients: reported accuracies/QR-vs-normal-equation differences not independently regenerated; no refit performed.','ne_dup':d['ne_dup'],'ne_dup_norm':d.get('ne_dup_norm'),'ne_dup_resid':d.get('ne_dup_resid'),'acc_test':d['acc_test']}
 d=data['ridge'];lam=np.asarray(d['lams']);coef=np.asarray(d['coef']);normal_res=coef@(Z.T@Z).T+lam[:,None]*coef-(Z.T@yc)[None,:]
 eq('ridge','all49cachedcoefficientnormalresiduals',normal_res,np.zeros_like(normal_res),1e-9)
 eq('ridge','effectiveDFidentity',d['df'],np.sum(np.asarray(d['d'])[None,:]**2/(np.asarray(d['d'])[None,:]**2+lam[:,None]),axis=1),1e-11)
 for l in d['shows']:eq('ridge','shrink'+str(l),d['shrink'][str(l)],np.asarray(d['d'])**2/(np.asarray(d['d'])**2+l),1e-13)
 eq('ridge','all49heldoutcachedcoefficientaccuracy',d['test_acc'],[acc(Zv@w+yt.mean(),yv) for w in coef],1e-14)
 best=int(np.argmin(d['cv_mse']));one=max(i for i,v in enumerate(d['cv_mse']) if v<=d['cv_mse'][best]+d['cv_mse_se'][best]);ck('ridge','bestand1SEfromstoredCV',best==d['best'] and one==d['one_se']);notes['ridge']={'best':best,'one_se':one,'lambda':float(lam[best]),'df':float(d['df'][best]),'heldout':float(d['test_acc'][best]),'singular_extrema':[float(d['d'][0]),float(d['d'][-1])],'first_two_signal_energy':float(np.sum(np.asarray(d['uy'])[:2]**2)/np.sum(np.asarray(d['uy'])**2))}
 d=data['lasso'];path=np.asarray(d['path']);lams=np.asarray(d['lams']);maxerr=0
 for l,w in zip(lams,path):
  grad=Z.T@(yc-Z@w)/n;on=w!=0;v=max(float(np.max(np.abs(grad[on]-l*np.sign(w[on])))) if on.any() else 0,float(np.max(np.maximum(np.abs(grad[~on])-l,0))) if (~on).any() else 0);maxerr=max(maxerr,v)
 ck('lasso','all61cachedpathKKT',maxerr<1e-6,max_residual=maxerr,stored=d['kkt']);eq('lasso','storedKKTmax',d['kkt'],maxerr,1e-12);eq('lasso','all61heldoutaccuracy',d['test_acc'],[acc(Zv@w+yt.mean(),yv) for w in path],1e-14);eq('lasso','pathnonzerocounts',d['nnz'],(path!=0).sum(1),0)
 best=int(np.argmin(d['cv_mse']));one=min(i for i,v in enumerate(d['cv_mse']) if v<=d['cv_mse'][best]+d['cv_se'][best]);ck('lasso','bestand1SEfromstoredCV',best==d['best'] and one==d['one_se']);notes['lasso']={'best_nonzero':int(d['nnz'][best]),'one_se_nonzero':int(d['nnz'][one]),'heldout':d['acc_one_se'],'first8':d['words8'],'acc8':d['acc8'],'pair':d['pair']}
 d=data['logistic'];w=np.asarray(d['w']);b=d['b'];z=X2[tr]@w+b;prob=.5*(1+np.tanh(z/2));eq('logistic','cachedraw2Dheldoutaccuracy',d['acc2'],acc(.5*(1+np.tanh((X2[te]@w+b)/2)),yv),1e-14);eq('logistic','cachedraw2Dtrainlossbits',d['loss_bits'],np.mean(np.logaddexp(0,np.where(yt==1,-z,z)))/math.log(2),1e-13)
 G=np.stack(np.meshgrid(d['xs'],d['ys']),-1);eq('logistic','wholeprobabilitysheet',d['prob'],.5*(1+np.tanh((G@w+b)/2)),1e-13)
 mu2=X2[tr].mean(0);sd2=X2[tr].std(0)+1e-9;Z2=(X2[tr]-mu2)/sd2;Av=np.column_stack([Z2,np.ones(n)]);H=(Av*(prob*(1-prob))[:,None]).T@Av/n;eq('logistic','actualHessianeigenvalues',d['hess_eig'],np.linalg.eigvalsh(H),1e-13);ck('logistic','gradientatcachedanswer',np.max(np.abs(Av.T@(prob-yt)/n))<1e-9,max_residual=float(np.max(np.abs(Av.T@(prob-yt)/n))));notes['logistic']={'loss_bits':d['loss_bits'],'acc2':d['acc2'],'acc70_reported_only':d['acc70'],'hessian':d['hess_eig'].tolist()}
 d=data['irls'];res=[]
 for typ in ['lines_newton','lines_gd']:
  e=[]
  for row in d[typ]:
   zz=X2[tr]@np.asarray(row[:2])+row[2];e.append(abs(float(np.mean(np.logaddexp(0,np.where(yt==1,-zz,zz))))/math.log(2)-row[3]))
  ck('irls',typ+'allstoredlineinferenceandloss',max(e)<1e-12,max_error=max(e))
 ck('irls','finiteNewtonandGDrecordedconvergence',np.isfinite(d['newton_gap']).all() and np.isfinite(d['gd']).all() and d['n_newton']==len(d['newton_gap'])-1,n_newton=d['n_newton'],gd_iters_to=d['gd_iters_to']);notes['irls']={k:d[k] for k in ['n_newton','gd_iters_to','norms','train_acc','losses','newton_gap']}
 d=data['nbvslr'];notes['nbvslr']={k:d[k] for k in ['sizes','nb_better_at','crossover','nb','lr']};nb_means=[d['nb'][str(k)]['mean'] for k in d['sizes']];lr_means=[d['lr'][str(k)]['mean'] for k in d['sizes']];better=[k for k,a,b in zip(d['sizes'],nb_means,lr_means) if a<b];cross=next((k for k,a,b in zip(d['sizes'],nb_means,lr_means) if b<a),None);ck('nbvslr','finitelearningcurveandmeasuredcomparison',np.isfinite(nb_means+lr_means).all() and better==d['nb_better_at'] and cross==d['crossover'],measured_nb_better_at=better,measured_crossover=cross)
 d=data['lda'];eq('lda','cached2Dcutaccuracy',d['acc2'],float(np.mean((X2[te]@d['w']>d['c'])==yv)),1e-14);ZA=Z[yt==0];ZD=Z[yt==1];dm=ZD.mean(0)-ZA.mean(0);SB=np.outer(dm,dm);SW=(ZA-ZA.mean(0)).T@(ZA-ZA.mean(0))+(ZD-ZD.mean(0)).T@(ZD-ZD.mean(0));eq('lda','actualpooledwithinmatrix',d['SW'],SW,1e-10);eq('lda','actualbetweenrank1matrix',d['SB'],SB,1e-12);Li=np.linalg.inv(np.linalg.cholesky(SW));ev=np.linalg.eigvalsh(Li@SB@Li.T);eq('lda','storedtop5generalizedeigenvalues',d['eigvals'],ev[::-1][:5],1e-12);eq('lda','maxRayleighquotient',d['rq'],ev[-1],1e-12);ck('lda','rankonepositiveeigenvalue',np.linalg.matrix_rank(SB)==d['rank_SB']==1 and ev[-1]>0 and np.max(np.abs(ev[:-1]))<1e-12)
 d=data['knn'];i=int(np.argmax(d['cv']));ck('knn','CVchoicefromcachedscores',d['k_cv']==d['ks'][i]);notes['knn']={'k_cv':d['k_cv'],'acc_kcv':d['acc_kcv'],'acc1':d['acc1'],'train1':d['train1'],'best_heldout_descriptive_only':max(d['ks'],key=lambda k:d['acc'+str(k)])}
 d=data['coverhart'];rs=.5*math.erfc(d['mu']/math.sqrt(2));eq('coverhart','normalBayeserror',d['Rstar'],rs,1e-15);eq('coverhart','asymptoticbound',d['bound'],2*rs*(1-rs),1e-15);ck('coverhart','limitbetweenBayesandbound',rs<=d['lim1']<=d['bound']);notes['coverhart']={k:d[k] for k in ['Rstar','lim1','bound']};notes['coverhart']['n10000']={'oneNN':d['e1']['10000'],'sqrtN':d['ek']['10000']}
 d=data['curse'];eq('curse','allcube10percentvolumeedges',[d['edge'][str(i)] for i in d['dims']],[.1**(1/i) for i in d['dims']],1e-14);ck('curse','actualdistancefractionsrange',np.all((np.asarray(d['nn_frac'])>=0)&(np.asarray(d['nn_frac'])<=1)));notes['curse']={'endpoints':list(zip([d['dims'][0],d['dims'][-1]],[d['nn_frac'][0],d['nn_frac'][-1]])),'knn':d['knn'],'lr':d['lr']}
 d=data['kernel'];D2=np.maximum(((Z2[:,None,:]-Z2[None,:,:])**2).sum(2),0);K2=np.exp(-D2);D70=np.maximum(((Z[:,None,:]-Z[None,:,:])**2).sum(2),0);K70=np.exp(-D70/70);eq('kernel','actual2featureGaussianGramspectrum',d['ev2'],np.linalg.eigvalsh(K2)[::-1],1e-10);eq('kernel','actual70featureGaussianGramspectrum',d['ev70'],np.linalg.eigvalsh(K70)[::-1],1e-10);eq('kernel','negativecountfromactualtanhGram',d['n_neg_sig'],int(np.sum(np.linalg.eigvalsh(np.tanh(Z2@Z2.T-1)) < -1e-9)),0);notes['kernel']={k:d[k] for k in ['poly_err','taylor_err','rep_err','rep_resid','n_neg_sig']}
 d=data['svm'];tt=2.*yt-1;Q=K2*tt[:,None]*tt[None,:];Gs=np.stack(np.meshgrid(d['xs'],d['ys']),-1).reshape(-1,2);Gz=(Gs-mu2)/sd2;Kgrid=np.exp(-((Gz[:,None,:]-Z2[None,:,:])**2).sum(2));Ktest=np.exp(-(((X2[te]-mu2)/sd2)[:,None,:]-Z2[None,:,:]) .__pow__(2).sum(2));svm_rows=[]
 for C in d['Cs']:
  key=f'C{C:g}';al=d['alpha_'+key];free=(al>1e-8)&(al<C-1e-8);grad=Q@al-1;vv=-tt*grad
  if free.any():bias=float(vv[free].mean())
  else:
   up=((tt>0)&(al<C))|((tt<0)&(al>0));low=((tt>0)&(al>0))|((tt<0)&(al<C));bias=float(.5*(vv[up].max()+vv[low].min()))
  scores=K2@(al*tt)+bias;dual=float(al.sum()-.5*al@Q@al);primal=float(.5*al@Q@al+C*np.maximum(0,1-tt*scores).sum());eq('svm',key+'cacheddual',d[key]['dual'],dual,1e-9);eq('svm',key+'cachedprimal',d[key]['primal'],primal,1e-8);eq('svm',key+'entiredecisionregion',d['region_'+key],(Kgrid@(al*tt)+bias).reshape(120,120),1e-9);eq('svm',key+'testaccuracy',d[key]['test'],float(np.mean((Ktest@(al*tt)+bias>0)==yv)),1e-14);ck('svm',key+'equalityandbox',abs(al@tt)<1e-8 and al.min()>=-1e-12 and al.max()<=C+1e-12,equality=float(al@tt));eq('svm',key+'supportindices',d['sv_'+key],np.flatnonzero(al>1e-8),0);svm_rows.append({'C':C,'relative_gap':(primal-dual)/max(abs(primal),1e-12),'stored':d[key],'reconstructed_bias':bias})
 notes['svm']={'rows':svm_rows,'kkt_stored':d['kkt'],'scope':'Inference/objective reconstruction from cachedalpha only; no SMO/refitting. Gamma-grid/70-feature models lack storedalpha and are not independently replayed.'}
 d=data['trees'];tree=d['tree3'];pred=[]
 for xx in X2:
  node=tree
  while 'leaf' not in node:node=node['l'] if xx[node['j']]<=node['t'] else node['r']
  pred.append(node['leaf'])
 eq('trees','cacheddepth3treeinference_train_test',[acc(np.asarray(pred)[tr],yt),acc(np.asarray(pred)[te],yv)],[d['train3'],d['acc3']],1e-14)
 notes['trees']={'depths':d['depths'],'heldout':[d['acc'+str(k)] for k in d['depths']],'cv':d['cv'].tolist(),'boot_root_counts':dict(collections.Counter(r[0] for r in d['boot_roots'])),'bootstrap_accuracy_range':[min(d['boot_acc']),max(d['boot_acc'])]}
 d=data['bagging'];v=[]
 for key in ['mf70','mf8','mf2']:
  row=d[key];eq('bagging',key+'rhoCovIdentity',row['rho'],row['cov']/row['s2'],1e-14);eq('bagging',key+'B50definingvariance',row['meas'][-1],row['cov']+(row['s2']-row['cov'])/50,1e-14);v.append({'key':key,**row,'prediction':[row['cov']+(row['s2']-row['cov'])/B for B in d['Bm']]})
 notes['bagging']={'measured':v,'B50_note':'Covariance is inferred from measuredB50variance; equality atB50 is definitional, not independent verification. OtherB values remain empirical comparisons. Originaltree predictions not cached.','forest_last':d['forest_acc'][-1],'bagging_last':d['bag_acc'][-1],'oob_last':d['forest_oob'][-1],'one_tree':d['one_tree']}
 d=data['adaboost'];ab=[]
 for feat in ['2','70']:
  a=X2 if feat=='2' else X;t=2*y-1;F=np.zeros(len(y));errs=[];loss=[];max_e=0.;weight=np.ones(n)/n
  for i,(j,thr,pol) in enumerate(d['stumps_'+feat]):
   h=np.where(a[:,int(j)]>thr,pol,-pol);observed=float(np.sum(weight*(h[tr]!=t[tr])));max_e=max(max_e,abs(observed-d['eps_'+feat][i]));F+=d['alpha_'+feat][i]*h;weight=np.exp(-t[tr]*F[tr]);weight/=weight.sum();errs.append([np.mean(np.sign(F[tr])!=t[tr]),np.mean(np.sign(F[te])!=t[te])]);loss.append(np.exp(-t[tr]*F[tr]).mean())
  eq('adaboost',feat+'allcachedstumptrainerrors',np.asarray(errs)[:,0],d['train_err_'+feat],1e-14);eq('adaboost',feat+'allcachedstumptesterrors',np.asarray(errs)[:,1],d['test_err_'+feat],1e-14);eq('adaboost',feat+'allcachedexponentiallosses',loss,d['exp_loss_'+feat],1e-12);ck('adaboost',feat+'weightederrorsequalcached',max_e<1e-12,max_error=max_e);eq('adaboost',feat+'alphaformula',d['alpha_'+feat],.5*np.log((1-np.asarray(d['eps_'+feat]))/np.asarray(d['eps_'+feat])),1e-13);ab.append({'features':feat,'rounds':len(errs),'first_zero_train_round':next((i+1 for i,v in enumerate(errs) if v[0]==0),None),'test_first_zero_train':next((v[1] for v in errs if v[0]==0),None),'test_last':errs[-1][1]})
 notes['adaboost']=ab
 d=data['xgb'];G,H=np.asarray(d['check_G']),np.asarray(d['check_H']);lam=d['lam'];gain=.5*(np.sum(G**2/(H+lam))-G.sum()**2/(H.sum()+lam));eq('xgb','secondordergainfromcachedGH',d['check_gain'],gain,1e-12);eq('xgb','directquadraticgain',d['check_gain'],d['check_direct'],1e-12);j=p['vocab'].index(d['check_word']);m=X[tr][:,j]<=d['check_thr'];grad=.5-yt;eq('xgb','actualsplitGH',[grad[m].sum(),grad[~m].sum(),.25*m.sum(),.25*(~m).sum()],[*G,*H],1e-14);notes['xgb']={'gain':d['check_gain'],'direct':d['check_direct'],'true_unregularized_drop':d['check_true'],'T':d['T'],'final_test70':d['test_acc_70'][-1],'final_test2':d['test_acc_2'][-1],'scope':'No storedboostedtrees/OOFlogits: cannot independently replay allXGB predictions without forbiddenrefit. Splitquadraticidentity directly checked.'}
except Exception as e:errors.append({'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
finally:
 after=inventory();safter={n:sha(R/n) for n in source_names};report={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'check_count':len(checks),'failed_checks':[r for r in checks if not r['passed']],'errors':errors,'actual_observations':notes,'payloads_before':before,'payloads_after':after,'payload_hash_size_mtime_unchanged':before==after,'source_before':sources,'source_after':safter,'source_unchanged':sources==safter,'scope':'Independent rawJSON/NPZ arithmetic, matrixidentities and inference from already cachedcoefficients/alphas/trees/stumps only. No actualproducer import/call, model fitting, data generation, optimizer or render. Seededstratifiedsplit reconstruction is deterministic metadata validation, not a numerical experiment. Three calibration/metrics/board items audited by separate readonly child.'};(OUT/'independent-scientific-checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,default=lambda x:x.item() if hasattr(x,'item') else x.tolist())+'\n');print(json.dumps({'checks':len(checks),'failed':len(report['failed_checks']),'errors':errors,'unchanged':before==after},indent=2))

assert not errors and not report['failed_checks'] and before==after and sources==safter
