from pathlib import Path
import hashlib,json,datetime,io,sys,math,platform,os
import numpy as np

B=Path('/workspace/explainer-videos');R=Path(__file__).parent
LEDGER=R/'child-metrics-board-reads.jsonl'
def identity(path,data=None):
 p=Path(path);st=p.stat()
 return {'path':str(p),'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'sha256':hashlib.sha256(p.read_bytes() if data is None else data).hexdigest()}
def pinned(path,kind):
 p=Path(path);before=identity(p);data=p.read_bytes();after=identity(p)
 row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':kind,'before':before,'after':after,'read_bytes_sha256':hashlib.sha256(data).hexdigest(),'unchanged':before==after and before['sha256']==hashlib.sha256(data).hexdigest()}
 with LEDGER.open('a') as f:f.write(json.dumps(row)+'\n')
 assert row['unchanged'],row
 return data
def readjson(p):return json.loads(pinned(p,'raw-json'))
def readnpz(p):
 with np.load(io.BytesIO(pinned(p,'raw-npz')),allow_pickle=False) as d:return {k:d[k].copy() for k in d.files}
def sources():
 names=['videos/ai/ai6/compute.py','videos/ai/ai6/contracts.py','videos/ai/ai6/README.md','videos/ai/ai6/s17_metrics.py','videos/ai/ai6/s18_contest.py','tests/test_ai6_score_contracts.py']
 return {n:pinned(B/n,'source').decode() for n in names}

def inventory():
 for q in [B.parent/'AGENTS.md',B/'AGENTS.md',B/'videos/AGENTS.md',B/'videos/ai/AGENTS.md',B/'videos/ai/ai6/AGENTS.md']:
  if q.exists():print('INSTRUCTIONS',str(q),pinned(q,'instructions').decode())
 out={}
 for item in ['metrics','board','calibration']:
  j=readjson(B/f'.cache/ai6/{item}.json');n=readnpz(B/f'.cache/ai6/{item}.npz')
  arrays={k:{'shape':list(v.shape),'dtype':str(v.dtype),'finite':bool(np.isfinite(v).all()) if v.dtype.kind in 'fiu' else None,'value':v.tolist() if v.size<30 else None,'min':float(v.min()) if v.size and v.dtype.kind in 'fiu' else None,'max':float(v.max()) if v.size and v.dtype.kind in 'fiu' else None} for k,v in n.items()}
  out[item]={'payload':{k:v for k,v in j.items() if k!='_cache'},'cache_metadata':j.get('_cache'),'arrays':arrays}
 (R/'child-metrics-board-inventory.json').write_text(json.dumps(out,indent=2)+'\n')
 for name,x in out.items():print('ITEM',name,json.dumps({'payload':x['payload'],'arrays':x['arrays']},indent=2))
 s=sources()
 for name in ['videos/ai/ai6/compute.py','videos/ai/ai6/contracts.py']:
  lines=s[name].splitlines(); spans=([(405,447),(590,646),(1550,1815)] if name.endswith('compute.py') else [(1,130),(240,295),(370,430)])
  for l,h in spans:print('SOURCE',name,l,h,'\n'+'\n'.join(f'{i+1}: {x}' for i,x in enumerate(lines) if l<=i+1<=h))

def audit():
 src=sources();data={k:readjson(B/f'.cache/ai6/{k}.json') for k in ['metrics','board','calibration','pages']}
 arr={k:readnpz(B/f'.cache/ai6/{k}.npz') for k in ['metrics','board','calibration','pages']}
 y=arr['pages']['y'].astype(int);test=arr['pages']['test'].astype(bool);N=len(y)
 checks=[]
 def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
 def near(x,z,tol=2e-12):return bool(np.allclose(x,z,rtol=tol,atol=tol))
 canonical=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 def folds(seed):
  gen=np.random.Generator(np.random.PCG64(seed));out=np.empty(N,int)
  for label in [0,1]:
   ix=np.flatnonzero(y==label);ix=ix[gen.permutation(len(ix))];out[ix]=np.arange(len(ix))%10
  return out
 check('labels are639 binary pages /288 Austen /351 Dickens',N==639 and np.array_equal(np.bincount(y),[288,351]))
 check('fixed heldout split has191 pages',int(test.sum())==191)
 for item in ['metrics','board','calibration']:
  meta=data[item].get('_cache',{})
  h=identity(B/f'.cache/ai6/{item}.npz')['sha256']
  check(item+' NPZ bytes match metadata arrays SHA',h==meta.get('arrays_sha256'),{'observed':h,'recorded':meta.get('arrays_sha256')})
  check(item+' all raw numerical arrays finite',all(v.dtype.kind in 'biuf' and np.isfinite(v).all() for v in arr[item].values()))
 cal=data['calibration'];ca=arr['calibration'];calrows={};eps=1e-12;cap=-math.log(eps);zthreshold=math.log1p(-eps)-math.log(eps)
 check('nb_z compatibility alias exactly z_nb',np.array_equal(ca['nb_z'],ca['z_nb']))
 for name in ['lr2','lr70','nb','nb_platt']:
  z=ca['z_'+name];p=ca['p_'+name];margin=(1-2*y)*z
  # Independent scalar softplus identity; no imported producer or contracts.
  losses=np.array([max(float(t),0.)+math.log1p(math.exp(-abs(float(t)))) for t in margin])
  stable=float(math.fsum(losses)/N)
  sig=np.array([1/(1+math.exp(-float(t))) if t>=0 else math.exp(float(t))/(1+math.exp(float(t))) for t in z])
  pc=np.clip(p,eps,1-eps);legacy=np.array([-math.log(float(pp)) if yy else -math.log1p(-float(pp)) for pp,yy in zip(pc,y)])
  bins=[]
  for k in range(10):
   ix=(p>=k/10)&((p<(k+1)/10) if k<9 else (p<=1));n=int(ix.sum());bins.append((n,float(p[ix].mean()) if n else 0.,float(y[ix].mean()) if n else 0.))
  counts,conf,frac=map(np.array,zip(*bins));ece=float(sum(n*abs(c-t) for n,c,t in bins)/N);brier=float(np.mean((p-y)**2));acc=float(np.mean((p>.5)==y))
  diag={'rows_beyond_old_probability_floor':int((np.abs(z)>zthreshold).sum()),'wrong_label_losses_above_old_cap':int((losses>cap).sum()),'n_pages':N}
  score=cal[name]['score'];check(name+' probabilities consistent with finite logits',near(p,sig),{'max_absolute_difference':float(np.max(abs(p-sig)))})
  for field,value in [('logloss',stable),('ece',ece),('brier',brier),('count',counts),('conf',conf),('frac',frac)]:check(name+' recomputed '+field,near(cal[name][field],value))
  check(name+' recomputed accuracy',near(cal['acc'][name],acc))
  check(name+' exact old-clipping diagnostic counts',all(diag[k]==score[k] for k in diag) and score['probability_clip'] is None and score['old_probability_floor']==eps,diag)
  calrows[name]={'stable_logloss_nats_per_page':stable,'stored_logloss':cal[name]['logloss'],'absolute_error':abs(stable-cal[name]['logloss']),'stable_max_page_loss':float(losses.max()),'legacy_probability_clipped_logloss':float(legacy.mean()),'stable_minus_legacy':stable-float(legacy.mean()),'old_probability_floor':eps,'old_wrong_label_loss_cap':cap,'old_abs_logit_threshold':zthreshold,**diag,'rows_actually_changed_by_legacy_probability_clip':int(np.count_nonzero(pc!=p)),'exact_probability_zero':int((p==0).sum()),'exact_probability_one':int((p==1).sum()),'target_probability_zero':int((np.where(y==1,p,1-p)==0).sum()),'accuracy':acc,'ece':ece,'brier':brier,'bin_counts':counts.tolist()}
 cfold=ca['fold_ids'];check('calibration declared1950folds reproduce exact stored vector',np.array_equal(cfold,folds(1950)));check('calibration stored fold digest',canonical(cfold.tolist())==cal['evaluation']['fold_sha256'])
 check('NB extreme-odds summary',near(cal['nb_extreme'],np.mean(abs(ca['nb_z'])>math.log(1e6))) and near(cal['nb_median_abs_z'],np.median(abs(ca['nb_z']))))
 def rank_stats(s,labels):
  pos=s[labels==1];neg=s[labels==0];greater=int((pos[:,None]>neg).sum());ties=int((pos[:,None]==neg).sum());pairs=len(pos)*len(neg);pair_auc=(greater+.5*ties)/pairs
  order=np.argsort(s,kind='stable');ranks=np.empty(len(s),float);a=0
  while a<len(s):
   b=a+1
   while b<len(s) and s[order[b]]==s[order[a]]:b+=1
   ranks[order[a:b]]=(a+1+b)/2;a=b
  rank_auc=(float(ranks[labels==1].sum())-len(pos)*(len(pos)+1)/2)/pairs
  values,inv=np.unique(s,return_inverse=True);positive=np.bincount(inv,weights=labels,minlength=len(values))[::-1];negative=np.bincount(inv,weights=1-labels,minlength=len(values))[::-1];tp=positive.cumsum();fp=negative.cumsum();tpr=np.r_[0,tp/len(pos)];fpr=np.r_[0,fp/len(neg)];precision=tp/(tp+fp);recall=tp/len(pos)
  roc_auc=float(np.trapezoid(tpr,fpr));ap=float(np.sum(precision*positive)/len(pos))
  return {'pairwise_auc':pair_auc,'average_rank_auc':rank_auc,'full_threshold_roc_auc':roc_auc,'average_precision':ap,'positive_negative_pairs':pairs,'strict_wins':greater,'cross_label_ties':ties,'pair_credit':greater+.5*ties,'unique_thresholds':len(values)},np.column_stack([fpr,tpr]),np.column_stack([recall,precision])
 met=data['metrics'];ma=arr['metrics'];metricrows={};curve_notes=[]
 for name in ['lr2','lr70','nb']:
  s=ca['nb_z'] if name=='nb' else ca['p_'+name];row,roc,pr=rank_stats(s,y);step=max(1,len(roc)//160);storedroc=ma['roc_'+name];storedpr=ma['pr_'+name]
  check(name+' pairwise / average-rank / full ROC equivalence',near([row['pairwise_auc'],row['average_rank_auc'],row['full_threshold_roc_auc']],[met[name]['auc']]*3))
  check(name+' stored Mann-Whitney / AP match independent calculations',near(met[name]['mw'],row['pairwise_auc']) and near(met[name]['ap'],row['average_precision']))
  check(name+' cached ROC and PR reproduce declared downsampling',near(storedroc,roc[::step]) and near(storedpr,pr[::step]))
  row.update({'stored_auc':met[name]['auc'],'stored_mw':met[name]['mw'],'stored_ap':met[name]['ap'],'stored_plot_stride':step,'stored_roc_endpoint':storedroc[-1].tolist(),'stored_plot_trapezoid_auc':float(np.trapezoid(storedroc[:,1],storedroc[:,0]))})
  if not np.array_equal(storedroc[-1],[1.,1.]):curve_notes.append({'case':name,'observation':'Declared stride downsampling omits the final ROC endpoint. Published AUC uses the full threshold curve, not a trapezoid of this plotting array.','stored_endpoint':storedroc[-1].tolist(),'full_endpoint':roc[-1].tolist()})
  metricrows[name]=row
 # Resample only stored OOF scores/labels; no estimator fit, cache loader or producer.
 gen=np.random.Generator(np.random.PCG64(2006));A=np.flatnonzero(y==0);D=np.flatnonzero(y==1);nd=int(round(.05/.95*len(A)));ra=[];rap=[]
 for _ in range(200):
  ix=np.r_[A,gen.choice(D,nd,replace=False)];row,roc,pr=rank_stats(ca['p_lr2'][ix],y[ix]);ra.append(row['pairwise_auc']);rap.append(row['average_precision'])
 rare={'n_dickens':nd,'n_austen':len(A),'always_austen':len(A)/(len(A)+nd),'auc':float(np.mean(ra)),'auc_lo':float(np.percentile(ra,10)),'auc_hi':float(np.percentile(ra,90)),'ap':float(np.mean(rap)),'ap_lo':float(np.percentile(rap,10)),'ap_hi':float(np.percentile(rap,90))}
 check('rare-class200draw numerical summaries reproduce raw JSON',all(near(v,met['rare'][k]) for k,v in rare.items()),rare);check('rare cached curves reproduce final stored-score draw',near(ma['roc_rare'],roc) and near(ma['pr_rare'],pr))
 sa=np.array(met['split_acc']);cv=np.array(met['cv_acc']);fa=np.array(met['fold_acc']).reshape(20,10);weighted=[]
 check('all100split accuracies correspond to integer191-page outcomes',np.all(np.abs(sa*test.sum()-np.rint(sa*test.sum()))<1e-9))
 for rep in range(20):
  sizes=np.bincount(folds(4000+rep),minlength=10);hits=fa[rep]*sizes;check(f'repeated CV{rep}fold scores correspond to integer outcomes',np.max(abs(hits-np.rint(hits)))<1e-9);weighted.append(float(np.rint(hits).sum()/N))
 check('20 pooled CV accuracies equal page-weighted stored fold outcomes',near(cv,weighted))
 spread={'split_range':sa[[sa.argmin(),sa.argmax()]].tolist(),'split_sd_population':float(sa.std()),'fold_sd_population':float(fa.std()),'repeated_cv_range':[float(cv.min()),float(cv.max())],'repeated_cv_sd_population':float(cv.std()),'all_finite':bool(np.isfinite(np.r_[sa,cv,fa.ravel()]).all())}
 board=data['board'];bf=arr['board']['fold_ids'];expected=folds(2025);sizes=np.bincount(bf,minlength=10);case_rows=[];casekeys=[]
 check('board same10fold assignment independently reproducible2025',np.array_equal(bf,expected));check('board fold hash / n / fold count',canonical(bf.tolist())==board['evaluation']['fold_sha256'] and board['n']==N and board['folds']==10)
 check('calibration and board use distinct explicitly declared folds',not np.array_equal(bf,cfold))
 for row in board['rows']:
  for nf in ['2','70']:
   if nf not in row:continue
   x=row[nf];scores=np.array(x['folds']);key=row['key']+'_'+nf;casekeys.append(key);stats=[float(scores.mean()),float(scores.std(ddof=1)),float(scores.min()),float(scores.max())]
   check(key+' all10scores/heldout finite and bounded',len(scores)==10 and np.isfinite(np.r_[scores,x['held']]).all() and np.all((scores>=0)&(scores<=1)) and 0<=x['held']<=1)
   check(key+' mean/sampleSD/min/max exact summary',near(stats,[x['cv'],x['sd'],x['lo'],x['hi']]))
   check(key+' every fold and heldout score implies integer outcome',np.max(abs(scores*sizes-np.rint(scores*sizes)))<1e-9 and abs(x['held']*test.sum()-round(x['held']*test.sum()))<1e-9)
   case_rows.append({'case':key,'name':row['name'],'cv':stats[0],'sample_sd':stats[1],'min':stats[2],'max':stats[3],'correct_per_fold':np.rint(scores*sizes).astype(int).tolist(),'fold_scores':scores.tolist(),'heldout_accuracy':x['held'],'heldout_correct':round(x['held']*test.sum()),'pooled_cv_accuracy_from_fold_outcomes':float(np.rint(scores*sizes).sum()/N),'display_mean_percent_1dp':f'{100*stats[0]:.1f}'})
 check('board all22 method-feature cases occur once and match declaration',len(casekeys)==22==len(set(casekeys)) and casekeys==board['evaluation']['method_feature_cases'])
 rows70=sorted([x for x in case_rows if x['case'].endswith('_70')],key=lambda x:-x['cv']);rows2=[x for x in case_rows if x['case'].endswith('_2')]
 lr=next(x for x in case_rows if x['case']=='lr_70');boost=next(x for x in case_rows if x['case']=='xgb_70');delta=np.array(lr['fold_scores'])-boost['fold_scores']
 paired={'comparison':'lr_70 minus xgb_70 on same ten folds','mean_accuracy_difference':float(delta.mean()),'sample_sd_of_fold_differences':float(delta.std(ddof=1)),'fold_differences':delta.tolist(),'wins':int((delta>0).sum()),'ties':int((delta==0).sum()),'losses':int((delta<0).sum()),'interpretation':'Descriptive paired comparison only, not a significance test or independent-fold uncertainty claim.'}
 numbers={'roc_auc_lr2_4dp':f"{met['lr2']['auc']:.4f}",'rare_n':[nd,len(A)],'rare_AP_2dp':f"{rare['ap']:.2f}",'balanced_AP_2dp':f"{met['lr2']['ap']:.2f}",'NB_accuracy_percent_1dp':f"{100*cal['acc']['nb']:.1f}",'NB_logloss_3dp':f"{cal['nb']['logloss']:.3f}",'Platt_logloss_3dp':f"{cal['nb_platt']['logloss']:.3f}",'LR70_logloss_3dp':f"{cal['lr70']['logloss']:.3f}",'ECE_LR2_NB_Platt_3dp':[f"{cal[k]['ece']:.3f}" for k in ['lr2','nb','nb_platt']],'extreme_NB_percent_0dp':f"{100*cal['nb_extreme']:.0f}",'split_range_percent_1dp':[f'{100*sa.min():.1f}',f'{100*sa.max():.1f}'],'CV_range_percent_1dp':[f'{100*cv.min():.1f}',f'{100*cv.max():.1f}'],'board_2rate_range_rounded_percent':[f"{100*min(x['cv'] for x in rows2):.0f}",f"{100*max(x['cv'] for x in rows2):.0f}"],'board_top_ties':[x['case'] for x in rows70 if x['cv']==rows70[0]['cv']]}
 readme=src['videos/ai/ai6/README.md']
 check('README actual score values/summary ranges match rounded payload',all(z in readme for z in ['0.9095','15 pages against 288','0.93 to 0.57','95.6%','0.478 to 0.088','0.034','77.5–88.5%','82.9–83.7%','76–83%','99.5%','99.4%','99.2%','99.1%','98.4%','98.3%','95.8%','93.0%']),numbers)
 check('scene score displays pull actual payload metrics and label uncapped nats',all(s in src['videos/ai/ai6/s17_metrics.py'] for s in ["m[\"lr2\"][\"auc\"]","c[k][\"logloss\"]",'stable log loss from logits, no probability cap','half for ties']))
 check('contest source calls ten folds / mean and SD, table uses payload CV/SD',all(s in src['videos/ai/ai6/s18_contest.py'] for s in ['same ten folds','one standard deviation over folds','r[key]["cv"], r[key]["sd"]']))
 report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'READONLY actual-default metrics,board,calibration scientific audit; pages raw labels/test are a necessary dependency. Independent stdlib/NumPy arithmetic only; no project imports, cache.load, estimator fit/train, producer, download or render.',
  'checks':checks,'passed_checks':sum(x['pass'] for x in checks),'failed_checks':[x for x in checks if not x['pass']],
  'calibration':{'n_pages':N,'rows':calrows,'fold_counts':np.bincount(cfold,minlength=10).tolist(),'fold_class_counts':[[int(np.sum((cfold==k)&(y==label))) for label in [0,1]] for k in range(10)],'metadata':cal['evaluation'],'NB_extreme_fraction':cal['nb_extreme'],'NB_median_abs_logit':cal['nb_median_abs_z']},
  'metrics':{'rows':metricrows,'rare_resampling':rare,'accuracy_spread':spread,'plot_array_observations':curve_notes},
  'board':{'method_feature_cases':len(case_rows),'rows':case_rows,'fold_counts':sizes.tolist(),'fold_class_counts':[[int(np.sum((bf==k)&(y==label))) for label in [0,1]] for k in range(10)],'same_pairing_vector_for_all_declared_cases':True,'metadata':board['evaluation'],'ranking_70':[{'case':x['case'],'cv':x['cv'],'display_percent':x['display_mean_percent_1dp']} for x in rows70],'paired_lr_vs_boost':paired},
  'README_scene_numeric_comparison':numbers,
  'source_wording_observation':{'path':'videos/ai/ai6/s18_contest.py','line':71,'text':"two numbers simply don't hold more",'assessment':'Observed maxima across these fixed named procedures do not establish an information-theoretic/Bayes ceiling for two features. Suggested qualification: these tested procedures reach this range on these folds. Numeric range itself matches actual payload.'},
  'gaps':['Stored board summaries and shared fold IDs do not retain per-page predictions or per-case fit records; this audit verifies pairing declaration, integer outcomes, finite scores and exact summaries, but does not refit models or independently re-prove every board accuracy.','Calibration OOF/nested-Platt fitting scope is consistent with inspected source and seeded fold IDs; stored arrays do not retain all fold training fits. No empirical refit/leakage proof is claimed.','Rare-class200draw summaries are reproduced by resampling stored OOF predictions only. Split/CV variability fits were not rerun; their stored outcomes and pooled weighted arithmetic were independently checked.','AUC values use full threshold curves. Some cached curves are subsampled plot arrays and should not be reintegrated as exact metrics.','Fixed full-corpus vocabulary is explicitly transductive; results concern new pages within the same five novels, not new novels or general ML leaderboards.'],
  'runtime':{'python':platform.python_version(),'numpy':np.__version__,'thread_env':{k:os.environ.get(k) for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']}},
  'read_ledger':str(LEDGER),'source_pins':[{**identity(B/n)} for n in src]}
 report['outcome']='PASS actual-default numerical checks' if not report['failed_checks'] else 'NUMERICAL CHECK FAILURE'
 # Close the exact read cohort: every instrumented raw/source read stays unchanged.
 ledger=[json.loads(line) for line in LEDGER.read_text().splitlines()];latest={x['before']['path']:x['before'] for x in ledger}
 close=[]
 for q,first in latest.items():
  last=identity(q);assert first==last,(q,first,last);close.append({'before':first,'after':last,'unchanged':True})
 report['file_closure']=close;report['instrumented_reads']=len(ledger);report['all_read_files_unchanged_before_after_and_close']=True
 (R/'child-metrics-board-report.json').write_text(json.dumps(report,indent=2)+'\n')
 lines=['# Part6 metrics, board and calibration actual-default audit','',report['outcome']+f" ({report['passed_checks']}/{len(checks)} checks).",'',
  'Raw JSON/NPZ data were read directly; no project cache loader/producer was imported, no model was fitted or trained, and no render/download/source edit occurred. Necessary raw pages labels/test membership supplied the639-page target cohort. Every instrumented read has SHA256/size/mtime before and after plus an unchanged closing identity.','',
  '| Predictor | Stable OOF log loss | Accuracy | Beyond old floor | Wrong-label losses above old cap |','|---|---:|---:|---:|---:|']
 for name,x in calrows.items():lines.append(f"| {name} | {x['stable_logloss_nats_per_page']:.12f} | {100*x['accuracy']:.4f}% | {x['rows_beyond_old_probability_floor']} | {x['wrong_label_losses_above_old_cap']} |")
 lines += ['', 'Log loss, Brier score, reliability counts/means and ECE reproduce from stored logits/probabilities and labels. The actual NB payload has494 rows beyond the old1e-12 probability floor, but zero wrong-label losses exceed the old27.631-nat cap: an extreme-logit clipping counterexample is not an observed default cap failure. Stable-logit scores preserve finite extreme predictions without a cap.', '',
  'AUC independently agrees across strict pair wins + half ties, average ranks and full threshold-ROC integration. LR2 AUC0.909460074391 rounds0.9095. All200 rare-class score resamples reproduce the stored mean/10th/90th summaries and final curves. Repeated-CV pooled accuracy agrees with integer fold outcomes, while board summaries correctly use unweighted fold means and sample SD.', '',
  'All22 board method-feature cases have finite bounded ten-fold scores, exact mean/sample-SD/min/max summaries and integer fold/heldout outcomes on the declared cohort. The shared2025 fold vector reproduces exactly; calibration independently uses its declared1950 vector. Logistic and Gaussian-kernel SVM tie at99.5337% mean CV. The paired logistic-minus-boosting fold differences are descriptive, not a significance claim.', '',
  'README and scenes reproduce the actual reported rounded values. One scientific wording caveat: contest line71 says “two numbers simply don’t hold more.” The tested procedure range76–83% does not establish a fundamental information ceiling; qualify it as the tested procedures on these folds. No source edit was made.', '',
  'Plot-array caveat: downsampling can omit the terminalROC point; full-score AUC is the authoritative metric. Details and actual endpoints/areas are recorded in JSON. Per-page board predictions and all fold fit records are absent, so raw-data verification cannot independently re-prove training provenance or refit accuracy. The benchmark explicitly uses a full-corpus transductive lexicon and same-five-novel page evaluation.', '',
  'Full checks, actual per-case results, source pins, paired differences, rounding comparisons, clipping diagnostics, gaps and the exact read ledger are in child-metrics-board-report.json and child-metrics-board-reads.jsonl.','']
 (R/'child-metrics-board-report.md').write_text('\n'.join(lines))
 print(json.dumps({'outcome':report['outcome'],'checks':len(checks),'passed':report['passed_checks'],'failed':report['failed_checks'],'numbers':numbers,'plot_notes':curve_notes,'logloss':calrows,'paired':paired,'read_files':len(close),'report_json_sha256':identity(R/'child-metrics-board-report.json')['sha256'],'report_md_sha256':identity(R/'child-metrics-board-report.md')['sha256']},indent=2))

if __name__=='__main__':
 if '--inventory' in sys.argv:inventory()
 else:audit()
