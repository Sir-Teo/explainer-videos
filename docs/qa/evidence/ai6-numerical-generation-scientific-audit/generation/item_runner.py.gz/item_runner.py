"""One frozen Part6 registered numerical CLI item, with explicit observation guards."""
import contextlib,io,json,os,runpy,sys,traceback
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent));import driver

def main():
 name,where=sys.argv[1:];where=Path(where);assert name in driver.ORDER;driver.activated();sys.path.insert(0,str(driver.ROOT));os.chdir(driver.ROOT)
 r={'name':name,'status':'running','child_pid':os.getpid(),'started_utc':driver.utc(),'requested_cli':['-m','videos.ai.ai6.compute',name],'thread_environment':{k:os.environ.get(k) for k in driver.THREAD_ENV},'scope':'Exact registered CLI with deny-other-item/upstream-production guards; no scenes/audio/models.'};driver.atomic_json(where,r);blocked=[];events=[]
 try:
  from videos.ai.ai1 import compute as c1
  def forbidden(*a,**kw):blocked.append('upstream-production-or-download');raise RuntimeError('Unexpected upstream generation/download; raw inputs must already be frozen')
  c1._download=forbidden;c1.compute_corpus=forbidden;c1._save=forbidden
  from videos.ai.ai6 import cache_contract
  original=cache_contract.SchemaCache._produce
  def observed(self,item,producer,**kw):
   if item!=name:blocked.append(item);raise RuntimeError('Unexpected producer dependency: '+item)
   events.append(item);return original(self,item,producer,**kw)
  cache_contract.SchemaCache._produce=observed
  class Tee(io.TextIOBase):
   def __init__(self,s):self.stream=s;self.text=''
   def write(self,x):self.text+=x;return self.stream.write(x)
   def flush(self):self.stream.flush()
  tee=Tee(sys.stdout);sys.argv=['videos.ai.ai6.compute',name]
  with contextlib.redirect_stdout(tee):ns=runpy.run_module('videos.ai.ai6.compute',run_name='__main__')
  assert not blocked;assert ns['CACHE'].current(name),ns['CACHE'].status(name);assert not any(n in sys.modules for n in ['torch','transformers'])
  action='cached-validated-by-existing-cli' if f'  cached  {name}' in tee.text else 'computed-by-existing-cli'
  assert events==([] if action.startswith('cached') else [name]),events
  if events:assert f'  done    {name} ' in tee.text
  r.update(status='passed',cache_current=True,outputs=driver.output_identities(name),cli_action=action,producer_events=events,unexpected_upstream_or_producer_calls=blocked,ended_utc=driver.utc());driver.atomic_json(where,r);return 0
 except BaseException as e:
  r.update(status='failed',error={'type':type(e).__name__,'message':str(e)},producer_events=events,unexpected_upstream_or_producer_calls=blocked,ended_utc=driver.utc());driver.atomic_json(where,r);traceback.print_exc();return e.code if isinstance(e,SystemExit) and isinstance(e.code,int) else 1
if __name__=='__main__':raise SystemExit(main())
