#!/usr/bin/env python3
"""Serial Part6 production driver. Preparation/import uses only Python stdlib.

Root alone runs `freeze`, then `run` after cores/translations/tests are ready.
No scene/caption identities or rendered approval are asserted by this driver.
"""
from __future__ import annotations
import argparse,ast,datetime,fcntl,hashlib,importlib.metadata,json,os,platform,signal,subprocess,sys,time
from pathlib import Path

ROOT=Path('/workspace/explainer-videos')
OUT=Path(__file__).resolve().parent
ACTIVATE=Path('/workspace/runtime/activate.sh')
PYTHON=ROOT/'.venv/bin/python'
ORDER=('pages', 'zipf', 'gaussmarkov', 'lsq', 'ridge', 'lasso', 'logistic', 'irls', 'calibration', 'nbvslr', 'lda', 'knn', 'coverhart', 'curse', 'kernel', 'svm', 'trees', 'bagging', 'adaboost', 'xgb', 'metrics', 'board')
CORE=('videos/ai/ai6/compute.py', 'videos/ai/ai6/contracts.py', 'videos/ai/ai6/cache_contract.py', 'videos/ai/ai1/compute.py', 'explainer/ai/cache.py', 'explainer/cache_lock.py', 'explainer/tts.py', 'explainer/paths.py', 'explainer/__init__.py')
RAW=('.cache/ai1/books/1342.txt', '.cache/ai1/books/158.txt', '.cache/ai1/books/98.txt', '.cache/ai1/books/1400.txt', '.cache/ai1/books/46.txt', '.cache/ai1/train.txt')
THREAD_ENV={k:'1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS','OMP_THREAD_LIMIT')}
THREAD_ENV.update(TOKENIZERS_PARALLELISM='false',CUDA_VISIBLE_DEVICES='',PYTHONUNBUFFERED='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
MIN_DISK=512*1024**2
MIN_RAM=2*1024**3
class DriverError(RuntimeError):pass
class Drift(DriverError):pass
class ChildFailure(DriverError):
 def __init__(self,item,code,log):
  super().__init__(f"{item} child exit {code}; log={log}");self.code=code

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def atomic_json(path,value):
 path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
 temp=path.with_name(path.name+f'.tmp-{os.getpid()}')
 with temp.open('w') as f:
  json.dump(value,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 os.replace(temp,path)
def identity(path,required=True):
 path=Path(path)
 if not path.is_file():
  if required:raise DriverError(f'Missing required regular file: {path}')
  return None
 before=path.stat();h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
 after=path.stat()
 if (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns):raise Drift(f'File changed during byte hashing: {path}')
 return {'bytes':after.st_size,'sha256':h.hexdigest()}
def literal_assignment(tree,name):
 for node in tree.body:
  if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets):return ast.literal_eval(node.value)
 raise DriverError(f'Static assignment not found: {name}')
def dependency_plan(root=ROOT):
 tree=ast.parse((root/'videos/ai/ai6/compute.py').read_text());funcs={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
 value=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(getattr(t,'id',None)=='ITEMS' for t in n.targets) and isinstance(n.value,ast.Dict))
 items={ast.literal_eval(k):v.id for k,v in zip(value.keys,value.values)}
 contracts=ast.parse((root/'videos/ai/ai6/contracts.py').read_text());required=literal_assignment(contracts,'REQUIRED')
 if len(items)!=22 or tuple(items)!=ORDER or set(required)!=set(items):raise DriverError('Exact22producer inventory mismatch')
 def deps(fn,seen=None):
  seen=set() if seen is None else seen
  if fn in seen:return set()
  seen.add(fn);out=set()
  for n in ast.walk(funcs[fn]):
   if not isinstance(n,ast.Call):continue
   if isinstance(n.func,ast.Name) and n.func.id=='load':
    if not n.args or not isinstance(n.args[0],ast.Constant) or not isinstance(n.args[0].value,str):raise DriverError('Nonliteral local dependency')
    out.add(n.args[0].value)
   elif isinstance(n.func,ast.Name) and n.func.id in funcs and n.func.id not in ('load','ai1'):out.update(deps(n.func.id,seen))
  return out
 observed={k:sorted(deps(v)) for k,v in items.items()};declared={k:([] if k in {'pages','zipf','gaussmarkov','coverhart'} else ['pages']) for k in items};declared['metrics']=['calibration','pages']
 for n in ORDER:
  if observed[n]!=declared[n]:raise DriverError(f'Dependency mismatch {n}: {observed[n]} vs {declared[n]}')
  if any(ORDER.index(d)>=ORDER.index(n) for d in observed[n]):raise DriverError('Producer order is not topological')
 return {'items':[dict(index=i+1,name=n,producer=items[n],local_dependencies=observed[n],cli=['-m','videos.ai.ai6.compute',n]) for i,n in enumerate(ORDER)],'scope':'AST-only local dependency check, registered CLI wrappers preserved, raw5books/train separately frozen.'}

def external_judge_paths(root=ROOT):return []

def runtime_identity():
 return {"python":sys.version,"executable":str(Path(sys.executable).resolve()),"packages":{p:importlib.metadata.version(p) for p in ("numpy","scipy","torch","transformers","tokenizers","Pillow")}}

def freeze_inventory(root=ROOT):
 files=[root/p for p in CORE+RAW]+external_judge_paths(root)+[ACTIVATE,PYTHON,Path(__file__).resolve(),OUT/'item_runner.py']
 return {str(p):identity(p) for p in files}
def verify_inventory(expected):
 for p,value in expected.items():
  got=identity(p,required=value is not None)
  if got!=value:raise Drift(f'Byte identity drift: {p}; expected={value}, actual={got}')
def parse_memory_stat(raw):
 """Malformed/missing inactive-file evidence receives NO reclaimable credit."""
 values={}
 try:
  for line in raw.splitlines():
   fields=line.split()
   if len(fields)!=2 or fields[0] in values or not fields[1].isdigit():raise ValueError('Expected unique memory.stat keys and nonnegative integer bytes/counters')
   values[fields[0]]=int(fields[1])
  return values,None
 except (AttributeError,ValueError) as exc:return {},f'{type(exc).__name__}: {exc}'

def cgroup_available(limit,current,raw_stat,host_available,inactive_key='inactive_file'):
 values,error=parse_memory_stat(raw_stat)
 if error is None and inactive_key not in values:error=f'missing {inactive_key}: no reclaimable-file credit'
 inactive=values.get(inactive_key,0) if error is None else 0
 headroom=limit-current
 bounded=max(0,min(limit,headroom+inactive))
 return {'limit_bytes':limit,'current_bytes':current,'memory_stat_raw':raw_stat,'memory_stat':values,'memory_stat_parse_error':error,'reclaimable_credit_key':inactive_key,'inactive_file_credit_bytes':inactive,'raw_headroom_bytes':headroom,'cgroup_available_estimate_bytes':bounded,'host_MemAvailable_bytes':host_available,'available_bytes':min(host_available,bounded),'derivation':'min(host_MemAvailable, clamp(limit - current + inactive_file, 0, limit)); only inactive_file credited; active_file and slab_reclaimable are not credited'}

def resources(root=ROOT,*,cgroup_directory=Path('/sys/fs/cgroup'),memory_info_path=Path('/proc/meminfo')):
 disk=os.statvfs(root);free_disk=disk.f_bavail*disk.f_frsize
 mem={}
 for line in Path(memory_info_path).read_text().splitlines():
  key,_,val=line.partition(':');mem[key]=int(val.strip().split()[0])*1024
 available=mem['MemAvailable'];directory=Path(cgroup_directory);observation={'version':None,'status':'no-readable-cgroup-memory-controller','available_bytes':available}
 maximum,current=directory/'memory.max',directory/'memory.current'
 if maximum.is_file() or current.is_file():
  # A partially unreadable/malformed limit must fail rather than use host RAM.
  text=maximum.read_text().strip();current_text=current.read_text().strip()
  if not current_text.isdigit():raise DriverError(f'Malformed cgroup memory.current: {current_text!r}')
  stat_path=directory/'memory.stat';raw=stat_path.read_text() if stat_path.is_file() else ''
  if text=='max':observation={'version':2,'status':'unlimited','limit_raw':text,'current_bytes':int(current_text),'memory_stat_raw':raw,'available_bytes':available,'derivation':'No finite cgroup limit; use host MemAvailable'}
  else:
   if not text.isdigit():raise DriverError(f'Malformed cgroup memory.max: {text!r}')
   observation={'version':2,'status':'finite-limit',**cgroup_available(int(text),int(current_text),raw,available)};available=observation['available_bytes']
 else:
  maximum,current=directory/'memory/memory.limit_in_bytes',directory/'memory/memory.usage_in_bytes'
  if maximum.is_file() or current.is_file():
   text=maximum.read_text().strip();current_text=current.read_text().strip()
   if not text.isdigit() or not current_text.isdigit():raise DriverError('Malformed cgroup v1 memory limit/current')
   stat_path=directory/'memory/memory.stat';raw=stat_path.read_text() if stat_path.is_file() else '';values,error=parse_memory_stat(raw)
   key='total_inactive_file' if 'total_inactive_file' in values else 'inactive_file'
   observation={'version':1,'status':'finite-limit',**cgroup_available(int(text),int(current_text),raw,available,key)};available=observation['available_bytes']
 return {'utc':utc(),'disk_available_bytes':free_disk,'ram_available_bytes':available,'host_MemAvailable_bytes':mem['MemAvailable'],'cgroup_memory':observation,'minimum_disk_bytes':MIN_DISK,'minimum_ram_bytes':MIN_RAM}

def guard_resources(root=ROOT):
 r=resources(root)
 if r['disk_available_bytes']<MIN_DISK:raise DriverError(f'Disk guard: {r["disk_available_bytes"]} < {MIN_DISK}bytes')
 if r['ram_available_bytes']<MIN_RAM:raise DriverError(f'RAM guard: {r["ram_available_bytes"]} < {MIN_RAM}bytes')
 return r

def reap_nonblocking(process):
 """The ONLY child reaper; never call Popen.poll/wait before rusage capture."""
 pid,status,usage=os.wait4(process.pid,os.WNOHANG)
 if pid==0:return None
 code=os.waitstatus_to_exitcode(status);process.returncode=code
 return {'returncode':code,'raw_wait_status':status,'peak_rss':usage.ru_maxrss,'peak_rss_unit':'KiB','platform':platform.system(),'scope':'Linux wait4 rusage for the direct per-item Python child, including its threads; not the parent, not a sum of concurrent processes.','user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime}

def monitor_child(command,log_path,env,heartbeat,on_start=None,interval=30.0,check=None):
 start=time.monotonic();last=start;stopping=None;sent_at=None
 with Path(log_path).open('wb') as log:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:
   if on_start:on_start(process.pid)
   while True:
    result=reap_nonblocking(process)
    if result is not None:
     result.update(child_pid=process.pid,wall_seconds=time.monotonic()-start,stopped_for=stopping)
     return result
    now=time.monotonic()
    if stopping is None and now-last>=interval:
     try:
      heartbeat(process.pid,now-start)
      if check:check()
     except Exception as exc:
      stopping=f'{type(exc).__name__}: {exc}';sent_at=time.monotonic()
      try:os.killpg(process.pid,signal.SIGTERM)
      except ProcessLookupError:pass
     last=time.monotonic()
    if stopping and sent_at is not None and now-sent_at>10:
     try:os.killpg(process.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     sent_at=None
    time.sleep(.25)
  except BaseException as exc:
   try:os.killpg(process.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   deadline=time.monotonic()+10
   while True:
    r=reap_nonblocking(process)
    if r is not None:break
    if time.monotonic()>deadline:
     try:os.killpg(process.pid,signal.SIGKILL)
     except ProcessLookupError:pass
    time.sleep(.1)
   r.update(child_pid=process.pid,wall_seconds=time.monotonic()-start,stopped_for=f'{type(exc).__name__}: {exc}',monitor_exception=type(exc).__name__)
   return r

def output_identities(name,root=ROOT):
 p=root/'.cache/ai6'/f'{name}.json'
 return {str(p):identity(p),str(p.with_suffix('.npz')):identity(p.with_suffix('.npz'),required=False)}

def activated():
 if Path(sys.executable).resolve()!=PYTHON.resolve():raise DriverError(f'Use activated Python {PYTHON}; observed {sys.executable}')
 if platform.system()!='Linux' or not hasattr(os,'wait4'):raise DriverError('Driver requires Linux wait4 with KiB ru_maxrss')
 if os.environ.get('HF_HOME')!='/workspace/runtime/huggingface':raise DriverError('Source /workspace/runtime/activate.sh first (HF_HOME mismatch)')

def run(freeze_path,readiness_note):
 activated();freeze_path=Path(freeze_path);frozen=json.loads(freeze_path.read_text())
 if not readiness_note.strip():raise DriverError('Root readiness note must identify finalized source/translation/test state')
 prior_path=OUT/'progress.json'
 if prior_path.exists():
  prior=json.loads(prior_path.read_text())
  if prior.get('status')=='running':raise DriverError(f'Prior operation unresolved: inspect driver PID {prior.get("driver_pid")} and active record {prior.get("active")}; root must reconcile/archive its progress before another run')
 plan=dependency_plan()
 if frozen['dependency_plan']!=plan:raise Drift('Dependency plan changed since source freeze')
 verify_inventory(frozen['files']);guard_resources()
 if frozen['runtime']!=runtime_identity():raise Drift('Installed numerical/runtime versions changed since freeze')
 lock=(OUT/'driver.lock').open('a')
 try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 except BlockingIOError:raise DriverError('Another Part6 driver holds the exclusive producer lock')
 run_dir=OUT/('run-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ'));run_dir.mkdir()
 progress={'schema':1,'status':'running','started_utc':utc(),'driver_pid':os.getpid(),'run_dir':str(run_dir),'freeze_path':str(freeze_path),'freeze_identity':identity(freeze_path),'readiness_note':readiness_note,'dependency_plan':plan,'items':[],'active':None,'scope':'Numerical generation/cache-current validation only. No scene/caption/render/audio/visual approval.'}
 completed={};expected=dict(frozen['files']);started=time.monotonic()
 def publish():
  progress['updated_utc']=utc();progress['wall_seconds']=time.monotonic()-started;atomic_json(run_dir/'progress.json',progress);atomic_json(OUT/'progress.json',progress)
  active=progress['active'];print(json.dumps({'utc':progress['updated_utc'],'status':progress['status'],'completed':len(completed),'active':active['name'] if active else None,'child_pid':active.get('child_pid') if active else None,'active_wall_seconds':active.get('wall_seconds') if active else None,'log':active.get('log_path') if active else None}),flush=True)
 def check():
  if (progress.get('active') or {}).get('wall_seconds',0)>3600:raise DriverError('One-hour per-item bound reached; preserve checkpoint and reconcile before resume')
  verify_inventory(expected)
  if frozen['runtime']!=runtime_identity():raise Drift('Installed numerical/runtime versions changed during run')
 def heartbeat(pid,wall):
  progress['active'].update(child_pid=pid,wall_seconds=wall,heartbeat_utc=utc(),resources=resources());publish()
 def stop_handler(signum,frame):raise KeyboardInterrupt(f'driver signal {signum}')
 previous={s:signal.signal(s,stop_handler) for s in (signal.SIGINT,signal.SIGTERM)}
 try:
  publish()
  for item in ORDER:
   check();r=guard_resources();index=ORDER.index(item)+1
   if any(d not in completed for d in plan['items'][index-1]['local_dependencies']):raise DriverError(f'Uncompleted dependency for {item}')
   log=run_dir/f'{index:02}-{item}.log';receipt=run_dir/f'{index:02}-{item}-child.json'
   record={'index':index,'name':item,'status':'running','started_utc':utc(),'log_path':str(log),'child_receipt_path':str(receipt),'resources_before':r,'command':[str(PYTHON),'-u',str(OUT/'item_runner.py'),item,str(receipt)],'thread_environment':THREAD_ENV}
   progress['active']=record;progress['items'].append(record);publish()
   env=dict(os.environ);env.update(THREAD_ENV)
   def child_started(pid):record['child_pid']=pid;publish()
   measured=monitor_child(record['command'],log,env,heartbeat,child_started,check=check)
   record.update(measured,ended_utc=utc());check()
   if measured.get('monitor_exception')=='KeyboardInterrupt':raise KeyboardInterrupt(measured['stopped_for'])
   if measured['stopped_for']:raise Drift(measured['stopped_for'])
   if measured['returncode']!=0:
    record['status']='failed';raise ChildFailure(item,measured['returncode'],log)
   child=json.loads(receipt.read_text())
   if child.get('status')!='passed' or child.get('cache_current') is not True or child.get('child_pid')!=measured['child_pid']:raise DriverError(f'{item}: completed CLI lacks matching strict cache-current validation receipt')
   outputs=output_identities(item)
   if child['outputs']!=outputs:raise Drift(f'{item} output changed between child validation and parent hash')
   completed[item]=outputs;expected.update(outputs);record.update(status='passed',outputs=outputs,cache_current=True,cli_action=child['cli_action'])
   progress['active']=None
   publish()
  check();progress['status']='passed';progress['completed_count']=22;progress['ended_utc']=utc();publish();return 0
 except BaseException as exc:
  if progress['active'] is not None and progress['active']['status']=='running':progress['active']['status']='aborted' if isinstance(exc,KeyboardInterrupt) else 'failed'
  progress.update(status='stopped',error={'type':type(exc).__name__,'message':str(exc)},ended_utc=utc(),completed_count=len(completed));publish()
  return 130 if isinstance(exc,KeyboardInterrupt) else ((exc.code if exc.code>0 else 128-exc.code) if isinstance(exc,ChildFailure) else (73 if isinstance(exc,Drift) else 74))
 finally:
  for s,handler in previous.items():signal.signal(s,handler)
  fcntl.flock(lock,fcntl.LOCK_UN);lock.close()

def main():
 ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='action',required=True)
 freeze=sub.add_parser('freeze',help='Pure byte/AST observations after root source freeze; never imports producer')
 freeze.add_argument('--output',type=Path,required=True)
 execute=sub.add_parser('run',help='ROOT ONLY: execute22 serial producer CLI jobs after finalized source/translations/tests')
 execute.add_argument('--freeze',type=Path,required=True);execute.add_argument('--readiness-note',required=True)
 args=ap.parse_args()
 try:
  if args.action=='freeze':
   activated();plan=dependency_plan();inventory=freeze_inventory();guard_resources()
   receipt={'schema':1,'created_utc':utc(),'status':'prepared-not-executed','files':inventory,'runtime':runtime_identity(),'dependency_plan':plan,'resources_observed':resources(),'scope':'Pure byte/AST freeze for numerical producers only; no scene/caption freezes, historical import claim, numerical execution or visualization approval.'}
   if args.output.exists():raise DriverError(f'Refusing to overwrite prior freeze: {args.output}')
   atomic_json(args.output,receipt);print(json.dumps({'freeze':str(args.output),'identity':identity(args.output)}));return 0
  return run(args.freeze,args.readiness_note)
 except (DriverError,OSError,ValueError,KeyError) as exc:
  print(f'{type(exc).__name__}: {exc}',file=sys.stderr);return 72
if __name__=='__main__':raise SystemExit(main())
